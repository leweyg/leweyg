/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include <windows.h>		// Header File For Windows
#include <math.h>
#include <assert.h>
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library

//#define Assert	assert
void CalledOnAssert()
{
//	assert(false);
	int* ptr=0;
	*ptr = 5;
}
#define Assert(stmt)	{if (!(stmt)) {CalledOnAssert();}}

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application
int ScrWidth=640, ScrHeight=480;

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

GLfloat	rtri;				// Angle For The Triangle ( NEW )
GLfloat	rquad;				// Angle For The Quad ( NEW )

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	ScrWidth = width;
	ScrHeight = height;

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

float lc_glv_LightAmbient[]= { 0.15f, 0.15f, 0.15f, 1.0f }; 				// Ambient Light Values ( NEW )
float lc_glv_LightDiffuse[]= { 0.7f, 0.7f, 0.7f, 1.0f };				 // Diffuse Light Values ( NEW )
float lc_glv_LightPosition[]= { 0.0f, 0.0f, 20.0f, 1.0f };				 // Light Position ( NEW )

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.2f, 0.2f, 0.2f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations

	glLightfv(GL_LIGHT1, GL_AMBIENT, lc_glv_LightAmbient);		// Setup The Ambient Light
	glLightfv(GL_LIGHT1, GL_DIFFUSE, lc_glv_LightDiffuse);		// Setup The Diffuse Light
	glLightfv(GL_LIGHT1, GL_POSITION, lc_glv_LightPosition);	// Position The Light
	glEnable(GL_LIGHT1);							// Enable Light One
	glEnable(GL_LIGHTING);
	glEnable(GL_COLOR_MATERIAL );

	int mytrue = 1;
	//glLightModeliv( GL_LIGHT_MODEL_TWO_SIDE, &mytrue );

	return TRUE;										// Initialization Went OK
}

#include "pnt.cpp"

GLUquadricObj* g_quadric = 0;

float Camera_Angle = 0;
float Camera_Pitch = 0;
fpnt Camera_Pos;
float Camera_Dist = 6;

void SetupCamera()
{
	Camera_Pos.x = sin( Camera_Angle ) * cos( Camera_Pitch );
	Camera_Pos.y = sin( Camera_Pitch );
	Camera_Pos.z = cos( Camera_Angle ) * cos( Camera_Pitch );
	Camera_Pos *= Camera_Dist;

	lc_glv_LightPosition[0] = Camera_Pos.x;
	lc_glv_LightPosition[1] = Camera_Pos.y;
	lc_glv_LightPosition[2] = Camera_Pos.z;
	glLightfv(GL_LIGHT1, GL_POSITION, lc_glv_LightPosition);	// Position The Light

    float ratio;
 
   if ( ScrHeight == 0 )
	ScrHeight = 1;

    ratio = ( float )ScrWidth / ( float )ScrHeight;

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

    gluPerspective( 45.0f, ratio, 0.1f, 100.0f );

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	gluLookAt(Camera_Pos.x, Camera_Pos.y, Camera_Pos.z,
			  0, 0, 0,
			  0, 1, 0);
}

enum DrawStyle
{
	DrawStyle_Proper = 0,
	DrawStyle_Additive = 1,
};

int NumDrawStyles = 2;
int GDrawStyle = DrawStyle_Proper;

#include "IOFF.h"

#include "balls.ioff"

typedef unsigned short ushort;

IOFFModel SortedModel;
ushort *IndexBuff1=0, *IndexBuff2=0;
float *VertDists;
int *PolyIndex;
typedef IOFF_VertType_C4F_N3F_V3F VertType;
int frame = 0;
bool IsDrawSolid=true, IsDrawTrans=true;
bool IsNoSorting=false;

void CheckIndices()
{
	int i;
	for (i=0; i<SortedModel.NumVPP * SortedModel.NumPolygons; i++)
	{
		int vi = SortedModel.Indices[i];
		Assert( (vi >= 0) && (vi < SortedModel.NumVertices) );
	}
}

void DrawSortedObject()
{
	int numinds = Balls.NumVPP * Balls.NumPolygons;
	if (IndexBuff1==0)
	{
		//generate the additional sorting and rendering buffers

		SortedModel = Balls; //same everything as model, except index buffer

		IndexBuff1 = new ushort [numinds];
		IndexBuff2 = new ushort [numinds];
		SortedModel.Indices = IndexBuff1;

		for (int j=0; j<numinds; j++)
		{
			SortedModel.Indices[j] = Balls.Indices[j];
		}

		VertDists = new float [SortedModel.NumPolygons];
		PolyIndex = new int [SortedModel.NumPolygons];
	}
	Assert( SortedModel.VertexSize == sizeof(VertType) );

	VertType* verts = (VertType*)SortedModel.Vertices;
	fpnt* cp;
	int vpp = SortedModel.NumVPP;
	int i;

	Assert( vpp == 3 );

	//get all the vertex distances
	for (i=0; i<SortedModel.NumPolygons; i++)
	{
		fpnt cur(0, 0, 0);
		for (int p=0; p<vpp; p++)
		{
			int vi = SortedModel.Indices[i*vpp+p];
			Assert( (vi >= 0) && (vi < SortedModel.NumVertices) );
			cp = (fpnt*)&(verts[vi].vert_x);
			cur += *cp;
		}
		cur *= (1.0f/((float)vpp));
		VertDists[i] = (cur - Camera_Pos).SelfDot();
	}

	//now sort them in PolyIndex
	PolyIndex[0] = 0;
	for (i=1; i<SortedModel.NumPolygons; i++)
	{
		float cd = VertDists[ i ];
		int k=i-1;
		while ((k >= 0) && (cd > VertDists[PolyIndex[k]]))
		{
			PolyIndex[k+1] = PolyIndex[k];
			k--;
		}
		PolyIndex[k+1] = i;
	}

	//now update the other index cache
	ushort* inds = IndexBuff1;
	if (SortedModel.Indices == inds)
		inds = IndexBuff2;

	for (i=0; i<SortedModel.NumPolygons; i++)
	{
		ushort* to = &inds[i*3];
		ushort* from = &SortedModel.Indices[PolyIndex[i]*3];
		for (int k=0; k<3; k++)
			to[k] = from[k];
	}
	SortedModel.Indices = inds;

	DrawIOFF( &SortedModel );

	frame++;
}

void DrawSolidObjects()
{
	if (!IsDrawSolid)
		return;

	float h = 3;
	float rad = 0.5;
	glColor4f( 1.0f, 0.5f, 0.5f, 0.5);
	glPushMatrix();
	glTranslatef( 0.0f,0.0f, -h/2 );
	gluCylinder( g_quadric, rad, rad, h, 8, 3);
	glPopMatrix();

	glPushMatrix();
	glTranslatef( 0.0f, 0.0f, h/2 );
	gluSphere( g_quadric, rad, 8, 4);
	glPopMatrix();

	glPushMatrix();
	glTranslatef( 0.0f, 0.0f, -h/2 );
	gluSphere( g_quadric, rad, 8, 4);
	glPopMatrix();
}

void DrawTransparentObjects()
{
	if (!IsDrawTrans)
		return;

	if ((GDrawStyle == DrawStyle_Additive) || (IsNoSorting))
		DrawIOFF( &Balls );
	else
		DrawSortedObject();
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	if (!g_quadric)
		g_quadric = gluNewQuadric();


	SetupCamera();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer

	//solid objects
	DrawSolidObjects();

	//setup and rendering transparent objects
	if (GDrawStyle == DrawStyle_Additive)
		glBlendFunc(GL_SRC_ALPHA, GL_ONE);
	if (GDrawStyle == DrawStyle_Proper)
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_BLEND);
	glDepthMask(false);

	//draw transparent objects
	DrawTransparentObjects();

	//return to normal rendering
	glDisable(GL_BLEND);
	glDepthMask(true);

	return TRUE;										// Keep Going
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								100, 100,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

POINT lastmouse;
bool mousedrag = false;

POINT MakePoint(int x, int y)
{
	POINT ans;
	ans.x = x;
	ans.y = y;
	return ans;
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			// LoWord Can Be WA_INACTIVE, WA_ACTIVE, WA_CLICKACTIVE,
			// The High-Order Word Specifies The Minimized State Of The Window Being Activated Or Deactivated.
			// A NonZero Value Indicates The Window Is Minimized.
			if ((LOWORD(wParam) != WA_INACTIVE) && !((BOOL)HIWORD(wParam)))
				active=TRUE;						// Program Is Active
			else
				active=FALSE;						// Program Is No Longer Active

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}
		case WM_LBUTTONDOWN:
		case WM_RBUTTONDOWN:
			{
				mousedrag = true;
				lastmouse = MakePoint( LOWORD(lParam), HIWORD(lParam) );
				return 0;
			}
		case WM_LBUTTONUP:
		case WM_RBUTTONUP:
			{
				mousedrag = false;
				return 0;
			}
		case WM_MOUSEMOVE:
			{
				if (mousedrag)
				{
					POINT cur = MakePoint( LOWORD(lParam), HIWORD(lParam) );
					Camera_Angle -= ((float)( cur.x - lastmouse.x )) / 200.0f;
					Camera_Pitch += ((float)( cur.y - lastmouse.y )) / 200.0f;
					lastmouse = cur;
				}
				return 0;
			}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			switch( wParam )
			{
			case ' ':
				GDrawStyle++;
				GDrawStyle %= NumDrawStyles;
				break;
			case 'T':
				IsDrawTrans = !IsDrawTrans;
				break;
			case 'S':
				IsNoSorting = !IsNoSorting;
				break;
			}
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	// Ask The User Which Screen Mode They Prefer
	//if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen=FALSE;							// Windowed Mode
	}

	// Create Our OpenGL Window
	if (!CreateGLWindow("Blending Example",640,480,16,fullscreen))
	{
		return 0;									// Quit If Window Was Not Created
	}

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawGLScene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				KillGLWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!CreateGLWindow("Blending Example",640,480,16,fullscreen))
				{
					return 0;						// Quit If Window Was Not Created
				}
			}
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
