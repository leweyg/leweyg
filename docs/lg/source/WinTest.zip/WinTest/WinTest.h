#pragma once

#include "resource.h"
#include <commctrl.h>
#include <richedit.h>
