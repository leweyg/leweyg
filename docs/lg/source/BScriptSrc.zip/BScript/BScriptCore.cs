using System;
using System.Collections;

namespace BScript
{
	/// <summary>
	/// A Code Block
	/// </summary>
	public class CB
	{
		public virtual bool IsJustLabel { get {return false;} }
		public virtual string Label { get{ return "";} }

		public virtual void Execute(EvalPoint at, bool isreturning)
		{
			at.Branch.ShortPop();
		}

		public override string ToString() {return Label;}
	};

	public class CB_Label : CB
	{
		private string label;

		public override bool IsJustLabel { get{ return true;} }
		public override string Label { get{ return label;} }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			LocalVar var = at.Locals.GetVar( label );

			if (var!=null)
				at.ArgStack.Push( var );
			else
			{
				if (label[0]=='"')
				{
					at.ArgStack.Push( label.Substring(1, label.Length-2) );
					at.Branch.ShortPop();
					return;
				}

				bool found = true;
				switch(label)
				{
					case "null":
						at.ArgStack.Push( null );
						break;
					case "true":
						at.ArgStack.Push( true );
						break;
					case "false":
						at.ArgStack.Push( false );
						break;
					case "pi":
						at.ArgStack.Push( Math.PI );
						break;
					default:
						found = false;
						break;
				}
				if (found)
				{
					at.Branch.ShortPop();
					return;
				}

				ArrayList funcs = Global.GGlobal.Functions;
				for (int i=0; i<funcs.Count; i++)
				{
					CB_Op_CustomFunc f = (CB_Op_CustomFunc)funcs[i];
					if (f.Name == label)
					{
						at.ArgStack.Push( f );
						at.Branch.ShortPop();
						return;
					}
				}

				double num;
				if (Double.TryParse(label, System.Globalization.NumberStyles.Any, null, out num))
					at.ArgStack.Push( num );
				else
				{
					//TODO: put other label types here
					throw new ArgumentException("Unknown Variable: ", label);
				}
			}

			at.Branch.ShortPop();
		}

		public CB_Label(string name) {label=name;}
	};

	public class CB_Op : CB
	{
		public override bool IsJustLabel { get{ return false; } }
		public virtual CB[] Args { get{ return null; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			Global.TODO();
		}

		public static bool ExecuteInOwnBlock(CB cb, EvalPoint at, bool isreturning)
		{
			if (!isreturning)
			{
				if ((at.WorkStack.Count==0) || (at.WorkStack.Peek()!=cb))
				{
					at.WorkStack.Push( cb );
					at.Branch.BlockPush( cb, at.Locals, false );
					at.Branch.CurPos.WorkStack.Push( cb );
					return false;
				}
			}
			else
			{
				if (at.WorkStack.Peek()==cb)
				{
					at.WorkStack.Pop();
					at.Branch.ShortPop();
					return false;
				}
			}
			return true;
		}

		public static object[] WaitForArgs(CB_Op op, EvalPoint at, bool isreturning)
		{
			if (!isreturning)
				at.WorkStack.Push( 0 );
			CB[] oargs = op.Args;

			int ca = (int)at.WorkStack.Pop();
			if (ca < oargs.Length)
			{
				if (ca > 0)
					at.WorkStack.Push( at.ArgStack.Pop() );

				if (oargs[ca]==null)
				{
					at.WorkStack.Push( ca+1 );
					at.ArgStack.Push( null );
					return null;
				}

				at.WorkStack.Push( ca+1 );
				at.Branch.ShortPush( oargs[ca] );
				return null;
			}
			if (oargs.Length > 0)
				at.WorkStack.Push( at.ArgStack.Pop() );

			object[] ans = new object[oargs.Length];
			for (int i=0; i<oargs.Length; i++)
				ans[oargs.Length-1-i] = at.WorkStack.Pop();

			return ans;
		}

		public override string ToString()
		{
			string ans = Label;
			CB[] args = Args;
			if (args!=null)
			{
				ans = "<" + ans;
				for (int i=0; i<args.Length; i++)
				{
					if (args[i]==null)
						ans += " NULL";
					else
						ans += " " + args[i].ToString();
				}
				ans += " >";
			}
			return ans;
		}
	}

	public class CB_Op_SquareBrak : CB_Op
	{
		public override string Label { get { return "[]"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
				at.WorkStack.Push( 0 );

			int state = (int)at.WorkStack.Pop();
			switch(state)
			{
				case 0:
					at.WorkStack.Push(1);
					at.Branch.ShortPush( args[0] );
					return;
				case 1:
					at.WorkStack.Push( at.ArgStack.Pop() );
					at.WorkStack.Push(2);
					at.Branch.ShortPush( args[1] );
					return;
				case 2:
				{
					object ob = LocalVar.ValueOf(at.WorkStack.Pop());
					int ind = (int)(double)LocalVar.ValueOf( at.ArgStack.Pop() );
					Global.Assert( ob is IEnumerable );
					/*
					IEnumerator ie = ((IEnumerable)ob).GetEnumerator();
					ie.MoveNext();
					for (int i=0; i<((int)ind); i++)
						ie.MoveNext();
					at.ArgStack.Push( ie.Current );
					*/
					at.ArgStack.Push(new LocalVar_Enumer(ob, ind));
					at.Branch.ShortPop();
				}
					return;
			}
		}

		public static CB_Op_SquareBrak Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "[" );
			at++;

			CB_Op_SquareBrak ans = new CB_Op_SquareBrak();
			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert(whole[at]=="]");
			at++;

			return ans;
		}

		public CB Enumerated
		{
			get { return args[0]; }
			set { args[0] = value; }
		}

		public CB Enumerator
		{
			get { return args[1]; }
			set { args[1] = value; }
		}

		public override CB[] Args{get{return args;}}
		private CB[] args;
		public CB_Op_SquareBrak() {args=new CB[2];}
	}

	public class CB_Op_ParenSet : CB_Op
	{
		public override string Label { get { return "(,)"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			object[] vals = CB_Op.WaitForArgs(this, at, isreturning);
			if (vals==null)
				return;
			at.ArgStack.Push( vals );
			at.Branch.ShortPop();
		}

		public static CB_Op Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "(" );
			at++;

			ArrayList list = new ArrayList();

			while (whole[at] != ")")
			{
				while (whole[at]==",")
					at++;
				CB cb = BScriptCore.CompileBlock(whole, ref at);
				if (cb!=null)
					list.Add(cb);
			}

			BScriptCore.Assert(whole[at]==")");
			at++;

			if (list.Count==1)
				return new CB_Op_Paren( (CB)list[0]);

			CB[] nr = new CB[list.Count];
			for (int i=0; i<list.Count; i++)
				nr[i] = (CB)list[i];

			CB_Op_ParenSet ans = new CB_Op_ParenSet();
			ans.args = nr;
			return ans;
		}

		public override CB[] Args{get{return args;}}
		private CB[] args;
		private CB_Op_ParenSet() {}
	}

	public class CB_Op_Paren : CB_Op
	{
		public override string Label { get { return "()"; } }

		public override void Execute(EvalPoint ev, bool isreturning)
		{
			if (!isreturning)
				ev.Branch.ShortPush( code );
			else
				ev.Branch.ShortPop();
		}

		public static CB_Op_Paren Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_Paren ans = new CB_Op_Paren();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert(whole[at]==")");
			at++;

			return ans;
		}

		public override CB[] Args{get{CB[] ans=new CB[1]; ans[0]=code; return ans;}}
		private CB code;
		private CB_Op_Paren() {code=null;}
		public CB_Op_Paren(CB cd) {code=cd;}
	}

	public class CB_Op_For : CB_Op
	{
		public override string Label { get { return "for"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
			{
				at.WorkStack.Push( at.ArgStack.Count );
				at.WorkStack.Push(0);
			}

			int state = (int)at.WorkStack.Pop();

			switch(state)
			{
				case 0:	//do init
					at.WorkStack.Push(1);
					at.Branch.ShortPush( args[0] );
					return;
				case 1: //clear arg stack and call test
					int depth = (int)at.WorkStack.Peek();
					while (at.ArgStack.Count > depth)
						at.ArgStack.Pop();

					at.WorkStack.Push(2);
					at.Branch.ShortPush( args[1] );
					return;
				case 2: //eval test
				{
					bool test = LocalVar.ValueOfB( at.ArgStack.Pop() );
					if (!test) //did test fail?
					{
						at.WorkStack.Pop(); //pop depth
						at.Branch.ShortPop();
						return;
					}

					//call main loop
					at.WorkStack.Push(3);
					at.Branch.ShortPush( args[3] );
					return;
				}
				case 3: //now call the iterator
					at.WorkStack.Push(1);
					at.Branch.ShortPush( args[2] );
					return;
			}
			Global.Assert(false); //shouldn't get here!
		}

		public static CB_Op_For Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "for" );
			at++;

			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_For ans = new CB_Op_For();

			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);
			if( whole[at] == ";" ) at++;
			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);
			if( whole[at] == ";" ) at++;
			ans.args[2] = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert( whole[at] == ")" );
			at++;

			ans.args[3] = BScriptCore.CompileBlock(whole, ref at);
			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_For() {args = new CB[4];}
	}

	public class CB_Op_While : CB_Op
	{
		public override string Label { get { return "while"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
				at.WorkStack.Push(0);

			int state = (int)at.WorkStack.Pop();

			switch(state)
			{
				case 0:	//at test
                    at.WorkStack.Push(1);
					at.Branch.ShortPush( args[0] );
					return;
				case 1: //just tested
				{
					bool test = LocalVar.ValueOfB( at.ArgStack.Pop() );
					if (!test) //did test fail?
					{
						at.Branch.ShortPop();
						return;
					}
					at.WorkStack.Push(0);
					at.Branch.ShortPush( args[1] );
					return;
				}
			}
			Global.Assert(false); //shouldn't get here!
		}

		public static CB_Op_While Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "while" );
			at++;

			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_While ans = new CB_Op_While();
			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert( whole[at] == ")" );
			at++;

			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);
			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_While() {args = new CB[2];}
	}

	public class CB_Op_DeclareVar : CB_Op
	{
		public override string Label { get { return "var"; } }

		private class VarData
		{
			public string Name;
			public CB Code;
		}

		public override void Execute(EvalPoint at, bool isreturning)
		{
			object[] vals = WaitForArgs(this, at, isreturning);
			if (vals==null) return;

			for (int i=0; i<vals.Length; i++)
				vals[i] = LocalVar.ValueOf( vals[i] );

			for (int i=0; i<vdata.Count; i++)
			{
				VarData vd = (VarData)vdata[i];

				LocalVar lv = new LocalVar();
				lv.Name = vd.Name;
				lv.Value = vals[i];
				lv.IsShared = IsSharedVars;

				at.Locals.Vars.Add( lv );
			}

			at.Branch.ShortPop();
		}

		public override string ToString()
		{
			string ans = "";
			for (int i=0; i<vdata.Count; i++)
			{
				VarData vd = (VarData)vdata[i];
				ans += vd.Name + ":";
			}
			if (IsSharedVars)
				ans += "S";
			return ans + base.ToString();
		}

		public static CB_Op_DeclareVar Compile(string[] whole, ref int at)
		{
			bool shared = false;
			if (whole[at]=="shared")
			{
				shared = true;
				at++;

				if (whole[at]=="var")
					at++;
			}
			else
			{
				BScriptCore.Assert( whole[at] == "var" );
				at++;
			}
			ArrayList list = new ArrayList();
			bool done = false;

			while ((!done) && (whole[at]!=";"))
			{
				list.Add( whole[at] ); at++;
				if (whole[at]=="=")
				{
					at++;
					list.Add( BScriptCore.CompileBlock(whole, ref at) );
					if (whole[at-1]==";")
					{
						at--;
						done=true;
					}
				}
				else
					list.Add(null);
				if ((!done) && (whole[at]==","))
					at++;
			}
			//if ((!done) && (whole[at]==";"))
			//	at++;

			BScriptCore.Assert( list.Count%2 == 0 );
			CB_Op_DeclareVar ans = new CB_Op_DeclareVar();
			int cn = list.Count/2;
			for (int i=0; i<cn; i++)
			{
				VarData vd = new VarData();
				vd.Name = (string)list[i*2];
				vd.Code = (CB)list[i*2 + 1];
				ans.vdata.Add( vd );
			}
			ans.IsSharedVars = shared;

			return ans;
		}

		public override CB[] Args 
		{ 
			get { 
				CB[] ans = new CB[vdata.Count];
				for (int i=0; i<vdata.Count; i++)
					ans[i] = ((VarData)vdata[i]).Code;
				return ans; 
			} 
		}

		private bool IsSharedVars;
		private ArrayList vdata;
		public CB_Op_DeclareVar() {vdata=new ArrayList(); IsSharedVars=false;}
	}

	public class CB_Op_New : CB_Op
	{
		public override string Label { get { return "new:"+typename; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
			{
				at.Branch.ShortPush( code );
				return;
			}
			
			object bargs = LocalVar.ValueOf(at.ArgStack.Pop());
			object[] args;
			if (bargs is object[])
				args = (object[])bargs;
			else
			{
				args = new object[1];
				args[0] = bargs;
			}
			for (int i=0; i<args.Length; i++)
				args[i] = LocalVar.ValueOf(args[i]);

			if (typename!="object")
			{
				Type type = Type.GetType(typename);
				if (type==null)
					type = Type.GetType("BScript." + typename);
				if (type==null)
					type = Type.GetType("System." + typename);
				object nob = System.Activator.CreateInstance(type, args);
				at.ArgStack.Push(nob);
			}
			else
			{
				BSObject nob = new BSObject();
				for (int i=0; i<args.Length; i++)
					nob.List.Add( args[i] );
				at.ArgStack.Push(nob);
			}
			at.Branch.ShortPop();
		}

		public static CB_Op_New Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "new" );
			at++;

			CB_Op_New ans = new CB_Op_New();
			ans.typename = whole[at];
			at++;

			ans.code = CB_Op_ParenSet.Compile(whole, ref at);
			BScriptCore.Assert( 
				(ans.code.Label=="()") || 
				(ans.code.Label=="(,)") );

			return ans;
		}

		private CB code;
		private string typename;
		public override CB[] Args { get {CB[] ans=new CB[1]; ans[0]=code; return ans; } }
		private CB_Op_New() {}
	}

	public class CB_Op_CustomFunc : CB_Op
	{
		public override string Label { get { return "func:"+Name; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			at.ArgStack.Push( this );
			at.Branch.ShortPop();
		}

		public static CB_Op_CustomFunc Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "function" );
			at++;

			CB_Op_CustomFunc ans = new CB_Op_CustomFunc();
			ans.Name = whole[at]; at++;

			BScriptCore.Assert( whole[at]=="(" );
			at++;

			while (whole[at]!=")")
			{
				if (whole[at]!=",")
					ans.ArgNames.Add( whole[at] );
				at++;
			}

			at++;

			ans.Code = BScriptCore.CompileBlock(whole, ref at);

			Global.GGlobal.AddFunction( ans );

			return ans;
		}

		/*
		public override string ToString()
		{
			return "func:" + Name;
		}
		*/

		public CB Code;
		public string Name;
		public ArrayList ArgNames;
		public override CB[] Args { get {CB[] ans=new CB[1]; ans[0]=Code; return ans; } }
		private CB_Op_CustomFunc() {Code=null; ArgNames=new ArrayList();}
	}

	public class CB_Op_Debug : CB_Op
	{
		public override string Label { get { return "debug_op"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			at.Branch.ShortPop();
		}

		public static CB_Op_Debug Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "debug" );
			at++;

			CB_Op_Debug ans = new CB_Op_Debug();

			return ans;
		}

		public override CB[] Args { get {CB[] ans=new CB[0]; return ans; } }
		public CB_Op_Debug() {}
	}

	public class CB_Op_Return : CB_Op
	{
		public override string Label { get { return "return"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if ((!isreturning) && (code!=null))
			{
				at.Branch.ShortPush( code );
				return;
			}
			object retval=null;
			if (code != null)
			{
				retval = at.ArgStack.Pop();
				LocalVar lv = at.Locals.GetVar("__bs_returnvalue");
				if (lv!=null)
					lv.SetValue( retval );
			}
			EvalPoint cur = at.Branch.CurPos;
			while (!cur.IsFunc)
			{
				at.Branch.BlockPop();
				cur = at.Branch.CurPos;
			}
			at.Branch.BlockPop();
			if (code != null)
				at.Branch.CurPos.ArgStack.Push( retval );
			return;
		}

		public static CB_Op_Return Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "return" );
			at++;
			CB_Op_Return ans = new CB_Op_Return();

			if (whole[at] != ";")
				ans.code = BScriptCore.CompileBlock(whole, ref at);
			else
			{
				ans.code = null;
				at++;
			}

			return ans;
		}

		private CB code;
		public override CB[] Args { get {CB[] ans=new CB[1]; ans[0]=code; return ans; } }
		public CB_Op_Return() {code=null;}
	}

	public class CB_Op_Branch : CB_Op
	{
		public override string Label { get { return "branch"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (isreturning)
			{
				at.Branch.ShortPop();
				return;
			}

			at.Branch.JustHadChild = true;
			Branch nb = Global.GGlobal.AddBranch( code, at.Locals, at.Branch );
			nb.Parent = at.Branch;
		}

		public static CB_Op_Branch Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "branch" );
			at++;

			CB_Op_Branch ans = new CB_Op_Branch();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			return ans;
		}

		private CB code;
		public override CB[] Args { get {CB[] ans=new CB[1]; ans[0]=code; return ans; } }
		public CB_Op_Branch() {code=null;}
	}

	public class CB_Op_WaitFor : CB_Op
	{
		public override string Label { get { return "waitfor"; } }

		public static CB_Op_WaitFor Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "waitfor" );
			at++;

			CB_Op_WaitFor ans = new CB_Op_WaitFor();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			return ans;
		}

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
			{
				at.Branch.ShortPush( code );
				at.WorkStack.Push( 0 );
				at.WorkStack.Push( 789 );
				return;
			}

			object args = at.WorkStack.Pop();
			if (args==null)
			{
				at.WorkStack.Push(null);
				at.Branch.IsSleeping = true;
				return;
			}

			int state = (int)at.WorkStack.Pop();
			switch(state)
			{
				case 0:
					LocalVar_Field field = (LocalVar_Field)at.ArgStack.Pop();
					BSEvent bse = (BSEvent)field.GetValue();
					if (bse==null)
					{
						bse = new BSEvent();
						field.SetValue( bse );
					}
					at.WorkStack.Push(1);
					at.WorkStack.Push(null);
					bse.Subscribe( at );
					return;
				case 1:
					at.ArgStack.Push( ((BSEventArgs)args).Args );
					at.Branch.ShortPop();
					return;
				default:
					Global.Assert( false );
					break;
			}
		}

		public override CB[] Args {get{CB[] args = new CB[1]; args[0]=code; return args; }	}
		private CB code;
		public CB_Op_WaitFor() {}
	}

	public class CB_Op_If : CB_Op
	{
		public override string Label { get { return "if"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
				at.WorkStack.Push(0);

			int state = (int)at.WorkStack.Pop();

			switch(state)
			{
				case 0:	//at test
					at.WorkStack.Push(1);
					at.Branch.ShortPush( args[0] );
					return;
				case 1: //just tested
				{
					bool test = LocalVar.ValueOfB( at.ArgStack.Pop() );
					if (!test) //did test fail?
					{
						if (args[2]==null) //no else
						{
							at.Branch.ShortPop();
							return;
						}
						//For else:
						at.WorkStack.Push(2);
						at.Branch.ShortPush( args[2] );
						return;
					}
					at.WorkStack.Push(2);
					at.Branch.ShortPush( args[1] );
					return;
				}
				case 2:
					at.Branch.ShortPop();
					return;
			}
			Global.Assert(false); //shouldn't get here!
		}

		public static CB_Op_If Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "if" );
			at++;

			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_If ans = new CB_Op_If();
			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert( whole[at] == ")" );
			at++;

			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);

			if ((at < whole.Length) && (whole[at]=="else"))
			{
				at++;
				ans.args[2] = BScriptCore.CompileBlock(whole, ref at);
			}
			else
				ans.args[2] = null;

			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_If() {args = new CB[3];}
	}

	public class CB_Op_Curley : CB_Op
	{
		public override string Label { get{ return "{}"; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!ExecuteInOwnBlock(this, at, isreturning))
				return;

			if (!isreturning)
			{
				at.Branch.CurPos.WorkStack.Push( at.Branch.CurPos.ArgStack.Count );
				at.Branch.CurPos.WorkStack.Push( 0 );

				if (at.Branch.CurPos.Parent == null)
				{
					at.Branch.CurPos.Locals = Global.GNamespace;
				}
			}

			int ca = (int)at.WorkStack.Pop();
			int depth = (int)at.WorkStack.Pop();

			while (at.ArgStack.Count > depth)
				at.ArgStack.Pop();

			while (ca < Blocks.Count)
			{
				if (Blocks[ca]!=null)
				{
					at.WorkStack.Push( depth );
					at.WorkStack.Push( ca+1 );
					at.Branch.ShortPush( (CB)Blocks[ca] );
					return;
				}
				else
					ca++;
			}

			at.Branch.ShortPop();
		}

		static public CB_Op_Curley Compile(string[] whole, ref int at)
		{
			CB_Op_Curley ans = new CB_Op_Curley();

			bool hasstart = (whole[at]=="{");
			if (hasstart)
				at++;

			while ((at<whole.Length) && (whole[at]!="}"))
			{
				CB b = BScriptCore.CompileBlock(whole, ref at);
				ans.AddBlock( b );
			}

			if ((at<whole.Length) && (whole[at]=="}"))
				at++;

			return ans;
		}

		public void AddBlock(CB block)
		{
			if (block != null)
				Blocks.Add(block);
		}

		public override CB[] Args
		{
			get { return BScriptCore.ListToArray(Blocks); }
		}

		/// <summary>
		/// Removes nested curlies
		/// </summary>
		public void RemoveNestedCurlies()
		{
			for (int i=0; i<Blocks.Count; )
			{
				if (Blocks[i]==null)
					Blocks.RemoveAt(i);
				else
				{
					if ( Blocks[i] is CB_Op_Curley )
					{
						CB_Op_Curley sub = (CB_Op_Curley)Blocks[i];
						sub.RemoveNestedCurlies();
						Blocks.RemoveAt(i);
						for (int j=0; j<sub.Blocks.Count; j++)
							Blocks.Insert(i+j, sub.Blocks[j] );
					}
					else
						i++;
				}
			}
		}

		private ArrayList Blocks;
		public CB_Op_Curley() {Blocks=new ArrayList();}
	};

	public class CB_Op_Call : CB_Op
	{
		private CB parens;
		private CB func;
		public override string Label { get { return "call"; } }

		private static Random myrand = new Random();

		public CB_Op_Call(CB f, CB args)
		{
			parens = args;
			func = f;
		}

		public override CB[] Args
		{
			get
			{
				CB[] args = new CB[2];
				args[0] = func;
				args[1] = parens;
				return args;
			}
		}

		private bool CallCustom(CB_Op_CustomFunc cf, EvalPoint at, object[] args, bool isreturning)
		{
			if (!isreturning)
			{
				at.Branch.BlockPush( cf.Code, at.Locals, false );
				EvalPoint np = at.Branch.CurPos;
				np.IsFunc = true;
				for (int a=0; a<cf.ArgNames.Count; a++)
					np.Locals.AddVar( (string)cf.ArgNames[a], args[a] );
				np.Locals.AddVar("__bs_returnvalue", null);
				at.WorkStack.Push(np);
				return false;
			}

			EvalPoint made = (EvalPoint)at.WorkStack.Pop();
			LocalVar var = made.Locals.GetVar("__bs_returnvalue");
			at.ArgStack.Push( var.Value );
			return true;
		}

		private bool CallFunc(string name, EvalPoint at, object[] args, bool isreturning)
		{
			for (int i=0; i<Global.GGlobal.Functions.Count; i++)
			{
				CB_Op_CustomFunc cf = (CB_Op_CustomFunc)Global.GGlobal.Functions[i];
				if (cf.Name == name)
				{
					return CallCustom(cf, at, args, isreturning);
				}
			}

			switch(name)
			{
				case "sleepframe":
				{
					if (!isreturning)
					{
						at.Branch.IsSleeping = true;
						return false;
					}
				}
					break;
				case "waitforbranches":
				{
					ArrayList list = Global.GGlobal.GetBranchesOf( at.Branch );
					foreach (object obr in list)
					{
						Branch br = (Branch)obr;
						if (!br.IsDone)
						{
							at.Branch.IsSleeping = true;
							return false;
						}
					}
				}
					break;
				case "print":
				{
					if (Form1.MainWnd!=null)
					{
						for (int i=0; i<args.Length; i++)
							Form1.MainWnd.Print( args[i].ToString() );
						Form1.MainWnd.PrintLn("");
					}
				}
					break;
				case "rand":
				{
					at.ArgStack.Push( myrand.NextDouble() );
				}
					break;
				case "int":
				{
					int v = (int)LocalVar.ValueOfD(args[0]);
					at.ArgStack.Push( ((double)v) );
				}
					break;
				case "abs":
				{
					double v = LocalVar.ValueOfD( args[0] );
					if (v < 0) v *= -1;
					at.ArgStack.Push( v );
				}
					break;
				case "string":
				{
					string s = args[0].ToString();
					at.ArgStack.Push( s );
				}
					break;
				case "sleep":
				{
					if (!isreturning)
					{
						double endtime = Global.Time;
						endtime += (double)args[0];
						at.WorkStack.Push(endtime);
					}
					double end = (double)at.WorkStack.Pop();
					if (end > Global.Time)
					{
						at.WorkStack.Push( end );
						at.Branch.IsSleeping = true;
						return false;
					}
				}
					break;
				default:
					throw new ArgumentException("Unknown Function:", name);
			}
			return true;
		}

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if (!isreturning)
			{
				at.WorkStack.Push( 0 );
				at.Branch.ShortPush( parens );
				return;
			}

			int state = (int)at.WorkStack.Pop();
			switch(state)
			{
				case 0:
					object ob = at.ArgStack.Pop();
					if (parens.Label=="()")
					{
						object[] nr = new Object[1];
						nr[0] = ob; ob = nr;
					}
					at.WorkStack.Push( ob );

					//Now get the name of the function
					if (func.IsJustLabel)
						at.ArgStack.Push( func.Label );
					else
						at.Branch.ShortPush( func );
					at.WorkStack.Push( 1 );
					break;
				case 1:
				{
					//put name on stack
					at.WorkStack.Push( LocalVar.ValueOf( at.ArgStack.Pop() ) );
					at.WorkStack.Push( 2 );
				}
					break;
				case 3:
				case 2:
				{
					object fob = at.WorkStack.Pop();
					object[] args = (object[])at.WorkStack.Pop();
					bool isret = (state==3);
					if (state == 2)
					{
						for (int i=0; i<args.Length; i++)
							args[i] = LocalVar.ValueOf(args[i]);
					}
					if (fob is string)
					{
						if (!CallFunc((string)fob, at, args, isret))
						{
							at.WorkStack.Push( args );
							at.WorkStack.Push( fob );
							at.WorkStack.Push( 3 );
							return;
						}
						else
							at.Branch.ShortPop();
					}
					else if (fob is CB_Op_CustomFunc)
					{
						if (!CallCustom( (CB_Op_CustomFunc)fob, at, args, isret))
						{
							at.WorkStack.Push( args );
							at.WorkStack.Push( fob );
							at.WorkStack.Push( 3 );
							return;
						}
						else
							at.Branch.ShortPop();
					}
					else if (fob is LocalVar_Method)
					{
						object res = ((LocalVar_Method)fob).Invoke(args);
						at.ArgStack.Push(res);
						at.Branch.ShortPop();
						return;
					}
					else
					{
						throw new ArgumentException("Cannot 'call':", fob.ToString());
					}
				}
					break;
			}
		}
	}

	public class CB_Op_Func : CB_Op
	{
		private string func;
		private CB[] args;
		public override string Label { get{ return func; } }
		public override CB[] Args { get { return args; } }

		public override void Execute(EvalPoint at, bool isreturning)
		{
			if ((args.Length==2) && (func == "."))
			{
				if (!isreturning)
				{
					at.Branch.ShortPush( args[0] );
					return;
				}
				object ob = LocalVar.ValueOf(at.ArgStack.Pop());
				at.ArgStack.Push( LocalVar.DotProp(ob, args[1].Label ) );
				at.Branch.ShortPop();
				return;
			}

			object[] vals = WaitForArgs(this, at, isreturning);
			if (vals==null)
				return;

			bool found = true;
			LocalVar var;

			switch(func) //these are functions which deal with vars
			{
				case "++":
					var = (LocalVar)vals[0];
					var.SetValue( ((double)LocalVar.ValueOf(vals[0])) +1 );
					break;
				case "--":
					var = (LocalVar)vals[0];
					var.SetValue( ((double)LocalVar.ValueOf(vals[0])) -1 );
					break;
				case "=":
					var = (LocalVar)vals[0];
					var.SetValue( LocalVar.ValueOf( vals[1] ) );
					break;
				case "+=":
				{
					var = (LocalVar)vals[0];
					object val = LocalVar.ValueOf(var);
					if (val is string)
						var.SetValue( val.ToString() + LocalVar.ValueOf(vals[1]).ToString() );
					else
						var.SetValue( ((double)LocalVar.ValueOf(var)) + ((double)LocalVar.ValueOf(vals[1])) );
				}
					break;
				case "*=":
					var = (LocalVar)vals[0];
					var.Value = (LocalVar.ValueOfD(var)) * LocalVar.ValueOfD(vals[1]);
					break;
				case "/=":
					var = (LocalVar)vals[0];
					var.SetValue( LocalVar.ValueOfD(var) / LocalVar.ValueOfD(vals[1]) );
					break;
				case "-=":
					var = (LocalVar)vals[0];
					var.SetValue( LocalVar.ValueOfD(var) - LocalVar.ValueOfD(vals[1]) );
					break;
				case "!":
					at.ArgStack.Push( !LocalVar.ValueOfB( vals[0] ) );
					break;
				default:
					found = false;
					break;
			}
			if (found)
			{
				at.Branch.ShortPop();
				return;
			}


			for (int i=0; i<args.Length; i++)
			{
				vals[i] = LocalVar.ValueOf( vals[i] );
			}

			found = true;
			switch(func)
			{
				case "+":
				{
					if (vals[0] is double)
						at.ArgStack.Push( ((double)vals[0]) + LocalVar.ValueOfD(vals[1]) );
					else if (vals[0] is string)
						at.ArgStack.Push( vals[0].ToString() + vals[1].ToString() );
					else Global.TODO();
				}
					break;
				case "==":
				{
					vals[0] = LocalVar.ValueOf(vals[0]);
					vals[1] = LocalVar.ValueOf(vals[1]);
					if ((vals[0]==null) || (vals[1]==null))
						at.ArgStack.Push(vals[0]==vals[1]);
					else
						at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) == 0 );
				}
					break;
				case "!=":
				{
					vals[0] = LocalVar.ValueOf(vals[0]);
					vals[1] = LocalVar.ValueOf(vals[1]);
					if ((vals[0]==null) || (vals[1]==null))
						at.ArgStack.Push(vals[0]!=vals[1]);
					else
						at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) != 0 );
				}
					break;
				case "&&":
					at.ArgStack.Push( LocalVar.ValueOfB(vals[0]) && LocalVar.ValueOfB(vals[1]) );
					break;
				case "||":
					at.ArgStack.Push( LocalVar.ValueOfB(vals[0]) || LocalVar.ValueOfB(vals[1]) );
					break;
				case "^^":
					at.ArgStack.Push( LocalVar.ValueOfB(vals[0]) ^ LocalVar.ValueOfB(vals[1]) );
					break;
				default:
					found = false;
					break;
			}
			if (found)
			{
				at.Branch.ShortPop();
				return;
			}

			for (int i=0; i<args.Length; i++)
			{
				vals[i] = LocalVar.ValueOfD(vals[i]);
			}

			found = true;
			switch(func)
			{
				case "-":
					at.ArgStack.Push( ((double)vals[0]) - ((double)vals[1]) );
					break;
				case "-S":
					at.ArgStack.Push( -((double)vals[0]) );
					break;
				case "*":
					at.ArgStack.Push( ((double)vals[0]) * ((double)vals[1]) );
					break;
				case "%":
					at.ArgStack.Push( (double)( ((int)(double)vals[0]) % ((int)(double)vals[1]) ) );
					break;
				case "/":
					at.ArgStack.Push( ((double)vals[0]) / ((double)vals[1]) );
					break;
				case "<":
					at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) < 0 );
					break;
				case "<=":
					at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) <= 0 );
					break;
				case ">":
					at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) > 0 );
					break;
				case ">=":
					at.ArgStack.Push( ((IComparable)vals[0]).CompareTo(vals[1]) >= 0 );
					break;
				default:
					found = false;
					break;
			}
			if (!found)
				throw new ArgumentException("Unknown Function", func);

			at.Branch.ShortPop();
		}

		public CB_Op_Func(string f, CB[] aargs) {func = f; args=aargs;}
	}

	public class BS_Shunter
	{
		private BS_Shunter() {}
		private Stack funcstack;
		private Stack argstack;
		private CB curroot;

		private void AddOp()
		{
			CB name = (CB)funcstack.Pop();
			int nargs = NumFuncArguments(name.Label);
			ArrayList args = null;

			if (nargs > 0)
			{
				for (args = new ArrayList(); nargs>0; nargs--)
				{
					//args.Add( argstack.Pop() );
					args.Insert( 0, argstack.Pop() );
				}
			}

			if (name is CB_Op_SquareBrak)
			{
				((CB_Op_SquareBrak)name).Enumerated = (CB)args[0];
				argstack.Push(name);
				curroot = name;
				return;
			}
			if ((name.Label=="()") || (name.Label=="(,)"))
			{
				CB_Op_Call call = new CB_Op_Call( (CB)args[0], name );
				argstack.Push(call);
				curroot = call;
				return;
			}

			CB_Op_Func ans = new CB_Op_Func(name.Label, BScriptCore.ListToArray(args));
			if (DoesReturn(name.Label))
				argstack.Push( ans );
			curroot = ans;
		}

		private void AddArgOp()
		{
			CB name = (CB)argstack.Pop();
			if (name.IsJustLabel)
			{
				CB_Op_Func ans = new CB_Op_Func(name.Label, null);
				argstack.Push(ans);
				curroot = ans;
			}
			else
			{
				argstack.Push( name );
				curroot = name;
			}
		}

		private CB doShuntingYard(ArrayList code)
		{
			funcstack = new Stack();
			argstack = new Stack();
			curroot = null;

			if (code.Count==1)
				return (CB)code[0];

			for (int i=0; i<code.Count; i++)
			{
				CB cur = (CB)code[i];
				CB next = null;
				if ((i+1)<code.Count)
					next = (CB)code[i+1];
				CB prev = null;
				if (i!=0)
					prev = (CB)code[i-1];
				bool prevwasop = ((i!=0) && (
					BScriptParser.IsOperator( prev.Label[0]) &&
					(prev.Label[0]!='(') &&
					(prev.Label[0]!='[')
					));

			//	if ( ((cur.IsJustLabel)&&(BScriptParser.IsOperator(cur.Label[0])))
			//		|| ((next!=null)&&((next.Label=="()")||(next.Label=="(,)"))))
	
			//	if ( (BScriptParser.IsOperator(cur.Label[0]))
			//		|| ((next!=null)&&((next.Label=="()")||(next.Label=="(,)"))))

				if ( (BScriptParser.IsOperator(cur.Label[0])) && (cur.Label!="{}") )//&&
				{
					//it is a function!
					if ((cur.Label=="()") && 
						(	(prevwasop) ||
							(argstack.Count==0) ||
							(i==0)
						))
					{
						argstack.Push( cur );
					}
					else
					{
						int mypres = Precidence(cur.Label);
						bool found=false;
						while ((!found) && (funcstack.Count!=0))
						{
							CB top = (CB)funcstack.Peek();
							if (Precidence(top.Label) >= mypres)
								AddOp();
							else
								found = true;
						}

						funcstack.Push( cur );
					}
				}
				else if (cur.Label == ";")
				{
					while ( funcstack.Count > 0 )
						AddOp();
					while ( argstack.Count > 0 )
						AddArgOp();
				}
				else
				{
					//just add it
					argstack.Push(cur);
				}
			}
			while ( funcstack.Count > 0 )
				AddOp();

			if (argstack.Count > 1)
			{
				CB_Op_Curley line = new CB_Op_Curley();
				Stack stk = new Stack();
				while (argstack.Count > 0)
					stk.Push( argstack.Pop() );
				while (stk.Count > 0)
					line.AddBlock( (CB)stk.Pop() );
				curroot = line;
			}
			if (argstack.Count == 1)
				curroot = (CB) argstack.Pop();

			if (curroot is CB_Op_Curley)
				((CB_Op_Curley)curroot).RemoveNestedCurlies();

			return curroot;
		}

		static public CB DoShuntingYard(ArrayList code)
		{
			BS_Shunter shunter = new BS_Shunter();
			return shunter.doShuntingYard(code);
		}

		static public bool DoesReturn(string str)
		{
			switch(str)
			{
				case "var":
					return false;
			}
			return true;
		}

		static public int NumFuncArguments(string str)
		{
			if (!BScriptParser.IsOperator(str[0]))
			{
				return 1;
			}
			switch(str)
			{
				case "++":
				case "--":
				case "!":
				case "[]":
				case "()":
				case "(,)":
				case "-S":
					return 1;
				case "?":
					return 3;
				default:
					return 2;
			}
		}

		static public int Precidence(string str)
		{
			if (str=="[]")
				return 29;
			if ((str=="()") || (str=="(,)"))
				return 29;
			if (str==".")
				return 29;

			if (str.Length > 2) 
				return 26;

			if (str.Length==2)
			{
				if (str[1]=='=')
					return 1;
				if (str[0]==str[1])
					return 5;
				return 1;
			}

			switch(str[0])
			{
				case '=':
				case '<':
				case '>':
					return 1;
				case '+':
				case '-':
					return 15;
				case '*':
				case '/':
					return 20;
				case '^':
					return 25;
			}

			return 26;
		}
	}

	public class BScriptCore
	{

		static public void TODO()
		{
			Assert(false);
		}

		static public void Assert(bool val)
		{
			if (!val)
			{
				throw new ArgumentException("Compiling Assert Failed", "Compiling Assert Failed");
			}
		}

		static public CB[] ListToArray(ArrayList al)
		{
			if (al==null)
				return null;
			if (al.Count==0)
				return null;

			CB[] ans = new CB[al.Count];
			for (int i=0; i<ans.Length; i++)
				ans[i] = (CB)al[i];
			return ans;
		}

		static public CB Compile(string code)
		{
			string[] parts = BScriptParser.Fragment(code);
			int i=0;

			for (int j=0; j<parts.Length; j++)
			{
				if (parts[j] == "-")
				{
					if ((j==0) || 
						((BScriptParser.IsOperator(parts[j-1][0])) &&
						(parts[j-1]!=")") &&
						(parts[j-1]!="]")
						)
						)
					{
						parts[j] = "-S";
					}
				}
			}

			CB_Op_Curley ans = CB_Op_Curley.Compile(parts, ref i);

			/*
			CB_Op_Curley ans = new CB_Op_Curley();
			
			while (i < parts.Length)
			{
				CB cb = CompileBlock(parts, ref i);
				ans.AddBlock( cb );
				if ((cb!=null) && (cb.Label=="{}"))
					return cb;
			}

			ans.RemoveNestedCurlies();
			*/

			if (ans.Args.Length==1)
				return ans.Args[0];

			return ans;
		}

		static public CB CompileBlock(string[] whole, ref int at)
		{
			ArrayList list = new ArrayList();
			CB toadd = null;
			bool first = true, islast=false;
			while ((first) || (toadd!=null))
			{
				if (first)
					first = false;
				else
					list.Add( toadd );

				if (!islast)
					toadd = CompileBlock(whole, ref at, true);
				else
					toadd = null;

				if (toadd!=null)
				{
					if ((list.Count==0) && (!toadd.IsJustLabel) && (toadd.Label[0]!='('))
						return toadd;
					/*
					if ((at < whole.Length) && (whole[at] == "{"))
						islast = true;
					if ((toadd!=null)&&(toadd.Label=="{}"))
						islast = true;
					*/
				}
			}
			return BS_Shunter.DoShuntingYard(list);

			//return CompileBlock(whole, ref at, false);
		}

		static public CB CompileBlock(string[] whole, ref int at, bool parts)
		{
			if (at >= whole.Length)
			{
				return null;
			}

			string cur = whole[at];

			switch(cur) //is it an end of block
			{
				case ";":
					at++;
					return null;
				case ")":
				case "}":
				case "]":
				case ",":
				case "else":
					return null;
			}

			switch(cur) //it is a keyword:
			{
				case "if":
					return CB_Op_If.Compile(whole, ref at);
				case "while":
					return CB_Op_While.Compile(whole, ref at);
				case "function":
					return CB_Op_CustomFunc.Compile(whole, ref at);
				case "for":
					return CB_Op_For.Compile(whole, ref at);
				case "new":
					return CB_Op_New.Compile(whole, ref at);
				case "return":
					return CB_Op_Return.Compile(whole, ref at);
				case "waitfor":
					return CB_Op_WaitFor.Compile(whole, ref at);
				case "debug":
					return CB_Op_Debug.Compile(whole, ref at);
				case "var":
				case "shared":
					return CB_Op_DeclareVar.Compile(whole, ref at);
				case "branch":
					return CB_Op_Branch.Compile(whole, ref at);
				case "(":
					return CB_Op_ParenSet.Compile(whole, ref at);
				case "[":
					return CB_Op_SquareBrak.Compile(whole, ref at);
				case "{":
					return CB_Op_Curley.Compile(whole, ref at);
				default:
					break;
			};

			if (parts)
			{
				//if it got this far it must be just a label
				at++;
				return new CB_Label(cur);
			}
			else
			{
				BScriptCore.TODO();
				return null;
			}
		}
	}
}
