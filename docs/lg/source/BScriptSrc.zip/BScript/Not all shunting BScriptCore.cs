using System;
using System.Collections;

namespace BScript
{
	/// <summary>
	/// A Code Block
	/// </summary>
	public class CB
	{
		public virtual bool IsJustLabel { get {return false;} }
		public virtual string Label { get{ return "";} }

		public override string ToString() {return Label;}
	};

	public class CB_Label : CB
	{
		private string label;

		public override bool IsJustLabel { get{ return true;} }
		public override string Label { get{ return label;} }

		public CB_Label(string name) {label=name;}
	};

	public class CB_Op : CB
	{
		public override bool IsJustLabel { get{ return false; } }
		public virtual CB[] Args { get{ return null; } }

		public override string ToString()
		{
			string ans = Label;
			CB[] args = Args;
			if (args!=null)
			{
				ans = "<" + ans;
				for (int i=0; i<args.Length; i++)
				{
					if (args[i]==null)
						ans += " NULL";
					else
						ans += " " + args[i].ToString();
				}
				ans += " >";
			}
			return ans;
		}
	}

	public class CB_Op_SquareBrak : CB_Op
	{
		public override string Label { get { return "[]"; } }

		public static CB_Op_SquareBrak Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "[" );
			at++;

			CB_Op_SquareBrak ans = new CB_Op_SquareBrak();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert(whole[at]=="]");
			at++;

			return ans;
		}

		public override CB[] Args{get{CB[] ans=new CB[1]; ans[0]=code; return ans;}}
		private CB code;
		private CB_Op_SquareBrak() {code=null;}
	}

	public class CB_Op_Paren : CB_Op
	{
		public override string Label { get { return "()"; } }

		public static CB_Op_Paren Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_Paren ans = new CB_Op_Paren();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert(whole[at]==")");
			at++;

			return ans;
		}

		public override CB[] Args{get{CB[] ans=new CB[1]; ans[0]=code; return ans;}}
		private CB code;
		private CB_Op_Paren() {code=null;}
	}

	public class CB_Op_For : CB_Op
	{
		public override string Label { get { return "for"; } }

		public static CB_Op_For Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "for" );
			at++;

			BScriptCore.Assert( whole[at] == "(" );
			at++;

			CB_Op_For ans = new CB_Op_For();

			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);
			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);
			ans.args[2] = BScriptCore.CompileBlock(whole, ref at);

			BScriptCore.Assert( whole[at] == ")" );
			at++;

			ans.args[3] = BScriptCore.CompileBlock(whole, ref at);
			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_For() {args = new CB[4];}
	}

	public class CB_Op_While : CB_Op
	{
		public override string Label { get { return "while"; } }

		public static CB_Op_While Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "while" );
			at++;

			CB_Op_While ans = new CB_Op_While();
			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);
			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);
			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_While() {args = new CB[2];}
	}

	public class CB_Op_DeclareVar : CB_Op
	{
		public override string Label { get { return "var"; } }

		public override string ToString()
		{
			string ans = "";
			for (int i=0; i<vnames.Length; i++)
			{
				ans += vnames[i] + ":";
			}
			return ans + base.ToString();
		}

		public static CB_Op_DeclareVar Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "var" );
			at++;
			ArrayList list = new ArrayList();
			bool done = false;

			while ((!done) && (whole[at]!=";"))
			{
				list.Add( whole[at] ); at++;
				if (whole[at]=="=")
				{
					at++;
					list.Add( BScriptCore.CompileBlock(whole, ref at) );
					if (whole[at-1]==";")
						done=true;
				}
				else
					list.Add(null);
				if ((!done) && (whole[at]==","))
					at++;
			}
			if ((!done) && (whole[at]==";"))
				at++;

			BScriptCore.Assert( list.Count%2 == 0 );
			CB_Op_DeclareVar ans = new CB_Op_DeclareVar();
			int cn = list.Count/2;
			ans.vnames = new string[cn];
			ans.args = new CB[cn];
			for (int i=0; i<cn; i++)
			{
				ans.vnames[i] = (string)list[i*2];
				ans.args[i] = (CB)list[i*2 + 1];
			}

			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		private string[] vnames;
		public CB_Op_DeclareVar() {args = null;}
	}

	public class CB_Op_Branch : CB_Op
	{
		public override string Label { get { return "branch"; } }

		public static CB_Op_Branch Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "branch" );
			at++;

			CB_Op_Branch ans = new CB_Op_Branch();
			ans.code = BScriptCore.CompileBlock(whole, ref at);

			return ans;
		}

		private CB code;
		public override CB[] Args { get {CB[] ans=new CB[1]; ans[0]=code; return ans; } }
		public CB_Op_Branch() {code=null;}
	}

	public class CB_Op_If : CB_Op
	{
		public override string Label { get { return "if"; } }

		public static CB_Op_If Compile(string[] whole, ref int at)
		{
			BScriptCore.Assert( whole[at] == "if" );
			at++;

			CB_Op_If ans = new CB_Op_If();
			ans.args[0] = BScriptCore.CompileBlock(whole, ref at);
			ans.args[1] = BScriptCore.CompileBlock(whole, ref at);
			return ans;
		}

		public override CB[] Args { get { return args; } }
		private CB[] args;
		public CB_Op_If() {args = new CB[2];}
	}

	public class CB_Op_Curley : CB_Op
	{
		public override string Label { get{ return "{}"; } }

		static public CB_Op_Curley Compile(string[] whole, ref int at)
		{
			CB_Op_Curley ans = new CB_Op_Curley();
			BScriptCore.Assert( whole[at] == "{" );
			at++;

			while (whole[at]!="}")
			{
				CB b = BScriptCore.CompileBlock(whole, ref at);
				ans.AddBlock( b );
			}
			at++;

			return ans;
		}

		public void AddBlock(CB block)
		{
			if (block != null)
				Blocks.Add(block);
		}

		public override CB[] Args
		{
			get { return BScriptCore.ListToArray(Blocks); }
		}

		private ArrayList Blocks;
		public CB_Op_Curley() {Blocks=new ArrayList();}
	};

	public class CB_Op_Func : CB_Op
	{
		private string func;
		private CB[] args;
		public override string Label { get{ return func; } }
		public override CB[] Args { get { return args; } }

		public CB_Op_Func(string f, CB[] aargs) {func = f; args=aargs;}
	}

	public class BS_Shunter
	{
		private BS_Shunter() {}
		private Stack funcstack;
		private Stack argstack;
		private CB curroot;

		private void AddOp()
		{
			CB name = (CB)funcstack.Pop();
			int nargs = NumFuncArguments(name.Label);
			ArrayList args = null;
			if (nargs > 0)
			{
				for (args = new ArrayList(); nargs>0; nargs--)
				{
					//args.Add( argstack.Pop() );
					args.Insert( 0, argstack.Pop() );
				}
			}
			CB_Op_Func ans = new CB_Op_Func(name.Label, BScriptCore.ListToArray(args));
			if (DoesReturn(name.Label))
				argstack.Push( ans );
			curroot = ans;
		}

		private void AddArgOp()
		{
			CB name = (CB)argstack.Pop();
			if (name.IsJustLabel)
			{
				CB_Op_Func ans = new CB_Op_Func(name.Label, null);
				argstack.Push(ans);
				curroot = ans;
			}
			else
			{
				argstack.Push( name );
				curroot = name;
			}
		}

		private CB doShuntingYard(ArrayList code)
		{
			funcstack = new Stack();
			argstack = new Stack();
			curroot = null;

			for (int i=0; i<code.Count; i++)
			{
				CB cur = (CB)code[i];
				CB next = null;
				if ((i+1)<code.Count)
					next = (CB)code[i+1];
				if ( ((cur.IsJustLabel)&&(BScriptParser.IsOperator(cur.Label[0])))
					|| ((next!=null)&&(next.Label=="()")))
				{
					//it is a function!
					int mypres = Precidence(cur.Label);
					bool found=false;
					while ((!found) && (funcstack.Count!=0))
					{
						CB top = (CB)funcstack.Peek();
						if (Precidence(top.Label) >= mypres)
							AddOp();
						else
							found = true;
					}

					funcstack.Push( cur );
				}
				else if (cur.Label == "[]")
				{
					BScriptCore.TODO();
				}
				else if (cur.Label == ";")
				{
					while ( funcstack.Count > 0 )
						AddOp();
					while ( argstack.Count > 0 )
						AddArgOp();
				}
				else
				{
					//not a function
					argstack.Push(cur);
				}
			}
			while ( funcstack.Count > 0 )
				AddOp();

			if (argstack.Count > 1)
			{
				CB_Op_Curley line = new CB_Op_Curley();
				while (argstack.Count > 0)
				{
					AddArgOp(); //convert arg into func
					line.AddBlock( (CB)argstack.Pop() );
				}
				curroot = line;
				return line;
			}
			if (argstack.Count == 1)
			{
				AddArgOp(); //convert arg into func
				curroot = (CB) argstack.Pop();
				return curroot;
			}

			return curroot;
		}

		static public CB DoShuntingYard(ArrayList code)
		{
			BS_Shunter shunter = new BS_Shunter();
			return shunter.doShuntingYard(code);
		}

		static public bool DoesReturn(string str)
		{
			return true;
		}

		static public int NumFuncArguments(string str)
		{
			if (!BScriptParser.IsOperator(str[0]))
			{
				return 1;
			}
			switch(str)
			{
				case "++":
				case "--":
				case "!":
					return 1;
				case "?":
					return 3;
				default:
					return 2;
			}
		}

		static public int Precidence(string str)
		{
			if (str.Length > 2) 
				return 26;

			if (str.Length==2)
			{
				if (str[1]=='=')
					return 1;
				if (str[0]==str[1])
					return 1;
				return 1;
			}

			switch(str[0])
			{
				case '+':
				case '-':
					return 15;
				case '*':
				case '/':
					return 20;
				case '^':
					return 25;
			}

			return 26;
		}
	}

	public class BScriptCore
	{

		static public void TODO()
		{
			Assert(false);
		}

		static public void Assert(bool val)
		{
			if (!val)
			{
				System.Windows.Forms.MessageBox.Show("Assert Failed", "damn");
				Environment.Exit(0);
			}
		}

		static public CB[] ListToArray(ArrayList al)
		{
			if (al==null)
				return null;
			if (al.Count==0)
				return null;

			CB[] ans = new CB[al.Count];
			for (int i=0; i<ans.Length; i++)
				ans[i] = (CB)al[i];
			return ans;
		}

		static public CB Compile(string code)
		{
			string[] parts = BScriptParser.Fragment(code);
			int i=0;
			CB_Op_Curley ans = new CB_Op_Curley();

			while (i < parts.Length)
			{
				ans.AddBlock( CompileBlock(parts, ref i) );
			}

			if (ans.Args.Length==1)
				return ans.Args[0];

			return ans;
		}

		static public CB CompileBlock(string[] whole, ref int at)
		{
			return CompileBlock(whole, ref at, false);
		}

		static public CB CompileBlock(string[] whole, ref int at, bool parts)
		{
			if (at >= whole.Length)
			{
				return null;
			}

			string cur = whole[at];

			switch(cur) //is it an end of block
			{
				case ";":
					at++;
					return null;
				case ")":
				case "}":
				case "]":
				case ",":
					return null;
			}

			switch(cur) //it is a keyword:
			{
				case "if":
					return CB_Op_If.Compile(whole, ref at);
				case "while":
					return CB_Op_While.Compile(whole, ref at);
				case "for":
					return CB_Op_For.Compile(whole, ref at);
				case "var":
					return CB_Op_DeclareVar.Compile(whole, ref at);
				case "branch":
					return CB_Op_Branch.Compile(whole, ref at);
				case "(":
					return CB_Op_Paren.Compile(whole, ref at);
				case "[":
					return CB_Op_SquareBrak.Compile(whole, ref at);
				case "{":
					return CB_Op_Curley.Compile(whole, ref at);
				default:
					break;
			};

			if (parts)
			{
				//if it got this far it must be just a label
				at++;
				return new CB_Label(cur);
			}
			else
			{
				ArrayList list = new ArrayList();
				CB toadd = new CB_Label(cur);
				at++;
				while (toadd!=null)
				{
					list.Add( toadd );
					toadd = CompileBlock(whole, ref at, true);
				}
				return BS_Shunter.DoShuntingYard(list);
			}
		}
	}
}
