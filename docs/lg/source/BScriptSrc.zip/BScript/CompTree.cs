using System;
using System.Collections;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace BScript
{
	public class fcolor
	{
		public double red, green, blue;

		public Color AsColor
		{
			get
			{
				int r = (int)(red * 255);
				int g = (int)(green * 255);
				int b = (int)(blue * 255);
				return Color.FromArgb(r, g, b);
			}
		}

		public fcolor(double r, double g, double b) {red=r; green=g; blue=b;}
		public fcolor() {red=0; green=0; blue=0;}
	}

	/// <summary>
	/// Just here to test how it works on structs
	/// </summary>
	public struct mystruct
	{
		public double val;

		public override string ToString()
		{
			return "{Val=" + val + "}";
		}
	}

	public class fpnt
	{
		public double x, y;

		public override string ToString()
		{
			return "(" + x.ToString() + "," + y.ToString() + ")";
		}

		public fpnt(double ax, double ay) {x=ax; y=ay;}
		public fpnt() {x=0; y=0;}
	}

	public class CompNode
	{
		public ArrayList Children;
		public ArrayList Transforms;
		public fpnt Pos;
		public fcolor Color;
		private CompNode parent;

		public CompNode()
		{
			Children = new ArrayList();
			Transforms = new ArrayList();
			Pos = new fpnt(0, 0);
			Color = new fcolor();
			parent = null;
		}

		public CompNode Parent
		{
			get { return parent; }
			set
			{
				if (parent!=null)
				{
					parent.Children.Remove( this );
				}
				parent = value;
				if (parent!=null)
					parent.Children.Add( this );
			}
		}

		public CompNode NewChild
		{
			set
			{
				Children.Add( value );
			}
		}

		public void Render(CompTree tree)
		{
			Graphics g = tree.Graphics;
			GraphicsState state = g.Save();

			g.TranslateTransform( (float)Pos.x, (float)Pos.y );

			for (int i=0; i<Transforms.Count; i++)
			{
				((Transform)Transforms[i]).Apply(g);
			}

			SelfRender(tree);

			foreach(object ob in Children)
			{
				((CompNode)ob).Render(tree);
			}

			g.Restore( state );
		}

		public virtual void SelfRender(CompTree tree) {}
	}

	public abstract class Transform
	{
		public abstract void Apply(Graphics g);
	}

	public class RotateTransform : Transform
	{
		public double Rot;

		public override void Apply(Graphics g)
		{
			g.RotateTransform( (float)Rot);
		}

		public RotateTransform() {Rot=0;}
		public RotateTransform(double rot) {Rot=rot;}
	}

	public class Disk : CompNode
	{
		public double Radius = 20;
		public double Slices = 15;

		public override void SelfRender(CompTree tree)
		{
			Brush brush = new System.Drawing.SolidBrush( Color.AsColor );
			Graphics g = tree.Graphics;
			PointF[] verts = new PointF[3];
			verts[0] = new PointF(0, 0);

			int slices = (int)Slices;
			int mod = (slices/3);
			for (int i=0; i<=slices; i++)
			{
				float ang = ((float)i) / ((float)slices);
				ang *= (float)(Math.PI*2);
                float len = (float)Radius;
				if ((i%mod)==0)
					len /= 2;
				verts[1] = new PointF((float)(Math.Cos(ang)*len), (float)(Math.Sin(ang)*len));

				if (i != 0)
				{
					g.FillPolygon(brush, verts);
				}
				verts[2] = verts[1];
			}
		}
	}

	public class TextView : CompNode
	{
		public string Text;
		private Font font;

		public double FontSize
		{
			get { return font.Size; }
			set
			{
				font = new Font("Ariel", (float)value);
			}
		}

		public TextView()
		{
			Text = "";
			font = new Font("Ariel", 5);
		}

		public override void SelfRender(CompTree tree)
		{
			Brush brush = new System.Drawing.SolidBrush( Color.AsColor );
			SizeF sf = tree.Graphics.MeasureString(Text, font);
			tree.Graphics.DrawString(Text, font, brush, -sf.Width/2, -sf.Height/2);
		}
	}

	public class Block : CompNode
	{
		public double Left, Right, Top, Bottom;

		public Block()
		{
			Left = -5; Right=5;
			Top = -5; Bottom=5;
		}

		public Block(double l, double r, double t, double b)
		{
			Left = l; Right = r;
			Top = t; Bottom = b;
		}

		public double Width
		{
			get { return (Right-Left); }
			set
			{
				double mid = (Right+Left)/2;
				Left = mid - value/2;
				Right = mid + value/2;
			}
		}

		public double Height
		{
			get { return (Bottom-Top); }
			set
			{
				double mid = (Bottom+Top)/2;
				Top = mid - value/2;
				Bottom = mid + value/2;
			}
		}

		public double SideLength
		{
			get
			{
				return (Right-Left);
			}
			set
			{
				double mid = (Right+Left)/2;
				double len = value/2;
				Left = mid - len;
				Right = mid + len;
				mid = (Top+Bottom)/2;
				Top = mid - len;
				Bottom = mid + len;
			}
		}

		public override void SelfRender(CompTree tree)
		{
			Brush brush = new System.Drawing.SolidBrush( Color.AsColor );
			tree.Graphics.FillRectangle( brush, (float)Left, 
				(float)Top, (float)(Right-Left), (float)(Bottom-Top));
		}
	}

	public class CompTree
	{
		public CompNode Root;
		public Graphics Graphics;

		protected void DrawBox()
		{
			Graphics.DrawRectangle(Pens.Black, -5, -5, 10, 10);
		}

		public void Render(Graphics g, int w, int h)
		{
			g.FillRectangle( Brushes.LightGray, 0, 0, w, h);
			Graphics = g;
			GraphicsState state = g.Save();

			float ratio = ((float)w) / ((float)h);
			ratio = 1;

			//Set system to go from 0 to 100
			Graphics.ScaleTransform( ((float)w)/(ratio*100.0f), ((float)h)/100.0f );

			Root.Render( this );

			Graphics.Restore( state );
		}

		public void Reset()
		{
			MouseUp = null;
			Root = new CompNode();
		}

		public BSEvent MouseUp = null;

		public CompTree()
		{
			Reset();
		}
	}

	public class CompTreeViewer : Control
	{
		public CompTree Tree;

		protected void myMouseUp(object sender, MouseEventArgs mea)
		{
			float mx = ((float)mea.X) / ((float)Width);
			float my = ((float)mea.Y) / ((float)Height);
			if (Tree.MouseUp!=null)
				Tree.MouseUp.Fire(mx*100.0,my*100.0);
		}

		public CompTreeViewer()
		{
			this.SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			this.MouseUp += new MouseEventHandler( myMouseUp );

			Tree = new CompTree();
		}

		protected override void OnSizeChanged(EventArgs ea)
		{
			this.Invalidate();
		}

		protected override void OnPaint(PaintEventArgs pea)
		{
			Graphics g = pea.Graphics;

			Tree.Render(pea.Graphics, Width, Height);
		}
	}
}
