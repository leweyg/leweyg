using System;
using System.Collections;
using System.Reflection;

namespace BScript
{
	public class LocalVar
	{
		public bool IsShared;
		public string Name;
		public object Value;

		static public object ValueOf(object of)
		{
			if (of==null) 
				return null;
			if (of is LocalVar)
				return ((LocalVar)of).GetValue();
			return of;
		}

		static public bool ValueOfB(object of)
		{
			of = ValueOf(of);
			if (of == null)
				return false;
			if (of is IConvertible)
				return ((IConvertible)of).ToBoolean(null);
			throw new ArgumentException("Cannot make into a bool", of.ToString());
		}

		static public double ValueOfD(object of)
		{
			of = ValueOf(of);
			if (of==null)
				return 0;
			if (of is IConvertible)
				return ((IConvertible)of).ToDouble(null);
			throw new ArgumentException("Cannot make into a number:", of.ToString());
		}

		public virtual object GetValue()
		{
			return Value;
		}

		public virtual void SetValue(object nv)
		{
			Value = nv;
		}

		static public object DotProp(object ob, string name)
		{
			Type type = ob.GetType();
			PropertyInfo pi = type.GetProperty(name);
			if (pi!=null)
				return new LocalVar_Prop(ob, pi);
			FieldInfo fi = type.GetField(name);
			if (fi!=null)
				return new LocalVar_Field(ob, fi);
			MethodInfo mi = type.GetMethod(name);
			if (mi!=null)
				return new LocalVar_Method(ob, mi);
			if (ob is BSObject)
				return new LocalVar_Prop( (BSObject)ob, name );
			
			throw new ArgumentException("Unknown Member of " + type.Name, name);
		}

		public LocalVar() {IsShared=false; Name=null; Value=null;}
	}

	public class BSEvent
	{
		private ArrayList callers;

		public void Fire(params object[] from)
		{
			if ((callers==null) || (callers.Count==0))
				return;
			BSEventArgs bea = new BSEventArgs( from );
			foreach(object ob in callers)
			{
				EvalPoint at = ((EvalPoint)ob);
				object last = at.WorkStack.Pop();
				Global.Assert( last==null );
				at.WorkStack.Push( bea );
			}
			callers.Clear();
		}

		public void Subscribe(EvalPoint at)
		{
			if (callers==null)
				callers = new ArrayList();
			callers.Add( at );
		}
	}

	public class BSEventArgs
	{
		public object[] Args;

		public BSEventArgs(object[] args)
		{
			Args = args;
		}
	}

	public class BSObject : IEnumerable
	{
		public ArrayList List;
		public ArrayList Props;

		public IEnumerator GetEnumerator()
		{
			return List.GetEnumerator();
		}

		public object GetProp(string name)
		{
			LocalVar var;
			for (int i=0; i<Props.Count; i++)
			{
				var = ((LocalVar)Props[i]);
				if (var.Name == name)
				{
					return var.Value;
				}
			}
			return null;
		}

		public void SetProp(string name, object val)
		{
			LocalVar var;
			for (int i=0; i<Props.Count; i++)
			{
				var = ((LocalVar)Props[i]);
				if (var.Name == name)
				{
					var.Value = val;
					return;
				}
			}
			var = new LocalVar();
			var.Name = name;
			var.Value = val;
			Props.Add(var);
		}

		public double Length
		{
			get
			{
				return List.Count;
			}
		}

		public BSObject()
		{
			List = new ArrayList();
			Props = new ArrayList();
		}
	}

	public class LocalVar_Enumer : LocalVar
	{
		private int index;

		public override object GetValue()
		{
			if (Value is BSObject)
			{
				BSObject ob = (BSObject)Value;
				if (index >= ob.List.Count)
					return null;
				return ob.List[index];
			}

			IEnumerator ie = ((IEnumerable)Value).GetEnumerator();
			ie.MoveNext();

			for (int i=0; i<index; i++)
				ie.MoveNext();

			return ie.Current;
		}

		public override void SetValue(object val)
		{
			if (Value is BSObject)
			{
				BSObject ob = (BSObject)Value;
				while (index >= ob.List.Count)
					ob.List.Add(null);
				ob.List[index] = val;
			}
			else if (Value is object[])
				((object[])Value)[index] = val;
			else if ((Value is IList) && ( !((IList)Value).IsFixedSize ))
			{
				IList list = ((IList)Value);
				list.RemoveAt(index);
				list.Insert(index, val);
			}
			else
			{
				throw new ArgumentException("Cannot set this array type", Value.GetType().Name );
			}
		}

		public LocalVar_Enumer(object ob, int ind) {Value=ob; index=ind; Name="[i]";}
	}

	public class LocalVar_Method : LocalVar
	{
		private MethodInfo mi;

		public object Invoke(object[] args)
		{
			return mi.Invoke(Value, args);
		}

		public override object GetValue()
		{
			return this;
		}

		public override void SetValue(object val)
		{
			throw new ArgumentException("Cannot set a method!","");
		}

		public LocalVar_Method(object ob, MethodInfo p)
		{
			Value = ob;
			mi = p;
			Name = p.Name;
		}
	}

	public class LocalVar_Field : LocalVar
	{
		private FieldInfo pi;

		public override object GetValue()
		{
			return pi.GetValue(Value);
		}

		public override void SetValue(object val)
		{
			pi.SetValue( Value, val );
		}

		public LocalVar_Field(object ob, FieldInfo p)
		{
			Value = ob;
			pi = p;
			Name = p.Name;
		}
	}

	public class LocalVar_Prop : LocalVar
	{
		private PropertyInfo pi;

		public override object GetValue()
		{
			if (pi==null)
				return ((BSObject)Value).GetProp(Name);
			return pi.GetValue(Value, null);
		}

		public override void SetValue(object val)
		{
			if (pi==null)
				((BSObject)Value).SetProp(Name, val);
			else
				pi.SetValue( Value, val, null );
		}

		public LocalVar_Prop(BSObject ob, string name)
		{
			Value = ob;
			Name = name;
			pi = null;
		}

		public LocalVar_Prop(object ob, PropertyInfo p)
		{
			Value = ob;
			pi = p;
			Name = p.Name;
		}
	}

	public class Namespace
	{
		public ArrayList Vars;
		public Namespace Parent;

		public void AddVar(string name, object ob)
		{
			LocalVar lv = new LocalVar();
			lv.Name = name;
			lv.Value = ob;
			Vars.Add( lv );
		}

		public LocalVar GetVar(string name)
		{
			for(int i=Vars.Count-1; i>=0; i--)
			{
				LocalVar var = (LocalVar)Vars[i];
				if (var.Name == name)
					return var;
			}
			if (Parent!=null)
				return Parent.GetVar(name);
			return null;
		}

		public Namespace() 
		{
			Vars = new ArrayList();
			Parent = null;
		}

		public Namespace(Namespace par, bool newbranch)
		{
			Vars = new ArrayList();
			Parent = par;
			if (newbranch) //TODO: uncomment this
			//if (false)
			{
				Namespace gn = Global.GNamespace;
				for (Namespace work = Parent; (work!=null)&&(work!=gn); work=work.Parent)
				{
					for (int i=0; i<work.Vars.Count; i++)
					{
						LocalVar var = (LocalVar)work.Vars[i];
						if (var.IsShared)
							Vars.Add( var );
						else
						{
							LocalVar nv = new LocalVar();
							nv.Name = var.Name;
							nv.IsShared = false;
							nv.Value = var.Value;
							if (nv.Value!=null)
							{
								Type t = nv.Value.GetType();
								if (t.IsValueType)
								{
									if (nv.Value is ICloneable)
										nv.Value = ((ICloneable)(nv.Value)).Clone();
									else if (nv.Value is IConvertible)
										nv.Value = ((IConvertible)nv.Value).ToType(t, null);
									else
									{
										//TODO: structs should get copied here but they don't
										throw new ArgumentException("Value type doesn't impliment ICloneable: ", t.Name);
									}
								}
							}
							Vars.Add( nv );
						}
					}
					Parent = gn;
				}
			}
		}
	}

	public class LinePos
	{
		public LinePos Parent;
		public CB Code;
		public bool IsReturning;

		public LinePos(LinePos parent, CB code) 
		{
			Parent = parent;
			Code = code;
			IsReturning = false;
		}

		public override string ToString()
		{
			if (Parent!=null)
				return Parent.ToString() + "_" + Code.Label;
			return Code.Label;
		}
	}

	public class EvalPoint
	{
		public EvalPoint Parent;
		public Branch Branch;
		public Namespace Locals;
		public Stack WorkStack;
		public Stack ArgStack;
		public LinePos Pos;
		public bool IsFunc = false;

		public override string ToString()
		{
			string ans = "NULL";
			if (Pos!=null)
				ans = "{" + Pos.ToString() + "}";
			if (Parent!=null)
				ans = Parent.ToString() + ":" + ans;
			return ans;
		}

		public EvalPoint(Branch owner, EvalPoint parent, CB code, Namespace nsp, bool isbranch)
		{
			Branch = owner;
			Parent = parent;
			if (nsp==null)
				Locals = new Namespace(Global.GNamespace, isbranch);
			else
				Locals = new Namespace(nsp, isbranch);
			ArgStack = new Stack();
			Pos = new LinePos(null, code);
			WorkStack = new Stack();
		}
	}

	public class Branch
	{
		public EvalPoint CurPos;
		public bool IsSleeping;
		public bool IsDone;
		public bool JustHadChild;
		public Branch Parent;

		public override string ToString()
		{
			string ans = "";
			if (IsSleeping)
				ans += "[sleep]";
			if (IsDone)
				ans += "[done]";
			if (CurPos!=null)
				ans += CurPos.ToString();
			return ans;
		}

		public void ShortPush(CB code)
		{
			Global.Assert( CurPos.Pos != null );

			CurPos.Pos = new LinePos(CurPos.Pos, code);
		}

		public void ShortPop()
		{
			CurPos.Pos = CurPos.Pos.Parent;
		}

		public void BlockPush(CB code, Namespace ns, bool isbranch)
		{
			CurPos = new EvalPoint(this, CurPos, code, ns, isbranch);
		}

		public void BlockPop()
		{
			CurPos = CurPos.Parent;
		}

		public void Run()
		{
			while ((!IsDone) && (!IsSleeping) && (!JustHadChild))
			{
				if (CurPos==null)
				{
					IsDone = true;
					return;
				}

				if (CurPos.Pos==null)
					CurPos = CurPos.Parent;
				else
				{
					LinePos torun = CurPos.Pos;
					torun.Code.Execute( CurPos, torun.IsReturning );
					torun.IsReturning = true;
				}
			}
		}

		public Branch() 
		{
			CurPos=null;
			IsSleeping = false;
			IsDone = false;
		}
	}

	public class TimeScale
	{
		public double from, mid, to, duration;
		public bool SlowStart, SlowEnd;
		private double starttime;
		private bool isdone, hasmid;

		public bool Going
		{
			get { return !isdone; }
		}

		public double Value
		{
			get
			{
				if (isdone)
					return to;

				double ct = Global.Time;
				ct -= starttime;
				ct /= duration;
				if (SlowStart)
					ct *= ct;
				if (SlowEnd)
				{
					ct = Math.Sqrt(ct);
				}
				if (ct >= 1)
				{
					isdone = true;
					return to;
				}

				if (!hasmid)
					return ((1.0-ct)*from) + (ct*to);

				/*
				if (ct <= 0.5)
				{
					ct *= 2;
					return ((1.0-ct)*from) + (ct*mid);
				}
				else
				{
					ct = (ct - 0.5)*2;
					return ((1.0-ct)*mid) + (ct*to);
				}*/

				double a = ((1.0-ct)*from) + (ct*mid);
				double b = ((1.0-ct)*mid) + (ct*to);
				return ((1.0-ct)*a) + (ct*b);
				
			}
		}

		public TimeScale(double f, double m, double t, double dt)
		{
			from = f;
			to = t;
			mid = m;
			hasmid = true;
			isdone = false;
			duration = dt;
			starttime = Global.Time;
		}

		public TimeScale(double f, double t, double dt)
		{
			from = f;
			to = t;
			hasmid = false;
			isdone = false;
			duration = dt;
			starttime = Global.Time;
		}
	}

	public class Global
	{
		private Namespace mnamespace;
		private ArrayList branches;
		public ArrayList Functions;
		private static Global global = new Global();

		public ArrayList GetBranchesOf(Branch br)
		{
			ArrayList ans = new ArrayList();
			for (int i=0; i<branches.Count; i++)
			{
				Branch cur = ((Branch)branches[i]);
				if (cur != br)
				{
					bool found = false;
					for (Branch par=cur.Parent; (!found)&&(par!=null); par=par.Parent)
					{
						if (par == br)
						{
							ans.Add(cur);
							found = true;
						}
					}
				}
			}
			return ans;
		}

		public void AddFunction(CB_Op_CustomFunc func)
		{
			Functions.Add(func);
		}

		private static double currenttime=0;
		static public double Time
		{
			get
			{
				return currenttime;
			}
		}

		public Branch AddBranch(CB code, Namespace ns, Branch before)
		{
			Branch br = new Branch();
			br.BlockPush(code, ns, true);
			if (before==null)
				branches.Add( br );
			else
				branches.Insert( branches.IndexOf(before), br );
			return br;
		}

		public void RunFrame()
		{
			if (!System.Threading.Monitor.TryEnter(this))
				return;

			currenttime = ((double)Environment.TickCount);

			int i;
			for (i=0; i<branches.Count; i++)
			{
				Branch br = ((Branch)branches[i]);
				br.IsSleeping = false;
			}

			bool found = true;
			while (found)
			{
				found = false;
				for (i=0; i<branches.Count;)
				{
					Branch br = (Branch)branches[i];
					if ((!br.IsDone) && (!br.IsSleeping))
					{
						found = true;
						br.Run();
					}
					if (!br.JustHadChild)
						i++;
					else
						br.JustHadChild = false;
				}
			}

			for (i=0; i<branches.Count;)
			{
				if ( ((Branch)branches[i]).IsDone )
					branches.RemoveAt(i);
				else
					i++;
			}

			System.Threading.Monitor.Exit(this);
		}

		public void Reset()
		{
			mnamespace = new Namespace();
			branches = new ArrayList();
			Functions = new ArrayList();
		}

		private Global()
		{
			Reset();
		}

		public static Global GGlobal
		{
			get { return global; }
		}

		public static Namespace GNamespace
		{
			get { return global.mnamespace; }
		}

		static public void TODO()
		{
			throw new NotImplementedException("TODO!");
		}

		static public void Assert(bool val)
		{
			if (!val)
			{
				throw new ArgumentException("Global Eval Assert Failed", "Global Eval Assert Failed");
			}
		}

	}
}
