namespace BScript
{

	public class BScriptParser
	{
		public static bool IsWhite(char let)
		{
			switch(let)
			{
				case ' ':
				case '\n':
				case '\r':
				case '\t':
					return true;
				default:
					return false;
			}
		}

		public static bool IsLetter(char let)
		{
			return (!IsWhite(let) && !IsOperator(let));
		}

		public static bool IsNumber(char let)
		{
			return ((let >= '0') && (let <= '9'));
		}

		public static bool IsNumber(string s)
		{
			double res;
			bool ans = System.Double.TryParse(s, System.Globalization.NumberStyles.Any, null, out res);
			return ans;
		}

		public static string RemoveBackslashes(string line)
		{
			string ans = "";
			for (int i=0; i<line.Length; i++)
			{
				if (line[i] != '\\')
					ans += line[i];
				else
				{
					char let='?';
					switch(line[i+1])
					{
						case '\\':
							let = '\\';
							break;
						case 'n':
							let = '\n';
							break;
						case 't':
							let = '\t';
							break;
						case 'r':
							let = '\r';
							break;
						case '\'':
							let = '\'';
							break;
						default:
							throw new System.ArgumentException("Unknown escape sequence:", line[i+1].ToString());
							break;
					}
					ans += let;
					i++;
				}
			}
			return ans;
		}

		public static bool IsDoubleOperator(char a, char b)
		{
			if (a==b) //of the form ??
			{
				switch(a)
				{
					case '+':
					case '-':
					case '*':
					case '&':
					case '^':
					case '|':
					case '<':
					case '>':
					case '=':
						return true;
				}
			}
			if (b=='=') //of the form ?=
			{
				switch(a)
				{
					case '+':
					case '-':
					case '=':
					case '*':
					case '/':
					case '&':
					case '^':
					case '%':
					case '$':
					case '#':
					case '@':
					case '!':
					case '|':
					case '<':
					case '>':
						return true;
				}
			}
			//any others?
			return false;
		}

		public static bool IsOperator(char let)
		{
			switch(let)
			{
				case '=':
				case '(':
				case ')':
				case '{':
				case '}':
				case '\'':
				case '.':
				case '+':
				case '-':
				case '*':
				case '&':
				case '^':
				case '%':
				case '$':
				case '#':
				case '@':
				case '!':
				case '|':
				case '/':
				case ']':
				case '[':
				case ';':
				case ':':
				case '?':
				case '>':
				case '<':
				case ',':
					return true;
				default:
					return false;
			}
		}

		public static string[] Fragment(string str)
		{
			str = str+" ";
			System.Collections.Queue que = new System.Collections.Queue();
			string cur;
			bool found;
			int i=0, start, end;

			while (i < str.Length)
			{
				found = false;
				if ((!found) && (IsWhite(str[i])))
				{
					start = i;
					end=i+1;
					found = true;
					while ((end<str.Length)&&(IsWhite(str[end])))
					{
						end++;
					}
					//	cur = str.Substring(start, end-start);
					i = end;
					//	que.Enqueue(cur);
				}
				if ((!found)&&(str[i]=='"'))
				{
					found = true;
					start = i;
					end = start+1;
					while ((str[end]!='"')||(str[end-1]=='\\'))
					{
						end++;
					}
					end++;
					cur = str.Substring(start, end-start);
					cur = RemoveBackslashes(cur);
					i = end;
					que.Enqueue(cur);
				}
				if ((!found) && (IsNumber(str[i])))
				{
					start = i;
					end=i+1;
					found = true;
					while (IsNumber(str[end]) || (str[end]=='.'))
						end++;
					cur = str.Substring(start, end-start);
					i = end;
					que.Enqueue(cur);
				}
				if ((!found) && (IsLetter(str[i])))
				{
					start = i;
					end=i+1;
					found = true;
					while (IsLetter(str[end]))
						end++;
					cur = str.Substring(start, end-start);
					i = end;
					que.Enqueue(cur);
				}
				if ((!found)&&(str[i]=='/')&&(str[i+1]=='*'))
				{
					found = true;
					start = 1;
					end = i+2;
					while ((end < str.Length)&&((str[end]!='/')||(str[end-1]!='*')))
					{
						end++;
					}
					end++;
					cur = str.Substring(start, end-start);
					i = end;
					//que.Enqueue(cur);
				}
				if ((!found)&&(str[i]=='/')&&(str[i+1]=='/'))
				{
					found = true;
					start = 1;
					end = i+1;
					while ((end < str.Length) && (str[end]!='\n'))
					{
						end++;
					}
					cur = str.Substring(start, end-start);
					i = end;
					//que.Enqueue(cur);
				}
				if ((!found)&&(IsOperator(str[i])))
				{
					found = true;
					if (!IsDoubleOperator(str[i], str[i+1]))
					{
						cur = str.Substring(i,1);
						que.Enqueue(cur);
						i++;
					}
					else
					{
						cur = str.Substring(i,2);
						que.Enqueue(cur);
						i+=2;
					}
				}


				if (!found)
				{
					cur = System.Char.ToString(str[i]);
					que.Enqueue(cur);
					i++;
				}
			}

			string[] ans = new string[que.Count];
			i=0;
			while (que.Count!=0)
			{
				ans[i] = (string)que.Dequeue();
				i++;
			}
			return ans;
		}
	};
}