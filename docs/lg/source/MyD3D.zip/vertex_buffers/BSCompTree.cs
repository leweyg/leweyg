using System;
using System.Collections;
using System.Drawing; //for Color
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace vertex_buffers
{
	public class CompNode
	{
		public Vector3 Pos;
		public ArrayList Children;

		public CompNode()
		{
			Pos = new Vector3(0, 0, 0);
			Children = new ArrayList();
		}

		public virtual void SelfRender(Device dev) {}

		public void Render(Device dev)
		{
			Matrix orig = dev.GetTransform(TransformType.World);

			Matrix work = dev.GetTransform( TransformType.World );
			work.Translate( Pos );
			dev.SetTransform( TransformType.World, work );
			Matrix test = dev.GetTransform( TransformType.World );


			SelfRender(dev);

			foreach(object ob in Children)
			{
				((CompNode)ob).Render( dev );
			}

			dev.SetTransform( TransformType.World, orig );
		}
	};

	public class Polygon : CompNode
	{
		private CustomVertex.PositionColored[] points;

		public override void SelfRender(Device dev)
		{
			dev.DrawUserPrimitives(PrimitiveType.TriangleFan,
				points.Length-2,
				points);
		}

		public void SimpleQuad(float side)
		{
			side /= 2;
			points = new CustomVertex.PositionColored[4];
			points[0] = new CustomVertex.PositionColored( -side, -side, 0, Color.Red.ToArgb() );
			points[1] = new CustomVertex.PositionColored(  side, -side, 0, Color.Green.ToArgb() );
			points[2] = new CustomVertex.PositionColored(  side,  side, 0, Color.Blue.ToArgb() );
			points[3] = new CustomVertex.PositionColored( -side,  side, 0, Color.Yellow.ToArgb() );
		}
	}

	public class CompTree
	{
		public CompNode Root;

		public void Render(Device dev)
		{
			dev.SetRenderState( RenderStates.Lighting, 0 );

			Root.Render(dev);
		}

		public CompTree()
		{
			Root = new CompNode();
		}
	}
}
