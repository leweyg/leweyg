//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ShuzzleWin.rc
//
#define IDD_Controls                    101
#define IDR_MENU1                       102
#define IDD_About                       103
#define IDI_ICON1                       104
#define IDD_Objective                   105
#define ID_GAME_EXIT                    40001
#define IDM_Main_Controls               40002
#define ID_GAME_SHOWVISABLEOBJECTS      40004
#define ID_GAME_RESTARTLEVEL            40005
#define ID_GAME_SKIPTOLEVEL_1           40007
#define ID_GAME_SKIPTOLEVEL_2           40008
#define ID_GAME_SKIPTOLEVEL_3           40009
#define ID_GAME_SKIPTOLEVEL_4           40010
#define ID_GAME_SKIPTOLEVEL_5           40011
#define ID_GAME_SKIPTOLEVEL_6           40012
#define ID_GAME_SKIPTOLEVEL_7           40013
#define ID_GAME_SKIPTOLEVEL_8           40014
#define ID_GAME_SKIPTOLEVEL_9           40015
#define ID_HELP_ABOUT                   40016
#define ID_HELP_OBJECTIVE               40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
