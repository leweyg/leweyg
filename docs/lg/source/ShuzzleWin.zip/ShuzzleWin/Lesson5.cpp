/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include <windows.h>		// Header File For Windows
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include "resource.h"

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		MainWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInst;		// Holds The Instance Of The Application


//
// Win32 OS Binding
//

#include "../cppforref/lewcid/OSBinding_Win32.cpp"

//
// Include Lewcid
//

#include "../cppforref/lewcid/lewcid.h"
#include "../cppforref/lewcid/utils.h"


//
// Shuzzle Implimentation
//

#include "../cppforref/lewcid/ShuzzleGame.cpp"


//
// Lewcid game code
//

bool IsShiftDown = false;

void Test_EachFrame()
{
	SetupCamera();
	Core.Render();
}

void Test_MoveDirection(int dir)
{
	fpnt v = Core.Graphics->CameraLookDir->mPos;
	v.z = 0;
	v.Normalize();
	
	if (dir==1)
		v *= -1;
	if ((dir/2)==1)
	{
		v = v.Cross( FPNT(0, 0, 1) );
		if (dir==3)
			v *= -1;
	}
	v *= 0.25;

	v += GGame->CameraLookAt->mPos;
	v = GGame->CameraBounds.Clip(v);
	GGame->CameraLookAt->mPos = v;
	SetupCamera();
}

const int NumZooms = 5;
int CurZoom = 0;
float ZoomValues[NumZooms] = {45, 35, 25, 65, 55 };

void Test_KeyDown(char let)
{
	switch(let)
	{
	case ' ':
		IsShiftDown = true;
		break;
	}
}

void Test_KeyUp(char let)
{
	if ((let >= 'A') && (let <= 'Z'))
		let -= ('A' - 'a');

	if ((let >= '1') && (let <= '9'))
	{
		GGame->GotoLevel(let-'0');
		GGame->SetIsInv((let-'0')>2);
	}

	switch (let)
	{
	case 'a':
		Test_MoveDirection(2);
		break;
	case 'd':
		Test_MoveDirection(3);
		break;
	case 's':
		Test_MoveDirection(1);
		break;
	case 'w':
		Test_MoveDirection(0);
		break;

	case 'r':
		{
			bool ni = GGame->GetIsInv();
			if (GGame->mLevel > 2)
				ni = false;
			GGame->GotoLevel( GGame->mLevel );
			GGame->SetIsInv(ni);
		}
		break;
	case 'g':
		if (GGame->GetIsInv())
			GGame->SetIsInv(false);
		else
		{
			ShowMessage("Can't be any easier, sorry.", "Shuzzle");
		}
		break;

	case ' ':
		IsShiftDown = false;
		break;
	case 'p':
		GGame->SetIsInv( !GGame->GetIsInv() );
		break;
	}
	SetupCamera();
}


#define DM_NONE		0
#define DM_CAMERA	1
#define DM_LIGHT	2
#define DM_BLOCK	3
#define BUTTON_LEFT		(1<<0)
#define BUTTON_RIGHT	(1<<1)
#define BUTTON_BOTH		(BUTTON_LEFT | BUTTON_RIGHT)
int DragMode = DM_NONE;
uint ButtonState = 0;
Block* DraggedBlock = 0;
ipnt DragTotal;
const int ActiveDist = 40;

void Test_LevelChanged(void* data)
{
	DragMode = DM_NONE;
	ButtonState = 0;
	DraggedBlock = 0;
}

int BestDragAxis(ipnt* dragtotal)
{
	fpnt drag = ITOFPNT(*dragtotal);
	float len = drag.Length();
	drag.Normalize();
	drag *= len-ActiveDist;
	*dragtotal = FTOIPNT( drag );
	int besti=-1;
	float bestd = -100;
	fpnt work2, work;
	drag.z = 0;
	ipnt* to;
	
	for (int i=0; i<4; i++)
	{
		to = (ipnt*)&Dirs[i][0];
		work = ITOFPNT(DraggedBlock->mCenter);
		work2 = Core.Graphics->Project( work + ITOFPNT(*to) );
		work = Core.Graphics->Project( work );
		work2 -= work;
		work2.z = 0;

		float cd = drag.Dot( work2 );
		if (cd > bestd)
		{
			bestd = cd;
			besti = i;
		}
	}

	return besti;
}

bool ScreenToPoint(int scrx, int scry, float height, fpnt* ans)
{
	fpnt del = Core.Graphics->LookDir(scrx, scry);
	del.Normalize();
	float len = (Core.Graphics->CameraPos->mPos.z - GGame->LightHeight());
	if (del.z < 0)
	{
		len /= del.z;
		fpnt nval = Core.Graphics->CameraPos->mPos - (del*len);
		nval.z = GGame->LightHeight();

		*ans = nval;
		return true;
	}
	return false;
}

void Test_MouseDrag(int scrx, int scry, int dx, int dy)
{
	if (DragMode==DM_NONE)
		return;

	DragTotal.x += dx;
	DragTotal.y += dy;
	int m = ActiveDist;

	if (DragMode == DM_BLOCK)
	{
		if (ButtonState==BUTTON_LEFT)
		{
			if (IsShiftDown)
			{
				if (DragTotal.y > m)
				{
					DraggedBlock->Shift( IPNT(0,0,-1) );
					DragTotal.y -= m;
				}
				if (DragTotal.y < -m)
				{
					DraggedBlock->Shift( IPNT(0,0,1) );
					DragTotal.y += m;
				}
			}
			else
			{
				fpnt drag = ITOFPNT( DragTotal );
				if (drag.Length() >= m)
				{
					int besti = BestDragAxis(&DragTotal);
					if (besti!=-1)
					{
						ipnt* to = (ipnt*)&Dirs[besti][0];
						DraggedBlock->Shift( *to );
					}
				}
			}
		}
		if (ButtonState==BUTTON_RIGHT)
		{
			if (IsShiftDown)
			{
				if (DragTotal.x > m)
				{
					DraggedBlock->Spin(true);
					DragTotal.x -= m;
				}
				if (DragTotal.x < -m)
				{
					DraggedBlock->Spin(false);
					DragTotal.x += m;
				}
			}
			else
			{
				fpnt drag = ITOFPNT( DragTotal );
				if (drag.Length() >= m)
				{
					int besti = BestDragAxis(&DragTotal);
					if (besti!=-1)
					{
						int i = ((besti/2)+1)%2;
						bool neg = ((besti%2)==1);
						if (i==0)
							neg = !neg;
						DraggedBlock->Flip(i, neg);
					}
				}
			}
		}
	}

	if (DragMode == DM_LIGHT)
	{
		fpnt del = Core.Graphics->LookDir(scrx, scry);
		del.Normalize();
		float len = (Core.Graphics->CameraPos->mPos.z - GGame->LightHeight());
		len /= del.z;
		if (del.z < 0)
		{
			fpnt nval = Core.Graphics->CameraPos->mPos - (del*len);
			nval.z = GGame->LightHeight();

			//if (!GGame->CameraBounds.Includes(IPNT(nval.x, nval.y, nval.z)))
			{
				nval = GGame->CameraBounds.Clip( nval );
			}

			Core.Graphics->LightPos->mPos = nval;
			SetupCamera();
		}
	}

	if (DragMode==DM_CAMERA)
	{
		if (ButtonState==BUTTON_LEFT)
		{
			fpnt front = Core.Graphics->CameraLookDir->mPos;
			front.z = 0;
			front.Normalize();
			fpnt side = front.Cross(FPNT(0, 0, 1));

			front *= ((float)dy) / 35.0f;
			side *= ((float)dx) / 35.0f;
			front += side + GGame->CameraLookAt->mPos;
			front = GGame->CameraBounds.Clip(front);
			GGame->CameraLookAt->mPos = front;
			SetupCamera();
		}
		if (ButtonState==BUTTON_RIGHT)
		{
			float fx = (150 * ((float)dx)) / 320.0f;
			float fy = (150 * ((float)dy)) / 320.0f;

			GGame->CameraAng -= fx;
			GGame->CameraPitch += fy;

			float max = 65;
			float min = 10;
			if (GGame->CameraPitch < min)
				GGame->CameraPitch = min;

			if (GGame->CameraPitch > max)
				GGame->CameraPitch = max;

			SetupCamera();
		}
	}
}

bool DoesHitLight(int x, int y)
{
	fpnt dir = Core.Graphics->LookDir(x, y);
	fpnt cam = Core.Graphics->CameraPos->mPos - Core.Graphics->LightPos->mPos;
	return (GGame->mLightMesh->PolyHitTest(cam, dir)!=-1);
}

void Test_MouseDown(int x, int y, bool isright)
{
	DragTotal.Set(0, 0, 0);
	FlagOn(ButtonState, ((isright)? BUTTON_RIGHT : BUTTON_LEFT ) );
	if (DoesHitLight(x,y))
	{
		DragMode = DM_LIGHT;
		return;
	}
	ResCompNode* node = Core.Graphics->HitCompNode( x, y );
	if ((!node) || (!node->mToken))
	{
		DragMode = DM_CAMERA;
	}
	else
	{
		DragMode = DM_BLOCK;
		DraggedBlock = (Block*)node->mToken;
	}
}

void Test_MouseUp(int x, int y, bool isright)
{
	//todo: only unflag the mouse that was let up
	DragMode = DM_NONE;
	ButtonState = 0;
}

void Test_GLSettings(void* data)
{
//	glShadeModel(GL_FLAT);
//	glDisable(GL_CULL_FACE);
}

void Test_Main()
{
	GGame = Game::Create();
	LC_Event_GLSettingsInit = Test_GLSettings;
	//Core.Graphics->mIsShiny = true;

	Core.Graphics->BackgroundColor = ResColor::Create( 98.0/255.0, 120.0/255.0, 191.0/255.0, 1.0);
	//Core.Graphics->BackgroundColor = ResColor::Create( Color4f::FromRGB( 0x005073 ) );

	uint smask = Core.Graphics->AddRenderStage(MeshFormat::Create(4, false));
	SolidRenderContext = smask;


	ResCompNode* root = ResCompNode::Create(0);
	Core.mRootNode = root;

	//Board* board = GenBoard_Level2();
	Board* board = GenBoard_Level1();
	//Board* board = GenBoard_Cuzzle();
	GGame->Init(root, 1, board);
	GGame->SetIsInv(false);

	SetupCamera();
	GGame->mEvent_LevelChanged = Test_LevelChanged;
}






















bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

int ScrSizeW=640, ScrSizeH=480;
int MenuYOffset=0;

GLfloat	rtri;				// Angle For The Triangle ( NEW )
GLfloat	rquad;				// Angle For The Quad ( NEW )

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	Core.Graphics->ScrWidth = width;
	Core.Graphics->ScrHeight = height;
	/*
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
	*/
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	/*
	glShadeModel(GL_SMOOTH);							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// Really Nice Perspective Calculations
	*/
	return TRUE;										// Initialization Went OK
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	Test_EachFrame();

	/*
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear Screen And Depth Buffer
	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(-1.5f,0.0f,-6.0f);						// Move Left 1.5 Units And Into The Screen 6.0
	glRotatef(rtri,0.0f,1.0f,0.0f);						// Rotate The Triangle On The Y axis ( NEW )
	glBegin(GL_TRIANGLES);								// Start Drawing A Triangle
		glColor3f(1.0f,0.0f,0.0f);						// Red
		glVertex3f( 0.0f, 1.0f, 0.0f);					// Top Of Triangle (Front)
		glColor3f(0.0f,1.0f,0.0f);						// Green
		glVertex3f(-1.0f,-1.0f, 1.0f);					// Left Of Triangle (Front)
		glColor3f(0.0f,0.0f,1.0f);						// Blue
		glVertex3f( 1.0f,-1.0f, 1.0f);					// Right Of Triangle (Front)
		glColor3f(1.0f,0.0f,0.0f);						// Red
		glVertex3f( 0.0f, 1.0f, 0.0f);					// Top Of Triangle (Right)
		glColor3f(0.0f,0.0f,1.0f);						// Blue
		glVertex3f( 1.0f,-1.0f, 1.0f);					// Left Of Triangle (Right)
		glColor3f(0.0f,1.0f,0.0f);						// Green
		glVertex3f( 1.0f,-1.0f, -1.0f);					// Right Of Triangle (Right)
		glColor3f(1.0f,0.0f,0.0f);						// Red
		glVertex3f( 0.0f, 1.0f, 0.0f);					// Top Of Triangle (Back)
		glColor3f(0.0f,1.0f,0.0f);						// Green
		glVertex3f( 1.0f,-1.0f, -1.0f);					// Left Of Triangle (Back)
		glColor3f(0.0f,0.0f,1.0f);						// Blue
		glVertex3f(-1.0f,-1.0f, -1.0f);					// Right Of Triangle (Back)
		glColor3f(1.0f,0.0f,0.0f);						// Red
		glVertex3f( 0.0f, 1.0f, 0.0f);					// Top Of Triangle (Left)
		glColor3f(0.0f,0.0f,1.0f);						// Blue
		glVertex3f(-1.0f,-1.0f,-1.0f);					// Left Of Triangle (Left)
		glColor3f(0.0f,1.0f,0.0f);						// Green
		glVertex3f(-1.0f,-1.0f, 1.0f);					// Right Of Triangle (Left)
	glEnd();											// Done Drawing The Pyramid

	glLoadIdentity();									// Reset The Current Modelview Matrix
	glTranslatef(1.5f,0.0f,-7.0f);						// Move Right 1.5 Units And Into The Screen 7.0
	glRotatef(rquad,1.0f,1.0f,1.0f);					// Rotate The Quad On The X axis ( NEW )
	glBegin(GL_QUADS);									// Draw A Quad
		glColor3f(0.0f,1.0f,0.0f);						// Set The Color To Green
		glVertex3f( 1.0f, 1.0f,-1.0f);					// Top Right Of The Quad (Top)
		glVertex3f(-1.0f, 1.0f,-1.0f);					// Top Left Of The Quad (Top)
		glVertex3f(-1.0f, 1.0f, 1.0f);					// Bottom Left Of The Quad (Top)
		glVertex3f( 1.0f, 1.0f, 1.0f);					// Bottom Right Of The Quad (Top)
		glColor3f(1.0f,0.5f,0.0f);						// Set The Color To Orange
		glVertex3f( 1.0f,-1.0f, 1.0f);					// Top Right Of The Quad (Bottom)
		glVertex3f(-1.0f,-1.0f, 1.0f);					// Top Left Of The Quad (Bottom)
		glVertex3f(-1.0f,-1.0f,-1.0f);					// Bottom Left Of The Quad (Bottom)
		glVertex3f( 1.0f,-1.0f,-1.0f);					// Bottom Right Of The Quad (Bottom)
		glColor3f(1.0f,0.0f,0.0f);						// Set The Color To Red
		glVertex3f( 1.0f, 1.0f, 1.0f);					// Top Right Of The Quad (Front)
		glVertex3f(-1.0f, 1.0f, 1.0f);					// Top Left Of The Quad (Front)
		glVertex3f(-1.0f,-1.0f, 1.0f);					// Bottom Left Of The Quad (Front)
		glVertex3f( 1.0f,-1.0f, 1.0f);					// Bottom Right Of The Quad (Front)
		glColor3f(1.0f,1.0f,0.0f);						// Set The Color To Yellow
		glVertex3f( 1.0f,-1.0f,-1.0f);					// Top Right Of The Quad (Back)
		glVertex3f(-1.0f,-1.0f,-1.0f);					// Top Left Of The Quad (Back)
		glVertex3f(-1.0f, 1.0f,-1.0f);					// Bottom Left Of The Quad (Back)
		glVertex3f( 1.0f, 1.0f,-1.0f);					// Bottom Right Of The Quad (Back)
		glColor3f(0.0f,0.0f,1.0f);						// Set The Color To Blue
		glVertex3f(-1.0f, 1.0f, 1.0f);					// Top Right Of The Quad (Left)
		glVertex3f(-1.0f, 1.0f,-1.0f);					// Top Left Of The Quad (Left)
		glVertex3f(-1.0f,-1.0f,-1.0f);					// Bottom Left Of The Quad (Left)
		glVertex3f(-1.0f,-1.0f, 1.0f);					// Bottom Right Of The Quad (Left)
		glColor3f(1.0f,0.0f,1.0f);						// Set The Color To Violet
		glVertex3f( 1.0f, 1.0f,-1.0f);					// Top Right Of The Quad (Right)
		glVertex3f( 1.0f, 1.0f, 1.0f);					// Top Left Of The Quad (Right)
		glVertex3f( 1.0f,-1.0f, 1.0f);					// Bottom Left Of The Quad (Right)
		glVertex3f( 1.0f,-1.0f,-1.0f);					// Bottom Right Of The Quad (Right)
	glEnd();											// Done Drawing The Quad

	rtri+=0.2f;											// Increase The Rotation Variable For The Triangle ( NEW )
	rquad-=0.15f;										// Decrease The Rotation Variable For The Quad ( NEW )
	*/
	return TRUE;										// Keep Going
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(MainWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (MainWnd && !DestroyWindow(MainWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release MainWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		MainWnd=NULL;										// Set MainWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInst))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInst=NULL;									// Set hInst To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInst			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInst;							// Set The Instance
	wc.hIcon			= LoadIcon(hInst, (LPCSTR)IDI_ICON1); //LoadIcon(NULL, IDI_WINLOGO);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= (LPCSTR)IDR_MENU1;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","Shuzzle",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(MainWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								100, 100,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInst,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		8,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(MainWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(MainWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(MainWnd);						// Slightly Higher Priority
	SetFocus(MainWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}


LRESULT CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
				break;
			}
			break;
	}
    return FALSE;
}

#define SkipToLevel(X)	case ID_GAME_SKIPTOLEVEL_##X: Test_KeyUp('0'+X); break;

int LastMX, LastMY;
LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
	case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			// LoWord Can Be WA_INACTIVE, WA_ACTIVE, WA_CLICKACTIVE,
			// The High-Order Word Specifies The Minimized State Of The Window Being Activated Or Deactivated.
			// A NonZero Value Indicates The Window Is Minimized.
			if ((LOWORD(wParam) != WA_INACTIVE) && !((BOOL)HIWORD(wParam)))
				active=TRUE;						// Program Is Active
			else
				active=FALSE;						// Program Is No Longer Active
			
			return 0;								// Return To The Message Loop
		}
		
	case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
			case SC_SCREENSAVE:					// Screensaver Trying To Start?
			case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}
	case WM_COMMAND:
		{
			int wmId    = LOWORD(wParam); 
			int wmEvent = HIWORD(wParam); 
			// Parse the menu selections:
			switch (wmId)
			{
			case ID_GAME_EXIT:
				PostQuitMessage(0);
				break;
			SkipToLevel(1);
			SkipToLevel(2);
			SkipToLevel(3);
			SkipToLevel(4);
			SkipToLevel(5);
			SkipToLevel(6);
			SkipToLevel(7);
			SkipToLevel(8);
			SkipToLevel(9);
			case ID_GAME_RESTARTLEVEL:
				Test_KeyUp('r');
				break;
			case ID_GAME_SHOWVISABLEOBJECTS:
				Test_KeyUp('g');
				break;
			case IDM_Main_Controls:
				{
					//IDM_Main_Controls
					DialogBox(hInst, (LPCTSTR)IDD_Controls, hWnd, (DLGPROC)AboutProc);
				}
				break;
			case ID_HELP_ABOUT:
				DialogBox(hInst, (LPCTSTR)IDD_About, hWnd, (DLGPROC)AboutProc);
				break;
			case ID_HELP_OBJECTIVE:
				DialogBox(hInst, (LPCTSTR)IDD_Objective, hWnd, (DLGPROC)AboutProc);
				break;
			}
			return 0;
		}
	case WM_CLOSE:								// Did We Receive A Close Message?
		{
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}
	case WM_LBUTTONDOWN:
	case WM_RBUTTONDOWN:
		{
			LastMX = LOWORD(lParam);
			LastMY = HIWORD(lParam)+MenuYOffset;
			Test_MouseDown( LastMX, LastMY, 
				(uMsg == WM_RBUTTONDOWN) );
			return 0;
		}
	case WM_LBUTTONUP:
	case WM_RBUTTONUP:
		{
			LastMX = LOWORD(lParam);
			LastMY = HIWORD(lParam)+MenuYOffset;
			Test_MouseUp( LastMX, LastMY, 
				(uMsg == WM_RBUTTONDOWN) );
			return 0;
		}
	case WM_MOUSEMOVE:
		{
			int cx = LOWORD(lParam);
			int cy = HIWORD(lParam)+MenuYOffset;
			Test_MouseDrag( cx, cy,
				cx-LastMX, cy-LastMY );
			LastMX = cx;
			LastMY = cy;
			return 0;
		}
		
	case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			Test_KeyDown( wParam );
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}
		
	case WM_KEYUP:								// Has A Key Been Released?
		{
			Test_KeyUp( wParam );
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}
		
	case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}
	
	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

int WINAPI WinMain(	HINSTANCE	hInst,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	// Ask The User Which Screen Mode They Prefer
//	if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
	{
		fullscreen=FALSE;							// Windowed Mode
	}

	// Create Our OpenGL Window
	if (!CreateGLWindow("Shuzzle - by Lewey Geselowitz - leweyg.com",ScrSizeW,ScrSizeH,16,fullscreen))
	{
		return 0;									// Quit If Window Was Not Created
	}

	RECT cr;
	GetClientRect(MainWnd, &cr);
	Core.Graphics->ScrHeight = cr.bottom;
	Core.Graphics->ScrWidth = cr.right;

	SetRandomSeed();
	Test_Main();

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawGLScene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}

			if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				KillGLWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!CreateGLWindow("NeHe's Solid Object Tutorial",640,480,16,fullscreen))
				{
					return 0;						// Quit If Window Was Not Created
				}
			}
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
