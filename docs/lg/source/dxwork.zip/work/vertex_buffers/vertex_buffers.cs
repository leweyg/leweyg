//
// VertexBuffers.cs - Drunken Hyena Vertex Buffers Tutorial
//
// Copyright (c) 2004 Drunken Hyena
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the Drunken Hyena License.  If a copy of the license was
// not included with this software, you may get a copy from:
// http://www.drunkenhyena.com/docs/DHLicense.txt

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using D3D = Microsoft.DirectX.Direct3D;
using vertex_buffers;


namespace DrunkenHyena{

public class VertexBuffersTutorial : D3DApp {

   protected static new string m_name="VertexBuffers Tutorial";
   protected bool m_wireframe=false;
	protected CompTree mCompTree;

   //The triangle data
   protected D3D.CustomVertex.TransformedColored[] m_list;

   //Vertex Buffer that will hold the data
   protected D3D.VertexBuffer m_vb;

   /// <summary>
   /// Simple Constructor - Calls the base constructor and then initializes the data
   /// </summary>
   /// <param name="p_name">Name of the Application - Used for the Window title</param>
   /// <param name="p_size">Size of rendering area</param>
   /// <param name="p_fullscreen">Full-screen or Windowed mode</param>
   public VertexBuffersTutorial(string p_name,Size p_size,bool p_fullscreen) : base(p_name,p_size,p_fullscreen){

      init_data();

   }


   /// <summary>
   /// init_data - This function allocates and initializes the data in the vertex array.  A VertexBuffer
   ///             is allocated and then initialized from the data in the data array
   /// </summary>
   protected void init_data(){

      m_list=new D3D.CustomVertex.TransformedColored[42];
      //Fan1
      m_list[0]=new D3D.CustomVertex.TransformedColored(100.0f,100.0f,1.0f,1.0f,Color.Black.ToArgb());
      m_list[1]=new D3D.CustomVertex.TransformedColored(  0.0f,  0.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[2]=new D3D.CustomVertex.TransformedColored(200.0f,  0.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[3]=new D3D.CustomVertex.TransformedColored(100.0f,100.0f,1.0f,1.0f,Color.Black.ToArgb());
      m_list[4]=new D3D.CustomVertex.TransformedColored(200.0f,  0.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[5]=new D3D.CustomVertex.TransformedColored(200.0f,200.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[6]=new D3D.CustomVertex.TransformedColored(100.0f,100.0f,1.0f,1.0f,Color.Black.ToArgb());
      m_list[7]=new D3D.CustomVertex.TransformedColored(200.0f,200.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[8]=new D3D.CustomVertex.TransformedColored(  0.0f,200.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[9]=new D3D.CustomVertex.TransformedColored(100.0f,100.0f,1.0f,1.0f,Color.Black.ToArgb());
      m_list[10]=new D3D.CustomVertex.TransformedColored(  0.0f,200.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[11]=new D3D.CustomVertex.TransformedColored(  0.0f,  0.0f,1.0f,1.0f,Color.Red.ToArgb());
      //Fan2
      m_list[12]=new D3D.CustomVertex.TransformedColored( 75.0f,350.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[13]=new D3D.CustomVertex.TransformedColored(  0.0f,225.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[14]=new D3D.CustomVertex.TransformedColored( 50.0f,215.0f,1.0f,1.0f,Color.FromArgb(0xF7,0xF7,0x00).ToArgb());
      m_list[15]=new D3D.CustomVertex.TransformedColored( 75.0f,350.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[16]=new D3D.CustomVertex.TransformedColored( 50.0f,215.0f,1.0f,1.0f,Color.FromArgb(0xF7,0xF7,0x00).ToArgb());
      m_list[17]=new D3D.CustomVertex.TransformedColored( 75.0f,205.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[18]=new D3D.CustomVertex.TransformedColored( 75.0f,350.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[19]=new D3D.CustomVertex.TransformedColored( 75.0f,205.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[20]=new D3D.CustomVertex.TransformedColored(125.0f,215.0f,1.0f,1.0f,Color.FromArgb(0x00,0xF7,0xF7).ToArgb());
      m_list[21]=new D3D.CustomVertex.TransformedColored( 75.0f,350.0f,1.0f,1.0f,Color.White.ToArgb());
      m_list[22]=new D3D.CustomVertex.TransformedColored(125.0f,215.0f,1.0f,1.0f,Color.FromArgb(0x00,0xF7,0xF7).ToArgb());
      m_list[23]=new D3D.CustomVertex.TransformedColored(150.0f,235.0f,1.0f,1.0f,Color.Blue.ToArgb());
      //Strip1
      m_list[24]=new D3D.CustomVertex.TransformedColored(250.0f,150.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[25]=new D3D.CustomVertex.TransformedColored(300.0f, 50.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[26]=new D3D.CustomVertex.TransformedColored(350.0f,150.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[27]=new D3D.CustomVertex.TransformedColored(300.0f, 50.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[28]=new D3D.CustomVertex.TransformedColored(400.0f, 50.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[29]=new D3D.CustomVertex.TransformedColored(350.0f,150.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[30]=new D3D.CustomVertex.TransformedColored(400.0f, 50.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[31]=new D3D.CustomVertex.TransformedColored(450.0f,150.0f,1.0f,1.0f,Color.FromArgb(0xF7,0xF7,0x00).ToArgb());
      m_list[32]=new D3D.CustomVertex.TransformedColored(350.0f,150.0f,1.0f,1.0f,Color.Blue.ToArgb());
      //Strip2
      m_list[33]=new D3D.CustomVertex.TransformedColored(250.0f,350.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[34]=new D3D.CustomVertex.TransformedColored(300.0f,250.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[35]=new D3D.CustomVertex.TransformedColored(350.0f,350.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[36]=new D3D.CustomVertex.TransformedColored(300.0f,250.0f,1.0f,1.0f,Color.Green.ToArgb());
      m_list[37]=new D3D.CustomVertex.TransformedColored(400.0f,250.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[38]=new D3D.CustomVertex.TransformedColored(350.0f,350.0f,1.0f,1.0f,Color.Blue.ToArgb());
      m_list[39]=new D3D.CustomVertex.TransformedColored(400.0f,250.0f,1.0f,1.0f,Color.Red.ToArgb());
      m_list[40]=new D3D.CustomVertex.TransformedColored(450.0f,350.0f,1.0f,1.0f,Color.FromArgb(0xF7,0xF7,0x00).ToArgb());
      m_list[41]=new D3D.CustomVertex.TransformedColored(350.0f,350.0f,1.0f,1.0f,Color.Blue.ToArgb());

      //The following 3 lines are not needed.  The equivalent values could be passed directly to the
      //VertexBuffer constructor.  They are included to keep line lengths shorter and more readable.
      Type vb_type=typeof(D3D.CustomVertex.TransformedColored);
      D3D.VertexFormats vb_format=D3D.CustomVertex.TransformedColored.Format;
      D3D.Usage usage=D3D.Usage.WriteOnly | D3D.Usage.SoftwareProcessing;

      //Allocate the VertexBuffer
      m_vb=new D3D.VertexBuffer(vb_type,              //The Type of our VertexBuffer
                                m_list.Length,        //Number of Vertices that will be stored
                                m_device,             //The device to associate with the VertexBuffer
                                usage,                //Usage Flags
                                vb_format,            //The VertexFormat of the VertexBuffer
                                D3D.Pool.Managed);    //The memory Pool that should be used for the Vertex Buffer

      //Copy the data from our array into the VertexBuffer
      m_vb.SetData(m_list,             //The data array to copy from
                   0,                  //Start location in the VB, this is where the data is copied to
                   D3D.LockFlags.None);//No special flags

	   //Lewey stuff
       mCompTree = new CompTree();
	   Polygon sp = new Polygon();
	   sp.SimpleQuad( 3 );
	   sp.Pos = new Vector3(2, 0, 0);
	   mCompTree.Root.Children.Add( sp );

	   Polygon np = new Polygon();
	   np.SimpleQuad( 2 );
	   np.Pos = new Vector3(2, 0, 0);
	   sp.Children.Add( np );
	   np.Transforms.Add( new RotateTransform(new Vector3(1,0,0), (float)Math.PI/6));

	   mCompTree.Root.Transforms.Add( new RotateTransform(new Vector3(0,0,1), (float)Math.PI/8) );

   }

   /// <summary>
   /// Render - Overrides our base Render.  Clears the display to CadetBlue and then renders our triangles.
   ///          If m_wireframe is true, all rendering is done in wireframe mode
   /// </summary>
   protected override void Render()
   {
	   mCompTree.Render(m_device, ((float)Width) / ((float)Height) );

      m_device.Present();

   }


   /// <summary>
   /// OnKeyDown - Toggles wireframe mode on/off via the 'w' key.  Passes
   ///             all other keys to our base class for processing
   /// </summary>
   /// <param name="e">The KeyCode of the key pressed</param>
   protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e){

      switch(e.KeyCode) {
         case Keys.W:
            m_wireframe=!m_wireframe;
            break;
         default:
            base.OnKeyDown(e);
            break;
      }

   }

   /// <summary>
   /// The main entry point for the application.
   /// </summary>
   [STAThread]
   static void Main(){

      //The size of our render target, or drawing area
      System.Drawing.Size size=new Size(800,600);

      //Ask the user if the application should run in full-screen or windowed mode
      bool fullscreen = false; //Utility.AskFullscreen(m_name);

      //Create a new instance of our application
      VertexBuffersTutorial app=new VertexBuffersTutorial(m_name,size,fullscreen);

      //Show the window
      app.Show();

      //Loop until the user exits
      while ( app.Created ) { 

         app.Heartbeat(); 

         Application.DoEvents (); 

      } 


   }


}  //VertexBuffersTutorial

}  //namespace
