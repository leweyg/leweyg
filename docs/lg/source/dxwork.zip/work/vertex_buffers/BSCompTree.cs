using System;
using System.Collections;
using System.Drawing; //for Color
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace vertex_buffers
{
	public interface Transform
	{
		void GetMatrix(ref Matrix ans);
	}

	public class RotateTransform : Transform
	{
		public Vector3 Axis;
		public float Angle;

		public void GetMatrix(ref Matrix ans)
		{
			ans.RotateAxis( Axis, ((float)Environment.TickCount) / 450.0f );
		}

		public RotateTransform(Vector3 axis, float angle)
		{
			Axis = axis;
			Angle = angle;
		}
	}


	public class CompNode
	{
		public Vector3 Pos;
		public ArrayList Children;
		public ArrayList Transforms;

		public CompNode()
		{
			Pos = new Vector3(0, 0, 0);
			Children = new ArrayList();
			Transforms = new ArrayList();
		}

		public virtual void SelfRender(Device dev) {}

		public void Render(Device dev)
		{
			Matrix orig = dev.Transform.World;

			Matrix work2 = dev.Transform.World;
			Matrix work1 = Matrix.Translation( Pos );
			work1.Multiply( work2 );
			bool use1 = true;

			for(int i=0; i<Transforms.Count; i++)
			{
				Transform t = (Transform)Transforms[i];
				if (use1)
				{
					t.GetMatrix( ref work2 );
					work2.Multiply( work1 );
				}
				else
				{
					t.GetMatrix( ref work1 );
					work1.Multiply( work2 );
				}
				use1 = !use1;
			}
			if (use1)
				dev.Transform.World = work1;
			else
				dev.Transform.World = work2;


			SelfRender(dev);

			foreach(object ob in Children)
			{
				((CompNode)ob).Render( dev );
			}

			dev.Transform.World = orig;
		}
	};

	/// <summary>
	/// Draws simple concave polygons
	/// Renders as a triangle fan
	/// </summary>
	public class Polygon : CompNode
	{
		private CustomVertex.PositionColored[] points;

		public override void SelfRender(Device dev)
		{
			dev.DrawUserPrimitives(PrimitiveType.TriangleFan,
				points.Length-2,
				points);
		}

		public void SimpleQuad(float side)
		{
			side /= 2;
			float z = 0;
			points = new CustomVertex.PositionColored[4];
			points[0] = new CustomVertex.PositionColored( -side, -side, z, Color.Red.ToArgb() );
			points[1] = new CustomVertex.PositionColored(  side, -side, z, Color.Green.ToArgb() );
			points[2] = new CustomVertex.PositionColored(  side,  side, z, Color.Blue.ToArgb() );
			points[3] = new CustomVertex.PositionColored( -side,  side, z, Color.Yellow.ToArgb() );
		}
	}

	public struct fcolor
	{
		public float red, green, blue;

		public int AsInt
		{
			get
			{
				int ans=0;
				ans |= ((int)(blue*255));
				ans |= ((int)(green*255)) << 8;
				ans |= ((int)(red*255)) << 16;
				return ans;
			}
		}

		public fcolor(float r, float g, float b)
		{
			red = r; green = g; blue = b;
		}
	}

	public class CompTree
	{
		public CompNode Root;
		public Vector3 CameraPos, CameraLookAt, CameraUp;
		public bool IsWireFrame;
		public fcolor ClearColor;

		public void Render(Device dev, float screenratio)
		{
			//Clear the render target
			dev.Clear( ClearFlags.Target, ClearColor.AsInt, 1.0f, 0);

			//Signal the device that we're beginning a new scene
			dev.BeginScene();

			//Set render states
			dev.RenderState.CullMode = Cull.None;
			dev.RenderState.ZBufferEnable = true;
			dev.RenderState.Lighting = false;
			dev.VertexFormat= CustomVertex.PositionColored.Format;

			if (IsWireFrame)
				dev.RenderState.FillMode=FillMode.WireFrame;
			else
				dev.RenderState.FillMode=FillMode.Solid;

			//Setup the cameras:
			//dev.Transform.World = Matrix.RotationZ(
			//	Environment.TickCount / 450.0f );
			dev.Transform.World = Matrix.Identity;

			dev.Transform.View = Matrix.LookAtLH( 
				new Vector3( 0.0f, 0.0f,-15.0f ),
				new Vector3( 0.0f, 0.0f, 0.0f ),
				new Vector3( 0.0f, 1.0f, 0.0f ) );

			dev.Transform.Projection = Matrix.PerspectiveFovLH( 
				(float)Math.PI / 4, screenratio, 1.0f, 100.0f );

			//Actually draw the tree
			Root.Render(dev);

			//Signal the device that we're done with our scene
			dev.EndScene();
		}

		public CompTree()
		{
			Root = new CompNode();

			CameraPos = new Vector3(0, 0, -10);
			CameraLookAt = new Vector3(0, 0, 0);
			CameraUp = new Vector3(0, 1, 0);
			ClearColor = new fcolor( 0.8f, 0.9f, 0.8f );

			IsWireFrame = false;
		}
	}
}
