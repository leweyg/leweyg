
/// <summary>
///  AniInk is a set of tools, classes and even a Windows Control which allow for
///  the creation of animated ink. That is they extend the Microsoft Ink classes
///  to allow them to be animated. This system is tightly bound with the Ink classes
///  so that any operation you could perform on normal Ink, can be applied to a single frame
///  from the animation. The animation works by smartly interpolating between ink strokes
///  
///Written and Developed by Lewey Geselowitz
///This software is public domain, which means anyone can use it for whatever you want.
///	(this includes it's inclusion modified or not in proprietary software). If you meantion my
///	name I would be grateful but it is not required, and telling me about it would be great.
///
///Written entirely in C# using the all mighty Visual Studio.Net
///
///email me at: lewey@ufl.edu
///my webpage: http://plaza.ufl.edu/lewey
///
///Special thanks go to the University of Florida
///  for allowing me to developed on one of their TabletPCs.
///To Microsoft for donating the TabletPC to UF and
///  writing the .Net Framework and Ink APIs.
///To my advisor Dr. Jorg Peters for his help in my research.
///And to my friends who acted as both my testers and test subjects.
///Thanks to you all!
///    -Lewey G.
/// </summary>
/// 

namespace AniInk
{
	using System;
	using System.Windows.Forms;
	using System.Drawing;
	using System.IO;
	using Microsoft.Ink;

	/// <summary>
	///  InkInterp is a set of interpolation utilities used to perfrom the animation in AniInk
	///  it allows for the interpolation between a number of different types. Including arrays
	///  of points or ints, float, bytes, colours, etc. It also included a "length-wise
	///  resampling or reparameterization" tool which adjusts the control points on a line to more
	///  evenly distribute the controls along the length of the line
	///  
	///  Each of the interpolation utilities usually take three arguements, the first two are the
	///  values to be interpolated between, and the last is a floating point value from 0.0 to 1.0
	///  which decides how far along the interpolation will go.
	/// </summary>
	public class InkInterp	//Ink interpolation utilities
	{
		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static int Interp(int from, int to, float t)
		{
			//interpolates between 'from' and 'to', based on 't'
			//0.0 for from, 1.0 for to, and the linear average in between

			int ans = (int)(((float)(to-from))*t);
			return ans+from;
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static float Interp(float from, float to, float t)
		{
			return (from + (t*(to-from)));
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static Point Interp(Point from, Point to, float t)
		{
			//interpolate between two points

			from.X = Interp(from.X, to.X, t);
			from.Y = Interp(from.Y, to.Y, t);
			return from;
		}

		/// <summary>
		/// This function accesses an array of ints at a floating point index between 0.0 and 1.0
		/// and interpolates between ints when the index is not exact
		/// </summary>
		/// <param name="ptr">array of ints</param>
		/// <param name="at">floating point index from 0.0 to 1.0</param>
		/// <returns></returns>
		public static int GetValue(int[] ptr, float at)
		{
			int size = ptr.Length-1;
			at *= (float)size;
			int i = (int)at;
			at -= (float)i;
			if (i == size)
				return ptr[size];
			if (at==0)
				return ptr[i];
			int cur=ptr[i], next=ptr[i+1];
			cur = Interp(cur, next, at);
			return cur;
		}

		/// <summary>
		/// This function accesses an array of points at a floating point index between 0.0 and 1.0
		/// and interpolates between points when the index is not exact
		/// </summary>
		/// <param name="ptr">array of points</param>
		/// <param name="at">floating point index from 0.0 to 1.0</param>
		/// <returns></returns>
		public static Point GetPoint(Point[] pts, float at)
		{
			//Get the point based on it's floating point index
 
			int size = pts.Length-1;
			at *= (float)size;
			int i = (int)at;
			at -= (float)i;
			if (i == size)
				return pts[size];
			if (at==0)
				return pts[i];
			Point cur=pts[i], next=pts[i+1];
			cur = Interp(cur, next, at);
			return cur;
		}

		/// <summary>
		/// Returns the floating point index (from 0.0 to 1.0) based on the a normal int index.
		/// </summary>
		/// <param name="ar"></param>
		/// <param name="i"></param>
		/// <returns></returns>
		public static float GetFIndex(int[] ar, int i)
		{
			//Get the floating point index from the integer index
			return ((float)i) / ((float)(ar.Length-1));
		}

		/// <summary>
		/// Returns the floating point index (from 0.0 to 1.0) based on the a normal int index.
		/// </summary>
		/// <param name="ar"></param>
		/// <param name="i"></param>
		/// <returns></returns>
		public static float GetFIndex(Point[] ar, int i)
		{
			//Get the floating point index from the integer index
			return ((float)i) / ((float)(ar.Length-1));
		}

		/// <summary>
		/// Interpolate between two piont lines, and store the result in ans. To calculate the answer
		/// the function will sample it at each of it's indexes interpolating between the two.
		/// Floating point indecies are used to resample at the amount neccasary.
		/// </summary>
		/// <param name="from">array of points (t = 0.0)</param>
		/// <param name="to">array of points (t = 1.0)</param>
		/// <param name="t">interpolation value</param>
		/// <param name="ans">array to store answer in</param>
		public static void Interp(Point[] from, Point[] to, float t, Point[] ans)
		{
			float fi;
			for (int i=0; i!=ans.Length; i++)
			{
				fi = GetFIndex(ans, i);
				ans[i] = Interp( GetPoint(from,fi), GetPoint(to,fi), t);
			}
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static byte Interp(byte from, byte to, float t)
		{
			if (to > from)
			{
				t *= (float)(to - from);
				return (byte)(from + ((byte)t));
			}
			if (to == from)
				return to;
			t = 1.0f-t;
			t *= (float)(from-to);
			return (byte)(to+((byte)t));
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static Color Interp(Color from, Color to, float t)
		{
			return Color.FromArgb( Interp((int)from.R,(int)to.R,t), Interp((int)from.G,(int)to.G,t), Interp((int)from.B,(int)to.B,t) );
			//	return Color.FromArgb( (int)Interp(from.R,to.R,t), (int)Interp(from.G,to.G,t), (int)Interp(from.B,to.B,t) );
		}

		/// <summary>
		/// This function interpolates both between the values in the two input point lines, but
		/// also between their size. This way you get a very accurate interpolation which uses
		/// just the right number of points to represent itself.
		/// </summary>
		/// <param name="from">from line (t = 0.0)</param>
		/// <param name="to">to line (t = 1.0)</param>
		/// <param name="t">interpolation value (0.0 to 1.0)</param>
		/// <returns>returns the inpolant between the two arrays</returns>
		public static Point[] Interp(Point[] from, Point[] to, float t)
		{
			Point[] ans = new Point[ Interp(from.Length, to.Length, t) ];
			Interp(from, to, t, ans);
			return ans;
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static void Interp(int[] from, int[] to, float t, int[] ans)
		{
			float fi;
			for (int i=0; i!=ans.Length; i++)
			{
				fi = GetFIndex(ans, i);
				ans[i] = Interp( GetValue(from,fi), GetValue(to,fi), t);
			}
		}

		/// <summary>
		/// Copies the from array into the to array, compensating for the difference in size
		/// by interpolating between values
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void ResampleLine(Point[] from, Point[] to)
		{
			float fi;
			for (int i=0; i!=to.Length; i++)
			{
				fi = GetFIndex(to, i);
				to[i] = GetPoint(from, fi);
			}
		}

		/// <summary>
		/// Copies the from array into the to array, compensating for the difference in size
		/// by interpolating between values
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void ResampleArray(int[] from, int[] to)
		{
			float fi;
			for (int i=0; i!=to.Length; i++)
			{
				fi = GetFIndex(to, i);
				to[i] = GetValue(from, fi);
			}
		}

		/// <summary>
		/// Returns the distance between two points, yes I know this is slow
		/// </summary>
		public static float Dist(Point from, Point to)
		{
			from.X -= to.X;
			from.Y -= to.Y;
			return (float)Math.Sqrt( (double)((from.X*from.X) + (from.Y*from.Y)) );
		}

		/// <summary>
		/// Returns the length of the given point line
		/// </summary>
		public static float LineLength(Point[] pts)
		{
			float sum = 0.0f;
			for (int i=0; i+1 < pts.Length; i++)
			{
				sum += Dist(pts[i], pts[i+1]);
			}
			return sum;
		}

		/// <summary>
		/// Travels along a line a given distance, and returns the point it reaches at that distance
		/// </summary>
		/// <param name="pts">point line</param>
		/// <param name="at">distance to travel</param>
		/// <returns>point at that distance</returns>
		public static Point GetLengthwisePoint(Point[] pts, float at)
		{
			int i=0;
			float curlen=0.0f, lastd=0.0f;
			while (curlen < at)
			{
				lastd = Dist(pts[i], pts[i+1]);
				curlen += lastd;
				i++;
				if (i+1 == pts.Length)
					return pts[pts.Length-1];
			}
			if (curlen == at)
				return pts[i];
			at = ((at-(curlen-lastd)) / lastd);
			return Interp(pts[i-1], pts[i], at);
			//carry on here
		}

		/// <summary>
		/// Resamples the given polygonal line, and stores the result into 'to'. What this essentially
		/// does is make the distance between each point equal by shifting around the points while
		/// still maintaining the shape of the line.
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void LengthwiseResample(Point[] from, Point[] to)
		{
			float total = LineLength(from);
			float step = total / ((float)(from.Length-1));
			for (int i=0; i!=from.Length; i++)
			{
				to[i] = GetLengthwisePoint(from, step*((float)i) );
			}
		}
	}

	/// <summary>
	/// These are just a collection of memory functions I created while I was working. Please
	/// remember that I'm new to C# so some of these could probably have been avoided, but I must
	/// admit they were good learning practise
	/// </summary>
	class Mem
	{
		/// <summary>
		/// Creates a new array of the given type, with the given length. Use it like this:
		/// new_array = (array_type[])NewArray(some_array, length)
		/// </summary>
		/// <param name="likeme">array whose type will be used</param>
		/// <param name="length">number of items in the new array</param>
		public static object[] NewArray(object[] likeme, int length)
		{
			object[] args = new Object[1];
			args[0] = length;
			object[] ans = (object[])( System.Activator.CreateInstance(likeme.GetType(), args));
			return ans;
		}

		/// <summary>
		/// Does the given array include the given object
		/// </summary>
		public static bool Includes(object[] ar, object ob)
		{
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] == ob)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Returns a new array which is like the given one, but doesn't include the given object
		/// Usage: some_array = (some_type[])Remove(some_array, some_object)
		/// </summary>
		public static object[] Remove(object[] ar, object ob)
		{
			if (!Includes(ar, ob))
				return ar;
			object[] nr = NewArray(ar, ar.Length-1);
			int toi = 0;
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] != ob)
				{
					nr[toi] = ar[i];
					toi++;
				}
			}
			return nr;
		}

		/// <summary>
		/// Returns a new array which is like the given one, but also has the given object at
		/// index (after+1)
		/// Usage: some_array = (some_type[])Remove(some_array, some_object, some_int)
		/// </summary>
		public static object[] AddAfter(object[] ar, object ob, int after)
		{
			object[] nr;
			if (ar == null)
			{
				nr = NewArray(ar, 2);
				nr[0] = ob;
				return nr;
			}
			int ito = 0;
			nr = NewArray(ar, ar.Length+1);
			for (int i=0; i!=ar.Length; i++)
			{
				if (after+1 == i)
				{
					nr[ito] = ob;
					ito++;
				}
				nr[ito] = ar[i];
				ito++;
			}
			if (after >= ar.Length-1)
				nr[ar.Length] = ob;
			return nr;
		}

		/// <summary>
		/// Returns a new array which is like the given one, but also has the given object at
		/// it's end.
		/// Usage: some_array = (some_type[])Remove(some_array, some_object)
		/// </summary>
		public static object[] AddToArray(object[] ar, object ob)
		{
			object[] nr;
			if (ar == null)
			{
				nr = NewArray(ar,1);
				nr[0] = ob;
				return nr;
			}
			nr = NewArray(ar, ar.Length+1);
			for (int i=0; i!=ar.Length; i++)
				nr[i] = ar[i];
			nr[ar.Length] = ob;
			return nr;
		}

		/// <summary>
		/// Returns the index of the given object in the given array
		/// </summary>
		public static int GetIndex(object[] ar, object ob)
		{
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] == ob)
					return i;
			}
			return -1;
		}
	}

	/// <summary>
	/// This is a "Stroke In Time" object, it represents a single frame of a single stroke.
	/// Please note that all of it's members are public, this is a performance issue, and I didn't
	/// think constituted a threat as most problems will never even come close to this object
	/// </summary>
	class StrokeIT
	{
		/// <summary>
		/// The time that this stroke first appears
		/// </summary>
		public float StartTime;

		/// <summary>
		/// The set of points which make up the shape of this stroke
		/// </summary>
		public Point[] Points;

		/// <summary>
		/// The pressure at each of the points along this stroke. Although this information
		/// is gathered by the InkCollector, packet data cannot be replaced back into Stroke
		/// objects, it is merely kept until hopefully the API changes
		/// </summary>
		public int[] Pressure;

		/// <summary>
		/// This is the StrokePath which this stroke is a part of
		/// </summary>
		public StrokePath Path;

		/// <summary>
		/// The Color of the stroke
		/// </summary>
		public Color Colour;

		/// <summary>
		/// The width of the stroke
		/// </summary>
		public float Width;

		/// <summary>
		/// This is the time when this stroke ends, this value is calculated by looking
		/// in owning path and getting the start time of the next stroke.
		/// </summary>
		public float EndTime
		{
			get
			{
				int i = Mem.GetIndex( Path.StrokesIT, this);
				if (i < 0)
					return (float)-1.0;
				if (i+1 < Path.StrokesIT.Length)
					return Path.StrokesIT[i+1].StartTime;
				if (Path.DoesEnd)
					return Path.EndTime;
				return (float)-1.0;
			}
		}

		/// <summary>
		/// Returns the index of this StrokeIT it it's owning StrokePath
		/// </summary>
		public int IndexInPath
		{
			get
			{
				for (int i=0; i!=Path.StrokesIT.Length; i++)
				{
					if (Path.StrokesIT[i] == this)
						return i;
				}
				return -1;
			}
		}

		/// <summary>
		/// Move the stroke by adding the given vector to all points.
		/// Vector is given in Ink coordinates
		/// </summary>
		/// <param name="delta">Vector to move all points by</param>
		public void Move(Point delta)
		{
			Point pt;
			for (int i=0; i!=Points.Length; i++)
			{
				pt = Points[i];
				pt.X += delta.X;
				pt.Y += delta.Y;
				Points[i] = pt;
			}
		}

		public void LengthwiseResample()
		{
			Point[] pts = new Point[Points.Length];
			InkInterp.LengthwiseResample(Points, pts);
			Points = pts;
		}

		/// <summary>
		/// Set the values of this StrokeIT based a real Ink Stroke. Note that this does not
		/// set the StartTime or Path of this object
		/// </summary>
		/// <param name="st">The Stroke whose information is to be extracted</param>
		public void FromStroke(Stroke st)
		{
			Points = st.GetPoints();

			LengthwiseResample();

			DrawingAttributes da = st.DrawingAttributes;
			Colour = da.Color;
			Width = da.Width;

			for (int i = 0; i < st.PacketDescription.Length; i++) 
			{
				if (st.PacketDescription[i] == PacketProperty.NormalPressure) 
				{ 
					this.Pressure = st.GetPacketValuesByProperty(PacketProperty.NormalPressure); 
					break; 
				} 
			}
		}

		/// <summary>
		/// Adds an Ink.Stroke object to the given Ink object
		/// </summary>
		/// <param name="to">The Ink to put the Stroke into</param>
		public void AddToInk(Ink to)
		{
			to.CreateStroke( Points );
		}

		/// <summary>
		/// Quickly copies this stroke into the given stroke. It also resamples the points
		/// so as to match the number of points in the 'other' line
		/// </summary>
		/// <param name="other">StrokeIT to copy data into</param>
		public void QuickToStroke(StrokeIT other)
		{
			InkInterp.ResampleLine( Points, other.Points );
			if ((this.Pressure!=null) && (other.Pressure!=null))
			{
				InkInterp.ResampleArray( Pressure, other.Pressure);
			}
			other.Width = Width;
			other.Colour = Colour;
		}

		/// <summary>
		/// Creates a new Ink.Stroke and in the given ink, and copies this strokes values
		/// into it.
		/// </summary>
		/// <param name="ink">Ink object to be added to</param>
		/// <returns>The newly created stroke, copied from this</returns>
		public Stroke ToStroke(Ink ink)
		{
			Stroke st = ink.CreateStroke( Points );
			DrawingAttributes da = st.DrawingAttributes;
			da.Width = Width;
			da.Color = Colour;
			st.DrawingAttributes = da;
			return st;
		}

		/// <summary>
		/// Interpolate between two StrokeITs, and store the result in the given Ink.
		/// </summary>
		/// <param name="from">From stroke (0.0)</param>
		/// <param name="to">ToStroke (1.0)</param>
		/// <param name="t">Interpolation value (0.0 to 1.0)</param>
		/// <param name="ink">Ink to be added to</param>
		/// <returns>The newly created stroke</returns>
		public static Stroke Interp(StrokeIT from, StrokeIT to, float t, Ink ink)
		{
			StrokeIT sit = new StrokeIT( InkInterp.Interp(from.Points.Length, to.Points.Length, t), false);
			Interp(from, to, t, sit);
			return sit.ToStroke(ink);
		}

		/// <summary>
		/// Interpolate between two StrokeITs, and store the result in the given StrokeIT.
		/// </summary>
		/// <param name="from">From stroke (0.0)</param>
		/// <param name="to">ToStroke (1.0)</param>
		/// <param name="t">Interpolation value (0.0 to 1.0)</param>
		/// <param name="ink">StrokeIT to hold result</param>
		public static void Interp(StrokeIT from, StrokeIT to, float t, StrokeIT ans)
		{
			InkInterp.Interp(from.Points, to.Points, t, ans.Points);
			if ((from.Pressure!=null) && (to.Pressure!=null) && (ans.Pressure!=null))
			{
				InkInterp.Interp(from.Pressure, to.Pressure, t, ans.Pressure);
			}
			ans.Width = InkInterp.Interp(from.Width, to.Width, t);
			ans.Colour = InkInterp.Interp(from.Colour, to.Colour, t);
		}

		public StrokeIT()
		{
			StartTime = (float)0.0;
			Points = new Point[0];
			Width = 3;
			Colour = System.Drawing.Color.Black;
			Pressure = null;
		}

		/// <summary>
		/// Create a new stroke with the given number of points. And specify if it is to have
		/// an array or pressure as well.
		/// </summary>
		/// <param name="numpoints">number of points in this stroke</param>
		/// <param name="haspressure">if this stroke holds memory for pressure</param>
		public StrokeIT(int numpoints, bool haspressure)
		{
			StartTime = (float)0.0;
			Points = new Point[numpoints];
			if (!haspressure)
				Pressure = null;
			else
				Pressure = new int [numpoints];
			Width = 3;
			Colour = System.Drawing.Color.Black;
		}

		/// <summary>
		/// Create a stroke with the given path as it's owning StrokePath
		/// </summary>
		/// <param name="path">Owner</param>
		public StrokeIT(StrokePath path) : this()
		{
			Path = path;
		}
	}

	/// <summary>
	/// A StrokePath represents a stroke across time. So it holds a series of individual StrokeITs
	/// and includes utilities to sample them correctly and interpolate between them as needed.
	/// It is essentially an animated Stroke. Also, it's members are made public for both
	/// performance, and because most programmers won't get anywhere near them.
	/// </summary>
	class StrokePath
	{
		/// <summary>
		/// The array of StrokeITs which make up this path
		/// </summary>
		public StrokeIT[] StrokesIT;

		/// <summary>
		/// Stores whether this path ends at some time
		/// </summary>
		public bool DoesEnd;

		/// <summary>
		/// Stores the time when this path ends, if any
		/// </summary>
		public float EndTime;

		/// <summary>
		/// Copies the previous StrokeIT before the given time into this given time
		/// This feature is useful for editing.
		/// </summary>
		public void CopyToThisTime(float time)
		{
			//StrokeIT sit = this.GetPrevStroke(time);
			StrokeIT sit = this.GetAtOrPrevStroke(time);
			if (sit == null)
				return;
			if (sit.StartTime == time)
				return;
			Stroke st = this.GetStrokeAtTime(new Ink(), time);
			StrokeIT ns = new StrokeIT();
			ns.FromStroke(st);
			ns.StartTime = time;
			ns.Path = this;
			StrokesIT = (StrokeIT[])Mem.AddAfter(StrokesIT, ns, sit.IndexInPath);
		}

		public int MaxSamples
		{
			get
			{
				int max = 0;
				foreach(StrokeIT sit in StrokesIT)
				{
					if (sit.Points.Length > max)
						max = sit.Points.Length;
				}
				return max;
			}
		}

		public void WriteSVGPoints(StreamWriter sw, Point[] line)
		{
			foreach(Point p in line)
			{
				sw.Write("{0} {1} ", p.X, p.Y);
			}
		}

		public string ToSVGColor(Color color)
		{
			return String.Format("rgb({0},{1},{2})", color.R, color.G, color.B );
		}

		public void WriteToSVG(StreamWriter sw)
		{
			int max = MaxSamples;
			Point[] line = new Point[max];

			sw.Write("\t<polyline style=\"stroke:{1};stroke-width:{0};fill-opacity:0.0;\" points=\"", StrokesIT[0].Width, ToSVGColor(StrokesIT[0].Colour));
			for (int i=0; i<max; i++)
			{
				sw.Write("0 0 ");
			}
			sw.WriteLine("\" >");

			if (StrokesIT.Length==1)
			{
				StrokeIT cur = StrokesIT[0];

				sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"points\" ", cur.StartTime);
				if (!DoesEnd)
				{
					sw.Write("dur=\"1s\" fill=\"freeze\" ");
				}
				else
				{
					sw.Write("dur=\"{0}s\" ", EndTime - cur.StartTime);
				}
				sw.Write("values=\"");
				WriteSVGPoints(sw, cur.Points );
				sw.WriteLine("\" />");
			}
			else
			{
				float starttime = StrokesIT[0].StartTime;
				float endtime = StrokesIT[StrokesIT.Length-1].StartTime;
				if (DoesEnd)
					endtime = EndTime;
				bool addextra = ((DoesEnd) && (endtime != StrokesIT[StrokesIT.Length-1].StartTime));
				//addextra = false;
				sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"points\" ", starttime );
				sw.Write("dur=\"{0}s\" ", endtime-starttime);
				if (!DoesEnd)
					sw.Write("fill=\"freeze\" ");

				sw.Write("keyTimes=\"");
				for (int s=0; s<StrokesIT.Length; s++)
				{
					sw.Write("{0}", (StrokesIT[s].StartTime-starttime)/(endtime-starttime));
					if (s+1 < StrokesIT.Length)
						sw.Write(";");
				}
				if (addextra)
					sw.Write(";1;");
				sw.Write("\" ");

				sw.Write("values=\"");
				for (int s=0; s<StrokesIT.Length; s++)
				{
					InkInterp.ResampleLine( StrokesIT[s].Points, line );
					WriteSVGPoints(sw, line );
					if (s+1 < StrokesIT.Length)
						sw.Write(";");
				}
				if (addextra)
				{
					sw.Write(";");
					WriteSVGPoints(sw, line);
				}
				sw.WriteLine("\" />");
			}

			/*
			for (int s=0; s<StrokesIT.Length-1; s++)
			{
				StrokeIT cur = StrokesIT[s];
				StrokeIT next = StrokesIT[s+1];

				sw.Write("\t\t<animate begin=\"{0}s\" repeatCount=\"1\" attributeName=\"points\" ", cur.StartTime);
				sw.Write("dur=\"{0}s\" ", next.StartTime-cur.StartTime);
				if (s+1 == StrokesIT.Length-1)
				{
					if (!DoesEnd)
					{
						sw.Write("fill=\"freeze\" ");
					}
				}
				sw.Write("values=\"");

				InkInterp.ResampleLine( cur.Points, line );
				WriteSVGPoints(sw, line );

				sw.Write(";");

				InkInterp.ResampleLine( next.Points, line );
				WriteSVGPoints(sw, line );

				sw.WriteLine("\" />");
			}
			*/

			for (int s=0; s<StrokesIT.Length-1; s++)
			{
				StrokeIT cur = StrokesIT[s];
				StrokeIT next = StrokesIT[s+1];

				if (cur.Colour != next.Colour)
				{
					sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"stroke\" ", cur.StartTime);
					if (s+1 == StrokesIT.Length-1)
					{
						if (!DoesEnd)
						{
							sw.Write("dur=\"1s\" fill=\"freeze\" ");
						}
					}
					else
						sw.Write("dur=\"{0}s\" fill=\"freeze\" ", next.StartTime-cur.StartTime);
					sw.Write("values=\"");
					sw.Write("{0};{1}", ToSVGColor(cur.Colour), ToSVGColor(next.Colour));
					sw.WriteLine("\" />");
				}
			}

			for (int s=0; s<StrokesIT.Length-1; s++)
			{
				StrokeIT cur = StrokesIT[s];
				StrokeIT next = StrokesIT[s+1];

				if (cur.Width != next.Width)
				{
					sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"stroke-width\" ", cur.StartTime);
					if (s+1 == StrokesIT.Length-1)
					{
						if (!DoesEnd)
						{
							sw.Write("dur=\"1s\" fill=\"freeze\" ");
						}
					}
					else
						sw.Write("dur=\"{0}s\" fill=\"freeze\" ", next.StartTime-cur.StartTime);
					sw.Write("values=\"");
					sw.Write("{0};{1}", cur.Width, next.Width);
					sw.WriteLine("\" />");
				}
			}

			sw.WriteLine("\t</polyline>");
		}

		/// <summary>
		/// Deletes the given StrokeIT from this path
		/// </summary>
		public void DeleteStrokeIT(StrokeIT sit)
		{
			StrokesIT = (StrokeIT[])Mem.Remove(StrokesIT, sit);
		}

		/// <summary>
		/// Adds an Ink.Stroke to this path by converting it into a StrokeIT first
		/// </summary>
		/// <param name="st">Ink.Stroke to add</param>
		/// <param name="starttime">Time to add it</param>
		/// <returns>Newly created StrokeIT</returns>
		public StrokeIT AddStroke(Stroke st, float starttime)
		{
			StrokeIT sit;

			//If there are no strokes:
			if (StrokesIT.Length == 0)
			{
				sit = new StrokeIT(this);
				sit.StartTime = starttime;
				sit.FromStroke( st );
				StrokesIT = new StrokeIT[1];
				StrokesIT[0] = sit;
				return sit;
			}

			//If there is already a stroke at that points
			StrokeIT at = GetStrokeStartingAt(starttime);
			if (at != null)
			{
				at.FromStroke( st );
				return at;
			}

			//Add a new stoke at some point in time;
			at = GetPrevStroke( starttime );
			sit = new StrokeIT(this);
			sit.StartTime = starttime;
			sit.FromStroke( st );
			StrokesIT = (StrokeIT[])Mem.AddAfter( StrokesIT, sit, at.IndexInPath);
			return sit;
		}

		/// <summary>
		/// Get a time event before the given time. Time events are either starting stroke times
		/// or the end time.
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="prev">Store result in here</param>
		/// <returns>Whether an even was found or not</returns>
		public bool PrevTimeEvent(float from, ref float prev)
		{
			if ((DoesEnd) && (from > EndTime))
			{
				prev = EndTime;
				return true;
			}
			if (StrokesIT.Length==0)
				return false;
			float best = StrokesIT[0].StartTime;
			if (from <= best)
				return false;

			for (int i=1; i < this.StrokesIT.Length; i++)
			{
				if (StrokesIT[i].StartTime < from)
					best = StrokesIT[i].StartTime;
			}
			prev = best;
			return true;
		}

		/// <summary>
		/// Get a time event after the given time. Time events are either starting stroke times
		/// or the end time.
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="prev">Store result in here</param>
		/// <returns>Whether an even was found or not</returns>
		public bool NextTimeEvent(float from, ref float next)
		{
			StrokeIT sit;
			for (int i=0; i!=this.StrokesIT.Length; i++)
			{
				sit = StrokesIT[i];
				if (sit.StartTime > from)
				{
					next = sit.StartTime;
					return true;
				}
			}
			if ((DoesEnd) && (this.EndTime > from))
			{
				next = EndTime;
				return true;
			}
			return false;
		}

		/// <summary>
		/// Gets the most recent StrokeIT from the given time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetPrevStroke(float t)
		{
			if (StrokesIT.Length==0)
				return null;

			int found = -1;
			int i;
			for (i=0; (found==-1)&&(i!=StrokesIT.Length); i++)
			{
				if (t < StrokesIT[i].StartTime)
					found = i;
			}
			if (found == -1)
			{
				return StrokesIT[StrokesIT.Length-1];
			}
			if (found == 0)
				return null;
			return StrokesIT[found-1];
		}

		/// <summary>
		/// Gets the most recent StrokeIT from the given time, including at the given time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetAtOrPrevStroke(float time)
		{
			StrokeIT sit = this.GetStrokeStartingAt(time);
			if (sit != null)
				return sit;
			sit = this.GetPrevStroke(time);
			return sit;
		}

		/// <summary>
		/// Add to the given Ink an Ink.Stroke which represents this path's value at the given time
		/// Note that is a high quality Stroke, meaning that this function should not be used for
		/// quick rendering, but rather for high quality ink creation.
		/// </summary>
		/// <param name="ink">Ink to be added to</param>
		/// <param name="time">Time to sample at</param>
		/// <returns>The newly created Stroke (null if time is out of domain)</returns>
		public Stroke GetStrokeAtTime(Ink ink, float time)
		{
			StrokeIT sit;
			if ((StrokesIT.Length==0) || (StrokesIT[0].StartTime > time))
				return null;
			if ((DoesEnd) && (time > EndTime))
				return null;
			sit = GetStrokeStartingAt(time);
			if (sit != null)
			{
				return sit.ToStroke(ink);
			}
			sit = GetPrevStroke(time);
			if (sit.IndexInPath == StrokesIT.Length-1)
			{
				return sit.ToStroke(ink);
			}
			StrokeIT next;
			next = StrokesIT[ sit.IndexInPath+1 ];
			time = ((time - sit.StartTime) / (next.StartTime - sit.StartTime));
			return StrokeIT.Interp(sit, next, time, ink);
		}

		/// <summary>
		/// Quickly calculate the StrokeIT at a given time, and interpolate between frames
		/// </summary>
		/// <param name="to">StrokeIT to store result</param>
		/// <param name="time">Time to sample at</param>
		/// <returns>Returns false if the time is outside of this stroke's domain</returns>
		public bool QuickStrokeAtTime(StrokeIT to, float time)
		{
			StrokeIT sit;
			if ((StrokesIT.Length==0) || (StrokesIT[0].StartTime > time))
				return false;
			if ((DoesEnd) && (time > EndTime))
				return false;
			sit = GetStrokeStartingAt(time);
			if (sit != null)
			{
				sit.QuickToStroke( to );
				return true;
			}
			sit = GetPrevStroke(time);
			if (sit.IndexInPath == StrokesIT.Length-1)
			{
				sit.QuickToStroke( to );
				return true;
			}
			StrokeIT next;
			next = StrokesIT[ sit.IndexInPath+1 ];
			time = ((time - sit.StartTime) / (next.StartTime - sit.StartTime));
			InkInterp.Interp(sit.Points, next.Points, time, to.Points );

			to.Colour = InkInterp.Interp( sit.Colour, next.Colour, time);
			to.Width = InkInterp.Interp( sit.Width, next.Width, time);

			if ((sit.Pressure!=null) && (next.Pressure!=null) && (to.Pressure!=null))
				InkInterp.Interp(sit.Pressure, next.Pressure, time, to.Pressure);
			return true;
		}

		/// <summary>
		/// Gets the StrokeIT which started at this time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetStrokeStartingAt(float time)
		{
			for (int i=0; i!=StrokesIT.Length; i++)
			{
				if (StrokesIT[i].StartTime == time)
					return StrokesIT[i];
			}
			return null;
		}

		/// <summary>
		/// Create a new StrokePath with the default settings
		/// </summary>
		public StrokePath()
		{
			StrokesIT = new StrokeIT[0];
			DoesEnd = false;
			EndTime = 0.0f;
		}
	}

	/// <summary>
	/// An InkPath is the equivalent of an Ink.Ink object but for animations. It holds a series
	/// of StrokePaths. This way it can animated as a series of strokes.
	/// </summary>
	[Serializable]
	class InkPath : System.Runtime.Serialization.ISerializable
	{
		private StrokePath[] paths;

		/// <summary>
		/// This returns the StrokePaths which make up this InkPath
		/// </summary>
		public StrokePath[] Paths
		{
			get { return paths; }
		}

		public bool ExportToSVG(string filename, int scrwidth, int scrheight, int inkwidth, int inkheight)
		{
			StreamWriter sw = new StreamWriter(filename);
			if (sw==null)
				return false;

			sw.WriteLine("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?> ");
			sw.Write("<svg id=\"root\" xml:space=\"preserve\" width=\"{0}\" height=\"{1}\" ", scrwidth, scrheight );
			sw.WriteLine("viewBox=\"0 0 {0} {1}\">", inkwidth, inkheight );

			sw.WriteLine("\t<text x=\"0\" y=\"450\" style=\"font-size:450;fill:black;text-anchor:left\">Reset");
			sw.WriteLine("\t\t<animate id=\"mytimer\" begin=\"mybox.click;mybox.load\" attributeName=\"fill\" values=\"black\" />");
			sw.WriteLine("\t</text>" );
			sw.WriteLine("\t<rect id=\"mybox\" x=\"0\" y=\"0\" width=\"1350\" height=\"600\" style=\"fill:black;fill-opacity:0.1\" />");

			foreach(StrokePath sp in paths)
			{
				sp.WriteToSVG(sw);
			}

			sw.WriteLine("</svg>");
			sw.Close();
			return true;
		}

		/// <summary>
		/// Returns the next previous time event from all the paths
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="ans">Will hold answer</param>
		/// <returns>Whether one was found or not</returns>
		public bool PrevTimeEvent(float from, ref float ans)
		{
			float best=0f, cur=0f;
			bool hasbest = false;
			StrokePath path;
			for (int i=0; i!=Paths.Length; i++)
			{
				path = Paths[i];
				if (path.PrevTimeEvent(from, ref cur))
				{
					if (!hasbest)
					{
						best = cur;
						hasbest = true;
					}
					else
					{
						if (cur > best)
							best = cur;
					}
				}
			}
			if (!hasbest)
				return false;
			ans = best;
			return true;
		}

		/// <summary>
		/// Returns the next time event from all the paths
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="ans">Will hold answer</param>
		/// <returns>Whether one was found or not</returns>
		public bool NextTimeEvent(float from, ref float ans)
		{
			float best=0f, cur=0f;
			bool hasbest = false;
			StrokePath path;
			for (int i=0; i!=Paths.Length; i++)
			{
				path = Paths[i];
				if (path.NextTimeEvent(from, ref cur))
				{
					if (!hasbest)
					{
						best = cur;
						hasbest = true;
					}
					else
					{
						if (cur < best)
							best = cur;
					}
				}
			}
			if (!hasbest)
				return false;
			ans = best;
			return true;
		}

		/// <summary>
		/// Delete all Paths
		/// </summary>
		public void DeletePaths()
		{
			paths = new StrokePath[0];
		}

		/// <summary>
		/// Delete the given path
		/// </summary>
		/// <param name="path">Path to delete</param>
		public void DeletePath(StrokePath path)
		{
			this.paths = (StrokePath[])Mem.Remove(paths, path);
		}

		/// <summary>
		/// Adds a stroke to this InkPath. If a 'selected' StrokePath is given, that the stroke is
		/// added to that path, otherwise a new path is created for it.
		/// </summary>
		/// <param name="st">Ink.Stroke to add</param>
		/// <param name="time">Time to add it at</param>
		/// <param name="selected">StrokePath to add it into (optional)</param>
		/// <returns>StrokePath it was added to</returns>
		public StrokePath AddStroke(Stroke st, float time, StrokePath selected)
		{
			if (selected != null)
			{
				selected.AddStroke( st, time );
				return selected;
			}
			StrokePath path;
			path = new StrokePath();
			path.AddStroke(st, time );
			paths = (StrokePath[])Mem.AddToArray(Paths, path);
			return path;
		}

		/// <summary>
		/// This is a text based file save, this is faster and more effiecient than the
		/// serialized size
		/// </summary>
		/// <param name="s">Stream to save into</param>
		public void SaveToStream(StreamWriter s)
		{

			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			Point pt;

			s.WriteLine("{0}", this.paths.Length);
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				s.WriteLine("{0}", path.DoesEnd);
				s.WriteLine("{0}", path.EndTime);
				s.WriteLine("{0}", path.StrokesIT.Length);

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					sit = path.StrokesIT[strokei];
					strokestr = pathstr + "S" + strokei + "";
					s.WriteLine("{0}", sit.Colour.ToArgb() );
					s.WriteLine("{0}", sit.Width );
					s.WriteLine("{0}", sit.StartTime );

					s.WriteLine("{0}", sit.Points.Length );
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						pt = sit.Points[pointi];
						s.WriteLine("{0}", pt.X );
						s.WriteLine("{0}", pt.Y );
					}

					s.WriteLine("{0}", (sit.Pressure!=null) );
					if (sit.Pressure!=null)
					{
						s.WriteLine("{0}", sit.Pressure.Length );
						for (pointi=0; pointi!=sit.Pressure.Length; pointi++)
						{
							s.WriteLine("{0}", sit.Pressure[pointi] );
						}
					}
				}
			}			
		}

		/// <summary>
		/// Allows for serialization. This isn't the fastest method, but considering the amount
		/// of information it has to convert to and from text, it's not bad
		/// </summary>
		public virtual void GetObjectData(
			System.Runtime.Serialization.SerializationInfo s, System.Runtime.Serialization.StreamingContext c)
		{

			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			Point pt;

			s.AddValue("NumPaths", this.Paths.Length);
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				s.AddValue(pathstr + "DoesEnd", path.DoesEnd);
				s.AddValue(pathstr + "EndTime", path.EndTime);
				s.AddValue(pathstr + "NumStrokes", path.StrokesIT.Length);

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					sit = path.StrokesIT[strokei];
					strokestr = pathstr + "S" + strokei + "";
					s.AddValue(strokestr + "Colour", sit.Colour.ToArgb() );
					s.AddValue(strokestr + "Width", sit.Width );
					s.AddValue(strokestr + "StartTime", sit.StartTime );

					s.AddValue(strokestr + "NumPoints", sit.Points.Length );
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						pt = sit.Points[pointi];
						s.AddValue(strokestr + "P" + pointi + "X", pt.X );
						s.AddValue(strokestr + "P" + pointi + "Y", pt.Y );
					}

					s.AddValue(strokestr + "HasPressure", sit.Pressure!=null);
					if (sit.Pressure!=null)
					{
						s.AddValue(strokestr + "NumPressures", sit.Pressure.Length );
						for (pointi=0; pointi!=sit.Pressure.Length; pointi++)
						{
							s.AddValue(strokestr + "PR" + pointi + "", sit.Pressure[pointi] );
						}
					}
				}
			}
		}

		/// <summary>
		/// Save this InkPath to a file
		/// </summary>
		/// <param name="filename">File to save it into</param>
		public void SaveToFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Create);
			StreamWriter s = new StreamWriter(fs);
			SaveToStream( s );
			s.Close();
			fs.Close();
		}

		/// <summary>
		/// Load the InkPath from a given file
		/// </summary>
		/// <param name="filename">File to load from</param>
		public void LoadFromFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Open);
			StreamReader r = new StreamReader(fs);
			LoadFromStream( r );
			r.Close();
			fs.Close();
		}

		/// <summary>
		/// Loads the InkPath from a text stream created with SaveToStream
		/// </summary>
		/// <param name="s">Stream to read from</param>
		public void LoadFromStream(StreamReader s)
		{
			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			int ptx, pty;

			paths = new StrokePath[ Int32.Parse( s.ReadLine() ) ];
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				Paths[pathi] = new StrokePath();
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				path.DoesEnd = Boolean.Parse( s.ReadLine() );
				path.EndTime = (float)Double.Parse( s.ReadLine() );
				path.StrokesIT = new StrokeIT[ Int32.Parse( s.ReadLine() ) ];

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					path.StrokesIT[strokei] = new StrokeIT();
					sit = path.StrokesIT[strokei];
					sit.Path = path;
					strokestr = pathstr + "S" + strokei + "";
					sit.Colour = Color.FromArgb( Int32.Parse( s.ReadLine() ) );
					sit.Width = (float)Double.Parse( s.ReadLine() );
					sit.StartTime = (float)Double.Parse( s.ReadLine() );

					sit.Points = new Point[ Int32.Parse( s.ReadLine() ) ];
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						ptx = Int32.Parse( s.ReadLine() );
						pty = Int32.Parse( s.ReadLine() );
						sit.Points[pointi].X = ptx;
						sit.Points[pointi].Y = pty;
					}

					sit.Pressure = null;
					if ( Boolean.Parse( s.ReadLine() ) )
					{
						sit.Pressure = new int[ Int32.Parse( s.ReadLine() ) ];
						for (pointi=0; pointi!=sit.Pressure.Length; pointi++)
						{
							sit.Pressure[pointi] = Int32.Parse( s.ReadLine() );
						}
					}
				}
			}
		}

		/// <summary>
		/// Constructor to allow for serialization
		/// </summary>
		private InkPath(
			System.Runtime.Serialization.SerializationInfo s, System.Runtime.Serialization.StreamingContext c)
		{
			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			int ptx, pty;

			paths = new StrokePath[ s.GetInt32( "NumPaths" ) ];
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				Paths[pathi] = new StrokePath();
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				path.DoesEnd = s.GetBoolean( pathstr + "DoesEnd" );
				path.EndTime = (float)s.GetDouble( pathstr + "EndTime" );
				path.StrokesIT = new StrokeIT[ s.GetInt32( pathstr + "NumStrokes" ) ];

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					path.StrokesIT[strokei] = new StrokeIT();
					sit = path.StrokesIT[strokei];
					sit.Path = path;
					strokestr = pathstr + "S" + strokei + "";
					sit.Colour = System.Drawing.Color.FromArgb( s.GetInt32( strokestr + "Colour" ) );
					sit.Width = (float)s.GetDouble( strokestr + "Width" );
					sit.StartTime = (float)s.GetDouble( strokestr + "StartTime" );

					sit.Points = new Point[ s.GetInt32( strokestr + "NumPoints" ) ];
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						ptx = s.GetInt32( strokestr + "P" + pointi + "X" );
						pty = s.GetInt32( strokestr + "P" + pointi + "Y" );
						sit.Points[pointi].X = ptx;
						sit.Points[pointi].Y = pty;
					}

					sit.Pressure = null;
					if (s.GetBoolean( strokestr + "HasPressure" ))
					{
						sit.Pressure = new int[ s.GetInt32( strokestr + "NumPressures" ) ];
						for (pointi=0; pointi!=sit.Pressure.Length; pointi++)
						{
							sit.Pressure[pointi] = s.GetInt32( strokestr + "PR" + pointi + "" );
						}
					}
				}
			}
		}

		/// <summary>
		/// Create an InkPath with default settings
		/// </summary>
		public InkPath()
		{
			paths = new StrokePath[0];
		}

		/// <summary>
		/// Sets the given Ink.Ink object to represent this InkPath at a given time. This is a
		/// high quality conversion which can be used for normal inking uses
		/// </summary>
		/// <param name="to">Ink to store into</param>
		/// <param name="time">Time to sample at</param>
		/// <returns>A array representing the mapping between Ink.Stroke and StrokePath objects</returns>
		public StrokeMapping[] GetInkAtTime(Ink to, float time)
		{
			Stroke st;
			StrokeMapping[] smaps = new StrokeMapping[0];
			StrokeMapping map;

			to.DeleteStrokes();
			foreach (StrokePath path in Paths)
			{
				st = path.GetStrokeAtTime(to, time);
				if (st != null)
				{
					map = new StrokeMapping();
					map.Stroke = st;
					map.StrokePath = path;
					smaps = (StrokeMapping[])Mem.AddToArray(smaps, map);
				}
			}

			return smaps;
		}
	};

	/// <summary>
	/// Used to map between Ink.Stroke and StrokePaths, this way StrokePaths rendering to Ink can
	/// be traced back to the StrokePath which created them
	/// </summary>
	class StrokeMapping
	{
		public Stroke Stroke;
		public StrokePath StrokePath;
	};

	/// <summary>
	/// Akin to the Renderer, the InkPathViewer contains a number of rendering and other such utilities
	/// can come in handy when dealing with InkPaths. I highly recomend you let this baby do
	/// all most of your rendering work for you. It also holds which strokes the user has 'selected'
	/// this is because it needs to know which to outline to show that they have been selected
	/// </summary>
	class InkPathViewer
	{
		private Ink renderInk;
		private int renderQuality;
		private Ink CurInk;
		private StrokeMapping[] strokeMapping;
		private InkPath AInk;
		private Stroke[] selectedStrokes;

		/// <summary>
		/// This is an array of the currently selected Strokes
		/// </summary>
		public Stroke[] SelectedStrokes
		{
			get	{ return selectedStrokes; }
		}

		/// <summary>
		/// Creates a Strokes object filled with the currently selected Strokes
		/// </summary>
		public Strokes Selected
		{
			get
			{
				Strokes st = (new Ink()).CreateStrokes();
				for (int i=0; i!=selectedStrokes.Length; i++)
					st.Add(selectedStrokes[i]);
				return st;
			}
			set
			{
				ClearSelected();
				for (int i=0; i!=value.Count; i++)
				{
					AddStrokeToSelected( value[i] );
				}
			}
		}

		/// <summary>
		/// Get whether or not there is Ink in the clipboard which can be pasted onto this InkPath
		/// </summary>
		public bool CanPaste
		{
			get { return this.CurInk.CanPaste(); }
		}

		/// <summary>
		/// Paste Ink from Clipboard onto the current InkPath at the given time
		/// </summary>
		/// <param name="attime">Time to sample at</param>
		public void PasteFromClipboard(float attime, bool autoselect)
		{
			if (!CanPaste)
				return;

			int oldnum = 0;
			if (autoselect)
			{
				oldnum = Ink.Strokes.Count;
			}

			Microsoft.Ink.Ink ink = InkAtTime(attime);
			Strokes pasted = ink.ClipboardPaste();
			int i;
			for (i=0; i!=pasted.Count; i++)
			{
				AddStroke(pasted[i], attime, null);
			}

			InkAtTime(attime); //make sure to get rid of newly created strokes

			if (autoselect)
			{
				ClearSelected();
				for (i=0; i < Ink.Strokes.Count; i++)
				{
					if (i >= oldnum)
						AddStrokeToSelected( Ink.Strokes[i] );
				}
			}
		}

		/// <summary>
		/// Copy the Ink at a given time onto the clipboard in the given formats. Note if no
		/// strokes are currently selected, then the entire frame is copied
		/// </summary>
		/// <param name="attime">time to sample Ink</param>
		/// <param name="formats">Formats to save in</param>
		public void CopyToClipboard(float attime, InkClipboardFormats formats)
		{
			Ink ink = InkAtTime(attime);
			if (selectedStrokes.Length==0)
			{
				ink.ClipboardCopy(ink.Strokes,formats, Microsoft.Ink.InkClipboardModes.Copy);
			}
			else
			{
				Strokes st = ink.CreateStrokes();
				for (int i=0; i!=selectedStrokes.Length; i++)
				{
					st.Add( selectedStrokes[i] );
				}
				ink.ClipboardCopy(st,formats, Microsoft.Ink.InkClipboardModes.Copy);
				InkAtTime(attime);	//make sure to get rid of the extra strokes created
			}
		}

		/// <summary>
		/// Clears the list of selected Strokes
		/// </summary>
		public void ClearSelected()
		{
			selectedStrokes = new Stroke[0];
			if (SelectedChanged!=null)
				SelectedChanged(this, null);
		}

		public int NumSelected
		{
			get { return selectedStrokes.Length; }
		}

		public event System.EventHandler SelectedChanged;

		/// <summary>
		/// Adds a Stroke to those that are selected
		/// </summary>
		/// <param name="st"></param>
		public void AddStrokeToSelected(Stroke st)
		{
			if (st==null)
				return;
			selectedStrokes = (Stroke[])Mem.AddToArray(selectedStrokes, st);
			if (SelectedChanged!=null)
				SelectedChanged(this, null);
		}

		/// <summary>
		/// Get or set the "render quality" this is the number of points used in the line
		/// which is used for quick rendering. In Quick rendering the length of the line is
		/// static and not interpolated based on the two interpolation Strokes, and thus there
		/// can be loss of quality
		/// </summary>
		public int QuickRenderQuality
		{
			get { return renderQuality; }
			set { renderQuality = value; }
		}

		/// <summary>
		/// Returns if a given Stroke is selected or not
		/// </summary>
		/// <param name="st">Stroke to look for</param>
		/// <returns>Is selected</returns>
		public bool IsSelected(Stroke st)
		{
			for (int i=0; i!=selectedStrokes.Length; i++)
			{
				if (selectedStrokes[i].Id == st.Id)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Maps a given Ink.Stroke to the StrokePath which created it. This is useful if you wish
		/// to track a Stroke as it changes with animation (remember Ink.Strokes change each rendering)
		/// </summary>
		/// <param name="st">Ink.Stroke to look for</param>
		/// <returns>Matching StrokePath</returns>
		public StrokePath StrokeToStrokePath(Stroke st)
		{
			if ((strokeMapping == null) || (st == null))
				return null;
			StrokeMapping map;
			for (int i=0; i!=this.strokeMapping.Length; i++)
			{
				map = strokeMapping[i];
				if (map.Stroke.Id == st.Id)
					return map.StrokePath;
			}
			return null;
		}

		/// <summary>
		/// Maps a given StrokePath to the Stroke which it created. This is useful if you wish
		/// to track a Stroke as it changes with animation (remember Ink.Strokes change each rendering)
		/// </summary>
		/// <param name="path">StrokePath to look for</param>
		/// <returns>Matching Ink.Stroke</returns>
		public Stroke StrokePathToStroke(StrokePath path)
		{
			if ((strokeMapping == null) || (path == null))
				return null;
			StrokeMapping map;
			for (int i=0; i!=strokeMapping.Length; i++)
			{
				map = strokeMapping[i];
				if (map.StrokePath == path)
					return map.Stroke;
			}
			return null;
		}

		/// <summary>
		/// Creates the new Ink object which represents the strokes at the given time. It also
		/// remaps the selected Strokes to keep them up to date.
		/// </summary>
		/// <param name="time">The time to sample at</param>
		/// <returns>The new Ink object with all the strokes in it</returns>
		public Ink InkAtTime(float time)
		{
			StrokePath[] path = new StrokePath[SelectedStrokes.Length];
			int i;
			for (i=0; i!=SelectedStrokes.Length; i++)
			{
				path[i] = StrokeToStrokePath( SelectedStrokes[i] );
			}
			strokeMapping = AInk.GetInkAtTime(CurInk, time);
			Stroke st;
			ClearSelected();
			for (i=0; i!=path.Length; i++)
			{
				st = StrokePathToStroke( path[i] );
				AddStrokeToSelected( st );
			}
			return CurInk;
		}

		/// <summary>
		/// Returns the Ink that was last rendered. This Ink can be used like any other Ink just
		/// remember that it's Stroke change from frame to frame.
		/// </summary>
		public Ink Ink	//returns the ink object that was last created using InkAtTime
			//	be careful how this is used
		{
			get { return CurInk; }
		}

		/// <summary>
		/// Get or set the InkPath which the Viewer uses for all it's tasks
		/// </summary>
		public InkPath InkPath
		{
			get { return AInk; }
			set { AInk = value; }
		}

		/// <summary>
		/// Add a stroke to the InkPath. Please note that this version allows you to enter an
		/// Ink.Stroke for the selected item, where as the InkPath.AddStroke function requires
		/// a StrokePath as the selected item type.
		/// </summary>
		/// <param name="st">This is the Ink.Stroke to add</param>
		/// <param name="time">The time to add it</param>
		/// <param name="selected">The selected Stroke which it will adjust or add to (optional)</param>
		public void AddStroke(Stroke st, float time, Stroke selected)
		{
			StrokePath path = StrokeToStrokePath(selected);
			AInk.AddStroke(st, time, path);
		}

		/// <summary>
		/// Deletes all the StrokePaths in it's InkPath
		/// </summary>
		public void DeletePaths()
		{
			AInk.DeletePaths();
			this.selectedStrokes = new Stroke[0];
			this.strokeMapping = new StrokeMapping[0];
		}

		/// <summary>
		/// Returns the next Stroke which also had a starting time as the given stroke. This
		/// is useful for identifying Strokes which are part of a group
		/// </summary>
		/// <param name="prev">Stroke to start looking from</param>
		/// <param name="time">Time to start looking from</param>
		/// <returns></returns>
		public Stroke NextStrokeAtTime(Stroke prev, float time)
		{
			StrokePath path = StrokeToStrokePath(prev);
			if (path == null)
				return null;
			StrokeIT sit = path.GetAtOrPrevStroke(time);
			float musthave = sit.StartTime;
			bool hasfound=false;
			int i;
			for (int a=0; a!=CurInk.Strokes.Count*2; a++)
			{
				i = a % CurInk.Strokes.Count;
				if (!hasfound)
				{
					if (CurInk.Strokes[i].Id == prev.Id)
						hasfound=true;
				}
				else
				{
					if (CurInk.Strokes[i].Id == prev.Id)
						return null;
					path = StrokeToStrokePath( CurInk.Strokes[i] );
					if (path != null)
					{
						sit = path.GetStrokeStartingAt(musthave);
						if (sit != null)
							return StrokePathToStroke( path );
					}
				}
			}
			return null;
		}

		public void LassoQuickRender(Graphics g, Point from, Point to)
		{
			Renderer rend = new Renderer();
			DrawingAttributes prev, sel;
			Point pt;
			Ink ink = CurInk;

			foreach(Stroke st in ink.Strokes)
			{
				if (IsSelected(st))
				{
					sel = st.DrawingAttributes;
					prev = sel.Clone();
					sel.Width *= 2;
					if (sel.Width < 100)
						sel.Width = 100;
					sel.Color = Color.Yellow;
					sel.FitToCurve = true;
					sel.IgnorePressure = true;
					sel.AntiAliased = true;
					rend.Draw(g, st);
					st.DrawingAttributes = prev;

					if (this.selectedStrokes.Length==1)
					{
						pt = st.GetPoint(0);
						rend.InkSpaceToPixel(g, ref pt);
						g.FillEllipse(System.Drawing.Brushes.Red, pt.X-5, pt.Y-5, 10, 10);
					}
				}
			}
			foreach (Stroke st in Ink.Strokes)
			{
				st.DrawingAttributes.IgnorePressure = true;
				st.DrawingAttributes.AntiAliased = true;
				st.DrawingAttributes.FitToCurve = true;

				rend.Draw(g, st);
			}

			if ((from.X != -1) && (from.Y != -1))
			{
				rend.InkSpaceToPixel(g, ref from);
				rend.InkSpaceToPixel(g, ref to);
				System.Drawing.Pen pen = new Pen(Color.Red, 2);
				pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
				g.DrawLine(pen, from, to);
			}
		}

		/// <summary>
		/// This method first recalculates the Ink for this time, and then draws it to the screen.
		/// This is a high quality rendering and is not meant for real-time use.
		/// </summary>
		/// <param name="g">Graphics object to render to</param>
		/// <param name="time">Time to sample at</param>
		public void Render(Graphics g, float time)
		{
			Ink ink = InkAtTime(time);
			LassoQuickRender(g, new Point(-1,-1), new Point(-1,-1));
		}

		private bool highqualityplay = true;
		public bool HighQualityPlay
		{
			get { return highqualityplay; }
			set { highqualityplay = value; }
		}

		/// <summary>
		/// This is a fast rendering of the InkPath at the given time. This method does not update
		/// the current Ink object (use Render()) for that.
		/// </summary>
		/// <param name="g">Graphics object to render to</param>
		/// <param name="time">Time to sample at</param>
		public void QuickRender(Graphics g, float time)
		{
			StrokeIT sit = new StrokeIT(renderQuality, true);
			Stroke st = null, wst;
			DrawingAttributes da = null;

			Renderer rend = new Renderer();
			int i;
			for (i=0; i!=AInk.Paths.Length; i++)
			{
				if (highqualityplay)
				{
						wst = AInk.Paths[i].GetStrokeAtTime(renderInk, time);
						if (wst != null)
						{
							rend.Draw(g, wst);
						}
				}
				else
				{
					//THIS IS THE NORMAL QUICK RENDER:
					//	if (AInk.Paths[i].QuickToPoints(pts, time))
					if (AInk.Paths[i].QuickStrokeAtTime(sit, time))
						if (sit != null)
						{
							if (st == null)
							{
								st = renderInk.CreateStroke( sit.Points );
								da = st.DrawingAttributes;
								da.IgnorePressure = true;
								da.FitToCurve = true;
								da.AntiAliased = true;
							}

							st.SetPoints( sit.Points );

							//	st.SetPacketValuesByProperty( PacketProperty.NormalPressure, sit.Pressure);

							da.Width = sit.Width;
							da.Color = sit.Colour;
							st.DrawingAttributes = da;
							rend.Draw(g, st);
						}
				}
			}
			renderInk.DeleteStrokes();
		}
			
		/// <summary>
		/// Creates a new InkPathViewer which views the given InkPath
		/// </summary>
		/// <param name="path">The InkPath to be used by this object</param>
		public InkPathViewer(InkPath path)
		{
			CurInk = new Ink();
			renderInk = new Ink();
			selectedStrokes = new Stroke[0];
			strokeMapping = null;
			AInk = path;

			renderQuality = 60;
		}
	}
	
	/// <summary>
	/// AniEd is a Windows Control, and can be generally used as such. It exposes a very simple
	/// API to allow you to make it into both an animation player, and a power animation editor.
	/// </summary>
	class AniEd : System.Windows.Forms.Control
	{
		private InkPathViewer viewer;
		private InkPath inkpath;
		private InkCollector ic;
		private float curtime;	//animation time
		private float rateoftime;
		private bool isPlaying;
		private long ticktime;
		private bool useeditor;
		private bool drawborder;
		private bool dragmode;

		/// <summary>
		/// Set this to true if you want to drag a single stroke, it will be set back
		/// once done dragging
		/// </summary>
		public bool IsDragMode
		{
			get { return dragmode; }
			set { dragmode = value; }
		}

		public bool ExportToSVG(string filename)
		{
			Point size = new Point(Size.Width, Size.Height);

			Graphics g = this.CreateGraphics();
			ic.Renderer.PixelToInkSpace( g, ref size );

			return inkpath.ExportToSVG(filename, Size.Width, Size.Height, size.X, size.Y);
		}

		/// <summary>
		/// Gets the InkPathViewer used for renderingm, selection, and so forth
		/// </summary>
		public InkPathViewer Viewer
		{
			get { return viewer; }
		}

		/// <summary>
		/// Get or set whether to draw a border when rendering or not.
		/// </summary>
		public bool DrawBorder
		{
			get { return drawborder; }
			set { drawborder = value; }
		}

		/// <summary>
		/// Returns the Ink.Ink object which was last rendered. You can use this for
		/// pretty much all of your Ink base needs, just as you would normal Ink.
		/// </summary>
		public Ink Ink
		{
			get { return viewer.Ink; }
		}

		/// <summary>
		/// Get or set the InkPath which is viewed/animated by this object.
		/// </summary>
		public InkPath InkPath
		{
			get { return inkpath; }
			set { inkpath = value; viewer.InkPath=inkpath; }	//WARNING! This will change alot of stuff! Becareful!
		}

		/// <summary>
		/// Allows you to change the drawing attributes used when creating new Strokes
		/// </summary>
		public DrawingAttributes DefaultDrawingAttributes
		{
			get { return this.ic.DefaultDrawingAttributes; }
		}

		/// <summary>
		/// This puts the Control into animation mode and playes the current InkPath as one
		/// would expect it to. While in Play mode it uses a QuickRender instead of the normal
		/// renderer, this gives good performance, but you must not access the current Ink object
		/// while the control is Playing, it will give garbage values. Note that if the editor
		/// if turn on, it will be turned off while playing
		/// </summary>
		public void Play()
		{
			isPlaying = true;
			ic.Enabled = false;
			ticktime = System.DateTime.Now.Ticks;
		}

		/// <summary>
		/// This stops the animation, and returns the system to high quality rendering, and
		/// if set will also turn the editor back on.
		/// </summary>
		public void Pause()
		{
			isPlaying = false;
			ic.Enabled = useeditor;
			this.Invalidate();
		}

		/// <summary>
		/// Moves the current lines to a most previous time event. Time events are either key frame
		/// strokes or the end of a stroke
		/// </summary>
		public void GoToPrevTimeEvent()
		{
			float to=0f;
			if (!viewer.InkPath.PrevTimeEvent(curtime, ref to))
				return;
			Time = to;
		}

		/// <summary>
		/// Moves the current lines to the next time event. Time events are either key frame
		/// strokes or the end of a stroke
		/// </summary>
		public void GoToNextTimeEvent()
		{
			float to=0f;
			if (!viewer.InkPath.NextTimeEvent(curtime, ref to))
				return;
			Time = to;
		}

		/// <summary>
		/// Returns if there is Ink you can paste from the clipboard or not
		/// </summary>
		public bool CanPasteFromClipboard
		{
			get { return viewer.CanPaste; }
		}

		/// <summary>
		/// Paste Ink form the clipboard into the animation at this current time
		/// </summary>
		public void PasteFromClipboard()
		{
			viewer.PasteFromClipboard(curtime, true);
		}

		/// <summary>
		/// Copy the current frame to the clipboard in the given formats.
		/// </summary>
		/// <param name="formats">Formats to copy Ink in</param>
		public void CopyToClipboard(Microsoft.Ink.InkClipboardFormats formats)
		{
			viewer.CopyToClipboard(curtime, formats);
		}

		/// <summary>
		/// Makes all StrokePaths end at 0.01 seconds before this frame. Useful for sudden changes
		/// </summary>
		public void ClearFromThisFrame()
		{
			StrokePath path;
			for (int i=0; i!=viewer.Ink.Strokes.Count; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.Ink.Strokes[i] );
				path.DoesEnd = true;
				path.EndTime = curtime-0.01f;
			}
		}

		/// <summary>
		/// Either returns if the system is playing or not, or calls Play() or Pause() to change
		/// it's state.
		/// </summary>
		public bool IsPlaying
		{
			get { return isPlaying; }
			set 
			{ 
				if (value) 
					Play(); 
				else 
					Pause();
			}
		}

		/// <summary>
		/// Subscribe to this event to get a notice everytime the time changes by a call to Time
		/// </summary>
		public event System.EventHandler TimeChange;

		/// <summary>
		/// Use this to get or set the current time used for all tasts
		/// </summary>
		public float Time
		{
			get
			{
				return curtime;
			}
			set
			{
				curtime = value;
				if (TimeChange != null)
					TimeChange(this, null);
				if (!isPlaying)
					this.Invalidate();
			}
		}

		/// <summary>
		/// This this to set or get whether or not this Control is used as an editor.
		/// </summary>
		public bool UseEditor
		{
			get
			{
				return useeditor;
			}
			set
			{
				useeditor = value;
				if (!this.isPlaying)
					ic.Enabled = useeditor;
			}
		}

		/// <summary>
		/// Get or set the rate of time at which the animation is played. Setting this to 1.0 gives
		/// normal playback, -1.0 gives reverse playback. 3.0 is Three times as fast etc.
		/// </summary>
		public float RateOfTime
		{
			get { return rateoftime; }
			set { rateoftime = value; }
		}

		/// <summary>
		/// This constructor automatically creates a new InkPath for this control to animate
		/// </summary>
		public AniEd() : this(new InkPath())
		{
		}

		/// <summary>
		/// Allows you to specify the InkPath that this control will use
		/// </summary>
		/// <param name="ipath">InkPath to use</param>
		public AniEd(InkPath ipath)
		{
		//	Parent = parent;
		//	this = target;

			this.SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			ic = new InkCollector(this.Handle);
			Guid[] wanted = new Guid[3];
			wanted[0] = PacketProperty.X;
			wanted[1] = PacketProperty.Y;
			wanted[2] = PacketProperty.NormalPressure;
			ic.DesiredPacketDescription = wanted;
			ic.DefaultDrawingAttributes.AntiAliased = true;
			ic.DefaultDrawingAttributes.IgnorePressure = true;
			ic.DefaultDrawingAttributes.FitToCurve = true;

			inkpath = ipath;
			viewer = new InkPathViewer( inkpath );

			curtime = 0.0f;
			rateoftime = 1.0f;
			isPlaying = false;
			this.selectradius = 200;
			drawborder = true;
			dragmode = false;

			this.Paint += new System.Windows.Forms.PaintEventHandler(this.onPaint);
			ic.Stroke += new InkCollectorStrokeEventHandler(onStroke);
			ic.NewPackets += new InkCollectorNewPacketsEventHandler( onNewPackets );
			Application.Idle += new System.EventHandler( onIdle );
			//this.KeyPress += new KeyPressEventHandler( onKeyUp );

			UseEditor = true;
		}

		/// <summary>
		/// Get or set the radius used when "selecting" a Stroke
		/// </summary>
		private float selectradius;
		public float SelectRadius
		{
			get { return selectradius; }
			set { selectradius = value; }
		}

		/// <summary>
		/// Deletes all selected Paths
		/// </summary>
		public void Selected_DeletePaths()
		{
			StrokePath path;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					viewer.InkPath.DeletePath(path);
				}
			}
		}

		private bool ismultiselect = false;

		protected override void OnResize(EventArgs ea)
		{
			Invalidate();
		}

		protected override void OnKeyDown(KeyEventArgs kea)
		{
			ismultiselect = (kea.Modifiers == Keys.Shift);
		}

		protected override void OnKeyUp(KeyEventArgs kea)
		{
			ismultiselect = (kea.Modifiers == Keys.Shift);
			if (kea.KeyCode == System.Windows.Forms.Keys.Delete)
			{
				this.Selected_DeleteMoment();
				this.Invalidate();
				return;
			}
		}

		/// <summary>
		/// Deletes all the Strokes in time which are selected at this moment. This essentially
		/// just removes the current or first previous keyframe from each selected path.
		/// </summary>
		public void Selected_DeleteMoment()
		{
			StrokePath path;
			StrokeIT sit;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					sit = path.GetAtOrPrevStroke(curtime);
					if (sit!=null)
						path.DeleteStrokeIT(sit);
				}
			}
		}

		/// <summary>
		/// Makes all selected paths end at the current time.
		/// </summary>
		public void Selected_EndPathsNow()
		{
			StrokePath path;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					path.DoesEnd = true;
					path.EndTime = curtime;
				}
			}
		}

		private void Selected_Move(Point by)
		{
			StrokePath path;
			StrokeIT sit;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					path.CopyToThisTime(curtime);
					sit = path.GetStrokeStartingAt(curtime);
					sit.Move(by);
				}
			}
		}

		/// <summary>
		/// Select all Ink strokes at this time.
		/// </summary>
		public void SelectAll()
		{
			for (int i=0; i!=viewer.Ink.Strokes.Count; i++)
			{
				viewer.AddStrokeToSelected( viewer.Ink.Strokes[i] );
			}
		}

		/// <summary>
		/// Copies all selected Paths from their first previous frame to the current frame, this
		/// gives the illusion of a stroke that doesn't move for a period of time.
		/// </summary>
		public void Selected_CopyLastFrameToThisTime()
		{
			Stroke st;
			StrokePath path;
			StrokeIT sit;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					sit = path.GetPrevStroke( curtime );
					st = sit.ToStroke(new Ink());
					path.AddStroke(st, curtime);
				}
			}
		}

		/// <summary>
		/// Makes an exact copy of the selected strokes into this time, this lets you make animated
		/// frames into key frames.
		/// </summary>
		public void Selected_CopyToThisTime()
		{
			StrokePath path;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					path.CopyToThisTime(curtime);
				}
			}
		}

		/// <summary>
		/// Gets the nearest stroke to the given point, the point must be given in Ink coordinates
		/// </summary>
		/// <param name="pt">Point to compare to (Ink coordinate)</param>
		/// <returns>The closest Stroke (can be null if outside of SelectionRadius)</returns>
		private Stroke GetStrokeNear(Point pt)
		{
			Strokes sts = viewer.Ink.HitTest(pt, selectradius);
			if (sts.Count > 0)
			{
				Stroke bs = sts[0];
				float bd = sts[0].NearestPoint( pt );
				float cur;
				for (int i=0; i < sts.Count; i++)
				{
					sts[i].NearestPoint(pt, out cur);
					if (cur < bd)
						bs = sts[i];
				}
				return bs;
			}
			return null;
		}

		private bool IsSelectionStroke(Microsoft.Ink.Cursor c)
		{
			for (int i=0; i!=c.Buttons.Count; i++)
			{
				if (c.Buttons[i].Name == "Barrel Switch")
				{
					if (c.Buttons[i].State == Microsoft.Ink.CursorButtonState.Down)
						return true;
					else
						return false;
				}
			}
			return false;
		}

		private void onSelectionStroke(Microsoft.Ink.InkCollectorStrokeEventArgs e, bool istap)
		{
			if (istap)
			{
				Point pt = e.Stroke.GetPoint(0);

				if (viewer.SelectedStrokes.Length == 0)
				{
					viewer.AddStrokeToSelected( this.GetStrokeNear(pt) );
				}

				Graphics gr = this.CreateGraphics();
				(new Renderer()).InkSpaceToPixel(gr, ref pt);
				gr.Dispose();
				RightClickOnSelectedEvent(pt);
			}
			else
			{
				viewer.Selected = viewer.Ink.HitTest(e.Stroke.GetPoints(), 50);
				Invalidate();
			}
		}

		private bool IsDragging
		{
			get
			{
				if (viewer.SelectedStrokes.Length > 1)
					return true;
				if (dragmode)
					return true;
				return false;
			}
		}

		private int curstroketype = 0;
		private void onNewPackets(object sender, InkCollectorNewPacketsEventArgs e)
		{
			if ((IsSelectionStroke(e.Cursor)) || (curstroketype == 1))
			{
				Point pt;

				if (curstroketype != 1)
				{
					pt = new Point(e.PacketData[0*e.Stroke.PacketSize+0],
						e.PacketData[0*e.Stroke.PacketSize+1]);

					this.lassostart = pt;
					lassoend = lassostart;
				}
				else
				{
					int i = e.PacketCount-1;
					pt = new Point(e.PacketData[i*e.Stroke.PacketSize+0],
						e.PacketData[i*e.Stroke.PacketSize+1]);

					this.lassoend = pt;
				}
				curstroketype = 1;
				e.Stroke.DrawingAttributes.Width = ic.DefaultDrawingAttributes.Width * 2;
				e.Stroke.DrawingAttributes.Color = System.Drawing.Color.Yellow;
				e.Stroke.DrawingAttributes.RasterOperation = Microsoft.Ink.RasterOperation.XOrPen;

				this.isusinglasso = true;
				Invalidate();
				return;
			}
			if ((IsDragging) || (curstroketype == 2))
			{
				curstroketype = 2;
				e.Stroke.DrawingAttributes.RasterOperation = Microsoft.Ink.RasterOperation.NoOperation;
				//if ((e.PacketCount >= 11) && (((e.PacketCount-1)%10)==0))
				Point[] pts = e.Stroke.GetPoints();
				if (InkInterp.LineLength(pts) < 500)
					return;
				if (pts.Length > 1)
				{
					Point delta = pts[ pts.Length-1 ];
					Point from = pts[ pts.Length-2 ];
					delta.X -= from.X;
					delta.Y -= from.Y;
					Selected_Move(delta);
					Invalidate();
				}
				return;
			}
		}

		/// <summary>
		/// Used in the Event hander for Right Clicks, holds the mouse coordinates of where
		/// the right click event originated
		/// </summary>
		public class RightClickEventArgs : System.EventArgs
		{
			private Point at;

			/// <summary>
			/// Create a new RightClickEvenArgs object at the given point
			/// </summary>
			/// <param name="mpos"></param>
			public RightClickEventArgs(Point mpos)
			{
				at = mpos;
			}

			/// <summary>
			/// The point at which the tap occured, given in pixel coordinates
			/// </summary>
			public Point At
			{
				get	{ return at; }
			}
		}

		/// <summary>
		/// Event hander for RightClickEvent
		/// </summary>
		public delegate void RightClickEventHander(
			object source, RightClickEventArgs e);

		/// <summary>
		/// This event occurs when the user performs a short
		/// tap while either pressing the right mouse button, or the barrel button on their pen.
		/// It is recomended that the owning form bring up a ContextMenu at the given point.
		/// </summary>
		public event RightClickEventHander	RightClickOnSelected;

		private void RightClickOnSelectedEvent(Point m)
		{
			RightClickEventArgs args = new RightClickEventArgs(m);
			if (RightClickOnSelected != null)
				RightClickOnSelected(this, args);
		}

		private void onStroke(object sender, Microsoft.Ink.InkCollectorStrokeEventArgs e)
		{
			e.Cancel = true; //make sure stroke isn't added to Ink
			float len = AniInk.InkInterp.LineLength( e.Stroke.GetPoints() );
			bool istap = (len < 200);
			Stroke st;

			if (curstroketype == 1)
			{
				this.isusinglasso = false;
				onSelectionStroke(e, istap);
				curstroketype = 0;
				return;
			}
			if (curstroketype == 2)
			{
				IsDragMode = false;
				if (istap)
				{
					st = null;
					if (this.ismultiselect)
					{
						st = GetStrokeNear( e.Stroke.GetPoint(0) );
						viewer.AddStrokeToSelected(st);
					}
					if (st == null)
						viewer.ClearSelected();
				}
				curstroketype = 0;
				Invalidate();
				return;
			}
			curstroketype = 0;

			StrokePath path;
			StrokeIT sit;
			bool added = false;
			float stroketime = 0f;
			if (istap)
			{
				st = GetStrokeNear( e.Stroke.GetPoint(0) );
				if (!this.ismultiselect)
					viewer.ClearSelected();
				viewer.AddStrokeToSelected( st );
			}
			else
			{
				sit = null;
				path = null;
				Stroke sel = null;
				bool addit = true;
				if (viewer.SelectedStrokes.Length==1)
				{
					sel = viewer.SelectedStrokes[0];
					path = viewer.StrokeToStrokePath(sel);
					if (path!=null)
					{
						sit = path.GetPrevStroke(curtime);
						if (sit != null)
						{
							added = true;
							stroketime = sit.StartTime;
						}
					}
				}
				if ((path != null)&&(path.GetStrokeStartingAt(curtime)!=null))
				{
					addit = false;
					if (MessageBox.Show(this, "Replace drawn stroke with selected stroke?\n(NOTE: They are at the same time)", "Ink AniEd", MessageBoxButtons.YesNo,MessageBoxIcon.Question,MessageBoxDefaultButton.Button2)==DialogResult.Yes)
					{
						addit = true;
					}
					sel = viewer.StrokePathToStroke(path);	//because of possible refresh during message box
				}
				if (addit)
					viewer.AddStroke(e.Stroke, curtime, sel);
			}
			this.Invalidate();

			if ((added) && (viewer.SelectedStrokes.Length == 1))
			{
				st = viewer.SelectedStrokes[0];
				st = viewer.NextStrokeAtTime(st, stroketime);
				viewer.ClearSelected();
				viewer.AddStrokeToSelected(st);
			}
		}

		private bool isusinglasso = false;
		private Point lassostart;
		private Point lassoend;

		private void onPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.FillRectangle( System.Drawing.Brushes.White, e.ClipRectangle );
			Rectangle rect = System.Drawing.Rectangle.FromLTRB(0, 0, Size.Width-1, Size.Height-1);
			if (drawborder)
				e.Graphics.DrawRectangle( System.Drawing.Pens.Black, rect );
			if (isPlaying)
				viewer.QuickRender(e.Graphics, curtime);
			else
			{
				if (!isusinglasso)
				{
					viewer.Render(e.Graphics, curtime);
					this.Focus();	//don't ask
				}
				else
					viewer.LassoQuickRender(e.Graphics, lassostart, lassoend);
			}
		}

		private void onIdle(object ob, System.EventArgs args)
		{
			if (!this.isPlaying)
				return;
			long now = System.DateTime.Now.Ticks;
			double dt = now - ticktime;
			ticktime = now;

			dt /= (10000000.0);
			dt *= rateoftime;
			Time += (float)dt;

			this.Invalidate();
		}
	}
};
