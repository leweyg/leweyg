
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using Microsoft.Ink;

namespace AniEd
{
	/// <summary>
	/// This is an example usage of the AniInk.AniEd Control, and shows how simple it is to use
	/// In the Constructor you will see that you use the AniEd control like any other, and then
	/// all the other functions in you program (menu options and such) you will notice are usually
	/// one or two calls to function in AniEd. Not to meantion that this is a full editor, creating
	/// just a player is almost no work at all.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private AniInk.AniEd anied;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.TrackBar trackBar1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.MenuItem menuItem19;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem20;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem21;
		private System.Windows.Forms.MenuItem menuItem22;
		private System.Windows.Forms.MenuItem menuItem23;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.MenuItem menuItem24;
		private System.Windows.Forms.MenuItem menuItem25;
		private System.Windows.Forms.MenuItem menuItem26;
		private System.Windows.Forms.PictureBox pictureBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1(string filetoopen) : this()
		{
			anied.InkPath.LoadFromFile(filetoopen);
		}

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			//Just create the AniEd, and place it on your window, just like any other control
			anied = new AniInk.AniEd();
			anied.Location = this.pictureBox1.Location;
			anied.Size = this.pictureBox1.Size;
			anied.Anchor = this.pictureBox1.Anchor;
			this.pictureBox1.Parent = null;
			anied.Parent = this;

			//Subscribe to the TimeChange event if you want to (used to update trackbar)
			anied.TimeChange += new System.EventHandler( onTimeChange );
			anied.RightClickOnSelected += new AniInk.AniEd.RightClickEventHander( onRightClicked );
			anied.Time = 0.0f;

			//Set up your track bar
			this.trackBar1.Minimum = 0;
			this.trackBar1.Maximum = 20;
			this.trackBar1.Scroll += new System.EventHandler( onScroll );

			anied.Viewer.SelectedChanged += new System.EventHandler( onSelectionChange );

			//Set up combo boxes
			this.comboBox1.Items.Insert(0, "Width: Thin");
			this.comboBox1.Items.Insert(1, "Width: Medium Thin");
			this.comboBox1.Items.Insert(2, "Width: Medium");
			this.comboBox1.Items.Insert(3, "Width: Medium Thick");
			this.comboBox1.Items.Insert(4, "Width: Thick");
			this.comboBox1.SelectedIndex = 1;
		}

		protected void onSelectionChange(object sender, System.EventArgs ea)
		{
			button8.Enabled = (anied.Viewer.NumSelected != 0);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button1 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.trackBar1 = new System.Windows.Forms.TrackBar();
			this.button6 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem23 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem26 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem18 = new System.Windows.Forms.MenuItem();
			this.menuItem19 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem24 = new System.Windows.Forms.MenuItem();
			this.menuItem25 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.button2 = new System.Windows.Forms.Button();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.button5 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem20 = new System.Windows.Forms.MenuItem();
			this.menuItem21 = new System.Windows.Forms.MenuItem();
			this.menuItem22 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem17 = new System.Windows.Forms.MenuItem();
			this.button8 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(104, 16);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(24, 24);
			this.button1.TabIndex = 0;
			this.button1.Text = ">";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(40, 16);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(24, 24);
			this.button3.TabIndex = 3;
			this.button3.Text = "<";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(72, 16);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(24, 24);
			this.button4.TabIndex = 4;
			this.button4.Text = "||";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.trackBar1,
																					this.button6,
																					this.button1,
																					this.button4,
																					this.button3,
																					this.label1});
			this.groupBox1.Location = new System.Drawing.Point(8, 240);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(336, 72);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Time Controls:";
			// 
			// trackBar1
			// 
			this.trackBar1.Location = new System.Drawing.Point(136, 16);
			this.trackBar1.Name = "trackBar1";
			this.trackBar1.Size = new System.Drawing.Size(192, 45);
			this.trackBar1.TabIndex = 7;
			this.trackBar1.TickStyle = System.Windows.Forms.TickStyle.Both;
			this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(8, 16);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(24, 24);
			this.button6.TabIndex = 6;
			this.button6.Text = "[]";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 48);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(112, 16);
			this.label1.TabIndex = 7;
			this.label1.Text = "0";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem3,
																					  this.menuItem24,
																					  this.menuItem14});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem23,
																					  this.menuItem10,
																					  this.menuItem9,
																					  this.menuItem26,
																					  this.menuItem2});
			this.menuItem1.Text = "File";
			// 
			// menuItem23
			// 
			this.menuItem23.Index = 0;
			this.menuItem23.Text = "New";
			this.menuItem23.Click += new System.EventHandler(this.menuItem23_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 1;
			this.menuItem10.Text = "Open...";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 2;
			this.menuItem9.Text = "Save...";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// menuItem26
			// 
			this.menuItem26.Index = 3;
			this.menuItem26.Text = "Export to SVG...";
			this.menuItem26.Click += new System.EventHandler(this.menuItem26_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 4;
			this.menuItem2.Text = "Exit";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 1;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem18,
																					  this.menuItem19,
																					  this.menuItem4,
																					  this.menuItem12,
																					  this.menuItem5});
			this.menuItem3.Text = "Edit";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem18
			// 
			this.menuItem18.Index = 0;
			this.menuItem18.Text = "Copy";
			this.menuItem18.Click += new System.EventHandler(this.menuItem18_Click);
			// 
			// menuItem19
			// 
			this.menuItem19.Index = 1;
			this.menuItem19.Text = "Paste";
			this.menuItem19.Click += new System.EventHandler(this.menuItem19_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 2;
			this.menuItem4.Text = "Clear All";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 3;
			this.menuItem12.Text = "Clear From This Time";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 4;
			this.menuItem5.Text = "Select all at this time";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click_1);
			// 
			// menuItem24
			// 
			this.menuItem24.Index = 2;
			this.menuItem24.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem25});
			this.menuItem24.Text = "Mode";
			// 
			// menuItem25
			// 
			this.menuItem25.Checked = true;
			this.menuItem25.Index = 0;
			this.menuItem25.Text = "High Quality Play";
			this.menuItem25.Click += new System.EventHandler(this.menuItem25_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 3;
			this.menuItem14.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem16,
																					   this.menuItem15});
			this.menuItem14.Text = "Help";
			// 
			// menuItem16
			// 
			this.menuItem16.Index = 0;
			this.menuItem16.Text = "Basic Help...";
			this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 1;
			this.menuItem15.Text = "About...";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// button2
			// 
			this.button2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button2.Location = new System.Drawing.Point(432, 280);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(64, 24);
			this.button2.TabIndex = 8;
			this.button2.Text = "Color";
			this.button2.Click += new System.EventHandler(this.button2_Click_1);
			// 
			// comboBox1
			// 
			this.comboBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox1.DropDownWidth = 112;
			this.comboBox1.Location = new System.Drawing.Point(352, 248);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(72, 21);
			this.comboBox1.TabIndex = 10;
			this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// button5
			// 
			this.button5.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button5.Location = new System.Drawing.Point(352, 280);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(32, 24);
			this.button5.TabIndex = 11;
			this.button5.Text = "|<";
			this.button5.Click += new System.EventHandler(this.button5_Click_1);
			// 
			// button7
			// 
			this.button7.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button7.Location = new System.Drawing.Point(392, 280);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(32, 24);
			this.button7.TabIndex = 12;
			this.button7.Text = ">|";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// contextMenu1
			// 
			this.contextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.menuItem6,
																						 this.menuItem20,
																						 this.menuItem21,
																						 this.menuItem22,
																						 this.menuItem7,
																						 this.menuItem8,
																						 this.menuItem11,
																						 this.menuItem13,
																						 this.menuItem17});
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 0;
			this.menuItem6.Text = "Use this width and color";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click_1);
			// 
			// menuItem20
			// 
			this.menuItem20.Index = 1;
			this.menuItem20.Text = "Drag this Stroke";
			this.menuItem20.Click += new System.EventHandler(this.menuItem20_Click_1);
			// 
			// menuItem21
			// 
			this.menuItem21.Index = 2;
			this.menuItem21.Text = "Copy (to clipboard)";
			this.menuItem21.Click += new System.EventHandler(this.menuItem21_Click);
			// 
			// menuItem22
			// 
			this.menuItem22.Index = 3;
			this.menuItem22.Text = "Paste";
			this.menuItem22.Click += new System.EventHandler(this.menuItem22_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 4;
			this.menuItem7.Text = "Delete Moment";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click_1);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 5;
			this.menuItem8.Text = "Delete Path";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click_1);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 6;
			this.menuItem11.Text = "Copy to this time";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click_1);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 7;
			this.menuItem13.Text = "End Path at this time";
			this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click_1);
			// 
			// menuItem17
			// 
			this.menuItem17.Index = 8;
			this.menuItem17.Text = "Copy Last frame to this one";
			this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click_1);
			// 
			// button8
			// 
			this.button8.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button8.Location = new System.Drawing.Point(432, 248);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(64, 24);
			this.button8.TabIndex = 13;
			this.button8.Text = "Actions";
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(488, 224);
			this.pictureBox1.TabIndex = 14;
			this.pictureBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(506, 313);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.pictureBox1,
																		  this.button8,
																		  this.button7,
																		  this.button5,
																		  this.comboBox1,
																		  this.button2,
																		  this.groupBox1});
			this.MaximizeBox = false;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Ink AniEd 1.2";
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) 
		{
			Form1 f;
			if (args.Length==1)
				f = new Form1(args[0]);
			else
				f = new Form1();
			Application.Run(f);
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			//Make sure the rate of time is set to normal playback
			anied.RateOfTime = 1.0f;

			//Press play, lay back, and relax
			anied.Play();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			//Yes it's that simple
			anied.Pause();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			//Set rate of time to reverse normal playback
			anied.RateOfTime = -1.0f;

			//Just hit play
			anied.Play();
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			//Reset time to 0.0, and then pause
			anied.Time = 0.0f;
			anied.Pause();
		}

		private void OpenContextMenu(Point at)
		{
			if (anied.Viewer.SelectedStrokes.Length == 0)
			{
				System.Windows.Forms.MessageBox.Show("No strokes currently selected", "Ink AniEd");
				return;
			}
			this.menuItem20.Enabled = (anied.Viewer.SelectedStrokes.Length == 1);
			this.menuItem6.Enabled = (anied.Viewer.SelectedStrokes.Length == 1);
			contextMenu1.Show(this, at);
		}

		private void onRightClicked(object sender, AniInk.AniEd.RightClickEventArgs e)
		{
			OpenContextMenu(e.At);
		}

		private void onTimeChange(object sender, System.EventArgs e)
		{
			//This is the event hander or when the time changes in AniEd, notice that only
			//the one line below actually deals with AniEd, the rest is trackbar stuff
			float time = anied.Time;

			this.label1.Text = "Time = "+time;
			int sec = (int)time;
			if (time >= 0)
			{
				time -= (float)sec;
				if (time > 0.5)
					sec++;
			}
			else
			{
				time -= (float)sec;
				if (time < 0.5)
					sec--;
			}
			int diff;
			if (sec <= this.trackBar1.Minimum)
			{
				diff = (this.trackBar1.Minimum - sec);
				this.trackBar1.Minimum -= diff;
			}
			if (sec > this.trackBar1.Maximum)
			{
				diff = (sec - this.trackBar1.Maximum);
				this.trackBar1.Maximum += diff;
			}
			this.trackBar1.Value = sec;
		}

		private void onScroll(object sender, System.EventArgs e)
		{
			//When the trackbar moves, just set this as the new time
			anied.Time = (float)(this.trackBar1.Value);

			//make sure to date it
			anied.Invalidate();
		}

		private void trackBar1_Scroll(object sender, System.EventArgs e)
		{
		}

		private void groupBox2_Enter(object sender, System.EventArgs e)
		{
		
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void button2_Click_1(object sender, System.EventArgs e)
		{
			//Create a new color selector
			ColorDialog cd = new ColorDialog();

			//set the default color to AniEd's current color
			cd.Color = anied.DefaultDrawingAttributes.Color;

			if (cd.ShowDialog() == DialogResult.OK)
				//Change anied current color
				anied.DefaultDrawingAttributes.Color = cd.Color;
		}

		private void comboBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			int i = this.comboBox1.Items.IndexOf( comboBox1.SelectedItem );
			if (i==-1)
				return;
			float width = i;
			width *= 50.0f;
			if (width == 0.0f)
				width = 5;

			//Set the width of the pen based on which item was selected.
			anied.DefaultDrawingAttributes.Width = width;
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			//delete all paths
			anied.Viewer.DeletePaths();
			anied.Invalidate();
		}

		private void button5_Click_1(object sender, System.EventArgs e)
		{
			anied.GoToPrevTimeEvent();
			anied.Invalidate();
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			anied.GoToNextTimeEvent();
			anied.Invalidate();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			//To save, first get the file to save to
			System.Windows.Forms.SaveFileDialog fd = new System.Windows.Forms.SaveFileDialog();
			fd.Filter = "Ink Animations (*.inka)|*.inka";
			fd.InitialDirectory = System.Environment.CurrentDirectory;
			fd.AddExtension = true;

			if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK)
				return;

			anied.InkPath.SaveToFile(fd.FileName);

		/* //This is how to save to a stream:

			FileStream fs = new FileStream(fd.FileName, FileMode.Create);
			StreamWriter s = new StreamWriter(fs);
			anied.InkPath.SaveToStream( s );
			s.Close();
			fs.Close(); */

		/*	//This is how you would save using standard serialization:
		 
			System.IO.Stream s = System.IO.File.Create(fd.FileName);
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter b = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			
			//Tough isn't it:
			b.Serialize(s, anied.InkPath);
			
			s.Close(); */
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			//To open a file, first get the file to open
			System.Windows.Forms.OpenFileDialog fd = new System.Windows.Forms.OpenFileDialog();
			fd.Filter = "Ink Animations (*.inka)|*.inka|All files (*.*)|*.*";
			fd.InitialDirectory = System.Environment.CurrentDirectory;

			if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK)
				return;

			anied.InkPath.LoadFromFile(fd.FileName);

			anied.Time = 0.0f;
			anied.Invalidate();

	/*		//This is how you would load from a stream:
	 * 
			FileStream fs = new FileStream(fd.FileName, FileMode.Open);
			StreamReader r = new StreamReader(fs);
			anied.InkPath.LoadFromStream( r );
			r.Close();
			fs.Close();
			anied.Time = 0.0f;
			anied.Invalidate(); */

	/*		// This is how you would load a file using serialization:
	 * 
			System.IO.Stream s = System.IO.File.OpenRead(fd.FileName);
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter b = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			
			//Create the new InkPath using deserialization:
			AniInk.InkPath path = (AniInk.InkPath)b.Deserialize(s);
			
			//Set the new InkPath for AniEd to use:
			anied.InkPath = path;
			anied.Invalidate();
			
			s.Close(); */
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			anied.ClearFromThisFrame();
		}

		private void menuItem13_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			string mess = "Ink AniEd  -  Version 1.2\n  http://plaza.ufl.edu/lewey/anied/\n\n";
			mess += "Written and Developed by Lewey Geselowitz\n�2003 Lewey Geselowitz";
			mess += "\n\nWritten entirely in C# using the all mighty Visual Studio.Net";
			mess += "\nThis software is public domain, which means anyone can use it for whatever you want.";
			mess += "\n (this includes it's inclusion modified or not in proprietary software). If you meantion my";
			mess += "\n name I would be grateful but it is not required, and telling me about it would be great.";
			mess += "\n\nEmail me at: lewey@ufl.edu\nMy webpage: http://plaza.ufl.edu/lewey";
			mess += "\n\nSpecial thanks go to the University of Florida";
			mess += "\n  for allowing me to developed on one of their TabletPCs.";
			mess += "\nTo Microsoft for donating the TabletPC to UF and";
			mess += "\n  writing the .Net Framework and Ink APIs.";
			mess += "\nTo my advisor Dr. Jorg Peters for his help in my research.";
			mess += "\nAnd to my friends who acted as both my testers and test subjects.";
			mess += "\n\nThanks to you all!\n    -Lewey";
			System.Windows.Forms.MessageBox.Show(mess, "About Ink AniEd");
		}

		private void menuItem16_Click(object sender, System.EventArgs e)
		{
			string mess;
			mess = "Animation:";
			mess += "\nSimply draw the objects you wish to animate,";
			mess += "\nand then adjust the time using either the bar or the time buttons.";
			mess += "\nYou can now change the object you draw in the last frame by";
			mess += "\nclicking on it to select it, and then drawing a new line. This";
			mess += "\nnew line will replace the selected one. You will now notice that if";
			mess += "\nyou go to a time between the two images you draw, the line will be blended";
			mess += "\nbetween them.";
			mess += "\n\nSelect multiple lines by right clicking and dragging";
			mess += "\na circle around them. Once you have selected one or many lines";
			mess += "\nyou can use the 'Actions' button to perform many common tasks";
			mess += "\nYou can also get the 'Actions' menu by right clicking on the selected";
			mess += "\nstroke(s).";
			System.Windows.Forms.MessageBox.Show(mess, "Help for Ink AniEd");
		}

		private void menuItem17_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem18_Click(object sender, System.EventArgs e)
		{
			InkClipboardFormats formats = new InkClipboardFormats();
  			formats |= InkClipboardFormats.InkSerializedFormat;
			formats |= InkClipboardFormats.Metafile;
			formats |= InkClipboardFormats.EnhancedMetafile;
			formats |= InkClipboardFormats.Bitmap;
			formats |= InkClipboardFormats.SketchInk;
			formats |= InkClipboardFormats.TextInk;
			anied.CopyToClipboard( formats );
		}

		private void menuItem19_Click(object sender, System.EventArgs e)
		{
			anied.PasteFromClipboard();
			anied.Invalidate();
		}

		private void menuItem20_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
		}

		private void menuItem6_Click_1(object sender, System.EventArgs e)
		{
			//Make sure at least one stroke is selected
			if (anied.Viewer.SelectedStrokes.Length < 1)
				return;
			//use the first selected stroke to get it's width and color:
			anied.DefaultDrawingAttributes.Width = anied.Viewer.SelectedStrokes[0].DrawingAttributes.Width;
			anied.DefaultDrawingAttributes.Color = anied.Viewer.SelectedStrokes[0].DrawingAttributes.Color;
		}

		private void menuItem8_Click_1(object sender, System.EventArgs e)
		{
			anied.Selected_DeletePaths();
			anied.Invalidate();
		}

		private void menuItem7_Click_1(object sender, System.EventArgs e)
		{
			anied.Selected_DeleteMoment();
			anied.Invalidate();
		}

		private void menuItem11_Click_1(object sender, System.EventArgs e)
		{
			anied.Selected_CopyToThisTime();
			anied.Invalidate();
		}

		private void menuItem13_Click_1(object sender, System.EventArgs e)
		{
			anied.Selected_EndPathsNow();
			anied.Invalidate();
		}

		private void menuItem17_Click_1(object sender, System.EventArgs e)
		{
			anied.Selected_CopyLastFrameToThisTime();
			anied.Invalidate();
		}

		private void menuItem20_Click_1(object sender, System.EventArgs e)
		{
			anied.IsDragMode = true;
		}

		private void menuItem5_Click_1(object sender, System.EventArgs e)
		{
			anied.SelectAll();
			anied.Invalidate();
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			menuItem19.Enabled = anied.CanPasteFromClipboard;
		}

		private void menuItem21_Click(object sender, System.EventArgs e)
		{
			menuItem18_Click(sender, e);
		}

		private void menuItem22_Click(object sender, System.EventArgs e)
		{
			menuItem19_Click(sender, e);
		}

		private void menuItem23_Click(object sender, System.EventArgs e)
		{
			//delete all paths
			anied.Viewer.DeletePaths();
			anied.Invalidate();
		}

		private void button8_Click(object sender, System.EventArgs e)
		{
			this.OpenContextMenu( button8.Location );
		}

		private void menuItem25_Click(object sender, System.EventArgs e)
		{
			this.anied.Viewer.HighQualityPlay = ! this.anied.Viewer.HighQualityPlay;
			menuItem25.Checked = this.anied.Viewer.HighQualityPlay;
		}

		private void menuItem26_Click(object sender, System.EventArgs e)
		{
			//To save, first get the file to save to
			System.Windows.Forms.SaveFileDialog fd = new System.Windows.Forms.SaveFileDialog();
			fd.Filter = "SVG Files (*.svg)|*.svg";
			fd.InitialDirectory = System.Environment.CurrentDirectory;
			fd.AddExtension = true;

			if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK)
				return;

			anied.ExportToSVG(fd.FileName);

		}
	}
}
