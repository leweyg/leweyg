using System;
using System.Drawing;
using System.Collections;
using System.Windows.Forms;
using System.Data;
using System.Threading;

namespace PocketAniEd
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MainMenu mainMenu1;

		public Form1(string[] args)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			Control p;

			anied = null;
			if (args.Length == 1)
			{
				InkPath ip = new InkPath(5);
				ip.LoadFromFile(args[0]);
				anied = new AniEd(ip);
			}
			else
				anied = new AniEd();

			anied.Location = pictureBox1.Location;
			anied.Size = pictureBox1.Size;
			p = pictureBox1.Parent;
			pictureBox1.Parent = null;
			anied.Parent = p;

			tracker = new TimeTrack(anied);
			tracker.Location = pictureBox2.Location;
			tracker.Size = pictureBox2.Size;
			p = pictureBox2.Parent;
			pictureBox2.Parent = null;
			tracker.Parent = p;

			anied.InkPath.MaxTime = tracker.Max;
			anied.tracker = tracker;

			anied.ChangedPlayState += new EventHandler( UpdatePlayButton );
			anied.Viewer.SelectedChanged += new EventHandler( onSelectedChanged );
			tracker.ValueChanged += new System.EventHandler( onTimeChanged );

			ThreadStart ts = new ThreadStart( timerThread );
			Thread tt = new Thread(ts);
			tt.Start();

			onSelectedChanged(this, null);

			this.Size = new Size(246, 325);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}
		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.button2 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.Add(this.menuItem1);
			this.mainMenu1.MenuItems.Add(this.menuItem4);
			this.mainMenu1.MenuItems.Add(this.menuItem6);
			// 
			// menuItem1
			// 
			this.menuItem1.MenuItems.Add(this.menuItem3);
			this.menuItem1.MenuItems.Add(this.menuItem14);
			this.menuItem1.MenuItems.Add(this.menuItem13);
			this.menuItem1.MenuItems.Add(this.menuItem15);
			this.menuItem1.MenuItems.Add(this.menuItem16);
			this.menuItem1.MenuItems.Add(this.menuItem2);
			this.menuItem1.Text = "File";
			// 
			// menuItem3
			// 
			this.menuItem3.Text = "New";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem14
			// 
			this.menuItem14.Text = "Open...";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Text = "Save...";
			this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
			// 
			// menuItem15
			// 
			this.menuItem15.Text = "Export to SVG...";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// menuItem16
			// 
			this.menuItem16.Text = "Set Ending Time...";
			this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Text = "Exit";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.MenuItems.Add(this.menuItem5);
			this.menuItem4.MenuItems.Add(this.menuItem8);
			this.menuItem4.MenuItems.Add(this.menuItem9);
			this.menuItem4.MenuItems.Add(this.menuItem10);
			this.menuItem4.MenuItems.Add(this.menuItem11);
			this.menuItem4.Text = "Selected";
			// 
			// menuItem5
			// 
			this.menuItem5.Text = "Delete Path";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Text = "Delete Moment";
			this.menuItem8.Click += new System.EventHandler(this.menuItem8_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Text = "End Paths Now";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Text = "Copy To This Time";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Text = "Copy Last To This Time";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.MenuItems.Add(this.menuItem12);
			this.menuItem6.MenuItems.Add(this.menuItem7);
			this.menuItem6.Text = "Help";
			// 
			// menuItem12
			// 
			this.menuItem12.Text = "Help";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Text = "About";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 8);
			this.pictureBox1.Size = new System.Drawing.Size(224, 216);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(200, 232);
			this.button2.Size = new System.Drawing.Size(32, 24);
			this.button2.Text = ">|";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(160, 232);
			this.button3.Size = new System.Drawing.Size(32, 24);
			this.button3.Text = "|<";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(8, 232);
			this.button4.Size = new System.Drawing.Size(24, 24);
			this.button4.Text = "S";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(40, 232);
			this.button5.Size = new System.Drawing.Size(24, 24);
			this.button5.Text = ">";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(72, 232);
			this.pictureBox2.Size = new System.Drawing.Size(80, 24);
			// 
			// Form1
			// 
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.button3);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.pictureBox1);
			this.Menu = this.mainMenu1;
			this.Text = "Pocket AniEd";

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>

		static void Main(string[] args) 
		{
			Application.Run(new Form1(args));
		}

		private void onSelectedChanged(object sender, System.EventArgs ea)
		{
			if ((anied.Viewer.SelectedStrokes==null) || (anied.Viewer.SelectedStrokes.Length==0))
			{
				menuItem4.Enabled = false;
			}
			else
				menuItem4.Enabled = true;
		}

		protected override void OnClosed(EventArgs e)
		{
			ShouldClose = true;
		}


		public bool ShouldClose = false;
		private void timerThread()
		{
			bool lastisplay = false;
			while (!ShouldClose)
			{
				if (anied.IsPlaying)
				{
					lastisplay = true;
					anied.OnTick(null);
					//System.Threading.Thread.Sleep( (int)anied.tickdt );
				}
				else
				{
					if (lastisplay)
						anied.MyRedraw();
					lastisplay = false;
					System.Threading.Thread.Sleep( 100 );
				}
			}
		}

		private void onTimeChanged(object sender, System.EventArgs ea)
		{
			anied.Time = tracker.Value;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private AniEd anied;
		private TimeTrack tracker;

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			anied.Pause();
			tracker.Value = 0;
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			float t;
			if (anied.InkPath.PrevTimeEvent( tracker.Value, out t))
			{
				tracker.Value = t;
			}
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			float t;
			if (anied.InkPath.NextTimeEvent( tracker.Value, out t))
			{
				tracker.Value = t;
			}
		}

		private void UpdatePlayButton(object sender, EventArgs ea)
		{
			if (anied.IsPlaying)
				button5.Text = "||";
			else
				button5.Text = ">";
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			anied.IsPlaying = !anied.IsPlaying;
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			anied.Viewer.DeletePaths();
			anied.MyRedraw();
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			anied.Selected_DeletePaths();
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			string mess = "Pocket AniEd 1.0\nWritten by Lewey Geselowitz";
			mess += "\n\nMore info at:\nhttp://plaza.ufl.edu/lewey/anied/pocket/";
			MessageBox.Show(mess, "About");
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
			anied.Selected_DeleteMoment();
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			anied.Selected_EndPathsNow();
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			anied.Selected_CopyToThisTime();
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			anied.Selected_CopyLastFrameToThisTime();
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			string mess = "Read help guide here:\nhttp://plaza.ufl.edu/lewey/anied/pocket/";
			MessageBox.Show(mess, "Help");
		}

		private void menuItem13_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "Pocket Animation (*.pani)|*.pani";
			if (sfd.ShowDialog()==DialogResult.OK)
			{
				anied.InkPath.SaveToFile( sfd.FileName );
			}
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog ofd = new OpenFileDialog();
			ofd.Filter = "Pocket Animation (*.pani)|*.pani";
			if (ofd.ShowDialog() == DialogResult.OK)
			{
				anied.LoadFromFile( ofd.FileName );
				tracker.Max = anied.InkPath.MaxTime;
			}
		}

		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog sfd = new SaveFileDialog();
			sfd.Filter = "SVG (*.svg)|*.svg";
			if (sfd.ShowDialog()==DialogResult.OK)
			{
				anied.ExportToSVG( sfd.FileName );
			}
		}

		private void menuItem16_Click(object sender, System.EventArgs e)
		{
			SetValue st = new SetValue( tracker.Max );
			if (st.ShowDialog() == DialogResult.OK)
			{
				tracker.Max = st.NewValue;
			}
		}
	}
}
