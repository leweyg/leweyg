
/// <summary>
///  Pocket AniInk is a rapid animation creation tool design for the Pocket PC using the
///  .Net compact framework.
///  
///  Read more about this app at it's homepage: http://plaza.ufl.edu/lewey/anied/pocket.html
///  
///	 Written and Developed by Lewey Geselowitz
///  This software is public domain, which means anyone can use it for whatever you want.
///	   (this includes it's inclusion modified or not in proprietary software). If you meantion my
///	   name I would be grateful but it is not required, and telling me about it would be great.
///
///  Written entirely in C# using the all mighty power of Visual Studio .Net 2003
///
///  Feel free to email with any questions or comemnts: lewey@ufl.edu
/// </summary>
/// 


namespace PocketAniEd
{
	using System;
	using System.Windows.Forms;
	using System.Drawing;
	using System.IO;
	
	/// <summary>
	/// This is a "Stroke In Time" object, it represents a single frame of a single stroke.
	/// Please note that all of it's members are public
	/// </summary>
	public class StrokeIT
	{
		/// <summary>
		/// The time that this stroke first appears
		/// </summary>
		public float StartTime;

		/// <summary>
		/// The set of points which make up the shape of this stroke
		/// </summary>
		public Point[] Points;

		/// <summary>
		/// This is the StrokePath which this stroke is a part of
		/// </summary>
		public StrokePath Path;

		public void FromStroke(StrokeIT other)
		{
			Path = other.Path;
			this.Points = new Point[other.Points.Length];
			for (int i=0; i<Points.Length; i++)
			{
				this.Points[i] = other.Points[i];
			}
		}

		/// <summary>
		/// This is the time when this stroke ends, this value is calculated by looking
		/// in owning path and getting the start time of the next stroke.
		/// </summary>
		public float EndTime
		{
			get
			{
				int i = Mem.GetIndex( Path.StrokesIT, this);
				if (i < 0)
					return (float)-1.0;
				if (i+1 < Path.StrokesIT.Length)
					return Path.StrokesIT[i+1].StartTime;
				if (Path.DoesEnd)
					return Path.EndTime;
				return (float)-1.0;
			}
		}

		/// <summary>
		/// Returns the index of this StrokeIT it it's owning StrokePath
		/// </summary>
		public int IndexInPath
		{
			get
			{
				for (int i=0; i!=Path.StrokesIT.Length; i++)
				{
					if (Path.StrokesIT[i] == this)
						return i;
				}
				return -1;
			}
		}

		/// <summary>
		/// Move the stroke by adding the given vector to all points.
		/// Vector is given in Ink coordinates
		/// </summary>
		/// <param name="delta">Vector to move all points by</param>
		public void Move(Point delta)
		{
			Point pt;
			for (int i=0; i!=Points.Length; i++)
			{
				pt = Points[i];
				pt.X += delta.X;
				pt.Y += delta.Y;
				Points[i] = pt;
			}
		}

		public void LengthwiseResample()
		{
			Point[] pts = new Point[Points.Length];
			InkInterp.LengthwiseResample(Points, pts);
			Points = pts;
		}

		/// <summary>
		/// Quickly copies this stroke into the given stroke. It also resamples the points
		/// so as to match the number of points in the 'other' line
		/// </summary>
		/// <param name="other">StrokeIT to copy data into</param>
		public void QuickToStroke(StrokeIT other)
		{
			InkInterp.ResampleLine( Points, other.Points );
		}

		/// <summary>
		/// Interpolate between two StrokeITs, and store the result in the given Ink.
		/// </summary>
		/// <param name="from">From stroke (0.0)</param>
		/// <param name="to">ToStroke (1.0)</param>
		/// <param name="t">Interpolation value (0.0 to 1.0)</param>
		/// <param name="ink">Ink to be added to</param>
		/// <returns>The newly created stroke</returns>
		public static StrokeIT Interp(StrokeIT from, StrokeIT to, float t)
		{
			StrokeIT sit = new StrokeIT( InkInterp.Interp(from.Points.Length, to.Points.Length, t), false);
			Interp(from, to, t, sit);
			return sit;
		}

		/// <summary>
		/// Interpolate between two StrokeITs, and store the result in the given StrokeIT.
		/// </summary>
		/// <param name="from">From stroke (0.0)</param>
		/// <param name="to">ToStroke (1.0)</param>
		/// <param name="t">Interpolation value (0.0 to 1.0)</param>
		/// <param name="ink">StrokeIT to hold result</param>
		public static void Interp(StrokeIT from, StrokeIT to, float t, StrokeIT ans)
		{
			InkInterp.Interp(from.Points, to.Points, t, ans.Points);
		}

		public StrokeIT()
		{
			StartTime = 0;
			Points = new Point[0];
		}

		/// <summary>
		/// Create a new stroke with the given number of points. And specify if it is to have
		/// an array or pressure as well.
		/// </summary>
		/// <param name="numpoints">number of points in this stroke</param>
		/// <param name="haspressure">if this stroke holds memory for pressure</param>
		public StrokeIT(int numpoints, bool haspressure)
		{
			StartTime = (float)0.0;
			Points = new Point[numpoints];
		}

		/// <summary>
		/// Create a stroke with the given path as it's owning StrokePath
		/// </summary>
		/// <param name="path">Owner</param>
		public StrokeIT(StrokePath path) : this()
		{
			Path = path;
		}
	}

	
	
	/// <summary>
	/// A StrokePath represents a stroke across time. So it holds a series of individual StrokeITs
	/// and includes utilities to sample them correctly and interpolate between them as needed.
	/// It is essentially an animated Stroke.
	/// </summary>
	public class StrokePath
	{
		/// <summary>
		/// The array of StrokeITs which make up this path
		/// </summary>
		public StrokeIT[] StrokesIT;

		/// <summary>
		/// Stores whether this path ends at some time
		/// </summary>
		public bool DoesEnd;

		/// <summary>
		/// Stores the time when this path ends, if any
		/// </summary>
		public float EndTime;

		/// <summary>
		/// Copies the previous StrokeIT before the given time into this given time
		/// This feature is useful for editing.
		/// </summary>
		public void CopyToThisTime(float time)
		{
			StrokeIT sit = this.GetAtOrPrevStroke(time);
			if (sit == null)
				return;
			if (sit.StartTime == time)
				return;
			StrokeIT ns = new StrokeIT();
			ns.FromStroke(sit);
			ns.StartTime = time;
			ns.Path = this;
			StrokesIT = (StrokeIT[])Mem.AddAfter(StrokesIT, ns, sit.IndexInPath);
		}

		public int MaxSamples
		{
			get
			{
				int max = 0;
				foreach(StrokeIT sit in StrokesIT)
				{
					if (sit.Points.Length > max)
						max = sit.Points.Length;
				}
				return max;
			}
		}

		public void WriteSVGPoints(StreamWriter sw, Point[] line)
		{
			foreach(Point p in line)
			{
				sw.Write("{0} {1} ", p.X, p.Y);
			}
		}

		public string ToSVGColor(Color color)
		{
			return String.Format("rgb({0},{1},{2})", color.R, color.G, color.B );
		}

		public void WriteToSVG(StreamWriter sw)
		{
			int max = MaxSamples;
			Point[] line = new Point[max];

			sw.Write("\t<polyline style=\"stroke:{1};stroke-width:{0};fill-opacity:0.0;\" points=\"", 2, ToSVGColor(Color.Black));
			for (int i=0; i<max; i++)
			{
				sw.Write("0 0 ");
			}
			sw.WriteLine("\" >");

			if (StrokesIT.Length==1)
			{
				StrokeIT cur = StrokesIT[0];

				sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"points\" ", cur.StartTime);
				if (!DoesEnd)
				{
					sw.Write("dur=\"1s\" fill=\"freeze\" ");
				}
				else
				{
					sw.Write("dur=\"{0}s\" ", EndTime - cur.StartTime);
				}
				sw.Write("values=\"");
				WriteSVGPoints(sw, cur.Points );
				sw.WriteLine("\" />");
			}
			else
			{
				float starttime = StrokesIT[0].StartTime;
				float endtime = StrokesIT[StrokesIT.Length-1].StartTime;
				if (DoesEnd)
					endtime = EndTime;
				bool addextra = ((DoesEnd) && (endtime != StrokesIT[StrokesIT.Length-1].StartTime));
				//addextra = false;
				sw.Write("\t\t<animate begin=\"mytimer.begin+{0}s\" repeatCount=\"1\" attributeName=\"points\" ", starttime );
				sw.Write("dur=\"{0}s\" ", endtime-starttime);
				if (!DoesEnd)
					sw.Write("fill=\"freeze\" ");

				sw.Write("keyTimes=\"");
				for (int s=0; s<StrokesIT.Length; s++)
				{
					sw.Write("{0}", (StrokesIT[s].StartTime-starttime)/(endtime-starttime));
					if (s+1 < StrokesIT.Length)
						sw.Write(";");
				}
				if (addextra)
					sw.Write(";1;");
				sw.Write("\" ");

				sw.Write("values=\"");
				for (int s=0; s<StrokesIT.Length; s++)
				{
					InkInterp.ResampleLine( StrokesIT[s].Points, line );
					WriteSVGPoints(sw, line );
					if (s+1 < StrokesIT.Length)
						sw.Write(";");
				}
				if (addextra)
				{
					sw.Write(";");
					WriteSVGPoints(sw, line);
				}
				sw.WriteLine("\" />");
			}

			sw.WriteLine("\t</polyline>");
		}

		/// <summary>
		/// Deletes the given StrokeIT from this path
		/// </summary>
		public void DeleteStrokeIT(StrokeIT sit)
		{
			StrokesIT = Mem.Remove(StrokesIT, sit);
		}

		/// <summary>
		/// Adds an Ink.Stroke to this path by converting it into a StrokeIT first
		/// </summary>
		/// <param name="st">Ink.Stroke to add</param>
		/// <param name="starttime">Time to add it</param>
		/// <returns>Newly created StrokeIT</returns>
		public void AddStroke(StrokeIT st, float starttime)
		{
			StrokeIT sit = st;
			sit.Path = this;

			//If there are no strokes:
			if (StrokesIT.Length == 0)
			{
				sit.Path = this;
				sit.StartTime = starttime;
				StrokesIT = new StrokeIT[1];
				StrokesIT[0] = sit;
				return;
			}

			//If there is already a stroke at that points
			StrokeIT at = GetStrokeStartingAt(starttime);
			if (at != null)
			{
				at.FromStroke( st );
				at.Path = this;
				return;
			}

			//Add a new stoke at some point in time;
			at = GetPrevStroke( starttime );
			sit.Path = this;
			sit.StartTime = starttime;
			StrokesIT = (StrokeIT[])Mem.AddAfter( StrokesIT, sit, at.IndexInPath);
			return;
		}

		/// <summary>
		/// Get a time event before the given time. Time events are either starting stroke times
		/// or the end time.
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="prev">Store result in here</param>
		/// <returns>Whether an even was found or not</returns>
		public bool PrevTimeEvent(float from, ref float prev)
		{
			if ((DoesEnd) && (from > EndTime))
			{
				prev = EndTime;
				return true;
			}
			if (StrokesIT.Length==0)
				return false;
			float best = StrokesIT[0].StartTime;
			if (from <= best)
				return false;

			for (int i=1; i < this.StrokesIT.Length; i++)
			{
				if (StrokesIT[i].StartTime < from)
					best = StrokesIT[i].StartTime;
			}
			prev = best;
			return true;
		}

		/// <summary>
		/// Get a time event after the given time. Time events are either starting stroke times
		/// or the end time.
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="prev">Store result in here</param>
		/// <returns>Whether an even was found or not</returns>
		public bool NextTimeEvent(float from, ref float next)
		{
			StrokeIT sit;
			for (int i=0; i!=this.StrokesIT.Length; i++)
			{
				sit = StrokesIT[i];
				if (sit.StartTime > from)
				{
					next = sit.StartTime;
					return true;
				}
			}
			if ((DoesEnd) && (this.EndTime > from))
			{
				next = EndTime;
				return true;
			}
			return false;
		}

		/// <summary>
		/// Gets the most recent StrokeIT from the given time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetPrevStroke(float t)
		{
			if (StrokesIT.Length==0)
				return null;

			int found = -1;
			int i;
			for (i=0; (found==-1)&&(i<StrokesIT.Length); i++)
			{
				if (t < StrokesIT[i].StartTime)
					found = i;
			}
			if (found == -1)
			{
				return StrokesIT[StrokesIT.Length-1];
			}
			if (found == 0)
				return null;
			return StrokesIT[found-1];
		}

		/// <summary>
		/// Gets the most recent StrokeIT from the given time, including at the given time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetAtOrPrevStroke(float time)
		{
			StrokeIT sit = this.GetStrokeStartingAt(time);
			if (sit != null)
				return sit;
			sit = this.GetPrevStroke(time);
			return sit;
		}

		public bool ExistsAtTime(float time)
		{
			if ((StrokesIT.Length==0) || (StrokesIT[0].StartTime > time))
				return false;
			if ((DoesEnd) && (time > EndTime))
				return false;
			return true;
		}

		public StrokeIT GetStrokeAtTime(float time)
		{
			if (!ExistsAtTime(time))
				return null;
			StrokeIT sit = GetStrokeStartingAt(time);
			if (sit != null)
				return sit;
			sit = GetPrevStroke(time);
			if (sit.IndexInPath == StrokesIT.Length-1)
			{
				StrokeIT ns = new StrokeIT();
				ns.FromStroke(sit);
				return ns;
			}
			StrokeIT next;
			next = StrokesIT[ sit.IndexInPath+1 ];
			time = ((time - sit.StartTime) / (next.StartTime - sit.StartTime));
			StrokeIT to = new StrokeIT(this);
			to.Points = InkInterp.Interp( sit.Points, next.Points, time);
			return to;
		}

		/// <summary>
		/// Quickly calculate the StrokeIT at a given time, and interpolate between frames
		/// </summary>
		/// <param name="to">StrokeIT to store result</param>
		/// <param name="time">Time to sample at</param>
		/// <returns>Returns false if the time is outside of this stroke's domain</returns>
		public StrokeIT QuickStrokeAtTime(StrokeIT to, float time)
		{
			StrokeIT sit;
			if (!ExistsAtTime(time))
				return null;
			sit = GetStrokeStartingAt(time);
			if (sit != null)
			{
				return sit;
			}
			sit = GetPrevStroke(time);
			if (sit == StrokesIT[StrokesIT.Length-1])
			{
				return sit;
			}
			StrokeIT next;
			next = StrokesIT[ sit.IndexInPath+1 ];
			time = ((time - sit.StartTime) / (next.StartTime - sit.StartTime));
			InkInterp.Interp(sit.Points, next.Points, time, to.Points );

			return null;
		}

		/// <summary>
		/// Gets the StrokeIT which started at this time
		/// </summary>
		/// <param name="t">Time to look from</param>
		/// <returns>StrokeIT which was found</returns>
		public StrokeIT GetStrokeStartingAt(float time)
		{
			for (int i=0; i!=StrokesIT.Length; i++)
			{
				if (StrokesIT[i].StartTime == time)
					return StrokesIT[i];
			}
			return null;
		}

		/// <summary>
		/// Create a new StrokePath with the default settings
		/// </summary>
		public StrokePath()
		{
			StrokesIT = new StrokeIT[0];
			DoesEnd = false;
			EndTime = 0.0f;
		}
	}

	
	
	/// <summary>
	/// An InkPath is a collection of StrokePaths.
	/// </summary>
	public class InkPath
	{
		private StrokePath[] paths;
		private float maxtime;

		public float MaxTime
		{
			get { return maxtime; }
			set { maxtime = value; }
		}

		/// <summary>
		/// This returns the StrokePaths which make up this InkPath
		/// </summary>
		public StrokePath[] Paths
		{
			get { return paths; }
		}

		public bool ExportToSVG(string filename, int scrwidth, int scrheight, int inkwidth, int inkheight)
		{
			StreamWriter sw = new StreamWriter(filename);
			if (sw==null)
				return false;

			sw.WriteLine("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?> ");
			sw.Write("<svg id=\"root\" xml:space=\"preserve\" width=\"{0}\" height=\"{1}\" ", scrwidth, scrheight );
			sw.WriteLine("viewBox=\"0 0 {0} {1}\">", inkwidth, inkheight );

			sw.WriteLine("\t<text x=\"0\" y=\"15\" style=\"font-size:15;fill:black;text-anchor:left\">Reset");
			sw.WriteLine("\t\t<animate id=\"mytimer\" begin=\"mybox.click;mybox.load\" attributeName=\"fill\" values=\"black\" />");
			sw.WriteLine("\t</text>" );
			sw.WriteLine("\t<rect id=\"mybox\" x=\"0\" y=\"0\" width=\"40\" height=\"20\" style=\"fill:black;fill-opacity:0.1\" />");

			foreach(StrokePath sp in paths)
			{
				sp.WriteToSVG(sw);
			}

			sw.WriteLine("</svg>");
			sw.Close();
			return true;
		}

		/// <summary>
		/// Returns the next previous time event from all the paths
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="ans">Will hold answer</param>
		/// <returns>Whether one was found or not</returns>
		public bool PrevTimeEvent(float from, out float ans)
		{
			float best=0f, cur=0f;
			bool hasbest = false;
			StrokePath path;
			ans = 0f;
			for (int i=0; i!=Paths.Length; i++)
			{
				path = Paths[i];
				if (path.PrevTimeEvent(from, ref cur))
				{
					if (!hasbest)
					{
						best = cur;
						hasbest = true;
					}
					else
					{
						if (cur > best)
							best = cur;
					}
				}
			}
			if (!hasbest)
				return false;
			ans = best;
			return true;
		}

		/// <summary>
		/// Returns the next time event from all the paths
		/// </summary>
		/// <param name="from">Time to look from</param>
		/// <param name="ans">Will hold answer</param>
		/// <returns>Whether one was found or not</returns>
		public bool NextTimeEvent(float from, out float ans)
		{
			float best=0f, cur=0f;
			bool hasbest = false;
			StrokePath path;
			ans = 0f;
			for (int i=0; i!=Paths.Length; i++)
			{
				path = Paths[i];
				if (path.NextTimeEvent(from, ref cur))
				{
					if (!hasbest)
					{
						best = cur;
						hasbest = true;
					}
					else
					{
						if (cur < best)
							best = cur;
					}
				}
			}
			if (!hasbest)
				return false;
			ans = best;
			return true;
		}

		/// <summary>
		/// Delete all Paths
		/// </summary>
		public void DeletePaths()
		{
			paths = new StrokePath[0];
		}

		/// <summary>
		/// Delete the given path
		/// </summary>
		/// <param name="path">Path to delete</param>
		public void DeletePath(StrokePath path)
		{
			this.paths = (StrokePath[])Mem.Remove(paths, path);
		}

		/// <summary>
		/// Adds a stroke to this InkPath. If a 'selected' StrokePath is given, that the stroke is
		/// added to that path, otherwise a new path is created for it.
		/// </summary>
		/// <param name="st">Ink.Stroke to add</param>
		/// <param name="time">Time to add it at</param>
		/// <param name="selected">StrokePath to add it into (optional)</param>
		/// <returns>StrokePath it was added to</returns>
		public StrokePath AddStroke(StrokeIT st, float time, StrokePath selected)
		{
			if (selected != null)
			{
				selected.AddStroke( st, time );
				return selected;
			}
			StrokePath path;
			path = new StrokePath();
			path.AddStroke(st, time );
			paths = (StrokePath[])Mem.AddToArray(Paths, path);
			return path;
		}

		/// <summary>
		/// This is a text based file save, this is faster and more effiecient than the
		/// serialized size
		/// </summary>
		/// <param name="s">Stream to save into</param>
		public void SaveToStream(StreamWriter s)
		{
			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			Point pt;

			s.WriteLine("{0}", maxtime );

			s.WriteLine("{0}", this.paths.Length);
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				s.WriteLine("{0}", path.DoesEnd);
				s.WriteLine("{0}", path.EndTime);
				s.WriteLine("{0}", path.StrokesIT.Length);

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					sit = path.StrokesIT[strokei];
					strokestr = pathstr + "S" + strokei + "";
					s.WriteLine("{0}", Color.Black.ToArgb() );
					s.WriteLine("{0}", 2 );
					s.WriteLine("{0}", sit.StartTime );

					s.WriteLine("{0}", sit.Points.Length );
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						pt = sit.Points[pointi];
						s.WriteLine("{0}", pt.X );
						s.WriteLine("{0}", pt.Y );
					}

					s.WriteLine("false");
				}
			}			
		}

		/// <summary>
		/// Save this InkPath to a file
		/// </summary>
		/// <param name="filename">File to save it into</param>
		public void SaveToFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Create);
			StreamWriter s = new StreamWriter(fs);
			SaveToStream( s );
			s.Close();
			fs.Close();
		}

		/// <summary>
		/// Load the InkPath from a given file
		/// </summary>
		/// <param name="filename">File to load from</param>
		public void LoadFromFile(string filename)
		{
			FileStream fs = new FileStream(filename, FileMode.Open);
			StreamReader r = new StreamReader(fs);
			LoadFromStream( r );
			r.Close();
			fs.Close();
		}

		/// <summary>
		/// Loads the InkPath from a text stream created with SaveToStream
		/// </summary>
		/// <param name="s">Stream to read from</param>
		public void LoadFromStream(StreamReader s)
		{
			string pathstr;
			int pathi;
			StrokePath path;

			int strokei;
			StrokeIT sit;
			string strokestr;

			int pointi;
			int ptx, pty;

			MaxTime = (float)Double.Parse( s.ReadLine() );

			paths = new StrokePath[ Int32.Parse( s.ReadLine() ) ];
			for (pathi=0; pathi!=Paths.Length; pathi++)
			{
				Paths[pathi] = new StrokePath();
				path = Paths[pathi];
				pathstr = "P"+pathi+"";
				path.DoesEnd = Boolean.Parse( s.ReadLine() );
				path.EndTime = (float)Double.Parse( s.ReadLine() );
				path.StrokesIT = new StrokeIT[ Int32.Parse( s.ReadLine() ) ];

				for (strokei=0; strokei!=path.StrokesIT.Length; strokei++)
				{
					path.StrokesIT[strokei] = new StrokeIT();
					sit = path.StrokesIT[strokei];
					sit.Path = path;
					strokestr = pathstr + "S" + strokei + "";
					Int32.Parse( s.ReadLine() );
					Double.Parse( s.ReadLine() );
					sit.StartTime = (float)Double.Parse( s.ReadLine() );

					sit.Points = new Point[ Int32.Parse( s.ReadLine() ) ];
					for (pointi=0; pointi!=sit.Points.Length; pointi++)
					{
						ptx = Int32.Parse( s.ReadLine() );
						pty = Int32.Parse( s.ReadLine() );
						sit.Points[pointi].X = ptx;
						sit.Points[pointi].Y = pty;
					}

					Boolean.Parse( s.ReadLine() );
				}
			}
		}

		/// <summary>
		/// Create an InkPath with default settings
		/// </summary>
		public InkPath(float max_time)
		{
			paths = new StrokePath[0];
			maxtime = max_time;
		}

		public StrokeIT[] GetInkAtTime(float time)
		{
			int len = 0;
			for (int i=0; i<this.Paths.Length; i++)
			{
				if (Paths[i].ExistsAtTime(time))
					len++;
			}
			StrokeIT[] ans = new StrokeIT[len];
			int to=0;
			for (int i=0; i<this.Paths.Length; i++)
			{
				if (Paths[i].ExistsAtTime(time))
				{
					ans[to] = Paths[i].GetStrokeAtTime(time);
					to++;
				}
			}
			return ans;
		}
	};

	/// <summary>
	/// InkPathViewer contains a number of rendering and other such utilities
	/// can come in handy when dealing with InkPaths.
	/// </summary>
	public class InkPathViewer
	{
		private int renderQuality;
		private InkPath AInk;
		private StrokeIT[] selectedStrokes;
		private StrokeIT[] curstrokes;

		public InkPath InkPath
		{
			get { return AInk; }
			set { AInk = value; }
		}

		public StrokePath StrokeToStrokePath(StrokeIT sit)
		{
			return sit.Path;
		}

		public StrokeIT[] CurStrokes
		{
			get { return curstrokes; }
			set { curstrokes = value; }
		}

		/// <summary>
		/// This is an array of the currently selected Strokes
		/// </summary>
		public StrokeIT[] SelectedStrokes
		{
			get	{ return selectedStrokes; }
		}

		/// <summary>
		/// Clears the list of selected Strokes
		/// </summary>
		public void ClearSelected()
		{
			selectedStrokes = new StrokeIT[0];
			if (SelectedChanged!=null)
				SelectedChanged(this, null);
		}

		public int NumSelected
		{
			get { return selectedStrokes.Length; }
		}

		public event System.EventHandler SelectedChanged;

		/// <summary>
		/// Adds a Stroke to those that are selected
		/// </summary>
		/// <param name="st"></param>
		public void AddStrokeToSelected(StrokeIT st)
		{
			if (st==null)
				return;
			selectedStrokes = Mem.AddToArray(selectedStrokes, st);
			if (SelectedChanged!=null)
				SelectedChanged(this, null);
		}

		/// <summary>
		/// Get or set the "render quality" this is the number of points used in the line
		/// which is used for quick rendering. In Quick rendering the length of the line is
		/// static and not interpolated based on the two interpolation Strokes, and thus there
		/// can be loss of quality
		/// </summary>
		public int QuickRenderQuality
		{
			get { return renderQuality; }
			set { renderQuality = value; }
		}

		/// <summary>
		/// Returns if a given Stroke is selected or not
		/// </summary>
		/// <param name="st">Stroke to look for</param>
		/// <returns>Is selected</returns>
		public bool IsSelected(StrokeIT st)
		{
			for (int i=0; i!=selectedStrokes.Length; i++)
			{
				if (selectedStrokes[i] == st)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Creates the new Ink object which represents the strokes at the given time. It also
		/// remaps the selected Strokes to keep them up to date.
		/// </summary>
		/// <param name="time">The time to sample at</param>
		/// <returns>The new Ink object with all the strokes in it</returns>
		public void InkAtTime(float time)
		{
			StrokeIT[] ns = this.AInk.GetInkAtTime(time);
			for (int i=0; i<selectedStrokes.Length;)
			{
				bool found = false;
				for (int j=0; (!found) && (j<ns.Length); j++)
				{
					if (selectedStrokes[i].Path == ns[j].Path)
					{
						selectedStrokes[i] = ns[j];
						found = true;
					}
				}
				if (!found)
					selectedStrokes = Mem.Remove(selectedStrokes, selectedStrokes[i]);
				else
					i++;
			}
			curstrokes = ns;
		}

		/// <summary>
		/// Deletes all the StrokePaths in it's InkPath
		/// </summary>
		public void DeletePaths()
		{
			ClearSelected();
			curstrokes = new StrokeIT[0];
			AInk.DeletePaths();
		}

		/// <summary>
		/// Returns the next Stroke which also had a starting time as the given stroke. This
		/// is useful for identifying Strokes which are part of a group
		/// </summary>
		/// <param name="prev">Stroke to start looking from</param>
		/// <param name="time">Time to start looking from</param>
		/// <returns></returns>
		public StrokeIT NextStrokeAtTime(StrokeIT sit, float time)
		{
			StrokePath path = sit.Path;
			if (path == null)
				return null;
			float musthave = sit.StartTime;
			bool hasfound=false;
			int i;
			int numpaths = this.AInk.Paths.Length;
			for (int a=0; a!=numpaths*2; a++)
			{
				i = a % numpaths;
				if (!hasfound)
				{
					if (AInk.Paths[i] == path)
						hasfound=true;
				}
				else
				{
					if (AInk.Paths[i] == path)
						return null;
					StrokePath cpath = AInk.Paths[i];
					sit = path.GetStrokeStartingAt(sit.StartTime);
					if (sit != null)
						return sit;
				}
			}
			return null;
		}

		public Pen NormalPen = null;
		public Pen SelectedPen = null;
		public Brush StartStroke = null;

		private void GenPens()
		{
			if (NormalPen == null)
			{
				NormalPen = new Pen(Color.Black);
				SelectedPen = new Pen(Color.YellowGreen);
				StartStroke = new SolidBrush(Color.YellowGreen);
			}
		}

		/// <summary>
		/// This method first recalculates the Ink for this time, and then draws it to the screen.
		/// This is a high quality rendering and is not meant for real-time use.
		/// </summary>
		/// <param name="g">Graphics object to render to</param>
		/// <param name="time">Time to sample at</param>
		public void Render(Graphics g, float time)
		{
			GenPens();
			InkAtTime(time);
			for (int i=0; i<CurStrokes.Length; i++)
			{
				if (!IsSelected(CurStrokes[i]))
					InkInterp.DrawLine(g, NormalPen, CurStrokes[i].Points );
				else
				{
					InkInterp.DrawLine(g, SelectedPen, CurStrokes[i].Points );
					Point pt = CurStrokes[i].Points[0];
					g.FillEllipse(StartStroke, pt.X-2, pt.Y-2, 4, 4);
				}
			}
		}

		private bool highqualityplay = true;
		public bool HighQualityPlay
		{
			get { return highqualityplay; }
			set { highqualityplay = value; }
		}

		private StrokeIT qrst;

		/// <summary>
		/// This is a fast rendering of the InkPath at the given time. This method does not update
		/// the current Ink object (use Render()) for that.
		/// </summary>
		/// <param name="g">Graphics object to render to</param>
		/// <param name="time">Time to sample at</param>
		public void QuickRender(Graphics g, float time)
		{
			if ((qrst==null) || (qrst.Points.Length != renderQuality))
			{
				qrst = new StrokeIT();
				qrst.Points = new Point[renderQuality];
			}

			for (int i=0; i<AInk.Paths.Length; i++)
			{
				StrokePath path = AInk.Paths[i];
				if (path.ExistsAtTime(time))
				{
					StrokeIT op = path.QuickStrokeAtTime(qrst, time);
					if (op == null)
						op = qrst;
					else
					{
					//	if (InkInterp.QuickResampleLine(op.Points, qrst.Points, qrst.Points.Length))
					//		op = qrst;
					}
					InkInterp.DrawLine(g, NormalPen, op.Points);
				}
			}
		}
			
	
		
		/// <summary>
		/// Creates a new InkPathViewer which views the given InkPath
		/// </summary>
		/// <param name="path">The InkPath to be used by this object</param>
		public InkPathViewer(InkPath path)
		{
			selectedStrokes = new StrokeIT[0];
			AInk = path;

			renderQuality = 10;
		}
	}
	
	
	
	/// <summary>
	/// AniEd is a Windows Control, and can be generally used as such. It exposes a very simple
	/// API to allow you to make it into both an animation player, and a powerful animation editor.
	/// </summary>
	public class AniEd : System.Windows.Forms.Control
	{
		private InkPath inkpath;
		private InkPathViewer viewer;
		private float curtime;	//animation time
		private bool isPlaying;
		public InkPath InkPath
		{
			get { return inkpath; }
		}

		public bool ExportToSVG(string filename)
		{
			Point size = new Point(Size.Width, Size.Height);

			return inkpath.ExportToSVG(filename, Size.Width, Size.Height, size.X, size.Y);
		}

		public void LoadFromFile(string filename)
		{
			viewer.ClearSelected();
			inkpath.LoadFromFile(filename);
			MyRedraw();
		}

		/// <summary>
		/// Gets the InkPathViewer used for renderingm, selection, and so forth
		/// </summary>
		public InkPathViewer Viewer
		{
			get { return viewer; }
		}

		/// <summary>
		/// Makes all StrokePaths end at 0.01 seconds before this frame. Useful for sudden changes
		/// </summary>
		public void ClearFromThisFrame()
		{
			StrokePath path;
			for (int i=0; i!=viewer.InkPath.Paths.Length; i++)
			{
				path = viewer.InkPath.Paths[i];
				path.DoesEnd = true;
				path.EndTime = curtime-0.01f;
			}
		}

		/// <summary>
		/// Either returns if the system is playing or not, or calls Play() or Pause() to change
		/// it's state.
		/// </summary>
		public bool IsPlaying
		{
			get { return isPlaying; }
			set 
			{ 
				if (value) 
					Play(); 
				else 
					Pause();
			}
		}

		/// <summary>
		/// Subscribe to this event to get a notice everytime the time changes by a call to Time
		/// </summary>
		public event System.EventHandler TimeChange;

		/// <summary>
		/// Use this to get or set the current time used for all tasts
		/// </summary>
		public float Time
		{
			get
			{
				return curtime;
			}
			set
			{
				curtime = value;
				if (TimeChange != null)
					TimeChange(this, null);
				if (!isPlaying)
					this.MyRedraw();
			}
		}

		/// <summary>
		/// This constructor automatically creates a new InkPath for this control to animate
		/// </summary>
		public AniEd() : this(new InkPath(5))
		{
		}

		/// <summary>
		/// Allows you to specify the InkPath that this control will use
		/// </summary>
		/// <param name="ipath">InkPath to use</param>
		public AniEd(InkPath ipath)
		{
			inkpath = ipath;
			viewer = new InkPathViewer( inkpath );

			curtime = 0.0f;
			isPlaying = false;
			this.selectradius = 200;

			viewer.InkAtTime(0);
		}

		/// <summary>
		/// Get or set the radius used when "selecting" a Stroke
		/// </summary>
		private float selectradius;
		public float SelectRadius
		{
			get { return selectradius; }
			set { selectradius = value; }
		}

		protected override void OnResize(EventArgs ea)
		{
			MyRedraw();
		}

		public void Selected_DeletePaths()
		{
			for (int i=0; i<viewer.SelectedStrokes.Length; i++)
			{
				InkPath.DeletePath(viewer.SelectedStrokes[i].Path);
			}
			MyRedraw();
		}

		/// <summary>
		/// Deletes all the Strokes in time which are selected at this moment. This essentially
		/// just removes the current or first previous keyframe from each selected path.
		/// </summary>
		public void Selected_DeleteMoment()
		{
			StrokePath path;
			StrokeIT sit;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					sit = path.GetAtOrPrevStroke(curtime);
					if (sit!=null)
					{
						path.DeleteStrokeIT(sit);
					}
				}
			}
			this.MyRedraw();
		}

		/// <summary>
		/// Makes all selected paths end at the current time.
		/// </summary>
		public void Selected_EndPathsNow()
		{
			StrokePath path;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.StrokeToStrokePath( viewer.SelectedStrokes[i] );
				if (path != null)
				{
					path.DoesEnd = true;
					path.EndTime = curtime;
				}
			}
			MyRedraw();
		}

		/// <summary>
		/// Select all Ink strokes at this time.
		/// </summary>
		public void SelectAll()
		{
			viewer.ClearSelected();
			for (int i=0; i<viewer.CurStrokes.Length; i++)
			{
				viewer.AddStrokeToSelected( viewer.CurStrokes[i] );
			}
			MyRedraw();
		}

		/// <summary>
		/// Copies all selected Paths from their first previous frame to the current frame, this
		/// gives the illusion of a stroke that doesn't move for a period of time.
		/// </summary>
		public void Selected_CopyLastFrameToThisTime()
		{
			StrokePath path;
			StrokeIT sit;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.SelectedStrokes[i].Path;
				if (path != null)
				{
					sit = new StrokeIT( path );
					sit.FromStroke( path.GetPrevStroke( curtime ) );
					path.AddStroke(sit, curtime);
				}
			}
			MyRedraw();
		}

		/// <summary>
		/// Makes an exact copy of the selected strokes into this time, this lets you make animated
		/// frames into key frames.
		/// </summary>
		public void Selected_CopyToThisTime()
		{
			StrokePath path;
			for (int i=0; i!=viewer.SelectedStrokes.Length; i++)
			{
				path = viewer.SelectedStrokes[i].Path;
				if (path != null)
				{
					path.CopyToThisTime(curtime);
				}
			}
			MyRedraw();
		}

		public int DistToPoint = 10;

		/// <summary>
		/// Gets the nearest stroke to the given point, the point must be given in Ink coordinates
		/// </summary>
		/// <param name="pt">Point to compare to (Ink coordinate)</param>
		/// <returns>The closest Stroke (can be null if outside of SelectionRadius)</returns>
		private StrokeIT GetStrokeNear(Point pt)
		{
			for (int i=0; i<viewer.CurStrokes.Length; i++)
			{
				if (InkInterp.IsNear(viewer.CurStrokes[i].Points, pt, DistToPoint))
					return viewer.CurStrokes[i];
			}
			return null;
		}

		private Point[] curdrawing=null;
		private int cappts=0, numpts=0;

		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (curdrawing==null)
			{
				cappts = 20;
				curdrawing = new Point[cappts];
			}
			skipper=0;
			numpts = 1;
			curdrawing[0].X = e.X;
			curdrawing[0].Y = e.Y;
		}

		private int MaxSelectLen = 10;

		protected override void OnMouseUp(MouseEventArgs e)
		{
			if (numpts == 0)
				return;

			Point[] pts = new Point[numpts];
			for (int i=0; i<numpts; i++)
			{
				pts[i] = curdrawing[i];
			}
			numpts = 0;

			if (InkInterp.IntLineLen(pts) <= MaxSelectLen)
			{
				StrokeIT sit = GetStrokeNear( pts[0] );
				if (sit == null)
					viewer.ClearSelected();
				else
				{
					if (viewer.IsSelected(sit))
						viewer.ClearSelected();
					viewer.AddStrokeToSelected(sit);
				}
			}
			else
			{
				StrokeIT sit = new StrokeIT();
				sit.Points = pts;
				StrokeIT sel = null;
				if ((viewer.SelectedStrokes!=null) && (viewer.SelectedStrokes.Length==1))
					sel = viewer.SelectedStrokes[0];
				if (sel!=null)
				{
					viewer.ClearSelected();
					bool found = false, done=false;
					for (int k=0; k<viewer.CurStrokes.Length*2; k++)
					{
						int i = (k % viewer.CurStrokes.Length);
						if (!found)
						{
							if (viewer.CurStrokes[i].Path == sel.Path)
								found = true;
						}
						else
						{
							if (!done)
							{
								done = true;
								viewer.AddStrokeToSelected( viewer.CurStrokes[i] );
							}
						}
					}
				}
				StrokePath selpath = null;
				if (sel!=null)
					selpath = sel.Path;
				viewer.InkPath.AddStroke(sit, this.curtime, selpath);
			}
			MyRedraw();
		}


		private int skipper = 0;
		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (numpts!=0)
			{
				if ((e.X < 0) || (e.X >= Width))
					return;
				if ((e.Y < 0) || (e.Y >= Height))
					return;

				skipper++;
				if ((skipper % 2)==0)
				{
					if (numpts >= cappts)
					{
						cappts = cappts*2 - (cappts/2);
						Point[] npts = new Point[cappts];
						for (int i=0; i<numpts; i++)
							npts[i] = curdrawing[i];
						curdrawing = npts;
					}
					curdrawing[numpts].X = e.X;
					curdrawing[numpts].Y = e.Y;
					numpts++;
					Graphics g = this.CreateGraphics();
					InkInterp.DrawLine(g, viewer.NormalPen, curdrawing, numpts );
					return;
				}
			}
		}

		private Bitmap backbuff = null;
		private Graphics backg;
		private bool forcequick = false;
		public bool ForceQuickRender
		{
			get { return forcequick; }
			set { forcequick = value; }
		}

		public bool Working = false;

		private void redraw(Graphics tog)
		{
			if (backbuff == null)
			{
				backbuff = new Bitmap(Width, Height);
				backg = Graphics.FromImage(backbuff);
			}
			if ((backbuff.Width!=Width) || (backbuff.Height!=Height))
			{
				backbuff = new Bitmap(Width, Height);
				backg = Graphics.FromImage(backbuff);
			}
			Graphics g = backg;
            
			Rectangle rect = System.Drawing.Rectangle.FromLTRB(0, 0, Width-1, Height-1);
			g.FillRectangle( new SolidBrush(Color.Lavender), rect );
			if ((isPlaying) || (forcequick))
				viewer.QuickRender(g, curtime);
			else
				viewer.Render(g, curtime);

			if (numpts!=0)
				InkInterp.DrawLine(g, viewer.NormalPen, curdrawing, numpts);

			rect = new Rectangle(0, 0, Width-1, Height-1);
			g.DrawRectangle( new Pen(Color.Black), rect );

			tog.DrawImage(backbuff, 0, 0);
		}

		public void MyRedraw()
		{
			redraw( this.CreateGraphics() );
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			redraw(e.Graphics);
		}

		/// <summary>
		/// This puts the Control into animation mode and playes the current InkPath as one
		/// would expect it to. While in Play mode it uses a QuickRender instead of the normal
		/// renderer, this gives good performance, but you must not access the current Ink object
		/// while the control is Playing, it will give garbage values. Note that if the editor
		/// if turn on, it will be turned off while playing
		/// </summary>
		public void Play()
		{
			if (isPlaying)
			{
				throw new ArgumentException("already playing");
			}
			TimeTrack.QueryPerformanceFrequency(ref timefreq);
			if (timefreq==0)
			{
				MessageBox.Show("This device doesn't support high quality timing", "Sorry");
				return;
			}
			starttime = 0;
			isPlaying = true;
			if (ChangedPlayState!=null)
				ChangedPlayState(this, null);
		}

		/// <summary>
		/// This stops the animation, and returns the system to high quality rendering, and
		/// if set will also turn the editor back on.
		/// </summary>
		public void Pause()
		{
			if (!isPlaying)
				return;
			isPlaying = false;
			if (ChangedPlayState!=null)
				ChangedPlayState(this, null);
		}

		public event EventHandler ChangedPlayState;

		private int timefreq, starttime;
		public long tickdt = 25;
		public TimeTrack tracker;
		public void OnTick(object ob)
		{
			if (!this.isPlaying)
				return;

			if (starttime!=0)
			{
				int curtime = 0;
				TimeTrack.QueryPerformanceCounter(ref curtime);
				curtime = ((curtime-starttime)*1000)/timefreq;
				float ct = (((float)curtime) / 1000.0f);
				tracker.Value = ct;
			}
			else
			{
				TimeTrack.QueryPerformanceCounter(ref starttime);
				tracker.Value = 0;
			}


			MyRedraw();
		}
	}

	
	/// <summary>
	/// This is the tracking bar at the bottom with shows the curren time, it also
	/// manages alot of the time related features of Pocket AniEd
	/// </summary>
	public class TimeTrack : Control
	{
		private AniEd anied;
		public float max = 5.0f;
		private float mvalue = 0.0f;
		public event System.EventHandler ValueChanged;
		private Pen WhitePen, TimePen;
		public bool FireChanged = true;

		public float Max
		{
			get { return max; }
			set
			{
				max = value;
				anied.InkPath.MaxTime = value;
				Value = 0;
				this.Invalidate();
			}
		}

		//If you use this DllImport trick and then call these functions
		//while running on a normal PC, the app with crash. For that reason
		//I'm using the Environment.TickCount. If you would prefer to use
		//the real QueryPerformanceFrequency from .Net read about it here:
		// http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncfhowto/html/uperfcoun.asp

		public static void QueryPerformanceFrequency(ref int lpFrequency)
		{
			//because there are 1000 milliseconds in a second
			lpFrequency = 1000;
		}

		public static void QueryPerformanceCounter(ref int lpPerformanceCount)
		{
			lpPerformanceCount = Environment.TickCount;
		}


		public TimeTrack(AniEd ed)
		{
			anied = ed;
			WhitePen = new Pen(Color.White);
			TimePen = new Pen(Color.Red);
		}

		public float Value
		{
			get { return mvalue; }
			set
			{
				float val = value;
				if (val >= Max)
				{
					anied.Pause();
					val = Max;
				}

				int oldx = ValueToX(mvalue);
				int nx = ValueToX(val);
				mvalue = val;
				if ((FireChanged) && (ValueChanged!=null))
					ValueChanged(this, null);
				anied.Time = val;

				Graphics g = this.CreateGraphics();
				if (oldx!=0)
					g.DrawLine(WhitePen, oldx, 1, oldx, Height-2);
				if (nx!=0)
					g.DrawLine(TimePen, nx, 1, nx, Height-2);
			}
		}

		public float XToValue(int x)
		{
			return Max*(((float)x) / ((float)(Width-2)));
		}

		public int ValueToX(float val)
		{
			int x = (int)((val/Max) * ((float)(Width-2)));
			if (x >= Width-1)
				x = Width-2;
			return x;
		}

		private Brush BackBrush = null;
		private bool isdragging;

		protected override void OnMouseUp(MouseEventArgs e)
		{
			if (isdragging)
			{
				anied.ForceQuickRender = false;
				isdragging = false;
				anied.MyRedraw();
			}
		}


		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (isdragging)
			{
				if ((e.X <= 0) || (e.X >= Width-1))
					return;
				if (!anied.Working)
					Value = XToValue(e.X);
			}
		}


		protected override void OnMouseDown(MouseEventArgs e)
		{
			if ((e.X <= 0) || (e.X >= Width-1))
				return;

			anied.ForceQuickRender = true;
			isdragging = true;
			Value = XToValue(e.X);
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			if (BackBrush == null)
				BackBrush = new SolidBrush(Color.White);
			Rectangle rect = new Rectangle(0, 0, Width-1, Height-1 );
			e.Graphics.FillRectangle(BackBrush, rect);
			int x = ValueToX(Value);
			e.Graphics.DrawLine(TimePen, x, 1, x, Height-2);
			e.Graphics.DrawRectangle(new Pen(Color.Black), rect);
		}
	}


	/// <summary>
	///  InkInterp is a collection of tools for doing stroke operations (strokes being
	///  arrays of poitns). These tools span from drawing to interpolation to collision
	///  detection.
	/// </summary>
	public class InkInterp
	{
		public static void DrawLine(Graphics g, Pen pen, Point[] pts, int count)
		{
			int cx, cy, lx, ly;
			lx = pts[0].X;
			ly = pts[0].Y;
			for (int i=1; i<count; i++)
			{
				cx = pts[i].X;
				cy = pts[i].Y;
				g.DrawLine(pen, cx, cy, lx, ly );
				lx = cx;
				ly = cy;
			}
		}

		public static void DrawLine(Graphics g, Pen pen, Point[] pts)
		{
			DrawLine(g, pen, pts, pts.Length);
		}

		public static bool IsNear(Point[] line, Point pnt, int dist)
		{
			dist = dist*dist;
			int x, y;
			for (int i=0; i<line.Length; i++)
			{
				x = line[i].X - pnt.X;
				y = line[i].Y - pnt.Y;
				if ( (x*x + y*y) <= dist )
					return true;
			}
			return false;
		}

		public static int ToFixed(float f)
		{
			return (int)(f * 256.0f);
		}

		public static int Interp(int from, int to, float t)
		{
			//interpolates between 'from' and 'to', based on 't'
			//0.0 for from, 1.0 for to, and the linear average in between

			int ans = (int)(((float)(to-from))*t);
			return ans+from;
		}

		public static float Interp(float from, float to, float t)
		{
			return (from + (t*(to-from)));
		}

		public static Point Interp(Point from, Point to, float t)
		{
			//interpolate between two points

			from.X = Interp(from.X, to.X, t);
			from.Y = Interp(from.Y, to.Y, t);
			return from;
		}

		/// <summary>
		/// This function accesses an array of ints at a floating point index between 0.0 and 1.0
		/// and interpolates between ints when the index is not exact
		/// </summary>
		/// <param name="ptr">array of ints</param>
		/// <param name="at">floating point index from 0.0 to 1.0</param>
		/// <returns></returns>
		public static int GetValue(int[] ptr, float at)
		{
			int size = ptr.Length-1;
			at *= (float)size;
			int i = (int)at;
			at -= (float)i;
			if (i == size)
				return ptr[size];
			if (at==0)
				return ptr[i];
			int cur=ptr[i], next=ptr[i+1];
			cur = Interp(cur, next, at);
			return cur;
		}

		/// <summary>
		/// This function accesses an array of points at a floating point index between 0.0 and 1.0
		/// and interpolates between points when the index is not exact
		/// </summary>
		/// <param name="ptr">array of points</param>
		/// <param name="at">floating point index from 0.0 to 1.0</param>
		/// <returns></returns>
		public static Point GetPoint(Point[] pts, float at)
		{
			//Get the point based on it's floating point index
 
			int size = pts.Length-1;
			at *= (float)size;
			int i = (int)at;
			at -= (float)i;
			if (i == size)
				return pts[size];
			if (at==0)
				return pts[i];
			Point cur=pts[i], next=pts[i+1];
			cur = Interp(cur, next, at);
			return cur;
		}

		/// <summary>
		/// Returns the floating point index (from 0.0 to 1.0) based on the a normal int index.
		/// </summary>
		/// <param name="ar"></param>
		/// <param name="i"></param>
		/// <returns></returns>
		public static float GetFIndex(int[] ar, int i)
		{
			//Get the floating point index from the integer index
			return ((float)i) / ((float)(ar.Length-1));
		}

		/// <summary>
		/// Returns the floating point index (from 0.0 to 1.0) based on the a normal int index.
		/// </summary>
		/// <param name="ar"></param>
		/// <param name="i"></param>
		/// <returns></returns>
		public static float GetFIndex(Point[] ar, int i)
		{
			//Get the floating point index from the integer index
			return ((float)i) / ((float)(ar.Length-1));
		}

		public static bool QuickResampleLine(Point[] from, Point[] to, int tolength)
		{
			if (from.Length <= tolength)
				return false;
			int fromi=0, fromd=(from.Length*256)/tolength;
			for (int i=0; i<tolength; i++)
			{
				to[i] = from[fromi>>8];
				fromi += fromd;
			}
			return true;
		}

		/// <summary>
		/// Interpolate between two piont lines, and store the result in ans. To calculate the answer
		/// the function will sample it at each of it's indexes interpolating between the two.
		/// Floating point indecies are used to resample at the amount neccasary.
		/// </summary>
		/// <param name="from">array of points (t = 0.0)</param>
		/// <param name="to">array of points (t = 1.0)</param>
		/// <param name="t">interpolation value</param>
		/// <param name="ans">array to store answer in</param>
		public static void Interp(Point[] from, Point[] to, float ratio, Point[] ans)
		{
			int mto = (int)(255 * ratio);
			int mfrom = (255 - mto);
			int fromi=0, fromd=(from.Length*256)/ans.Length;
			int toi=0, tod=(to.Length*256)/ans.Length;

			for (int i=0; i<ans.Length; i++)
			{
				Point f = from[fromi>>8];
				Point t = to[toi>>8];
				ans[i].X = (((f.X * mfrom) + (t.X * mto))>>8);
				ans[i].Y = (((f.Y * mfrom) + (t.Y * mto))>>8);

				fromi += fromd;
				toi += tod;
			}
		}

		/// <summary>
		/// Interpolate between two values
		/// </summary>
		/// <param name="from">initial value</param>
		/// <param name="to">final value</param>
		/// <param name="t">interpolation value</param>
		/// <returns>interpolant</returns>
		public static byte Interp(byte from, byte to, float t)
		{
			if (to > from)
			{
				t *= (float)(to - from);
				return (byte)(from + ((byte)t));
			}
			if (to == from)
				return to;
			t = 1.0f-t;
			t *= (float)(from-to);
			return (byte)(to+((byte)t));
		}

		/// <summary>
		/// This function interpolates both between the values in the two input point lines, but
		/// also between their size. This way you get a very accurate interpolation which uses
		/// just the right number of points to represent itself.
		/// </summary>
		/// <param name="from">from line (t = 0.0)</param>
		/// <param name="to">to line (t = 1.0)</param>
		/// <param name="t">interpolation value (0.0 to 1.0)</param>
		/// <returns>returns the inpolant between the two arrays</returns>
		public static Point[] Interp(Point[] from, Point[] to, float t)
		{
			Point[] ans = new Point[ Interp(from.Length, to.Length, t) ];
			Interp(from, to, t, ans);
			return ans;
		}

		/// <summary>
		/// Copies the from array into the to array, compensating for the difference in size
		/// by interpolating between values
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void ResampleLine(Point[] from, Point[] to)
		{
			float fi;
			for (int i=0; i!=to.Length; i++)
			{
				fi = GetFIndex(to, i);
				to[i] = GetPoint(from, fi);
			}
		}

		/// <summary>
		/// Copies the from array into the to array, compensating for the difference in size
		/// by interpolating between values
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void ResampleArray(int[] from, int[] to)
		{
			float fi;
			for (int i=0; i!=to.Length; i++)
			{
				fi = GetFIndex(to, i);
				to[i] = GetValue(from, fi);
			}
		}

		/// <summary>
		/// Returns the distance between two points, yes I know this is slow
		/// </summary>
		public static float Dist(Point from, Point to)
		{
			from.X -= to.X;
			from.Y -= to.Y;
			return (float)Math.Sqrt( (double)((from.X*from.X) + (from.Y*from.Y)) );
		}

		/// <summary>
		/// Returns the length of the given point line
		/// </summary>
		public static float LineLength(Point[] pts)
		{
			float sum = 0.0f;
			for (int i=0; i+1 < pts.Length; i++)
			{
				sum += Dist(pts[i], pts[i+1]);
			}
			return sum;
		}

		public static int SlowIntSqrt(int val)
		{
			int a=1;
			while (a*a < val)
			{
				a++;
			}
			return a;
		}
		private static int[] sqrts = null;

		public static int IntSqrt(int val)
		{
			if (sqrts == null)
			{
				sqrts = new int[100];
				sqrts[0] = 0;
				for (int i=1; i<sqrts.Length; i++)
					sqrts[i] = SlowIntSqrt(i);
			}
			if (val < sqrts.Length)
				return sqrts[val];
			return SlowIntSqrt(val);
		}

		public static int IntLineLen(Point[] pts)
		{
			int x, y;
			int len = 0;
			for (int i=0; i<pts.Length-1; i++)
			{
				x = pts[i].X - pts[i+1].X;
				y = pts[i].Y - pts[i+1].Y;
				len += IntSqrt(x*x + y*y);
			}
			return len;
		}

		/// <summary>
		/// Travels along a line a given distance, and returns the point it reaches at that distance
		/// </summary>
		/// <param name="pts">point line</param>
		/// <param name="at">distance to travel</param>
		/// <returns>point at that distance</returns>
		public static Point GetLengthwisePoint(Point[] pts, float at)
		{
			int i=0;
			float curlen=0.0f, lastd=0.0f;
			while (curlen < at)
			{
				lastd = Dist(pts[i], pts[i+1]);
				curlen += lastd;
				i++;
				if (i+1 == pts.Length)
					return pts[pts.Length-1];
			}
			if (curlen == at)
				return pts[i];
			at = ((at-(curlen-lastd)) / lastd);
			return Interp(pts[i-1], pts[i], at);
			//carry on here
		}

		/// <summary>
		/// Resamples the given polygonal line, and stores the result into 'to'. What this essentially
		/// does is make the distance between each point equal by shifting around the points while
		/// still maintaining the shape of the line.
		/// </summary>
		/// <param name="from">input array</param>
		/// <param name="to">output array</param>
		public static void LengthwiseResample(Point[] from, Point[] to)
		{
			float total = LineLength(from);
			float step = total / ((float)(from.Length-1));
			for (int i=0; i!=from.Length; i++)
			{
				to[i] = GetLengthwisePoint(from, step*((float)i) );
			}
		}
	}

	
	
	/// <summary>
	/// These are just a collection of memory functions I created while I was working. Please
	/// remember that I'm new to C# so some of these could probably have been avoided, but I must
	/// admit they were good learning practise
	/// </summary>
	public class Mem
	{
		/// <summary>
		/// Does the given array include the given object
		/// </summary>
		public static bool Includes(object[] ar, object ob)
		{
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] == ob)
					return true;
			}
			return false;
		}

		/// <summary>
		/// Returns the index of the given object in the given array
		/// </summary>
		public static int GetIndex(object[] ar, object ob)
		{
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] == ob)
					return i;
			}
			return -1;
		}

		public static StrokeIT[] Remove(StrokeIT[] ar, StrokeIT ob)
		{
			if (!Includes(ar, ob))
				return ar;
			StrokeIT[] nr = new StrokeIT[ar.Length-1];
			int toi = 0;
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] != ob)
				{
					nr[toi] = ar[i];
					toi++;
				}
			}
			return nr;
		}

		public static StrokeIT[] AddAfter(StrokeIT[] ar, StrokeIT ob, int after)
		{
			StrokeIT[] nr;
			if (ar == null)
			{
				nr = new StrokeIT[2];
				nr[0] = ob;
				return nr;
			}
			int ito = 0;
			nr = new StrokeIT[ar.Length+1];
			for (int i=0; i!=ar.Length; i++)
			{
				if (after+1 == i)
				{
					nr[ito] = ob;
					ito++;
				}
				nr[ito] = ar[i];
				ito++;
			}
			if (after >= ar.Length-1)
				nr[ar.Length] = ob;
			return nr;
		}

		public static StrokeIT[] AddToArray(StrokeIT[] ar, StrokeIT ob)
		{
			StrokeIT[] nr;
			if (ar == null)
			{
				nr = new StrokeIT[1];
				nr[0] = ob;
				return nr;
			}
			nr = new StrokeIT[ar.Length+1];
			for (int i=0; i!=ar.Length; i++)
				nr[i] = ar[i];
			nr[ar.Length] = ob;
			return nr;
		}

		public static StrokePath[] Remove(StrokePath[] ar, StrokePath ob)
		{
			if (!Includes(ar, ob))
				return ar;
			StrokePath[] nr = new StrokePath[ar.Length-1];
			int toi = 0;
			for (int i=0; i!=ar.Length; i++)
			{
				if (ar[i] != ob)
				{
					nr[toi] = ar[i];
					toi++;
				}
			}
			return nr;
		}

		public static StrokePath[] AddAfter(StrokePath[] ar, StrokePath ob, int after)
		{
			StrokePath[] nr;
			if (ar == null)
			{
				nr = new StrokePath[2];
				nr[0] = ob;
				return nr;
			}
			int ito = 0;
			nr = new StrokePath[ar.Length+1];
			for (int i=0; i!=ar.Length; i++)
			{
				if (after+1 == i)
				{
					nr[ito] = ob;
					ito++;
				}
				nr[ito] = ar[i];
				ito++;
			}
			if (after >= ar.Length-1)
				nr[ar.Length] = ob;
			return nr;
		}

		public static StrokePath[] AddToArray(StrokePath[] ar, StrokePath ob)
		{
			StrokePath[] nr;
			if (ar == null)
			{
				nr = new StrokePath[1];
				nr[0] = ob;
				return nr;
			}
			nr = new StrokePath[ar.Length+1];
			for (int i=0; i!=ar.Length; i++)
				nr[i] = ar[i];
			nr[ar.Length] = ob;
			return nr;
		}

	}
};
