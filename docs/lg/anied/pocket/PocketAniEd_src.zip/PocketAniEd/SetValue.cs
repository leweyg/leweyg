using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PocketAniEd
{
	/// <summary>
	/// Summary description for SetValue.
	/// </summary>
	public class SetValue : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
	
		public SetValue(float val)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.textBox1.Text = val.ToString();
			this.DialogResult = DialogResult.Cancel;

			MainMenu mm = new MainMenu();
			MenuItem cancel = new MenuItem();
			cancel.Text = "Cancel";
			cancel.Click += new EventHandler(button1_Click);
			mm.MenuItems.Add( cancel );

			this.Menu = mm;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 40);
			this.label1.Size = new System.Drawing.Size(224, 24);
			this.label1.Text = "How long should the animation last?";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(72, 72);
			this.textBox1.Size = new System.Drawing.Size(104, 22);
			this.textBox1.Text = "textBox1";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(48, 104);
			this.button1.Size = new System.Drawing.Size(56, 24);
			this.button1.Text = "Cancel";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(136, 104);
			this.button2.Size = new System.Drawing.Size(56, 24);
			this.button2.Text = "Okay";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// SetValue
			// 
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.label1);
			this.Text = "SetValue";

		}
		#endregion

		private void button2_Click(object sender, System.EventArgs e)
		{
			nvalue = (float)System.Double.Parse( this.textBox1.Text );
			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		private float nvalue;

		public float NewValue
		{
			get { return nvalue; }
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
