/* 	CAP 5705 - Project 1 - Lewey Geselowitz (id = 7671)
*
*	Cubic Spline Sketcher
*/

#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>

#define PI 3.1415926535897932384626433832795

//allows for negative mod values. i.e. MOD(v,b) == MOD(v+b,b) no matter what v is.
int MOD(int v, int b)
{
	if (v >= 0) 
		return (v%b);
	v = ((-v)%b);
	return ((b-v)%b);
}

//This represents a 3d vertex, and lets me use vector notation
//via operator overloading.
struct fpnt
{
	float x, y, z;

	float& operator [] (int i) {return *((&x)+i);};
	operator float* () {return &x;};

	fpnt operator * (float val)
	{
		fpnt ans;
		ans.x = x*val;
		ans.y = y*val;
		ans.z = z*val;
		return ans;
	};

	fpnt operator / (float val)
	{
		return (*this)*(1.0/val);
	};

	fpnt operator + (fpnt other)
	{
		fpnt ans;
		ans.x = x + other.x;
		ans.y = y + other.y;
		ans.z = z + other.z;
		return ans;
	};

	fpnt operator - (fpnt& other)
	{
		fpnt ans;
		ans.x = x - other.x;
		ans.y = y - other.y;
		ans.z = z - other.z;
		return ans;
	};

	fpnt Lerp(float* vec, float t)
	{
		fpnt ans;
		float nt = 1.0 - t;
		ans.x = x*nt + vec[0]*t;
		ans.y = y*nt + vec[1]*t;
		ans.z = z*nt + vec[2]*t;
		return ans;
	};

	float Dot(float* vec)
	{
		return (x*vec[0] + y*vec[1] + z*vec[2]);
	};

	float Magnitude()
	{
		return sqrt( this->Dot(&x) );
	};
};


fpnt ScrMin, ScrMax;
fpnt WndSize;
float MinScrSize = 5;
float MinSelectDist = 0.1;

fpnt ScrToWorld(int mx, int my)
{
	fpnt work;
	work.x = ((float)mx) / WndSize.x;
	work.y = 1.0f - (((float)my) / WndSize.y);
	work.z = 0;

	work.x = ScrMin.x*(1.0f-work.x) + ScrMax.x*work.x;
	work.y = ScrMin.y*(1.0f-work.y) + ScrMax.y*work.y;

	return work;
}

//This represents a set of control points
class Controls
{
public:
	fpnt* Verts;
	int Count;

	void Init(int count)
	{
		UnInit();
		Count = count;
		Verts = new fpnt[Count+10];
	};

	void UnInit()
	{
		if (Verts)
			delete [] Verts;
		Count = 0;
		Verts = 0;
	};

	void RenderSimplePoly();
	void RenderWithMap1();
	void RenderDeCasteljau();
	void RenderNURBS();

	void Circle(float radius);
	int NearPoint(fpnt mouse);
	int VMOD(int i) {return MOD(i,Count);};
	Controls* DeBoors();
	float SimpleLength();
	fpnt& Vertex(int i) {return Verts[VMOD(i)];};

	Controls() {Verts=0; Count=0;};
	~Controls() {UnInit();};

private:
	fpnt DeCasteljauSample(fpnt* ctrls, float t);
};

Controls* Controls::DeBoors()
{
	Controls* nc = new Controls();
	nc->Init(Count*2);

	for (int i=0; i<Count; i++)
	{
		nc->Verts[i*2] = (Vertex(i)*0.75 + Vertex(i-1)*0.125 + Vertex(i+1)*0.125);
		nc->Verts[(i*2)+1] = Vertex(i).Lerp( Vertex(i+1), 0.5 );
	}
	
	return nc;
}

float Controls::SimpleLength()
{
	float len = 0;
	for (int i=0; i<Count; i++)
	{
		len += ( Vertex(i+1) - Vertex(i) ).Magnitude();
	}
	return len;
}

int Controls::NearPoint(fpnt mouse)
{
	int besti=-1;
	float bestd;

	for (int i=0; i<Count; i++)
	{
		float mag = (mouse - Verts[i]).Magnitude();
		if ((besti==-1) || (bestd > mag))
		{
			bestd = mag;
			besti = i;
		}
	}

	if (bestd > MinSelectDist)
		return -1;
	return besti;
}

void Controls::Circle(float radius)
{
	for (int i=0; i<Count; i++)
	{
		float ang = ((float)i) / ((float)Count);
		ang *= 2.0*PI;
		Verts[i].x = cos(ang)*radius;
		Verts[i].y = sin(ang)*radius;
		Verts[i].z = 0;
	}
}

void Controls::RenderSimplePoly()
{
	int i;

	glColor3f( 1, 1, 1);
	glBegin(GL_LINE_LOOP);
		for (i=0; i<Count; i++)
			glVertex3fv( Verts[i] );
	glEnd();

	glPointSize(5);
	glColor3f( 0, 1, 0);
	glBegin(GL_POINTS);
		for (i=0; i<Count; i++)
			glVertex3fv( Verts[i] );
	glEnd();
}

#define MAP1SAMPLES 10

void Controls::RenderWithMap1()
{
	fpnt c[4];

	glPointSize(3);

	for (int i=0; i<Count; i++)
	{
		c[1] = ( Vertex(i)*2.0 + Vertex(i+1) )/3.0;
		c[2] = ( Vertex(i) + Vertex(i+1)*2.0 )/3.0;

		c[0] = ( Vertex(i-1) + Vertex(i)*2.0 )/3.0;
		c[0] = ( c[1] + c[0] )/2.0;

		c[3] = ( Vertex(i+1)*2.0 + Vertex(i+2) )/3.0;
		c[3] = ( c[2] + c[3] )/2.0;

		glColor3f( 1, 0, 0);
		glBegin(GL_POINTS);
			for (int j=0; j<4; j++)
			{
				glVertex3fv( c[j] );
			}
		glEnd();

		glColor3f( 0, 0, 1);
		glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &c[0][0] );
		glBegin(GL_LINE_STRIP);
			for (int k=0; k<=MAP1SAMPLES; k++)
			{
				glEvalCoord1f( ((float)k) / ((float)MAP1SAMPLES) );
			}
		glEnd();
	}
}

fpnt Controls::DeCasteljauSample(fpnt* ctrls, float t)
{
	static fpnt abbc, bccd;
	static fpnt ab, bc, cd;

	ab = ctrls[0].Lerp( ctrls[1], t);
	bc = ctrls[1].Lerp( ctrls[2], t);
	cd = ctrls[2].Lerp( ctrls[3], t);
	abbc = ab.Lerp(bc, t);
	bccd = bc.Lerp(cd, t);
	return abbc.Lerp(bccd, t);
}

#define DECSAMPLE 10

void Controls::RenderDeCasteljau()
{
	glColor3f(1, 0, 1);

	fpnt c[4];
	int j;

	glPointSize(3);
	for (int i=0; i<Count; i++)
	{
		c[1] = ( Vertex(i)*2.0 + Vertex(i+1) )/3.0;
		c[2] = ( Vertex(i) + Vertex(i+1)*2.0 )/3.0;

		c[0] = ( Vertex(i-1) + Vertex(i)*2.0 )/3.0;
		c[0] = ( c[1] + c[0] )/2.0;

		c[3] = ( Vertex(i+1)*2.0 + Vertex(i+2) )/3.0;
		c[3] = ( c[2] + c[3] )/2.0;

		glColor3f( 0.95, 0.5, 1 );
		glBegin(GL_LINE_STRIP);
		for (j=0; j<DECSAMPLE; j++)
		{
			float t = ((float)j) / ((float)(DECSAMPLE-1));
			fpnt v = DeCasteljauSample(&c[0], t);
			glVertex3fv(v);
		}
		glEnd();

		glColor3f( 0, 235.0/255.0, 239.0/255.0 );
		glBegin(GL_POINTS);
		for (j=0; j<DECSAMPLE; j++)
		{
			float t = ((float)j) / ((float)(DECSAMPLE-1));
			fpnt v = DeCasteljauSample(&c[0], t);
			glVertex3fv(v);
		}
		glEnd();
	}
}

void Controls::RenderNURBS()
{
	GLUnurbsObj* robj = gluNewNurbsRenderer();

	int ksize = Count+(2*4);
	int i;

	float* knots = new float[ksize];
	for (i=0; i<ksize; i++)
		knots[i] = (float)i;
	for (i=Count; i<ksize; i++)
		Verts[i] = Verts[i%Count];

	glColor3f(1, 1, 0);
	gluBeginCurve(robj);
		gluNurbsCurve(robj, ksize, knots, 3, Verts[0], 4, GL_MAP1_VERTEX_3);
	gluEndCurve(robj);

	delete [] knots;
	gluDeleteNurbsRenderer(robj);
}







enum RenderMethod
{
	RM_None,
	RM_Map1,
	RM_DeCasteljau,
	RM_NURBS,
};


Controls* GControls;
int GrippedPoint = -1;
RenderMethod GRenderMethod = RM_None;

void init(void)
{
	GControls = new Controls();
	GControls->Init(6);
	GControls->Circle(3);

	glClearColor(0.0, 0.0, 0.0, 0.0);	
	glEnable(GL_MAP1_VERTEX_3);
	//   glShadeModel(GL_FLAT);
	//   glMap1f(GL_MAP1_VERTEX_3, 0.0, 1.0, 3, 4, &ctrlpoints[0][0]);
}

void display(void)
{	
	glClear(GL_COLOR_BUFFER_BIT);

	//drawing code here

	GControls->RenderSimplePoly();

	switch(GRenderMethod)
	{
	case RM_Map1:
		GControls->RenderWithMap1();
		break;
	case RM_DeCasteljau:
		GControls->RenderDeCasteljau();
		break;
	case RM_NURBS:
		GControls->RenderNURBS();
		break;
	default:
		break;
	}
	
	glFlush();
}

void reshape(int w, int h)
{
	WndSize.x = w;
	WndSize.y = h;

	if (w > h)
	{
		float ratio = ((float)w) / ((float)h);
		ScrMin.y = -MinScrSize;
		ScrMax.y = MinScrSize;
		ScrMin.x = -ratio*MinScrSize;
		ScrMax.x = ratio*MinScrSize;
	}
	else
	{
		float ratio = ((float)h) / ((float)w);
		ScrMin.x = -MinScrSize;
		ScrMax.x = MinScrSize;
		ScrMin.y = -ratio*MinScrSize;
		ScrMax.y = ratio*MinScrSize;
	}

	glViewport(0, 0, (GLsizei) w, (GLsizei) h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho( ScrMin.x, ScrMax.x, ScrMin.y, ScrMax.y, -1, 1);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void onHitS()
{
	float origlen = GControls->SimpleLength();

	Controls* nc = GControls->DeBoors();
	delete GControls;
	GControls = nc;

	float newlen = GControls->SimpleLength();

	printf("Orig Length = %f, Cur Length = %f\n", origlen, newlen);
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
		break;
	case '3':
		GRenderMethod = RM_NURBS;
		break;
	case '2':
		GRenderMethod = RM_DeCasteljau;
		break;
	case '1':
		GRenderMethod = RM_Map1;
		break;
	case ' ':
		GRenderMethod = RM_None;
		break;
	case 's':
	case 'S':
		onHitS();
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

void onMouseClick(int button, int state, int x, int y)
{
	if (state == GLUT_UP)
	{
		GrippedPoint = -1;
		return;
	}

	if (state == GLUT_DOWN)
	{
		if (button == GLUT_LEFT_BUTTON)
		{
			fpnt m = ScrToWorld(x, y);
			GrippedPoint = GControls->NearPoint(m);
			if (GrippedPoint!=-1)
			{
				GControls->Verts[GrippedPoint] = m;
				glutPostRedisplay();
			}
		}
	}
}

void onMouseDrag(int x, int y)
{
	fpnt m = ScrToWorld(x, y);
	if (GrippedPoint!=-1)
		GControls->Verts[GrippedPoint] = m;
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("7671 / Lewey Geselowitz");



	init ();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc (keyboard);
	glutMouseFunc( onMouseClick );
	glutMotionFunc( onMouseDrag );
	glutMainLoop();
	return 0;
}

