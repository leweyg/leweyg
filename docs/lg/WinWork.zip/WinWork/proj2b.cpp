/* 	CAP 5705 - Project 2b - Lewey Geselowitz (id = 7671)
*
*	Tetrahedron Linkage Program
*/

#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <time.h>

#define PI 3.1415926535897932384626433832795
#define RADTODEG(r)		(((r)*180.0f)/PI)

//allows for negative mod values. i.e. MOD(v,b) == MOD(v+b,b) no matter what v is.
int MOD(int v, int b)
{
	if (v >= 0) 
		return (v%b);
	v = ((-v)%b);
	return ((b-v)%b);
}


//This represents a 3d vertex, and lets me use vector notation
//via operator overloading.
struct fpnt
{
	float x, y, z;

	float& operator [] (int i) {return *((&x)+i);};
	operator float* () {return &x;};

	bool operator != (float* other)
	{
		return ((x!=other[0]) || (y!=other[1]) || (z!=other[2]));
	};

	fpnt operator * (float val)
	{
		fpnt ans;
		ans.x = x*val;
		ans.y = y*val;
		ans.z = z*val;
		return ans;
	};

	void operator *= (float val)
	{
		x *= val;
		y *= val;
		z *= val;
	};

	void operator += (float* other)
	{
		x += other[0];
		y += other[1];
		z += other[2];
	};

	void operator -= (float* other)
	{
		x -= other[0];
		y -= other[1];
		z -= other[2];
	};

	fpnt operator / (float val)
	{
		return (*this)*(1.0/val);
	};

	fpnt operator + (fpnt other)
	{
		fpnt ans;
		ans.x = x + other.x;
		ans.y = y + other.y;
		ans.z = z + other.z;
		return ans;
	};

	fpnt operator - (fpnt& other)
	{
		fpnt ans;
		ans.x = x - other.x;
		ans.y = y - other.y;
		ans.z = z - other.z;
		return ans;
	};

	fpnt Lerp(float* vec, float t)
	{
		fpnt ans;
		float nt = 1.0 - t;
		ans.x = x*nt + vec[0]*t;
		ans.y = y*nt + vec[1]*t;
		ans.z = z*nt + vec[2]*t;
		return ans;
	};

	void operator = (float* vec)
	{
		x = vec[0];
		y = vec[1];
		z = vec[2];
	};

	float Dot(float* vec)
	{
		return (x*vec[0] + y*vec[1] + z*vec[2]);
	};

	float Magnitude()
	{
		return sqrt( this->Dot(&x) );
	};

	void Normalize()
	{
		(*this) *= 1.0f/Magnitude();
	};

	fpnt Cross(float* other);
};

struct fmatrix
{
	float Values[16];

	operator float* () {return &Values[0];};
	float* operator [] (int i) {return &Values[4*i];};

	void Transpose();
	void Identity();

	void RotateX(float angle);
	void RotateY(float angle);
	void RotateZ(float angle);
	void Scale(float x, float y, float z);

	fpnt TimesVec(float* other);
	fpnt TimesVecAlt(float* other);
	void MultMatrix(fmatrix* one, fmatrix* two);
	void MultEqual(fmatrix* other);
};

fmatrix _matrixformult;
void fmatrix::MultEqual(fmatrix* other)
{
	_matrixformult.MultMatrix(other, this);
	(*this) = _matrixformult;
}

void fmatrix::Scale(float x, float y, float z)
{
	Identity();

	(*this)[0][0] = x;
	(*this)[1][1] = y;
	(*this)[2][2] = z;
}

void fmatrix::RotateX(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[1][1] = c;
	(*this)[2][1] = -s;
	(*this)[1][2] = s;
	(*this)[2][2] = c;
}

void fmatrix::RotateY(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[0][0] = c;
	(*this)[2][0] = s;
	(*this)[0][2] = -s;
	(*this)[2][2] = c;
}

void fmatrix::RotateZ(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[0][0] = c;
	(*this)[1][0] = -s;
	(*this)[0][1] = s;
	(*this)[1][1] = c;
}

void fmatrix::Identity()
{
	for (int i=0; i<16; i++)
	{
		Values[i] = ((i/4)==(i%4))? 1 : 0;
	}
}

void fmatrix::Transpose()
{
	for (int i=1; i<4; i++)
	{
		for (int j=0; j<i; j++)
		{
			float t = Values[(i*4)+j];
			Values[(i*4)+j] = Values[(j*4)+i];
			Values[(j*4)+i] = t;
		}
	}
}

void fmatrix::MultMatrix(fmatrix* one, fmatrix* two)
{
	float *rowf;
	float *mat = &one->Values[0];
	float *mat2 = &two->Values[0];

	for (int c=0; c<4; c++)
	{
		rowf = &two->Values[c*4];
		for (int i=0; i<4; i++)
		{
			float a = 0;
			for (int j=0; j<4; j++)
			{
				a += rowf[j]*mat[j*4 + i];
			}
			Values[(c*4)+i] = a;
		}
	}
}

fpnt fmatrix::TimesVecAlt(float* other)
{
	fpnt ans;
	for (int i=0; i<3; i++)
	{
		ans[i] = Values[3*4 + i];
		for (int j=0; j<3; j++)
		{
			ans[i] += other[j]*Values[j*4 + i];
		}
	}
	return ans;
}

fpnt fmatrix::TimesVec(float* other)
{
	fpnt ans;
	for (int i=0; i<3; i++)
	{
		ans[i] = Values[i*4 + 3];
		for (int j=0; j<3; j++)
		{
			ans[i] += other[j]*Values[i*4 + j];
		}
	}
	return ans;
}

fpnt fpnt::Cross(float* vec2)
{
	fpnt theans;
	float * ans = theans;
	float * vec1 = &x;
	//float * vec2 = other;
	ans[0]=((vec1[1] * vec2[2]) - (vec1[2] * vec2[1]));
	ans[1]=((vec1[2] * vec2[0]) - (vec1[0] * vec2[2]));
	ans[2]=((vec1[0] * vec2[1]) - (vec1[1] * vec2[0]));
	for (int i=0; i!=3; i++)
		ans[i] *= -1;
	return theans;
}

fpnt FPNT(float x, float y, float z)
{
	fpnt ans;
	ans.x = x; ans.y = y; ans.z = z;
	return ans;
}

fpnt WndSize;
fpnt ViewSize;
float CameraAng = PI*11.0f/16.0f;
float CameraPitch = PI/4.0f;
float CameraDist = 20;
fpnt LastMousePos;
bool CameraDrag = false;

void SetupCamera()
{
	fpnt campos;

	campos.x = cos( CameraAng ) * cos(CameraPitch);
	campos.z = sin( CameraAng ) * cos(CameraPitch);
	campos.y = sin( CameraPitch );
	campos *= CameraDist;

	fpnt up = campos.Cross( FPNT(0, 1, 0) );
	up = campos.Cross( up )*-1.0f;

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt( campos.x, campos.y, campos.z,
		0, 0, 0,
		up.x, up.y, up.z );
}


















void Draw_Axis()
{
	glLineWidth( 3 );

	glBegin(GL_LINES);
		glColor3f( 1, 0, 0);
		glVertex3f( 0, 0, 0 );
		glVertex3f( 5, 0, 0 );

		glColor3f( 0, 1, 0);
		glVertex3f( 0, 0, 0 );
		glVertex3f( 0, 5, 0 );

		glColor3f( 0, 0, 1);
		glVertex3f( 0, 0, 0 );
		glVertex3f( 0, 0, 5 );
	glEnd();
}

void Draw_Grid()
{
	glLineWidth( 1 );

	glColor3f(0.5, 0.5, 0.5);
	glBegin( GL_LINES );
		for (float x=-5; x<=5; x+=0.5)
		{
			glVertex3f(x, 0, -5);
			glVertex3f(x, 0, 5);
		}
		for (float z=-5; z<=5; z+=0.5)
		{
			glVertex3f(-5, 0, z);
			glVertex3f(5, 0, z);
		}
	glEnd();
}

class Tetra
{
public:
	fpnt Color[4];	//the four colours of the sides
	float RotAngle;	//the rotation of the object between it's parents and itself
	int Snaps[4];	//Which vertices of this object and of it's parent it snaps to

	void ApplyRotation();	//Transforms into the current Tetras coordinate system
	void Render();			//Draw the Tetra
	void SetSnaps(int m1, int m2, int p1, int p2);	//Sets which vertices on this Tetra
													//rotate about which vertices on
													//it's parents Tetra
};

#define Snap_My_1		0
#define Snap_My_2		1
#define Snap_Parent_1	2
#define Snap_Parent_2	3

void Tetra::SetSnaps(int m1, int m2, int p1, int p2)
{
	Snaps[Snap_My_1] = m1;
	Snaps[Snap_My_2] = m2;
	Snaps[Snap_Parent_1] = p1;
	Snaps[Snap_Parent_2] = p2;
}

Tetra GTetras[3];
Tetra* GCurTetra = 0;
fpnt TetraZeroOffset = FPNT(0.0, 0, 0.0);

float GTetraVerts[4*3] = {
	-1, -1, -1,
	-1, 1, 1,
	1, -1, 1,
	1, 1, -1,
};

//Given two initial and two final points, this function transforms the
//OpenGL state so that the first map to the second points. It also rotates
//about their axis by a given angle
void SnapTo(fpnt from1, fpnt from2, fpnt to1, fpnt to2, float rotation)
{
	float angle;
	fmatrix mat, mat1;
	fpnt axis;
	fpnt del1 = (from2 - from1);
	fpnt del2 = (to2 - to1);

	fmatrix result, work, result2;

	//First go from original values (from1,from2) to X axis

	//Scale to fit
	float scale = ((to2-to1).Magnitude() / (from2-from1).Magnitude());
	result2.Scale(scale, scale, scale);

	//get rid of the Z (rot about Y)
	angle = atan2( del1.z, del1.x );
	work.RotateY(angle);
	result.MultMatrix(&work, &result2);

	//get rid of the Y (rot about Z)
	del1 = result.TimesVec( del1 );
	angle = atan2( del1.y, del1.x );
	work.RotateZ(angle);
	result2.MultMatrix(&work, &result);

	//rotate about the X for looks!
	work.RotateX( rotation );
	mat1.MultMatrix(&work, &result2);



	//Now go from X axis to final orientation

	//Calculate the rotations to go from the final direction to the
	//X axis, we will use these in reverse to work out the matrix

	float rotbacky, rotbackz;
	
	//Get rid of the Z by rotating about the Y
	rotbacky = atan2( del2.z, del2.x );
	work.RotateY( rotbacky );

	//Get rid of the Y by rotating about the Z
	del2 = work.TimesVec(del2);
	rotbackz = atan2( del2.y, del2.x );

	//Now we have the Y and Z rotations, simply combine them
	result2.RotateZ( -rotbackz );
	result.RotateY( -rotbacky );
	mat.MultMatrix( &result, &result2 );


	//Now apply the translates and transforms
	//to OpenGL (read backwards for best understanding)
	glTranslatef( to1.x, to1.y, to1.z );			//translate to final dest
	glMultMatrixf( mat );							//go to new world space
	glMultMatrixf( mat1 );							//go to unit space
	glTranslatef( -from1.x, -from1.y, -from1.z );	//to origin
}

void Tetra::ApplyRotation()
{
	fpnt from1, from2, to1, to2;
	if (this == &GTetras[0])
	{
		//if it's the first Tetra, offset it and then use the default snap points
		glTranslatef( TetraZeroOffset.x, TetraZeroOffset.y, TetraZeroOffset.z );
		to1 = FPNT(0, 0, -sqrt(2));
		to2 = FPNT(0, 0,  sqrt(2));
	}
	else
	{
		//If it's not the first Tetra, use the vertices from the parents
		//Remember that we are in the parents coordinate system so their
		//default vertice locations will suffice.
		to1 = &GTetraVerts[ 3*Snaps[Snap_Parent_1] ];
		to2 = &GTetraVerts[ 3*Snaps[Snap_Parent_2] ];
	} 

	//Use the default tetra coordinates
	from1 = &GTetraVerts[ 3*Snaps[Snap_My_1] ];
	from2 = &GTetraVerts[ 3*Snaps[Snap_My_2] ];

	SnapTo(from1, from2, to1, to2, this->RotAngle );
}

void Tetra::Render()
{
	if (this == GCurTetra)
		glColor3f( 1, 1, 1);
	else
		glColor3fv( Color[0] );
	glutWireCube( 2.0f );

	glBegin(GL_TRIANGLES);
		glColor3fv( Color[0] );
		glVertex3fv( &GTetraVerts[0*3] );
		glVertex3fv( &GTetraVerts[1*3] );
		glVertex3fv( &GTetraVerts[2*3] );

		glColor3fv( Color[1] );
		glVertex3fv( &GTetraVerts[0*3] );
		glVertex3fv( &GTetraVerts[1*3] );
		glVertex3fv( &GTetraVerts[3*3] );

		glColor3fv( Color[2] );
		glVertex3fv( &GTetraVerts[0*3] );
		glVertex3fv( &GTetraVerts[3*3] );
		glVertex3fv( &GTetraVerts[2*3] );

		glColor3fv( Color[3] );
		glVertex3fv( &GTetraVerts[3*3] );
		glVertex3fv( &GTetraVerts[1*3] );
		glVertex3fv( &GTetraVerts[2*3] );
	glEnd();
}

fpnt GCurTetraDelta = FPNT(0, 0, 0);

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);	
	glEnable(GL_DEPTH_TEST);
	
	//Setup the Tetras:

	GTetras[0].Color[0] = FPNT(1.0,0.0,0.0);
	GTetras[0].Color[1] = FPNT(1.0,0.5,0.0);
	GTetras[0].Color[2] = FPNT(1.0,0.0,0.5);
	GTetras[0].Color[3] = FPNT(1.0,0.5,0.5);
	GTetras[0].RotAngle = -((PI/2)-0.95);
	GTetras[0].SetSnaps(2, 3, 0, 1 );

	GTetras[1].Color[0] = FPNT(0.0,1.0,0.0);
	GTetras[1].Color[1] = FPNT(0.5,1.0,0.0);
	GTetras[1].Color[2] = FPNT(0.0,1.0,0.5);
	GTetras[1].Color[3] = FPNT(0.5,1.0,0.5);
	GTetras[1].RotAngle = PI;
	GTetras[1].SetSnaps(2, 3, 0, 1);	//This sets up which vertices of this cube
										//bind to the vertices of it's parent

	GTetras[2].Color[0] = FPNT(0.0,0.0,1.0);
	GTetras[2].Color[1] = FPNT(0.0,0.5,1.0);
	GTetras[2].Color[2] = FPNT(0.5,0.0,1.0);
	GTetras[2].Color[3] = FPNT(0.5,0.5,1.0);
	GTetras[2].RotAngle = PI;
	GTetras[2].SetSnaps(2, 3, 0, 1);
}

class Bullet
{
public:
	fpnt Start, Delta, Current;
	bool ShouldDisplay, Stopped;
	float Speed;
	int TimeStart;

	void Update();
	void Draw();
	void Fire();

	Bullet() {ShouldDisplay=false;};
};

#define BULLETVELMIN	1
#define BULLETVELMAX	5
#define BULLETGRAVITY	3

void Bullet::Update()
{
	if (Stopped)
		return;

	double t = ((double)(clock() - TimeStart)) / ((double)CLOCKS_PER_SEC);

	Current.y = Start.y  +  Delta.y*t*Speed - 0.5*t*t*BULLETGRAVITY;
	Current.x = Start.x + Delta.x*t*Speed;
	Current.z = Start.z + Delta.z*t*Speed;

	if (Current.y <= 0)
	{
		Stopped = true;
		Current.y = 0; //yes I know this is a hack
	}
}

void Bullet::Draw()
{
	if (!ShouldDisplay)
		return;

	Update();

	glPushMatrix();
		glTranslatef( Current.x, Current.y, Current.z );
		glColor3f( 0.8, 0.8, 0.8 );
		glutSolidCube( 0.25 );
	glPopMatrix();
}

void Bullet::Fire()
{
	fmatrix mat;

	glPushMatrix();
		glLoadIdentity();

		for (int i=0; i<3; i++)
		{
			GTetras[i].ApplyRotation();
		}

		glGetFloatv(GL_MODELVIEW_MATRIX, mat);

	glPopMatrix();

	fpnt pos1 = mat.TimesVecAlt( &GTetraVerts[3*0] );
	fpnt pos2 = mat.TimesVecAlt( &GTetraVerts[3*1] );

	if (pos1.y < pos2.y)
	{
		fpnt t=pos1; pos1=pos2; pos2=t;
	}

	TimeStart = clock();
	Start = pos1;
	Delta = (pos1 - pos2);
	Delta.Normalize();

	Speed = ((double)rand()) / ((double)RAND_MAX);
	Speed = Speed*BULLETVELMAX + (1-Speed)*BULLETVELMIN;

	ShouldDisplay = true;
	Stopped = false;
}

#define MAXBULLETS	30
Bullet GBullets[MAXBULLETS];
int GNumBullets = 0;
int GCurBullet = 0;

void DrawObjects(bool usenames)
{
	if (usenames)
		glPushName(0);

	Draw_Axis();
	Draw_Grid();

	glPushMatrix();
		for (int i=0; i<3; i++)
		{
			if (usenames)
				glLoadName(1+i);
			GTetras[i].ApplyRotation();
			GTetras[i].Render();
		}
	glPopMatrix();
}

void display(void)
{	
	//setup the camera
	SetupCamera();

	//apply any changes made by the user
	if (GCurTetra)
	{
		if (GCurTetra == &GTetras[0])
			TetraZeroOffset += FPNT(-GCurTetraDelta.y, 0, GCurTetraDelta.x)*0.05;
		if (GCurTetra == &GTetras[1])
			GCurTetra->RotAngle += (GCurTetraDelta.x/100.0f) * PI;
		if (GCurTetra == &GTetras[2])
			GCurTetra->RotAngle += (GCurTetraDelta.y/100.0f) * PI;
	}
	GCurTetraDelta = FPNT(0, 0, 0);


	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	DrawObjects(false);

	for (int i=0; i<GNumBullets; i++)
		GBullets[i].Draw();

	glFlush();
	glutSwapBuffers();
}

void FocusOrthoView(float cx, float cy, float sw, float sh)
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(cx-sw, cx+sw, cy-sh, cy+sh, 10, 30);

	glMatrixMode(GL_MODELVIEW);
}

void reshape(int w, int h)
{
	WndSize.x = w;
	WndSize.y = h;

	float ratio = ((float)w) / ((float)h);

	glViewport(0, 0, (GLsizei) w, (GLsizei) h);

 	float vsize = 8;

	ViewSize = FPNT(vsize*ratio, vsize, 0);

	FocusOrthoView( 0, 0, ViewSize.x, ViewSize.y);

	glLoadIdentity();
	gluLookAt( 10, 10, 10,
		0, 0, 0,
		0, -1, 0 );
}

void keyboard_spec(int key, int x, int y)
{
	switch(key)
	{
	case GLUT_KEY_LEFT:
		GCurTetraDelta = FPNT(-10, 0, 0);
		break;
	case GLUT_KEY_RIGHT:
		GCurTetraDelta = FPNT(10, 0, 0);
		break;
	case GLUT_KEY_UP:
		GCurTetraDelta = FPNT(0, -10, 0);
		break;
	case GLUT_KEY_DOWN:
		GCurTetraDelta = FPNT(0, 10, 0);
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
		break;
	case '1':
		GCurTetra = &GTetras[0];
		break;
	case '2':
		GCurTetra = &GTetras[1];
		break;
	case '3':
		GCurTetra = &GTetras[2];
		break;
	case 'C':
	case 'c':
		GCurTetra = NULL;
		break;
	case ' ':
		{
			if (GNumBullets < MAXBULLETS)
				GNumBullets++;
			GCurBullet = (GCurBullet+1)%GNumBullets;
			GBullets[GCurBullet].Fire();
		}
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

#define SELECTBUFFERSIZE	512

#define _HitZ(z)		{if((bestname==-1)||(bestz<(z))){usethis=true;};}
int HitNameFromSelectBuffer(int hits, GLuint* buffer)
{
	GLuint* ptr = (GLuint *)buffer;
	GLuint names;

	int bestname = -1;
	float bestz;

	for (int i = 0; i < hits; i++) /*  for each hit  */
	{
		names = *ptr;
		bool usethis = false;
		ptr++;

		_HitZ(*ptr); ptr++;
		_HitZ(*ptr); ptr++;

		for (int j = 0; j < names; j++) /*  for each name */
		{
			if (usethis)
				bestname = *ptr;
			ptr++;
		}
	}
	if (bestname == -1)
		return 0;
	return bestname;
}

void onSelect(int x, int y)
{
	GLuint SelectBuffer[SELECTBUFFERSIZE];

	float cvx = ((float)x) / WndSize.x;
	cvx = ((cvx * 2.0) - 1.0) * ViewSize.x;

	float cvy = ((float)y) / WndSize.y;
	cvy = (-((cvy * 2.0) - 1.0)) * ViewSize.y;

	FocusOrthoView(cvx, cvy, 0.025, 0.025);

	glSelectBuffer(SELECTBUFFERSIZE, SelectBuffer);
	glRenderMode( GL_SELECT );
	glInitNames();

	DrawObjects(true);

	int hits = glRenderMode(GL_RENDER);

	int hit = HitNameFromSelectBuffer(hits, SelectBuffer);

	if (hit==0)
		GCurTetra = NULL;
	else
		GCurTetra = &GTetras[hit-1];

	FocusOrthoView(0, 0, ViewSize.x, ViewSize.y);

	glutPostRedisplay();
}

void onMouseClick(int button, int state, int x, int y)
{
	if (state == GLUT_UP)
	{
	}

	if (state == GLUT_DOWN)
	{
		onSelect(x, y);
	}

	LastMousePos = FPNT(x, y, 0);
}

void onMouseDrag(int x, int y)
{
	if (GCurTetra==NULL)
	{
		fpnt curpos = FPNT(x, y, 0);
		fpnt d = curpos - LastMousePos;

		CameraAng += d.x / 200;
		CameraPitch += d.y / 200;
	}
	else
	{
		GCurTetraDelta = FPNT(x-LastMousePos.x, y-LastMousePos.y, 0);
	}

	LastMousePos = FPNT(x, y, 0);
	glutPostRedisplay();
}

void onIdle()
{
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("7671 / Lewey Geselowitz");


	init ();
	glutIdleFunc( onIdle );
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc (keyboard);
	glutSpecialUpFunc (keyboard_spec);
	glutMouseFunc( onMouseClick );
	glutMotionFunc( onMouseDrag );
	glutMainLoop();
	return 0;
}


