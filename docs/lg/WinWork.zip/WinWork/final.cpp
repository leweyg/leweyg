/* 	CAP 5705 - Project 2b - Lewey Geselowitz (id = 7671)
*
*	Tetrahedron Linkage Program
*/

#include <GL/glut.h>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include <fstream.h>

#define Assert assert
#define TODO() Assert(false)

#define PI 3.1415926535897932384626433832795
#define RADTODEG(r)		(((r)*180.0f)/PI)
bool Debugging = false;

//allows for negative mod values. i.e. MOD(v,b) == MOD(v+b,b) no matter what v is.
int MOD(int v, int b)
{
	if (v >= 0) 
		return (v%b);
	v = ((-v)%b);
	return ((b-v)%b);
}

void ZeroMem(void* data, int size)
{
	char* cd = (char*)data;
	for (int i=0; i<size; i++)
		cd[i] = 0;
}

//This represents a 3d vertex, and lets me use vector notation
//via operator overloading.
struct fpnt
{
	float x, y, z;

	float& operator [] (int i) {return *((&x)+i);};
	operator float* () {return &x;};

	void Zero() {x=0; y=0; z=0;};

	bool operator != (float* other)
	{
		return ((x!=other[0]) || (y!=other[1]) || (z!=other[2]));
	};

	fpnt operator * (float val)
	{
		fpnt ans;
		ans.x = x*val;
		ans.y = y*val;
		ans.z = z*val;
		return ans;
	};

	void operator *= (float val)
	{
		x *= val;
		y *= val;
		z *= val;
	};

	void operator += (float* other)
	{
		x += other[0];
		y += other[1];
		z += other[2];
	};

	void operator -= (float* other)
	{
		x -= other[0];
		y -= other[1];
		z -= other[2];
	};

	fpnt operator / (float val)
	{
		return (*this)*(1.0/val);
	};

	fpnt operator + (fpnt other)
	{
		fpnt ans;
		ans.x = x + other.x;
		ans.y = y + other.y;
		ans.z = z + other.z;
		return ans;
	};

	fpnt operator - (fpnt& other)
	{
		fpnt ans;
		ans.x = x - other.x;
		ans.y = y - other.y;
		ans.z = z - other.z;
		return ans;
	};

	fpnt Lerp(float* vec, float t)
	{
		fpnt ans;
		float nt = 1.0 - t;
		ans.x = x*nt + vec[0]*t;
		ans.y = y*nt + vec[1]*t;
		ans.z = z*nt + vec[2]*t;
		return ans;
	};

	void Lerp(float* a, float* b, float t)
	{
		float ot = 1.0-t;
		x = a[0]*t + b[0]*ot;
		y = a[1]*t + b[1]*ot;
		z = a[2]*t + b[2]*ot;
	};

	void operator = (float* vec)
	{
		x = vec[0];
		y = vec[1];
		z = vec[2];
	};

	float Dot(float* vec)
	{
		return (x*vec[0] + y*vec[1] + z*vec[2]);
	};
	float SelfDot()
	{
		return x*x + y*y + z*z;
	}

	float Magnitude()
	{
		return sqrt( this->Dot(&x) );
	};

	void Normalize()
	{
		(*this) *= 1.0f/Magnitude();
	};

	fpnt Normalized()
	{
		return (*this) * (1.0f/Magnitude());
	};

	void Print()
	{
		printf("(%f,%f,%f)", x, y, z);
	}

	fpnt Cross(float* other);
};

struct fmatrix
{
	float Values[16];

	operator float* () {return &Values[0];};
	float* operator [] (int i) {return &Values[4*i];};

	void Transpose();
	void Identity();

	void RotateX(float angle);
	void RotateY(float angle);
	void RotateZ(float angle);
	void Scale(float x, float y, float z);

	fpnt TimesVec(float* other);
	fpnt TimesVecAlt(float* other);
	void MultMatrix(fmatrix* one, fmatrix* two);
	void MultEqual(fmatrix* other);
};

fmatrix _matrixformult;
void fmatrix::MultEqual(fmatrix* other)
{
	_matrixformult.MultMatrix(other, this);
	(*this) = _matrixformult;
}

void fmatrix::Scale(float x, float y, float z)
{
	Identity();

	(*this)[0][0] = x;
	(*this)[1][1] = y;
	(*this)[2][2] = z;
}

void fmatrix::RotateX(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[1][1] = c;
	(*this)[2][1] = -s;
	(*this)[1][2] = s;
	(*this)[2][2] = c;
}

void fmatrix::RotateY(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[0][0] = c;
	(*this)[2][0] = s;
	(*this)[0][2] = -s;
	(*this)[2][2] = c;
}

void fmatrix::RotateZ(float angle)
{
	Identity();
	float s = sin(angle);
	float c = cos(angle);

	(*this)[0][0] = c;
	(*this)[1][0] = -s;
	(*this)[0][1] = s;
	(*this)[1][1] = c;
}

void fmatrix::Identity()
{
	for (int i=0; i<16; i++)
	{
		Values[i] = ((i/4)==(i%4))? 1 : 0;
	}
}

void fmatrix::Transpose()
{
	for (int i=1; i<4; i++)
	{
		for (int j=0; j<i; j++)
		{
			float t = Values[(i*4)+j];
			Values[(i*4)+j] = Values[(j*4)+i];
			Values[(j*4)+i] = t;
		}
	}
}

void fmatrix::MultMatrix(fmatrix* one, fmatrix* two)
{
	float *rowf;
	float *mat = &one->Values[0];
	float *mat2 = &two->Values[0];

	for (int c=0; c<4; c++)
	{
		rowf = &two->Values[c*4];
		for (int i=0; i<4; i++)
		{
			float a = 0;
			for (int j=0; j<4; j++)
			{
				a += rowf[j]*mat[j*4 + i];
			}
			Values[(c*4)+i] = a;
		}
	}
}

fpnt fmatrix::TimesVecAlt(float* other)
{
	fpnt ans;
	for (int i=0; i<3; i++)
	{
		ans[i] = Values[3*4 + i];
		for (int j=0; j<3; j++)
		{
			ans[i] += other[j]*Values[j*4 + i];
		}
	}
	return ans;
}

fpnt fmatrix::TimesVec(float* other)
{
	fpnt ans;
	for (int i=0; i<3; i++)
	{
		ans[i] = Values[i*4 + 3];
		for (int j=0; j<3; j++)
		{
			ans[i] += other[j]*Values[i*4 + j];
		}
	}
	return ans;
}

fpnt fpnt::Cross(float* vec2)
{
	fpnt theans;
	float * ans = theans;
	float * vec1 = &x;
	//float * vec2 = other;
	ans[0]=((vec1[1] * vec2[2]) - (vec1[2] * vec2[1]));
	ans[1]=((vec1[2] * vec2[0]) - (vec1[0] * vec2[2]));
	ans[2]=((vec1[0] * vec2[1]) - (vec1[1] * vec2[0]));
	for (int i=0; i!=3; i++)
		ans[i] *= -1;
	return theans;
}

fpnt FPNT(float x, float y, float z)
{
	fpnt ans;
	ans.x = x; ans.y = y; ans.z = z;
	return ans;
}



fpnt WndSize;
fpnt ViewSize;

fpnt CameraPos = FPNT(0, 0, 0); //FPNT(0, 0, 10);
float CameraAng=-PI/2, CameraPitch=0;
float CameraDist = 6;

fpnt LastMousePos;
bool CameraDrag = false;

fpnt CameraDir()
{
	fpnt camdir;

	camdir.x = cos( CameraAng ) * cos(CameraPitch);
	camdir.z = sin( CameraAng ) * cos(CameraPitch);
	camdir.y = sin( CameraPitch );
	camdir.Normalize();

	return camdir;
}

void LightProp(GLenum p, float r, float g, float b)
{
	float vals[] = {r, g, b, 0};
	glLightfv(GL_LIGHT0, p, &vals[0]);
}

void LightProp(GLenum v, float all)
{
	LightProp(v, all, all, all);
}

void MatProp(GLenum p, float r, float g, float b)
{
	float vals[] = {r, g, b, 0};
	glMaterialfv(GL_FRONT_AND_BACK, p, &vals[0] );
}

void SetupLight(bool onlyambient)
{
	LightProp(GL_AMBIENT, 0.2, 0.2, 0.2);
	if (!onlyambient)
		LightProp(GL_DIFFUSE, 0.9, 0.5, 0.5);
	else
		LightProp(GL_DIFFUSE, 0.65, 0.35, 0.35);

	MatProp(GL_AMBIENT, 0.5, 0.5, 1);
	if (!onlyambient)
		MatProp(GL_DIFFUSE, 1, 1, 1);
	else
		MatProp(GL_DIFFUSE, 0.75, 0.75, 0.75);
//	MatProp(GL_AMBIENT, 0.5, 0.5, 0.5);
}

void SetupCamera()
{
	fpnt camdir = CameraDir();

	fpnt up = FPNT(0, 1, 0);
	/*
	fpnt up = camdir.Cross( FPNT(0, 1, 0) );
	up = camdir.Cross( up )*-1.0f;
	*/

	glMatrixMode(GL_MODELVIEW);

	glLoadIdentity();

	
	camdir *= CameraDist;
	CameraPos = camdir;
	gluLookAt( camdir.x, camdir.y, camdir.z,
		0, 0, 0,
		0, 1, 0);

	/*
	fpnt lookat = CameraPos + camdir;
	gluLookAt(CameraPos.x, CameraPos.y, CameraPos.z,
			  lookat.x, lookat.y, lookat.z,
			  up.x, up.y, up.z);
	*/

//	float vec[4] = { CameraPos.x, CameraPos.y, CameraPos.z, 1 };
//	glLightfv(GL_LIGHT0, GL_POSITION, &vec[0]);

	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);

	LightProp(GL_POSITION, -camdir.x, -camdir.y, -camdir.z);

	SetupLight(false);
}
















struct VERT
{
	fpnt Pos;
	fpnt Normal;
	//extra...
	float S, T, Attrib0;

	void ST(float s, float t) {S=s; T=t;};
	void Interp(VERT* a, VERT* b, float t);
	void Interp(VERT* a, VERT* b, VERT* c, fpnt* weights);
	int Compare(VERT* other);
};

int VERT::Compare(VERT* other)
{
	char* t = (char*)this;
	char* ot = (char*)other;

	for (int i=0; i<sizeof(VERT); i++)
	{
		if (t[i] != ot[i])
		{
			return ((t[i] < ot[i])? -1 : 1);
		}
	}
	return 0;
}
void VERT::Interp(VERT* va, VERT* vb, VERT* vc, fpnt* weights)
{
	float *a=(float*)va, *b=(float*)vb, *c=(float*)vc;
	float *to=(float*)this;

	const int num = sizeof(VERT)/sizeof(float);
	for (int i=0; i<num; i++)
	{
		to[i] = a[i]*weights->x + b[i]*weights->y + c[i]*weights->z;
	}
	Normal.Normalize();
}

void VERT::Interp(VERT* a, VERT* b, float t)
{
	Pos = (a->Pos*t) + (b->Pos*(1-t));
	Normal = (a->Normal*t) + (b->Normal*(1-t));
	Attrib0 = (a->Attrib0*t) + (b->Attrib0*(1-t));
	S = (a->S*t) + (b->S*(1-t));
	T = (a->T*t) + (b->T*(1-t));

	Normal.Normalize();
}

typedef void (*PolyShader)(VERT* a, VERT* b, VERT* c);

typedef unsigned short INDEX;

class Mesh
{
public:
	VERT* Verts;
	INDEX* Inds;
	int NumVerts, NumInds;

	void Init(int nverts, int ninds);
	void UnInit();

	void FormCube();
	void FormTri();
	void FormPyramid();
	void Scale(float f);
	void Invert();
	void BasicRender(bool usenormals);
	void Render();
	void Render(PolyShader shader);
	void CalcNormals(bool smooth);
	void LoadFromTXT(char* filename);
	void LoadFromOFF(char* filename);
	void Normalize();
	void SetAttrib0(float atb);
	void Simplify();

	Mesh() {Verts=0; NumVerts=0; NumInds=0; Inds=0;};
	~Mesh() {UnInit();};
};

void Mesh::Simplify()
{
	int* work = new int[NumVerts];
	int i, j;

	work[0] = 0;
	for (i=1; i<NumVerts; i++)
	{
		VERT* cur = &Verts[i];
		work[i] = i;
		for (j=0; j<i; j++)
		{
			if (cur->Compare( &Verts[work[j]] )==0)
			{
				work[i] = work[j];
				break;
			}
		}
	}

	j=0;
	for (i=0; i<NumVerts; i++)
	{
		if (work[i]==i)
		{
			work[i] = j;
			if (i != j)
				Verts[j] = Verts[i];
			j++;
		}
		else
			work[i] = work[work[i]];
	}
	NumVerts = j;

	for (i=0; i<NumInds; i++)
		Inds[i] = work[Inds[i]];


	delete [] work;
}

#define MAXOF(a,b)	(((a)>(b))? (a) : (b) )

void Mesh::SetAttrib0(float atb)
{
	for (int i=0; i<NumVerts; i++)
		Verts[i].Attrib0 = atb;
}

void Mesh::Normalize()
{
	fpnt min, max;
	min = this->Verts[0].Pos;
	max = Verts[0].Pos;

	int i;
	for (i=0; i<NumVerts; i++)
	{
		if (max.x < Verts[i].Pos.x)
			max.x = Verts[i].Pos.x;
		if (max.y < Verts[i].Pos.y)
			max.y = Verts[i].Pos.y;
		if (max.z < Verts[i].Pos.z)
			max.z = Verts[i].Pos.z;

		if (min.x > Verts[i].Pos.x)
			min.x = Verts[i].Pos.x;
		if (min.y > Verts[i].Pos.y)
			min.y = Verts[i].Pos.y;
		if (min.z > Verts[i].Pos.z)
			min.z = Verts[i].Pos.z;
	}

	fpnt mid = (min + max)/2;
	float scale = max.x - min.x;
	scale = MAXOF(scale, max.y-min.y);
	scale = MAXOF(scale, max.z-min.z);
	scale = 1/(scale/2);

	for (i=0; i<NumVerts; i++)
	{
		Verts[i].Pos = (Verts[i].Pos - mid)*scale;
	}
}

void Mesh::LoadFromTXT(char* filename)
{
	ifstream fin(filename);
	
	int tris, i;
	fin >> tris;

	Init(tris*3, tris*3);

	for (i=0; i<NumVerts; i++)
	{
		fin >> Verts[i].Pos.x >> Verts[i].Pos.y >> Verts[i].Pos.z;
	}

	for (i=0; i<NumInds; i++)
		Inds[i] = i;
}

void Mesh::LoadFromOFF(char* filename)
{
	ifstream fin(filename);
	char text[200];
	fin >> text;
	
	int numv, numi, i;
	fin >> numv >> numi >> i;
	float other;

	Init(numv, numi*3);

	for (i=0; i<numv; i++)
	{
		fin >> Verts[i].Pos.x >> Verts[i].Pos.y >> Verts[i].Pos.z;
	}

	for (i=0; i<numi; i++)
	{
		fin >> other;
		fin >> Inds[i*3+0] >> Inds[i*3+1] >> Inds[i*3+2];
		for (int j=0; j<3; j++)
			fin >> other;
	}

//	this->SetAttrib0(1);
}

void Mesh::Invert()
{
	if (NumInds!=0)
	{
		for (int i=0; i<NumInds; i+=3)
		{
			int t = Inds[i+2];
			Inds[i+2] = Inds[i+1];
			Inds[i+1] = t;
		}
	}
	else
		TODO();
}

void Mesh::Scale(float f)
{
	for (int i=0; i<NumVerts; i++)
		Verts[i].Pos *= f;
}

void Mesh::CalcNormals(bool smooth)
{
	int i;
	for (i=0; i<NumVerts; i++)
	{
		Verts[i].Normal.Zero();
	}

	if (NumInds!=0)
	{
		fpnt a, b;
		for (i=0; i<NumInds; i+=3)
		{
			a = Verts[Inds[i+0]].Pos - Verts[Inds[i+1]].Pos;
			b = Verts[Inds[i+2]].Pos - Verts[Inds[i+1]].Pos;
			a = a.Cross(b) * -1;
			a.Normalize();
			if (smooth)
			{
				Verts[Inds[i+0]].Normal += a;
				Verts[Inds[i+1]].Normal += a;
				Verts[Inds[i+2]].Normal += a;
			}
			else
			{
				Verts[Inds[i+0]].Normal = a;
				Verts[Inds[i+1]].Normal = a;
				Verts[Inds[i+2]].Normal = a;
			}
		}
	}
	else
		TODO();

	if (smooth)
	{
		for (i=0; i<NumVerts; i++)
			Verts[i].Normal.Normalize();
	}
}

void Mesh::BasicRender(bool usenormals)
{
	glBegin(GL_TRIANGLES);
		if (NumInds != 0)
		{
			for (int i=0; i<NumInds; i+=3)
			{
				if (usenormals)
					glNormal3fv( Verts[Inds[i+0]].Normal );
				glVertex3fv( Verts[Inds[i+0]].Pos );
				if (usenormals)
					glNormal3fv( Verts[Inds[i+1]].Normal );
				glVertex3fv( Verts[Inds[i+1]].Pos );
				if (usenormals)
					glNormal3fv( Verts[Inds[i+2]].Normal );
				glVertex3fv( Verts[Inds[i+2]].Pos );
			}
		}
		else
		{
			TODO();
		}
	glEnd();
}

void Mesh::Init(int nverts, int ninds)
{
	if ((NumVerts == nverts) && (NumInds == ninds))
		return;

	UnInit();
	if (nverts!=0)
	{
		Verts = new VERT[nverts];
		ZeroMem(Verts, nverts*sizeof(VERT));
	}
	if (ninds!=0)
		Inds = new INDEX[ninds];
	NumInds = ninds;
	NumVerts = nverts;
}

void Mesh::UnInit()
{
	if (Verts!=0)
		delete [] Verts;
	if (Inds!=0)
		delete [] Inds;
	Inds = 0;
	Verts = 0;
	NumVerts = 0;
	NumInds = 0;
}

void QuadInds(INDEX* to, int cq, int a, int b, int c, int d)
{
	cq *= 6;
	to[cq+0] = a; to[cq+1] = d; to[cq+2] = c;
	to[cq+3] = c; to[cq+4] = b; to[cq+5] = a;
}

void TriInds(INDEX* to, int ct, int a, int b, int c)
{
	ct *= 3;
	to[ct+0] = a; to[ct+1] = b; to[ct+2] = c;
}

void Mesh::FormTri()
{
	Init(3, 3);

	Verts[0].Pos = FPNT(-1, -1, 0);
	Verts[1].Pos = FPNT( 1, -1, 0);
	Verts[2].Pos = FPNT( 0,  1, 0);

	for (int i=0; i<NumVerts; i++)
	{
		Verts[i].Normal = (Verts[i].Pos + FPNT(0,0,1)).Normalized();
	}

	Inds[0] = 0;
	Inds[1] = 2;
	Inds[2] = 1;
}

void Mesh::FormPyramid()
{
	Init(4, 3*4);

	double ang = PI*2/3;
	double y = sqrt(2)/2;
	Verts[0].Pos = FPNT(0,y,0);
	Verts[1].Pos = FPNT(cos(0), -y, sin(0));
	Verts[2].Pos = FPNT(cos( ang), -y, sin(ang));
	Verts[3].Pos = FPNT(cos(-ang), -y, sin(-ang));

	TriInds(Inds,0, 1, 0, 2);
	TriInds(Inds,1, 2, 0, 3);
	TriInds(Inds,2, 3, 0, 1);
	TriInds(Inds,3, 1, 2, 3);
}

void Mesh::FormCube()
{
	Init(8, 6*2*3);

	Verts[0].Pos = FPNT(-1, -1, -1);
	Verts[1].Pos = FPNT( 1, -1, -1);
	Verts[2].Pos = FPNT( 1, -1,  1);
	Verts[3].Pos = FPNT(-1, -1,  1);

	Verts[4].Pos = FPNT(-1,  1, -1);
	Verts[5].Pos = FPNT( 1,  1, -1);
	Verts[6].Pos = FPNT( 1,  1,  1);
	Verts[7].Pos = FPNT(-1,  1,  1);

	this->SetAttrib0(0);
	Verts[0].Attrib0 = 1;
	Verts[1].Attrib0 = 1;
	Verts[3].Attrib0 = 1;

	QuadInds(Inds,0, 3, 2, 1, 0);
	QuadInds(Inds,1, 4, 5, 6, 7);
	QuadInds(Inds,2, 0, 1, 5, 4);
	QuadInds(Inds,3, 1, 2, 6, 5);
	QuadInds(Inds,4, 2, 3, 7, 6);
	QuadInds(Inds,5, 3, 0, 4, 7);


	Verts[0].ST(0,0);
	Verts[1].ST(1,0);
	Verts[2].ST(1,1);
	Verts[3].ST(0,1);

	Verts[7].ST(0,0);
	Verts[6].ST(1,0);
	Verts[5].ST(1,1);
	Verts[4].ST(0,1);
}


bool SH_InvertTris = false;
bool SH_FlatNormals = false;
bool SH_Wireframe = false;

#define MAXSHADERSTACK	20
PolyShader _shaderstack[MAXSHADERSTACK];
int _shadercount=0, _shadercur=0;

void SH_AddShader(PolyShader sh)
{
	_shaderstack[_shadercount++] = sh;
}
void SH_AddShader(PolyShader sh, int count)
{
	for (int i=0; i<count; i++)
		SH_AddShader(sh);
}

void SH_ClearShaders()
{
	_shadercount=0;
}

int _SH_CurTriCount = 0;

void SH_Tri(VERT* a, VERT* b, VERT* c)
{
	if (_shadercur < _shadercount)
	{
		_shadercur++;
		(*_shaderstack[_shadercur-1])(a, b, c);
		_shadercur--;
		return;
	}

	if (SH_InvertTris)
	{
		VERT* t = b; b = c; c = t;
	}

	if (!SH_FlatNormals)
	{
		glNormal3fv(a->Normal);
		glVertex3fv(a->Pos);

		glNormal3fv(b->Normal);
		glVertex3fv(b->Pos);

		glNormal3fv(c->Normal);
		glVertex3fv(c->Pos);

		if (SH_Wireframe)
		{
			glNormal3fv(a->Normal);
			glVertex3fv(a->Pos);

			glNormal3fv(b->Normal);
			glVertex3fv(b->Pos);

			glNormal3fv(c->Normal);
			glVertex3fv(c->Pos);
		}
	}
	else
	{
		fpnt n = (a->Pos - b->Pos).Cross( c->Pos - b->Pos );
		n.Normalize(); n *= -1;

		glNormal3fv( n );
		glVertex3fv( a->Pos );
		glVertex3fv( b->Pos );
		glVertex3fv( c->Pos );

		if (SH_Wireframe)
		{
			glVertex3fv( a->Pos );
			glVertex3fv( b->Pos );
			glVertex3fv( c->Pos );
		}
	}
	_SH_CurTriCount++;
}

void Mesh::Render()
{
	if (NumInds!=0)
	{
		if (NumVerts <= 3)
			glDisable(GL_CULL_FACE);
		if (SH_Wireframe)
			glBegin(GL_LINES);
		else
			glBegin(GL_TRIANGLES);
		for (int i=0; i<NumInds; i+=3)
		{
			//(*shader)( &Verts[Inds[i+0]], &Verts[Inds[i+1]], &Verts[Inds[i+2]] );
			SH_Tri( &Verts[Inds[i+0]], &Verts[Inds[i+1]], &Verts[Inds[i+2]] );
		}
		glEnd();
		glEnable(GL_CULL_FACE);
	}
	else
		TODO();
}

void Mesh::Render(PolyShader shader)
{
	SH_ClearShaders();
	SH_AddShader(shader);
	Render();
}



#define _disp_size 5
float _disp_Values[_disp_size*_disp_size] = {
/*	1, 0, 1, 0, 0,
	0, 1, 1, 0, 0,
	0, 0, 1, 0, 1,
	0, -1,1, 0, 1,
	-1,-1,-1,0, 1 */
	1, 1, 0, 0, 0,
	1, 1, 1, 0, 0,
	0, 1, 1, 1, 0,
	0, 0, 1, 1, 1,
	0, 0, 0, 1, 1
};

float SampleDispMap(float s, float t)
{
	s *= _disp_size-1;
	t *= _disp_size-1;
	int si = s;
	int ti = t;
	s -= si; t -= ti;
	if ((s==0) && (t==0))
		return _disp_Values[si + ti*_disp_size];
//	si %= _disp_size; ti %= _disp_size;

	float zz = _disp_Values[si + ti*_disp_size];
	float oz = _disp_Values[(si+1)%_disp_size + ti*_disp_size];
	float zo = _disp_Values[si + ((ti+1)%_disp_size)*_disp_size];
	float oo = _disp_Values[(si+1)%_disp_size + ((ti+1)%_disp_size)*_disp_size];

	zz = zz*s + oz*(1-s);
	oo = zo*s + oo*(1-s);
	return zz*t + oo*(1-t);
}


//Shaders:

void Shader_Simple(VERT* a, VERT* b, VERT* c)
{
	SH_Tri(a, b, c);
}

bool SV_PN_Creases = false;
float __af(VERT* v)
{
	if (!SV_PN_Creases)
		return 1;
	return v->Attrib0;
}
#define PN_AB	(1<<0)
#define PN_BC	(1<<1)
#define PN_CA	(1<<2)
#define PN_ALL	(PN_AB | PN_BC | PN_CA)

fpnt PNNORMAL(VERT* a, VERT* b)
{
	fpnt edge = (b->Pos - a->Pos);
	fpnt avnorm = (b->Normal + a->Normal)/2;
	float tmpf = edge.Magnitude();
	edge = edge / tmpf;
	tmpf = (edge.Dot( avnorm ))*2;
	avnorm -= edge*tmpf;
	tmpf = 1.0/sqrt( avnorm.SelfDot() );
	return avnorm*tmpf;
}
fpnt PNWORK(VERT* a, VERT* b)
{
	fpnt edge = (b->Pos - a->Pos);
	fpnt tangent = edge;
	float tmpf = edge.Dot( a->Normal );
	tangent -= a->Normal * tmpf;
	return a->Pos + tangent*(1.0/3.0);
}
void AverageFloats(float* to, float* a, float* b, float* c, int num)
{
	for (int i=0; i<num; i++)
	{
		to[i] = (a[i] + b[i] + c[i])/3;
	}
}
void Weighted(float* to, float* a, float* b, float* c, fpnt* weights, int n)
{
	for (int i=0; i<n; i++)
	{
		to[i] = a[i]*weights->x + b[i]*weights->y + c[i]*weights->z;
	}
}
fpnt BezierSample(fpnt* grid, fpnt w)
{
	int i, x, y;
	fpnt buff[6];
	int n = 3;

	x=0;
	y=1;
	for (i=0; i<6; i++)
	{
		Weighted( buff[i], grid[x], grid[y], grid[y+1], &w, n );

		x++;
		if ((i==0)||(i==2))
			y += 2;
		else
			y++;
	}

	x=0;
	y=1;
	for (i=0; i<3; i++)
	{
		Weighted( buff[i], buff[x], buff[y], buff[y+1], &w, n );

		x++;
		if (i==0)
			y += 2;
		else
			y++;
	}

	Weighted(buff[0], buff[0], buff[1], buff[2], &w, n );
	return buff[0];
}

fpnt SV_LOD_Camera = FPNT(1.5, 1.5, 1.5);
float SV_LOD_Length = 0.06;
bool _Shader_LOD_IsLongLine(fpnt* a, fpnt* b)
{
	fpnt one = (*a - SV_LOD_Camera).Normalized();
	fpnt two = (*b - SV_LOD_Camera).Normalized();
	float l = (one.Cross(two)).Magnitude();
	return (l > SV_LOD_Length);
}

struct _BezierPatch
{
	fpnt *Coords;
	VERT *a, *b, *c;
};

#define PN_A	(1<<6)
#define PN_B	(1<<7)
#define PN_C	(1<<8)
#define PN_VALL	(PN_A | PN_B | PN_C)

int lod_level = 0;
void _Shader_LOD_MultiPN(_BezierPatch* patch, fpnt* w1, fpnt* w2, fpnt* w3)
{
	fpnt pa, pb, pc;
	pa = BezierSample( patch->Coords, *w1 );
	pb = BezierSample( patch->Coords, *w2 );
	pc = BezierSample( patch->Coords, *w3 );
	
	int count=0;
	int mask = 0;
	mask |= ((_Shader_LOD_IsLongLine(&pa,&pb))? PN_AB : 0);
	mask |= ((_Shader_LOD_IsLongLine(&pb,&pc))? PN_BC : 0);
	mask |= ((_Shader_LOD_IsLongLine(&pc,&pa))? PN_CA : 0);
	if (mask & PN_AB) count++;
	if (mask & PN_BC) count++;
	if (mask & PN_CA) count++;
	
	if ((mask==0))// || (lod_level > 1))
	//if (true)
	{
		VERT va, vb, vc;
		va.Interp( patch->a, patch->b, patch->c, w1 );
		va.Pos = pa;
		vb.Interp( patch->a, patch->b, patch->c, w2 );
		vb.Pos = pb;
		vc.Interp( patch->a, patch->b, patch->c, w3 );
		vc.Pos = pc;
		SH_Tri( &va, &vb, &vc );
		return;
	}
	
	fpnt mid;
	pa.Lerp( *w1, *w2, 0.5f);
	pb.Lerp( *w2, *w3, 0.5f);
	pc.Lerp( *w3, *w1, 0.5f);
	mid = (*w1 + *w2 + *w3)/3;
	lod_level++;

	if (count<3)
	{
		if (mask & PN_AB)
		{
			_Shader_LOD_MultiPN(patch, w1, &mid, &pa);
			_Shader_LOD_MultiPN(patch, &pa, &mid, w2);	
		}
		else
			_Shader_LOD_MultiPN(patch, w1, w2, &mid);
		if (mask & PN_BC)
		{
			_Shader_LOD_MultiPN(patch, w2, &mid, &pb);
			_Shader_LOD_MultiPN(patch, &pb, &mid, w3);		
		}
		else
			_Shader_LOD_MultiPN(patch, w2, w3, &mid);
		if (mask & PN_CA)
		{
			_Shader_LOD_MultiPN(patch, w3, &mid, &pc);
			_Shader_LOD_MultiPN(patch, &pc, &mid, w1);	
		}
		else
			_Shader_LOD_MultiPN(patch, w3, w1, &mid);
	}
	else
	{
		_Shader_LOD_MultiPN(patch, w1, &pa, &pc );
		_Shader_LOD_MultiPN(patch, &pa, w2, &pb );
		_Shader_LOD_MultiPN(patch, &pb, w3, &pc );
		_Shader_LOD_MultiPN(patch, &pa, &pb, &pc );
	}
		
		
	/*
	*/
	
	lod_level--;
}

bool _Shader_MultiPN_UseLOD = false;
#define TSWAP(a,b)	{t=(a);(a)=(b);(b)=t;}
void _Shader_MultiPN(VERT* a, VERT* b, VERT* c, int level,PolyShader func, int mask=PN_ALL)
{
	//Bezier control grid
	//   a-0
	//    1 2
	//   3 4 5
	//b-6 7 8 9-c
	int i;
	fpnt pos[10];
	a->Normal.Normalize();
	b->Normal.Normalize();
	c->Normal.Normalize();

	pos[0] = a->Pos;
	pos[6] = b->Pos;
	pos[9] = c->Pos;

	pos[1] = PNWORK(a,b);
	pos[3] = PNWORK(b,a);
	if ((!(mask & PN_AB)) || (SV_PN_Creases))
	{
		fpnt m; float f;
		m.Lerp(a->Pos, b->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? 1-(a->Attrib0*2 + b->Attrib0)/3 : 1 );
		pos[1].Lerp( m, pos[1], f);

		m.Lerp(b->Pos, a->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? 1-(b->Attrib0*2 + a->Attrib0)/3 : 1 );
		pos[3].Lerp( m, pos[3], f);
	}

	pos[2] = PNWORK(a,c);
	pos[5] = PNWORK(c,a);
	if ((!(mask & PN_CA)) || (SV_PN_Creases))
	{
		fpnt m; float f;
		m.Lerp(c->Pos, a->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? (c->Attrib0*2 + a->Attrib0)/3 : 1 );
		pos[2].Lerp( m, pos[2], f);

		m.Lerp(a->Pos, c->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? (a->Attrib0*2 + c->Attrib0)/3 : 1 );
		pos[5].Lerp( m, pos[5], f);
	}
	
	pos[7] = PNWORK(b,c);
	pos[8] = PNWORK(c,b);
	if ((!(mask & PN_BC)) || (SV_PN_Creases))
	{
		fpnt m; float f;
		m.Lerp(b->Pos, c->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? (b->Attrib0*2 + c->Attrib0)/3 : 1 );
		pos[7].Lerp( m, pos[7], f);

		m.Lerp(c->Pos, b->Pos, 1.0/3.0);
		f = ((SV_PN_Creases)? (c->Attrib0*2 + b->Attrib0)/3 : 1 );
		pos[8].Lerp( m, pos[8], f);
	}

	pos[4] = (pos[1] + pos[2] + pos[3] + pos[5] + pos[7] + pos[8])/6;
	pos[4] -= ((pos[0] + pos[6] + pos[9])/3 - pos[4])*2;
	
	if (_Shader_MultiPN_UseLOD)
	{
		_BezierPatch patch;
		patch.Coords = pos;
		patch.a = a; patch.b = b; patch.c = c;
		fpnt w1=FPNT(1,0,0), w2=FPNT(0,1,0), w3=FPNT(0,0,1);
		_Shader_LOD_MultiPN(&patch, &w1, &w2, &w3);
		return;
	}

	VERT *row1=new VERT[level+2], *row2=new VERT[level+1], *t;
	fpnt w;
	float inc = 1.0 / ((float)(level+1));

	for (int y=0; y<level+2; y++)
	{
		w.x = 0;
		w.y = inc*y;
		w.z = 1 - w.y - w.x;
		for (int x=0; x<((level+2)-y); x++)
		{
			row1[x].Interp( a, b, c, &w );
			row1[x].Pos = BezierSample(pos, w);

			if (y!=0)
			{
				(*func)( &row2[x], &row2[x+1], &row1[x] );
				if (x != 0)
					(*func)( &row1[x-1], &row2[x] , &row1[x]);
			}

			w.z -= inc;
			w.x += inc;
		}
		TSWAP(row1, row2);
	}

	delete [] row1;
	delete [] row2;
}
int SV_MultiPN_Level = 2;
void Shader_MultiPN(VERT* a, VERT* b, VERT* c)
{
	_Shader_MultiPN(a, b, c, SV_MultiPN_Level, SH_Tri, PN_ALL);
}

void Shader_LOD_PNTri(VERT* a, VERT* b, VERT* c)
{
	_Shader_MultiPN_UseLOD = true;
	_Shader_MultiPN(a, b, c, 1, NULL, PN_ALL);
	_Shader_MultiPN_UseLOD = false;
}

float SV_Hair_Length = 0.3;
fpnt SV_Hair_Gravity = FPNT(0, 0.8, 0);
float SV_Hair_RotationalVel = 0;
void Shader_Hair(VERT* a, VERT* b, VERT* c)
{
	VERT mid;
//	AverageFloats( (float*)&mid, (float*)a, (float*)b, (float*)c, sizeof(VERT)/sizeof(float));

	VERT hpos, ma;
	VERT* verts[3] = { a, b, c };
	for (int i=0; i<3; i++)
	{
		/*
		hpos.Interp( verts[(i+1)%3], verts[(i+2)%3], 0.5 );
		ma.Interp( &hpos, verts[i], 1/4 );
		*/
		ma = *verts[i];
		ma.Pos = (a->Pos + b->Pos + c->Pos + verts[i]->Pos*2)/5;

		fpnt advel = ma.Pos; advel.y=0; advel = advel.Cross(FPNT(0,1,0.01));
		advel.Normalize();
		ma.Normal = advel;
		advel *= SV_Hair_RotationalVel;
		advel += SV_Hair_Gravity;

		hpos = ma;
		fpnt p = (verts[i]->Normal + advel);
		p.Normalize();
		hpos.Pos += p*(-SV_Hair_Length);
		
		//SH_Tri(verts[i], &hpos, &mid);

		mid = hpos;
		p += SV_Hair_Gravity/2 + advel;
		p.Normalize(); p *= -SV_Hair_Length;
		mid.Pos += p;

		ma.Normal = verts[i]->Normal;
		SH_Tri( &mid, &hpos, &ma );
	}
}

void Shader_Crack(VERT* a, VERT* b, VERT* c)
{
	VERT ab, bc, ca;
	
	ab.Interp(a, b, 0.5);
	bc.Interp(b, c, 0.5);
	ca.Interp(c, a, 0.5);

	SH_Tri(a, &ab, &ca);
	SH_Tri(&ab, b, &bc);
	SH_Tri(&bc, c, &ca);
	SH_Tri(&ab, &bc, &ca);
}

float SV_Displace_Factor = 0.5;
void Shader_Displace(VERT* a, VERT* b, VERT* c)
{
	VERT na=*a, nb=*b, nc=*c;

	na.Pos += na.Normal * -SV_Displace_Factor * SampleDispMap(na.S, na.T);
	nb.Pos += nb.Normal * -SV_Displace_Factor * SampleDispMap(nb.S, nb.T);
	nc.Pos += nc.Normal * -SV_Displace_Factor * SampleDispMap(nc.S, nc.T);

	SH_Tri(&na, &nb, &nc);
}


void Shader_Koch(VERT* a, VERT* b, VERT* c)
{
	VERT ab, bc, ca;
	
	ab.Interp(a, b, 0.5);
	bc.Interp(b, c, 0.5);
	ca.Interp(c, a, 0.5);

	SH_Tri(a, &ab, &ca);
	SH_Tri(&ab, b, &bc);
	SH_Tri(&bc, c, &ca);
}


fpnt SV_LightPos = FPNT( -1.5, 1.2, 1.5 );
void Shader_ShadowVolume(VERT* a, VERT* b, VERT* c)
{
	VERT sa=*a, sb=*b, sc=*c;

	sa.Pos += (a->Pos - SV_LightPos).Normalized()*100;
	sb.Pos += (b->Pos - SV_LightPos).Normalized()*100;
	sc.Pos += (c->Pos - SV_LightPos).Normalized()*100;

	SH_Tri(a, c, &sa); SH_Tri(c, &sc, &sa);
	SH_Tri(c, b, &sc); SH_Tri(b, &sb, &sc);
	SH_Tri(b, a, &sb); SH_Tri(a, &sa, &sb);
}


fpnt SV_PS_Pos = FPNT( 1.5, 1.5, 1.5 );
fpnt SV_PS_Up = FPNT( 0, 1, 0 );
float SV_PS_Size = 0.2;
void Shader_PointSprite(VERT* a, VERT* b, VERT* c)
{
	fpnt x, y, n;
	int i;
	VERT np[4];

	n = (SV_PS_Pos - a->Pos);
	x = n.Cross( SV_PS_Up );
	y = n.Cross( x );
	x.Normalize(); x *= SV_PS_Size;
	y.Normalize(); y *= SV_PS_Size;
	n.Normalize(); n *= -1;
	for (i=0; i<4; i++)
	{
		np[i] = *a;
		np[i].Normal = n;
	}
	np[0].Pos += (x*-1) + (y*-1);
	np[1].Pos += (x) + (y*-1);
	np[2].Pos += (x) + (y);
	np[3].Pos += (x*-1) + (y);
	SH_Tri(&np[0], &np[3], &np[2]);
	SH_Tri(&np[2], &np[1], &np[0]);
}

fpnt SV_Cull_CameraPos = FPNT(1, 0, 0);
void Shader_FaceCull(VERT* a, VERT* b, VERT* c)
{
	fpnt n = (a->Pos - b->Pos).Cross( c->Pos - b->Pos );
	fpnt lp = SV_Cull_CameraPos - b->Pos;
	if (n.Dot(lp) < 0)
		return;

	SH_Tri(a, b, c);
}









//Display Examples:
void SetupLight(bool onlyambient);
Mesh* GMesh;

void Display_Plain()
{
	SH_ClearShaders();
	GMesh->Render();
}

void Display_JustPN1()
{
	SV_MultiPN_Level = 1;
	GMesh->Render( Shader_MultiPN );
}

void Display_JustPN2()
{
	SV_MultiPN_Level = 2;
	GMesh->Render( Shader_MultiPN );
}

void Display_JustPN3()
{
	SV_MultiPN_Level = 3;
	GMesh->Render( Shader_MultiPN );
}

void Display_MultiPN()
{
	GMesh->Render( Shader_MultiPN );
}

void Display_PointSprites()
{
	SV_PS_Pos = CameraPos;
	GMesh->Render( Shader_PointSprite );
}

float DV_Hair_Accel = 0;
float DV_Hair_Vel = 0;
float DV_Hair_Moment = 0;
void Display_Hair()
{
	GMesh->Render( Shader_Simple );

//	DV_Hair_Moment += DV_Hair_Accel - DV_Hair_Vel;
	DV_Hair_Vel += DV_Hair_Accel - DV_Hair_Vel*0.1;

	if (fabs(DV_Hair_Moment) < 0.01)
		DV_Hair_Moment = 0;
	if (fabs(DV_Hair_Vel) < 0.001)
		DV_Hair_Vel = 0;

	SV_Hair_RotationalVel = DV_Hair_Vel;
	glDisable(GL_CULL_FACE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 1);
	SH_ClearShaders();
	SH_AddShader( Shader_Crack );
	SH_AddShader( Shader_Hair );
		GMesh->Render( );
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 0);
	glEnable(GL_CULL_FACE);
}

void Display_LODPNTris()
{
	glDisable(GL_CULL_FACE);
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 1);

	SV_LOD_Camera = CameraPos;
	GMesh->Render( Shader_LOD_PNTri );
	
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, 0);
	glEnable(GL_CULL_FACE);
}

void Display_Displace()
{
	SH_ClearShaders();
	SH_AddShader( Shader_Crack );
	SH_AddShader( Shader_Crack );
	SH_AddShader( Shader_Displace );
	GMesh->Render();
}

void Display_Koch()
{
	glDisable(GL_CULL_FACE);

	SH_ClearShaders();
	SH_AddShader( Shader_Koch, 4 );

	GMesh->Render();
	glEnable(GL_CULL_FACE);
}

void Display_StencilVolume()
{
	static Mesh cubemesh;
	static Mesh mtri;
	if (cubemesh.NumVerts==0)
	{
		cubemesh.FormCube();
		cubemesh.Invert();
		cubemesh.Scale( 10 );
		cubemesh.CalcNormals(true);

		mtri.FormTri();
		//mtri.CalcNormals(false);
	}

	glColor3f(0.8, 0.6, 0.8 );
	cubemesh.Render( Shader_Simple );
	GMesh->Render( Shader_Simple );


	
	glEnable(GL_STENCIL_TEST);
		glDepthMask(0);
		glColorMask(0, 0, 0, 0);
		glStencilFunc(GL_ALWAYS, 1, ~0);
		glStencilOp(GL_KEEP, GL_KEEP, GL_INCR);
			SH_ClearShaders();
			SV_Cull_CameraPos = SV_LightPos;
			SH_AddShader( Shader_FaceCull );
			SH_AddShader( Shader_ShadowVolume );
			GMesh->Render( );

		glStencilFunc(GL_ALWAYS, 1, ~0);
		glStencilOp(GL_KEEP, GL_KEEP, GL_DECR);
			glCullFace(GL_FRONT);

			GMesh->Render( );

			glCullFace(GL_BACK);
		glDepthMask(1);
		glColorMask(1, 1, 1, 1);

		glStencilFunc(GL_NOTEQUAL, 0, ~0);
		glStencilOp(GL_KEEP, GL_KEEP, GL_KEEP);
		glClear(GL_DEPTH_BUFFER_BIT);
		SetupLight(true);
			cubemesh.Render( Shader_Simple );
			GMesh->Render( Shader_Simple );
		SetupLight(false);

	glDisable(GL_STENCIL_TEST);
}

typedef void (*DisplayFunc)();
const int GNumDisplays = 10;
DisplayFunc GDisplayFuncs[GNumDisplays] = {
	Display_Plain,
	Display_JustPN1, 
	Display_JustPN2, 
	Display_JustPN3,
	Display_StencilVolume,
	Display_Koch,
	Display_PointSprites,
	Display_LODPNTris,
	Display_MultiPN,
	Display_Hair,
};
int GCurDisplay = 0;

























Mesh meshCube;
Mesh meshOFF;
Mesh meshTri;
Mesh meshPyr;
Mesh meshComp;

#define NumMeshes 5
int GCurMesh = 0;
Mesh* GMeshes[NumMeshes] = {
	&meshCube,
	&meshOFF,
	&meshComp,
	&meshTri,
	&meshPyr,
};

void init(void)
{
	glClearColor(0.8, 0.9, 0.8, 0.0);
	glClearStencil(0);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_SMOOTH);

	glEnable(GL_CULL_FACE);

	int i;
	meshCube.FormCube();
	meshCube.CalcNormals(true);

	meshPyr.FormPyramid();
	meshPyr.CalcNormals(true);

	meshOFF.LoadFromOFF("QuakeMarine.off");
	meshOFF.Normalize();
	meshOFF.Scale( 1.4 );
	meshOFF.CalcNormals(true);

	meshComp.LoadFromTXT("compmodel.txt");
	meshComp.Invert();
	meshComp.Simplify();
	meshComp.Normalize();
	meshComp.CalcNormals(true);

	meshTri.FormTri();
//	meshTri.CalcNormals(false);

	GMesh = &meshCube;
}

void display(void)
{	
	//setup the camera
	SetupCamera();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT );


	int lastcount = _SH_CurTriCount;
	_SH_CurTriCount = 0;
	(*GDisplayFuncs[GCurDisplay%GNumDisplays])();
	if (lastcount != _SH_CurTriCount)
		printf("Triangles: %d\n", _SH_CurTriCount );
	DV_Hair_Accel = 0;

	//GMesh->Render(GPolyShader);

	//GMesh->BasicRender(true);

	/*
	glColor3f( 1, 0, 0);
	glBegin(GL_QUADS);
		glNormal3f(0, 0, 1);
		glVertex3f(-1, -1, 0);
		glVertex3f( 1, -1, 0);
		glVertex3f( 1,  1, 0);
		glVertex3f(-1,  1, 0);

		glNormal3f(1, 0, 0);
		glVertex3f(0, -1, -1);
		glVertex3f(0,  1, -1);
		glVertex3f(0,  1,  1);
		glVertex3f(0, -1,  1);
	glEnd();
	*/

	glFlush();
	glutSwapBuffers();
}

bool NarrowView = false;
void reshape(int w=-1, int h=-1)
{
	if (w!=-1)
	{
		WndSize.x = w;
		WndSize.y = h;
	}
	else
	{
		w = WndSize.x; h = WndSize.y;
	}

	float ratio = ((float)w) / ((float)h);

	glViewport(0, 0, (GLsizei) w, (GLsizei) h);

	glMatrixMode(GL_PROJECTION);

	glLoadIdentity();

	float angle = ((NarrowView)? 95 : 45 );

    gluPerspective( angle, ratio, 0.1f, 100.0f );

	SetupCamera();
}

void keyboard_spec(int key, int x, int y)
{
	switch(key)
	{
	case GLUT_KEY_LEFT:
		GCurDisplay--;
		if (GCurDisplay < 0)
			GCurDisplay = GNumDisplays-1;
		break;
	case GLUT_KEY_RIGHT:
		GCurDisplay++;
		break;
	case GLUT_KEY_UP:
		GCurMesh++;
		GCurMesh %= NumMeshes;
		GMesh = GMeshes[GCurMesh];
		break;
	case GLUT_KEY_DOWN:
		GCurMesh--;
		if (GCurMesh < 0)
			GCurMesh = NumMeshes-1;
		GMesh = GMeshes[GCurMesh];
		break;
	default:
		break;
	}
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 27:
		exit(0);
		break;
	case '1':
		break;
	case '2':
		break;
	case '3':
		break;


	case 's':
		CameraPos += CameraDir();
		break;
	case 'x':
		CameraPos -= CameraDir();
		break;
	case 'p':
		NarrowView = !NarrowView;
		reshape();
		break;
	case 'c':
		SV_PN_Creases = !SV_PN_Creases;
		break;

	case '[':
		CameraDist += 0.25;
		break;
	case ']':
		CameraDist -= 0.25;
		break;

	case 'o':
		SV_MultiPN_Level++;
		break;
	case 'i':
		SV_MultiPN_Level--;
		break;
	case 'd':
		Debugging = !Debugging;
		break;

	case 'f':
		SH_FlatNormals = !SH_FlatNormals;
		break;
	case 'w':
		SH_Wireframe = !SH_Wireframe;
		break;
	case ' ':
		GCurDisplay++;
		break;

	default:
		break;
	}
	glutPostRedisplay();
}

bool IsZooming = false;
void onMouseClick(int button, int state, int x, int y)
{
	if (state == GLUT_UP)
	{
	}

	if (state == GLUT_DOWN)
	{
		IsZooming = (button == GLUT_RIGHT_BUTTON);
	}

	LastMousePos = FPNT(x, y, 0);
}

void onMouseDrag(int x, int y)
{
	fpnt curpos = FPNT(x, y, 0);
	fpnt d = curpos - LastMousePos;

	if (!IsZooming)
	{
		CameraAng += d.x / 200;
		CameraPitch += d.y / 200;
	}
	else
		CameraDist += d.y / 100;
	DV_Hair_Accel = d.x / 100;

	LastMousePos = FPNT(x, y, 0);
	glutPostRedisplay();
}

void onIdle()
{
	if ((DV_Hair_Moment==0) && (DV_Hair_Vel==0))
		return;

	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	printf("Started...\n");
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB | GLUT_STENCIL );
	glutInitWindowSize (500, 500);
	glutInitWindowPosition (100, 100);
	glutCreateWindow ("7671 / Lewey Geselowitz");


	printf("Initing...\n");
	init ();
	glutIdleFunc( onIdle );
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc (keyboard);
	glutSpecialUpFunc (keyboard_spec);
	glutMouseFunc( onMouseClick );
	glutMotionFunc( onMouseDrag );
	glutMainLoop();
	return 0;
}


