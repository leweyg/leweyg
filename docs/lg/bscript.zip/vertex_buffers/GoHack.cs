using System;
using System.Collections;

namespace GoHack
{
	class Cell
	{
		public int State;
		public object View;
		public int PosX, PosY;
		public Board Board;
		public bool _Used;

		public Cell(Board b) {Board=b; State=0; View=null;}
	};

	class Board
	{
		public static int Empty {get{return 0;}}
		public static int Blue {get{return 1;}}
		public static int Red {get{return 2;}}
		public static int FixedOpen {get{return 3;}}
		public static int FixedClosed {get{return 4;}}
		public static int OtherTurn(int t)
		{
			if (t==Red) return Blue;
			if (t==Blue) return Red;
			return t;
		}

		private int width, height;
		private Cell[] state;
		private int turn;
		public object View;

		public void ClearUsed()
		{
			for (int i=0; i<state.Length; i++)
				state[i]._Used = false;
		}

		public class SearchResult
		{
			public ArrayList List;
			public int Liberties;

			public SearchResult()
			{
				List = new ArrayList();
				Liberties = 0;
			}
		}

		public SearchResult Search(int x, int y)
		{
			SearchResult res = new SearchResult();
			if (!IsValid(x,y))
				return res;
			ClearUsed();
			int side = Get(x,y).State;
			//TODO
			return res;
		}

		public bool IsValid(int x, int y)
		{
			if ((x < 0) || (x >= Width))
				return false;
			if ((y < 0) || (y >= Height))
				return false;
			return true;
		}
		public int Turn {get{return turn;}set{turn=value;}}
		public int Width {get{return width;}}
		public int Height {get{return height;}}

		public Cell Get(int w, int h)
		{
			int i = w + h*width;
			return state[i];
		}

		public Board(double w, double h)
		{
			width = (int)w; height = (int)h;
			state = new Cell[width * height];
			turn = 1;
			for (int i=0; i<width*height; i++)
			{
				state[i] = new Cell(this);
				state[i].PosX = (i%width);
				state[i].PosY = (i/width);
			}
		}
	}
}
