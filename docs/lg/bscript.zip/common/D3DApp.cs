//
// D3DApp.cs - Drunken Hyena Direct3D Base App
//
// Copyright (c) 2004 Drunken Hyena
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the Drunken Hyena License.  If a copy of the license was
// not included with this software, you may get a copy from:
// http://www.drunkenhyena.com/docs/DHLicense.txt

using System;
using System.Threading; //Needed for Sleep
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;

namespace DrunkenHyena
{
	/// <summary>
	/// Our base D3D application.
	/// </summary>
   public class D3DApp : System.Windows.Forms.Form {

      private bool m_fullscreen=false;
      private Size m_app_size=new Size(800,600);

      protected string m_name="D3DApp";
      protected D3D.Device m_device = null;
      protected D3D.PresentParameters m_present_parameters = new D3D.PresentParameters();

      public new Size ClientSize{
         get{
            return m_app_size;
         }
         set{
            base.ClientSize=value;
            m_app_size=value;
         }
      }

      /// <summary>
      /// GoFullscreen - Modifies the window to be in full-screen mode.  If the window is
      /// already visible, it hides it, makes all changes and the shows it again.
      /// </summary>
      protected virtual void GoFullscreen(){
         System.Drawing.Rectangle rect;
         bool was_visible;

         //We're full-screen now
         m_fullscreen=true;

         //Check if we're already visible
         was_visible=this.Visible;

         //Hide the window, make all changes, then show it.  Just for smoother presentation
         if (was_visible) {
            Hide();
         }

         //Get the rectangle describing the primary display
         rect=System.Windows.Forms.Screen.PrimaryScreen.Bounds;

         //Set our window to cover the entire display
         base.ClientSize = rect.Size;

         //Set window to be borderless
         FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

         //Hide the cursor
         //Cursor.Hide();

         //Center the window
         CenterToScreen();

         //Appear above all other windows
         TopMost=true;

         //If the window was visible, show the window again
         if (was_visible) {
            Show();
         }

         init_present_params();
         
         //We don't want to call this the first time through since the device
         //isn't set up yet.
         if (m_device != null){
            m_device.Reset(m_present_parameters);
         }

      }

      /// <summary>
      /// GoWindowed - Modifies the window to be in windowed mode.  If the window is
      /// already visible, it hides it, makes all changes and the shows it again.
      /// </summary>
      protected virtual void GoWindowed(){
         bool was_visible;

         m_fullscreen=false;

         //Check if we're already visible
         was_visible=this.Visible;

         //Hide the window, make all changes, then show it.  Just for smoother presentation
         if (was_visible){
            Hide();
         }

         //Window Size
         ClientSize = m_app_size;

         //We don't want to always be the front-most window in Windowed mode
         TopMost=false;

         //Nice 3D border, but no sizing
         FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;

         //Remove the Maximize and Minimize buttons
         MaximizeBox=false;
         MinimizeBox=true;

         //Make sure Cursor is visible
         Cursor.Show();


         //If we were visible, center the window and show it again
         if (was_visible) {

            Show();

         }

         //Place the window in the center of the screen
         CenterToScreen();        

         init_present_params();
         
         //We don't want to call this the first time through since the device
         //isn't set up yet.
         if (m_device != null){
            m_device.Reset(m_present_parameters);
         }

      }

      public D3DApp(string p_name,Size p_size,bool p_fullscreen){

         m_name=p_name;

         m_fullscreen=p_fullscreen;

         //This makes the window auto-scale based on font size.  Since we aren't adding
         //controls we probably don't need to turn it off, but it doesn't hurt.
         AutoScale = false;

         //Background colour
         BackColor=System.Drawing.Color.Black;

         //Center this window
         StartPosition = FormStartPosition.CenterScreen;

         //Set window title
         this.Text=m_name;

         if (m_fullscreen){
            GoFullscreen();
         }else{
            GoWindowed();
         }



         init_present_params();

         //Create our device
         m_device = new D3D.Device(0,                    //Adapter
            D3D.DeviceType.Hardware,  //Device Type
            this,                     //Render Window
            D3D.CreateFlags.SoftwareVertexProcessing, //behaviour flags
            m_present_parameters);    //PresentParamters

         //Turn off MDX automatic resize handling
         m_device.DeviceResizing += new System.ComponentModel.CancelEventHandler(this.CancelResize);

         //Register our event handlers for Lost Devices
         m_device.DeviceLost +=new EventHandler(OnDeviceLost);
         m_device.DeviceReset +=new EventHandler(OnDeviceReset);

      }
      /// <summary>
      /// CancelResize - This is an event handler used to turn off the automatic
      /// Resize handling that Managed D3D does behind the scenes
      /// </summary>
      /// <param name="sender">not used</param>
      /// <param name="e">not used</param>
      protected void CancelResize(object sender, System.ComponentModel.CancelEventArgs e) {
         e.Cancel=true;
         Trace.WriteLine("CancelResize");
      }

      /// <summary>
      /// OnDeviceLost - The device has been lost.  Some resources will need
      ///   to be freed to allow the device to be Reset.
      /// </summary>
      /// <param name="sender">not used</param>
      /// <param name="e">not used</param>
      protected void OnDeviceLost(object sender, EventArgs e){

         //Nothing to free in this tutorial
         Trace.WriteLine("OnDeviceLost");
      }
      
      /// <summary>
      /// OnDeviceReset - The device has been successfully Reset.
      ///   Settings lost by the Reset should be set here and any resources
      ///   that were freed in OnDeviceLost should be reallocated.
      /// </summary>
      /// <param name="sender">not used</param>
      /// <param name="e">not used</param>
      protected void OnDeviceReset(object sender, EventArgs e){

         //Nothing to setup or reallocate in this tutorial
         Trace.WriteLine("OnDeviceReset");

      }

      /// <summary>
      /// init_present_params - Initializes our PresentParamters class
      /// </summary>
      protected void init_present_params(){

         //No Z (Depth) buffer or Stencil buffer
         //m_present_parameters.EnableAutoDepthStencil=true;
		  m_present_parameters.EnableAutoDepthStencil = true;
    	  m_present_parameters.AutoDepthStencilFormat = D3D.DepthFormat.D16;

         //1 Back buffer for double-buffering
         m_present_parameters.BackBufferCount=1;

         //Set our Window as the Device Window
         m_present_parameters.DeviceWindow=this;

         //Do not wait for VSync
         m_present_parameters.PresentationInterval=D3D.PresentInterval.Immediate;

         //Discard old frames for better performance
         m_present_parameters.SwapEffect=D3D.SwapEffect.Discard;

         //Set Windowed vs. Full-screen
         m_present_parameters.Windowed=!m_fullscreen;

         //We only need to set the Width/Height in full-screen mode
         if(m_fullscreen) {
            m_present_parameters.BackBufferHeight=m_app_size.Height;
            m_present_parameters.BackBufferWidth=m_app_size.Width;

            //Choose a compatible 16-bit mode.
            m_present_parameters.BackBufferFormat=Utility.Find16BitMode();
         }else{
            m_present_parameters.BackBufferHeight=0;
            m_present_parameters.BackBufferWidth=0;
            m_present_parameters.BackBufferFormat=D3D.Format.Unknown;
         }

      }

      protected void Heartbeat(){
         int result;

         if (m_device.CheckCooperativeLevel(out result)){  //Okay to render

            try{
               Render();
            }catch(D3D.DeviceLostException){
               m_device.CheckCooperativeLevel(out result);
            }catch(D3D.DeviceNotResetException){
               m_device.CheckCooperativeLevel(out result);
            }

         }
         if (result == (int)D3D.ResultCode.DeviceLost){
            Thread.Sleep(500);    //Can't Reset yet, wait for a bit
         }else if (result == (int)D3D.ResultCode.DeviceNotReset){
            m_device.Reset(m_present_parameters);
         }


      }
      protected virtual void Render(){
         Color colour=Color.CadetBlue;

         m_device.Clear(D3D.ClearFlags.Target,colour,1.0f,0);


         m_device.BeginScene();

         //Spiffy rendering goes here

         m_device.EndScene();

         m_device.Present();

      }

      /// <summary>
      /// Exit when user hits Escape, F/W - Swap between full-screen and windowed mode
      /// </summary>
      /// <param name="e">Used to test KeyCode</param>
      protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e){

         switch(e.KeyCode) {
            case Keys.F:
               GoFullscreen();
               break;
            case Keys.W:
               GoWindowed();
               break;
            case Keys.Escape:
               this.Close();
               break;
            default:
               base.OnKeyDown(e);
               break;
         }

      }
   }

   }
