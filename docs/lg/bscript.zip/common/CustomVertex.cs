using System;
using DX = Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;

namespace DrunkenHyena
{
	/// <summary>
	/// Summary description for CustomVertex.
	/// </summary>
	namespace CustomVertex
	{

      public struct TransformedColored{
         public float X;
         public float Y;
         public float Z;
         public float Rhw;
         public UInt32 Colour;
         public static readonly D3D.VertexFormats Format = D3D.VertexFormats.Transformed | D3D.VertexFormats.Diffuse;
         public static readonly int StrideSize=DX.DXHelp.GetTypeSize(typeof(TransformedColored));


         public TransformedColored(float p_x,float p_y,float p_z,float p_rhw,uint p_colour){

            X=p_x;
            Y=p_y;
            Z=p_z;
            Rhw=p_rhw;

            Colour=p_colour;
         }

         public TransformedColored(Microsoft.DirectX.Vector4 p_position,uint p_colour){

            X=p_position.X;
            Y=p_position.Y;
            Z=p_position.Z;
            Rhw=p_position.W;

            Colour=p_colour;
         }

         public TransformedColored(float p_x,float p_y,float p_z,float p_rhw,System.Drawing.Color p_colour){

            X=p_x;
            Y=p_y;
            Z=p_z;
            Rhw=p_rhw;

            Colour=unchecked((uint)p_colour.ToArgb());
         }

         public TransformedColored(Microsoft.DirectX.Vector4 p_position,System.Drawing.Color p_colour){

            X=p_position.X;
            Y=p_position.Y;
            Z=p_position.Z;
            Rhw=p_position.W;

            Colour=unchecked((uint)p_colour.ToArgb());
         }


         public Microsoft.DirectX.Vector4 GetPosition(){

            return new Microsoft.DirectX.Vector4(X,Y,Z,Rhw);

         }

         public void SetPosition(Microsoft.DirectX.Vector4 p_position){

            X=p_position.X;
            Y=p_position.Y;
            Z=p_position.Z;
            Rhw=p_position.W;

         }

         public uint Color {
            get {
               return Colour;
            }
            set {
               Colour=value;
            }
         }

      };


	}
}
