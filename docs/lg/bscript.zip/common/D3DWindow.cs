//
// D3DWindow.cs - Drunken Hyena Direct3D Window
//
// Copyright (c) 2004 Drunken Hyena
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the Drunken Hyena License.  If a copy of the license was
// not included with this software, you may get a copy from:
// http://www.drunkenhyena.com/docs/DHLicense.txt

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace DrunkenHyena{

	/// <summary>
	/// D3DWindow - A nice little window we can use in the lessons that follow.
	/// </summary>
	public class D3DWindow :System.Windows.Forms.Form{

   private bool m_fullscreen=false;
   private Size m_win_size=new Size(640,480);

      public new Size ClientSize{
         get{
            return m_win_size;
         }
         set{
            base.ClientSize=value;
            m_win_size=value;
         }
      }

      public bool FullScreen{
         get{
            return m_fullscreen;
         }

         set{
            //If already in that mode, do nothing
            if (m_fullscreen == value) {
               return;
            }

            if (value) {
               GoFullscreen();
            }else{
               GoWindowed();
            }

         }

      }
      /// <summary>
      /// GoFullscreen - Modifies the window to be in full-screen mode.  If the window is
      /// already visible, it hides it, makes all changes and the shows it again.
      /// </summary>
      protected virtual void GoFullscreen(){
      System.Drawing.Rectangle rect;
      bool was_visible;

         //We're full-screen now
         m_fullscreen=true;

         //Check if we're already visible
         was_visible=this.Visible;

         //Hide the window, make all changes, then show it.  Just for smoother presentation
         if (was_visible) {
            Hide();
         }

         //Get the rectangle describing the primary display
         rect=System.Windows.Forms.Screen.PrimaryScreen.Bounds;

         //Set our window to cover the entire display
         base.ClientSize = rect.Size;

         //Set window to be borderless
         FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

         //Hide the cursor
         Cursor.Hide();

         //Center the window
         CenterToScreen();

         //Appear above all other windows
         TopMost=true;

         //If the window was visible, show the window again
         if (was_visible) {
            Show();
         }      
      }

      /// <summary>
      /// GoWindowed - Modifies the window to be in windowed mode.  If the window is
      /// already visible, it hides it, makes all changes and the shows it again.
      /// </summary>
      protected virtual void GoWindowed(){
      bool was_visible;

         m_fullscreen=false;

         //Check if we're already visible
         was_visible=this.Visible;

         //Hide the window, make all changes, then show it.  Just for smoother presentation
         if (was_visible){
            Hide();
         }

         //Window Size
         ClientSize = m_win_size;

         //We don't want to always be the front-most window in Windowed mode
         TopMost=false;

         //Nice 3D border, but no sizing
         FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;

         //Remove the Maximize and Minimize buttons
         MaximizeBox=false;
         MinimizeBox=false;

         //Make sure Cursor is visible
         Cursor.Show();


         //If we were visible, center the window and show it again
         if (was_visible) {

            Show();

         }

         //Place the window in the center of the screen
         CenterToScreen();        

      }

      /// <summary>
      /// Exit when user hits Escape, F/W - Swap between full-screen and windowed mode
      /// </summary>
      /// <param name="e">Used to test KeyCode</param>
      protected override void OnKeyDown(System.Windows.Forms.KeyEventArgs e){

         switch(e.KeyCode) {
            case Keys.F:
               FullScreen=true;
               break;
            case Keys.W:
               FullScreen=false;
               break;
            case Keys.Escape:
               this.Close();
               break;
            default:
               base.OnKeyDown(e);
               break;
         }

      }

      /// <summary>
      /// OnClick - We close down on a mouse click
      /// </summary>
      /// <param name="e">Not used</param>
      protected override void OnClick(System.EventArgs e){

         this.Close();

      }


      public D3DWindow() {

         //This makes the window auto-scale based on font size.  Since we aren't adding
         //controls we probably don't need to turn it off, but it doesn't hurt.
         AutoScale = false;

         //Background colour
         BackColor=System.Drawing.Color.Black;

         //Center this window
         StartPosition = FormStartPosition.CenterScreen;         

         //Use Windowed as default
         GoWindowed();

      }
	}
}
