Evil Dice PE for Windows

This is a port of Evil Dice PE (Pocket Edition) to Windows using the SDL libary. Simply run it and use the arrow keys to control the little character. The low resolution is because this game is really meant for the Pocket PC. Oh and hit the N key to get a new game. I hope you enjoy it.

For more info and guide and such, check out:
http://plaza.ufl.edu/lewey/pocketpc/evildicepe.html

This is donateware, so it's totally free and is the full version. And if you like it, donations would be appreciated.
  -Lewey