//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CrystalMath.rc
//
#define IDC_MYICON                      2
#define IDI_ICON1                       101
#define IDD_About                       103
#define IDD_MainDlg                     104
#define IDD_Errors                      105
#define IDR_MENU1                       106
#define IDD_Hexer                       107
#define IDD_Console                     108
#define IDC_Errors_List                 1001
#define IDC_Calc_equals                 1002
#define IDC_ListBanner                  1003
#define IDC_Hex_FromBin                 1005
#define IDC_Hex_Bin                     1006
#define IDC_Hex_FromDec                 1007
#define IDC_Hex_Dec                     1008
#define IDC_Console_Text                1008
#define IDC_Hex_FromHex                 1009
#define IDC_Console_Input               1009
#define IDC_Hex_Let                     1010
#define IDC_Console_Copy                1010
#define IDC_Hex_FromLet                 1011
#define IDC_Console_Degrees             1011
#define IDC_Hex_Hex                     1012
#define IDC_Console_Clear               1012
#define IDC_Calc_Func                   1069
#define IDC_Calc_Done                   1071
#define IDC_Calc_Answer                 1072
#define IDC_Calc_Copy                   1073
#define IDC_Calc_History                1076
#define IDC_Calc_ClearHistory           1077
#define IDC_Calc_Clear                  1079
#define IDC_Calc_sin                    1082
#define IDC_Calc_cos                    1083
#define IDC_Calc_tan                    1084
#define IDC_Calc_ln                     1085
#define IDC_Calc_seven                  1086
#define IDC_Calc_four                   1088
#define IDC_Calc_one                    1089
#define IDC_Calc_eight                  1090
#define IDC_Calc_five                   1091
#define IDC_Calc_two                    1092
#define IDC_Calc_nine                   1093
#define IDC_Calc_six                    1095
#define IDC_Calc_three                  1096
#define IDC_Calc_open                   1097
#define IDC_Calc_zero                   1098
#define IDC_Calc_close                  1099
#define IDC_Calc_plus                   1102
#define IDC_Calc_minus                  1103
#define IDC_Calc_times                  1104
#define IDC_Calc_divide                 1106
#define IDC_Calc_e                      1107
#define IDC_Calc_pi                     1108
#define IDC_Calc_power                  1109
#define IDC_Calc_ans                    1110
#define IDC_Calc_Help                   1111
#define IDC_Calc_go                     1112
#define IDC_Calc_Degrees                1113
#define IDC_Calc_sqrt                   1114
#define IDC_Calc_period                 1115
#define IDC_Calc_Back                   1116
#define IDC_Calc_comma                  1116
#define IDM_Calc_Exit                   32780
#define IDM_Calc_CallHelp               32781
#define IDM_Calc_Evaluate               32782
#define IDM_Calc_Copy                   32783
#define IDM_Calc_ClearHistory           32784
#define IDM_Calc_ClearFunc              32786
#define IDM_Calc_Degrees                32797
#define IDM_Calc_SetDigits              32798
#define IDM_Calc_CallHex                32801
#define IDM_Exit                        40001
#define IDM_ShowASM                     40002
#define IDM_ToggleDegrees               40003
#define IDM_CallAbout                   40004
#define IDM_CallHexer                   40005
#define IDM_Calc_Help                   40006
#define IDM_CallConsole                 40007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40008
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
