//using namespace std;

//DArray (Double linked Array) is different version of the Array 
//	class from Array2.cpp (is was edited and rewritten from TArray)
//
//Most of the features work the same, just the names are now DAMem
//	and DArray. And the DAMem struct contains a Prev pointer to the
//  cell previous to this one.

#ifndef HasDArray
#define HasDArray

template <class X> struct DAMem
{
	DAMem<X> * Next, * Prev;

	X Val;
	DAMem<X>() {Next=0; Prev=0;};
};

template <class X> class DArray
{
public:
	DAMem<X> * Base, * Last;

	void DelAll();

	DAMem<X> * AddCell();
	DAMem<X> * AddCell(DAMem<X> * before);
	DAMem<X> * AddCellBefore(DAMem<X> * after);
	X * AddMember() {return &(AddCell()->Val);};
	X * AddMember(DAMem<X> * before) {return &(AddCell(before)->Val);};
	DAMem<X> * AxsCell(int num);
	X * Axs(int num);
	X & operator [] (int num) {return (*Axs(num));};
	void DelCell(DAMem<X> * work);
	void DelMember(int num) {DelCell(AxsCell(num));};
	void Switch(DAMem<X> * one, DAMem<X> * two);
	int GetLength();
	void RemoveCell(DAMem<X> * one);
	void InsertCell(DAMem<X> * cell, DAMem<X> * before);
	void MoveCell(DAMem<X> * one, DAMem<X> * before) {RemoveCell(one); InsertCell(one,before);};
	DAMem<X> * FindCell(X * adrs);
	void TakeAll(DArray<X> * other);

	DAMem<X> * AddTop() {return AddCell();};
	DAMem<X> * AddBottom();
	void DelTop();
	void DelBottom();

	DArray() {Base=0; Last=0;};
	~DArray();
};

template <class X> DAMem<X> * DArray<X>::AddCellBefore(DAMem<X> * after)
{
	if (!after)
		return AddTop();
	DAMem<X>*work=new DAMem<X>;
	work->Next=after;
	work->Prev=after->Prev;
	if (after->Prev)
		after->Prev->Next=work;
	else
		Base=work;
	after->Prev=work;
	return work;
}

template <class X> DArray<X>::~DArray<X>()
{
	DelAll();
	Base=0;
	Last=0;
}

template <class X> void DArray<X>::TakeAll(DArray<X> * other)
{
	if (!Base)
	{
		Base=other->Base;
		Last=other->Last;
		other->Base=0;
		other->Last=0;
		return;
	}
	Last->Next=other->Base;
	if (other->Base)
		other->Base->Prev=Last;
	Last=other->Last;
	other->Last=0;
	other->Base=0;
}

template <class X> DAMem<X> * DArray<X>::FindCell(X * adrs)
{
	//NOTE: the arguement must the exact same member as in the list,
	//	not just of the same type, but the same address, which is what
	//	it works with.
	DAMem<X> * work=Base;
	while (work)
	{
		if (&(work->Val) == adrs)
			return work;
		work=work->Next;
	}
	return 0;
}

template <class X> DAMem<X> * DArray<X>::AddCell(DAMem<X> * before)
{
	if (!before)
		return AddCell();
	DAMem<X> * work=new DAMem<X>;
	work->Next=before->Next;
	work->Prev=before;
	before->Next=work;
	if (work->Next)
		work->Next->Prev=work;
	else
		Last=work;
	return work;
}

template <class X> void DArray<X>::InsertCell(DAMem<X> * cell, DAMem<X> * before)
{
	//give cell, then cell infront (or 0 for the new cell at the end
	//	of the list)
	if (!Base)
	{
		cell->Prev=0;
		cell->Next=0;
		Base=cell;
		Last=cell;
		return;
	}
	if (!before)
	{
		Last->Next=cell;
		cell->Prev=Last;
		cell->Next=0;
		Last=cell;
		return;
	}
	if (before->Prev)
		before->Prev->Next=cell;
	else
		Base=cell;
	cell->Prev=before->Prev;
	cell->Next=before;
	before->Prev=cell;
}

template <class X> void DArray<X>::RemoveCell(DAMem<X> * work)
{
	//removes from list, but doesn't delete
	if (!work)
		return;
	if (Last==Base)
	{
		Base=0;
		Last=0;
		return;
	}
	if (work==Base)
		Base=work->Next;
	if (work==Last)
		Last=work->Prev;
	if (work->Next)
		work->Next->Prev=work->Prev;
	if (work->Prev)
		work->Prev->Next=work->Next;
}

template <class X> void DArray<X>::Switch(DAMem<X> * one, DAMem<X> * two)
{
	//Switchs the two (must be in this list)
	if (((!one) || (!two)) || (one==two))
		return;
	DAMem<X> * work;

	work=one->Next;
	one->Next=two->Next;
	two->Next=work;
	if (two->Next)
		two->Next->Prev=two;
	else
		Last=two;
	if (one->Next)
		one->Next->Prev=one;
	else
		Last=one;

	work=one->Prev;
	one->Prev=two->Prev;
	two->Prev=work;
	if (two->Prev)
		two->Prev->Next=two;
	else
		Base=two;
	if (one->Prev)
		one->Prev->Next=one;
	else
		Base=one;

}

template <class X> void DArray<X>::DelBottom()
{
	//deletes bottom cell
	if (!Base)
		return;
	DAMem<X> * work=Base;
	if (work->Next)
	{
		Base=work->Next;
		Base->Prev=0;
	}
	else
	{
		Base=0;
		Last=0;
	}
	delete work;
}

template <class X> void DArray<X>::DelTop()
{
	//deletes top
	if (!Last)
		return;
	DAMem<X> * work=Last;
	if (work->Prev)
	{
		Last=work->Prev;
		Last->Next=0;
	}
	else
	{
		Last=0;
		Base=0;
	}
	delete work;
}

template <class X> DAMem<X> * DArray<X>::AddBottom()
{
	//adds new one at bottom of list

	DAMem<X> * work=new DAMem<X>;
	if (!Base)
	{
		Base=work; Last=work;
		work->Next=0;
		work->Prev=0;
		return work;
	}
	work->Next=Base;
	work->Prev=0;
	Base->Prev=work;
	Base=work;
	return work;
}

template <class X> int DArray<X>::GetLength()
{
	//returns the number of members in list
	DAMem<X> * work=Base;
	int len=0;
	while (work)
	{
		work=work->Next;
		len++;
	}
	return len;
}

template <class X> void DArray<X>::DelCell(DAMem<X> * work)
{
	//deletes a cell
	if (!work)
		return;
	if (work==Base)
		Base=work->Next;
	if (work==Last)
		Last=work->Prev;
	if (work->Next)
		work->Next->Prev=work->Prev;
	if (work->Prev)
		work->Prev->Next=work->Next;
	delete work;
}

template <class X> DAMem<X> * DArray<X>::AxsCell(int num)
{
	//gets a cell from the list
	DAMem<X> * work=Base;
	while ((num>0) && (work))
	{
		work=work->Next;
		num--;
	}
	return work;
}

template <class X> X * DArray<X>::Axs(int num)
{
	//gets a member from the list
	if (num < 0)
		return 0;
	DAMem<X> * work=Base;
	while ((num>0) && (work))
	{
		work=work->Next;
		num--;
	}
	if (work)
		return &work->Val;
	return 0;
}

template <class X> DAMem<X> * DArray<X>::AddCell()
{
	//adds a cell to the top of the list
	DAMem<X> * work;
	work=new DAMem<X>;
	if (!Base)
	{
		Base=work; Last=work;
		work->Next=0;
		work->Prev=0;
		return work;
	}
	Last->Next=work;
	work->Next=0;
	work->Prev=Last;
	Last=work;
	return work;
}

template <class X> void DArray<X>::DelAll()
{
	//deletes all cells
	if (!Base)
		return;
	DAMem<X> * next=Base, * work;
	while (next)
	{
		work=next;
		next=next->Next;
		delete work;
	}
	Base=0; Last=0;
}

template <class X> DAMem<X> * GetCell(DArray<X> * list, X * like)
{
	DAMem<X> * work=list->Base;
	while (work)
	{
		if (work->Val == like)
			return work;
		work=work->Next;
	}
	return 0;
}


#endif