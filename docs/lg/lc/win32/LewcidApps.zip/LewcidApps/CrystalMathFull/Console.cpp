
//A series of characters and functions to handel them, only looks correct under Windows
//	console programs

//Border and Texture Values
//This file contains functions and definitions for character values
//	which represent lines and such.
//The definitions work like such:
//	Sl_: is a single line
//	Dl_: is a double line
//	Tx_: is a texture
//	Follow the type with the first initials of all the places they point.
//	For example a single line pointing south and west would be Sl_sw.
//	Make sure you have the directions in the correct order (n,s,e,w)
//	The Tx_ type is followed with a number from 0 to 4 (0 is blank, 4 is full on)
//
//These can also be called using functions
//	Sl(), Dl(), Tx() - the arguements for Sl and Dl are just the bools
//		for whether the line goes in that direction for not.
//	For example, a double line to north, south and west would be:
//		Dl(1,1,0,1)
//	The Tx() function takes just one int, with a value from 0 to 4
//		0 is lowest, 4 is highest
//
//The declarations Bl_ make a block facing that direction,
//	For example a block facing n would be Bl_n.
//	And the total block (also Tx(4)) is Bl_nsew
//
//Also in this file is the OgreLogo(int) function which displays "Ogre I"
//	with the given number of spaces before it, using single lines
//	With it is the Rept funciton which repeates the given character
//		the given number of times

#define Sl(a,b,c,d) SingleLine(a,b,c,d)
#define Dl(a,b,c,d) DoubleLine(a,b,c,d)
#define Tx(x) Texture(x)

#define Dl_ns (unsigned char)186
#define Dl_ew (unsigned char)205
#define Dl_sw (unsigned char)187
#define Dl_ne (unsigned char)200
#define Dl_se (unsigned char)201
#define Dl_nw (unsigned char)188
#define Dl_nsw (unsigned char)185
#define Dl_new (unsigned char)202
#define Dl_sew (unsigned char)203
#define Dl_nse (unsigned char)204
#define Dl_nsew (unsigned char)206

#define Sl_ew (unsigned char)196
#define Sl_ns (unsigned char)179
#define Sl_sw (unsigned char)191
#define Sl_ne (unsigned char)192
#define Sl_nw (unsigned char)217
#define Sl_se (unsigned char)218
#define Sl_nsw (unsigned char)180
#define Sl_new (unsigned char)193
#define Sl_sew (unsigned char)194
#define Sl_nse (unsigned char)195
#define Sl_nsew (unsigned char)197

#define Bl_nsew (unsigned char)219
#define Bl_s (unsigned char)220
#define Bl_w (unsigned char)221
#define Bl_e (unsigned char)222
#define Bl_n (unsigned char)223

#define Tx_0 (' ')
#define Tx_1 (unsigned char)176
#define Tx_2 (unsigned char)177
#define Tx_3 (unsigned char)178
#define Tx_4 (unsigned char)219

unsigned char Texture(int num)
{
	//pass in number from 0 to 4
	if (num==4)
		return Bl_nsew;
	if (num==0)
		return ' ';
	return (((unsigned char)num) + 175);
}

unsigned char SingleLine(bool n, bool s, bool e, bool w)
{
	if ((n && s) && (!w && !e))
		return 179;
	if ((n && s && w) && (!e))
		return 180;
	if ((s && w) && (!n && !e))
		return 191;
	if ((n && e) && (!s && !w))
		return 192;
	if ((n && e && w) && (!s))
		return 193;
	if ((s && e && w) && (!n))
		return 194;
	if ((n && e && s) && (!w))
		return 195;
	if ((w && e) && (!s && !n))
		return 196;
	if (n && s && w && e)
		return 197;
	if ((n && w) && (!s && !e))
		return 217;
	if ((s && e) && (!n && !w))
		return 218;

	if ((n) && (!s && !w && !e))
		return Sl_ns;
	if ((s) && (!n && !w && !e))
		return Sl_ns;
	if ((e) && (!s && !n && !e))
		return Sl_ew;
	if ((w) && (!s && !w && !n))
		return Sl_ew;

	return ' ';
}

unsigned char DirectionalLine(int dx, int dy)
{
	dx*=3;
	switch (dx + dy)
	{
	case -4:
		return '\\';
//	case -3:
//		return Sl_ew;
	case -3:
		return '-';
	case -2:
		return '/';
//	case -1:
//		return Sl_ns;
	case -1:
		return '|';
	case 0:
		return Sl_nsew;
//	case 1:
//		return Sl_ns;
	case 1:
		return '|';
	case 2:
		return '/';
//	case 3:
//		return Sl_ew;
	case 3:
		return '-';
	case 4:
		return '\\';
	}
	return Sl_nsew;
}

unsigned char WinDirectionalLine(int dx, int dy)
{
	dx*=3;
	switch (dx + dy)
	{
	case -4:
		return '\\';
	case -3:
		return Sl_ew;
//	case -3:
//		return '-';
	case -2:
		return '/';
	case -1:
		return Sl_ns;
//	case -1:
//		return '|';
	case 0:
		return Sl_nsew;
	case 1:
		return Sl_ns;
//	case 1:
//		return '|';
	case 2:
		return '/';
	case 3:
		return Sl_ew;
//	case 3:
//		return '-';
	case 4:
		return '\\';
	}
	return Sl_nsew;
}

unsigned char DoubleLine(bool n, bool s, bool e, bool w)
{
	if ((n && s && w) && (!e))
		return 185;
	if ((n && s) && (!e && !w))
		return 186;
	if ((s && w) && (!e && !n))
		return 187;
	if ((n && w) && (!e && !s))
		return 188;
	if ((n && e) && (!w && !s))
		return 200;
	if ((s && e) && (!w && !n))
		return 201;
	if ((n && e && w) && (!s))
		return 202;
	if ((s && e && w) && (!n))
		return 203;
	if ((n && s && e) && (!w))
		return 204;
	if ((w && e) && (!n && !s))
		return 205;
	if (n && s && w && e)
		return 206;
	
	if ((n) && (!s && !e && !w))
		return Dl_ns;
	if ((s) && (!n && !e && !w))
		return Dl_ns;
	if ((e) && (!s && !n && !w))
		return Dl_ew;
	if ((w) && (!s && !e && !n))
		return Dl_ew;

	return ' ';
}

