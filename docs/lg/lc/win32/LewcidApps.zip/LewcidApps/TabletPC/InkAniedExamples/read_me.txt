
Ink AniEd - An Ink based Animation Editor
  Written and Developed by Lewey Geselowitz

To use Ink AniEd, there is no need to "install" it, simply run AniEd.exe, to view any of the example .inka files (Ink Animation), simply drag them over AniEd.exe or "Open" them from the "File" menu. All examples files where created using Ink AniEd by yours truly.

For a guide, updates, and other "inka" files, check out http://plaza.ufl.edu/lewey/anied"

UPDATES: Version 1.2: 5/10/2004

Added SVG exporter so that you can post animations on the web.

Made the main window resize able.

UPDATES: Version 1.1: 9/5/2003:

Added "High Quality Play Back" in the "Mode" menu. This is on by default and means strokes drawn in animations are drawn with full quality.

Add "Action" button, same as you get if you right click on selected strokes

Added "New" command to "File" menu (same as "Edit - Clear All" )

Added error message if user tries to overwrite stroke at the same time.

Gave the application an icon, albiet a bad one

