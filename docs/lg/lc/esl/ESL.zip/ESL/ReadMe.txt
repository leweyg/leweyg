ESL Compiler Prototype v0.2
	Written by Lewey Geselowitz
	ESL Homepage: http://www.leweyg.com/lc/esl/

ESL_Designer.exe
	This is a visual front end for creating ESL materials, it reads myshader.esl, syntax.txt, System.esl and can export to output.fx

FxViewer.exe
	This is a simple Fx based program which reads in output.fx and applies it to model. It supports numerous semantics, most of which you can find referenced in myshader.esl

myshader.esl
	This is the main shader code file, this is where you write your class declarations, try making a backup of this file and then writing your own classes or modifiying the ones in there.

For more information check out the ESL homepage, or email me at lewey@leweyg.com .