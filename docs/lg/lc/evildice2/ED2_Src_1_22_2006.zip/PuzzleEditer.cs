using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using EvilGame;
using EvilGame.Puzzle;
using RealSharp;

namespace threed_objects
{
	/// <summary>
	/// Summary description for PuzzleEditer.
	/// </summary>
	public class PuzzleEditer : System.Windows.Forms.Form
	{
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.PropertyGrid propertyGrid1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public PuzzleEditer(Level lvl)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			Campaign = lvl.Campaign;
			Level = lvl;
		}
		[transient] private Campaign campaign = null;
		[transient] private Level level = null;

		public Level Level
		{
			get { return level; }
			set
			{
				level = value;
				this.propertyGrid1.SelectedObject = level;
				Code.TheApp.CurrentLevel = level;
				this.listBox1.SelectedItem = level;
			}
		}

		public Campaign Campaign
		{
			get { return campaign; }
			set
			{
				campaign = value;
				this.listBox1.Items.Clear();
				foreach (Level el in campaign.Levels)
				{
					this.listBox1.Items.Add( el );
				}
				Level = campaign.Levels[0];
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.button7 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.groupBox2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem5,
																					  this.menuItem2,
																					  this.menuItem3,
																					  this.menuItem4});
			this.menuItem1.Text = "File";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "New";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.Text = "Open...";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.Text = "Save...";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 3;
			this.menuItem4.Text = "Exit Editor";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// listBox1
			// 
			this.listBox1.Location = new System.Drawing.Point(8, 16);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(176, 264);
			this.listBox1.TabIndex = 0;
			this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(48, 288);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(56, 32);
			this.button2.TabIndex = 1;
			this.button2.Text = "Remove";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 288);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(40, 32);
			this.button1.TabIndex = 0;
			this.button1.Text = "Add";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.button7);
			this.groupBox2.Controls.Add(this.button3);
			this.groupBox2.Controls.Add(this.propertyGrid1);
			this.groupBox2.Location = new System.Drawing.Point(208, 8);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(280, 280);
			this.groupBox2.TabIndex = 2;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "This Puzzle";
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(136, 240);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(80, 32);
			this.button7.TabIndex = 2;
			this.button7.Text = "Play";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(40, 240);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(88, 32);
			this.button3.TabIndex = 1;
			this.button3.Text = "Edit";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// propertyGrid1
			// 
			this.propertyGrid1.CommandsVisibleIfAvailable = true;
			this.propertyGrid1.HelpVisible = false;
			this.propertyGrid1.LargeButtons = false;
			this.propertyGrid1.LineColor = System.Drawing.SystemColors.ScrollBar;
			this.propertyGrid1.Location = new System.Drawing.Point(8, 16);
			this.propertyGrid1.Name = "propertyGrid1";
			this.propertyGrid1.Size = new System.Drawing.Size(264, 216);
			this.propertyGrid1.TabIndex = 0;
			this.propertyGrid1.Text = "propertyGrid1";
			this.propertyGrid1.ToolbarVisible = false;
			this.propertyGrid1.ViewBackColor = System.Drawing.SystemColors.Window;
			this.propertyGrid1.ViewForeColor = System.Drawing.SystemColors.WindowText;
			this.propertyGrid1.Click += new System.EventHandler(this.propertyGrid1_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(0, 0);
			this.button4.Name = "button4";
			this.button4.TabIndex = 0;
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(408, 296);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(80, 40);
			this.button5.TabIndex = 3;
			this.button5.Text = "Exit Editor";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.button9);
			this.groupBox3.Controls.Add(this.button8);
			this.groupBox3.Controls.Add(this.listBox1);
			this.groupBox3.Controls.Add(this.button1);
			this.groupBox3.Controls.Add(this.button2);
			this.groupBox3.Location = new System.Drawing.Point(8, 8);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(192, 328);
			this.groupBox3.TabIndex = 5;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Campaign";
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(144, 288);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(40, 32);
			this.button9.TabIndex = 3;
			this.button9.Text = "Move Down";
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(104, 288);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(40, 32);
			this.button8.TabIndex = 2;
			this.button8.Text = "Move Up";
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// PuzzleEditer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(496, 345);
			this.Controls.Add(this.groupBox3);
			this.Controls.Add(this.button5);
			this.Controls.Add(this.groupBox2);
			this.Menu = this.mainMenu1;
			this.Name = "PuzzleEditer";
			this.Text = "Evil Dice 2 - Campaign Editor";
			this.Load += new System.EventHandler(this.PuzzleEditer_Load);
			this.groupBox2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void propertyGrid1_Click(object sender, System.EventArgs e)
		{
		
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Level el = new Level();
			el.name = "Level "+(this.listBox1.Items.Count+1);
			Campaign.Add( el );
			Campaign = Campaign;
			Level = el;
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			this.Close();
			Code.TheApp.GotoMainMenu();
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			IsAskSave = false;
			this.Close();
			Code.TheApp.StartPuzzleNewGame( Level );
			Code.TheApp.IsEditorMode = true;
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			IsAskSave = false;
			this.Close();
			Code.TheApp.StartPuzzleEditor( Level );
		}

		public bool IsAskSave = true;
		public bool AskSave()
		{
			if ( !IsAskSave )
				return true;

			DialogResult dr = MessageBox.Show( this, "Do you wish to save?", "Save?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question );
			if ( dr == DialogResult.Cancel )
				return false;

			if ( dr == DialogResult.Yes )
			{
				DoSave( false );
			}

			return true;
		}

		public void DoSave(bool issaveas)
		{
			if ( issaveas || Campaign.FileName=="" )
			{
				SaveFileDialog sfd = new SaveFileDialog();
				sfd.InitialDirectory = Environment.CurrentDirectory;
				sfd.RestoreDirectory = true;
				sfd.Filter = "Evil Dice 2 Puzzle Campaign (*.PZL)|*.PZL";
				if ( sfd.ShowDialog( this ) == DialogResult.OK )
				{
					Campaign.FileName = sfd.FileName;
				}
				else
					return;
			}
			this.campaign.SaveToFile( Campaign.FileName );
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			DoSave(false);
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			OpenFileDialog sfd = new OpenFileDialog();
			sfd.InitialDirectory = Environment.CurrentDirectory;
			sfd.RestoreDirectory = true;
			sfd.CheckFileExists = true;
			sfd.Filter = "Evil Dice 2 Puzzle Campaign (*.PZL)|*.PZL";
			if ( sfd.ShowDialog( this ) != DialogResult.OK )
				return;
			Campaign.FileName = sfd.FileName;
			Campaign.LoadFromFile( Campaign.FileName );
			Campaign = Campaign;
		}

		private void listBox1_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.Level = (Level)this.listBox1.SelectedItem;
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			Campaign c = Campaign;
			Level el = (Level)this.listBox1.SelectedItem;
			int i = this.listBox1.SelectedIndex;
			if ( c.Levels.Length <= 1 )
				return;
			c.Levels = (Level[])Code.ArrayRemove( c.Levels, el );
			Campaign = c;

			this.listBox1.SelectedIndex = ( i % c.Levels.Length );
		}

		private void PuzzleEditer_Load(object sender, System.EventArgs e)
		{
			this.CenterToParent();
		}

		private void button8_Click(object sender, System.EventArgs e)
		{
			int i = this.listBox1.SelectedIndex;
			if ( i == 0 )
				return;

			Level t = Campaign.Levels[i];
			Campaign.Levels[i] = Campaign.Levels[i-1];
			Campaign.Levels[i-1] = t;
			Campaign = Campaign;

			this.listBox1.SelectedIndex = i-1;
		}

		private void button9_Click(object sender, System.EventArgs e)
		{
			int i = this.listBox1.SelectedIndex;
			if ( i+1 < Campaign.Levels.Length )
				return;

			Level t = Campaign.Levels[i];
			Campaign.Levels[i] = Campaign.Levels[i+1];
			Campaign.Levels[i+1] = t;
			Campaign = Campaign;

			this.listBox1.SelectedIndex = i+1;
		
		}

		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing (e);

			if ( !AskSave() )
				e.Cancel = true;
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			Campaign c = new Campaign();
			Level el = new Level();
			c.Add( el );
			Campaign = c;
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			DoSave( true );
		}

	}
}
