using System;
using RealSharp;
namespace EvilGame 
{
	public class rs_Wrap_Player : EvilGame.Player 
	{
		private EvilGame.Cursor rs_pvs_Cursor;
		private System.String rs_pvs_Name;
		private System.Int32 rs_pvs_TeamPref;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_Cursor=( this.Cursor );
			rs_pvs_Name=( this.Name );
			rs_pvs_TeamPref=( this.TeamPref );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_Cursor !=( this.Cursor)) ||(rs_pvs_Name !=( this.Name)) ||(rs_pvs_TeamPref !=( this.TeamPref)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_RSActor(Cursor);

				dp.Push_string(Name);

				dp.Push_int(TeamPref);
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.Cursor=(EvilGame.Cursor)dp.Pop_RSActor(); 
			this.Name=(System.String)dp.Pop_string(); 
			this.TeamPref=(System.Int32)dp.Pop_int(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{

			dp.Push_RSActor(Cursor);

			dp.Push_string(Name);

			dp.Push_int(TeamPref);
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.Cursor=(EvilGame.Cursor)dp.Pop_RSActor(); 
			this.Name=(System.String)dp.Pop_string(); 
			this.TeamPref=(System.Int32)dp.Pop_int(); 
		}
	} 
	public class rs_Wrap_Lounge : EvilGame.Lounge 
	{
		private System.Int32 rs_pvs_BoardSize;
		private EvilGame.Game.GameType rs_pvs_NextGameType;
		private EvilGame.Lounge.TeamSetup rs_pvs_NextTeamSetup;
		private EvilGame.Player[] rs_pvs_Players;
		private EvilGame.Game rs_pvs_TheGame;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_BoardSize=( this.BoardSize );
			rs_pvs_NextGameType=( this.NextGameType );
			rs_pvs_NextTeamSetup=( this.NextTeamSetup );
			rs_pvs_Players=( this.Players );
			rs_pvs_TheGame=( this.TheGame );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_BoardSize !=( this.BoardSize)) ||(rs_pvs_NextGameType !=( this.NextGameType)) ||(rs_pvs_NextTeamSetup !=( this.NextTeamSetup)) ||(rs_pvs_Players !=( this.Players)) ||(rs_pvs_TheGame !=( this.TheGame)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_int(BoardSize);
				dp.Push_byte( (byte)NextGameType);
				dp.Push_byte( (byte)NextTeamSetup);
				dp.Push_ushort( (ushort)Players.Length);
				foreach ( EvilGame.Player i in Players)
				{

					dp.Push_RSActor(i);}


				dp.Push_RSActor(TheGame);
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.BoardSize=(System.Int32)dp.Pop_int(); 
			NextGameType=(EvilGame.Game.GameType)dp.Pop_byte();
			NextTeamSetup=(EvilGame.Lounge.TeamSetup)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Players=new EvilGame.Player[length];
			for (int i=0;i<length;i++)
				this.Players[i]=(EvilGame.Player)dp.Pop_RSActor(); }
			this.TheGame=(EvilGame.Game)dp.Pop_RSActor(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{

			dp.Push_int(BoardSize);

			dp.Push_bool(IsSinglePlayer);
			dp.Push_byte( (byte)NextGameType);
			dp.Push_byte( (byte)NextTeamSetup);
			dp.Push_ushort( (ushort)Players.Length);
			foreach ( EvilGame.Player i in Players)
			{

				dp.Push_RSActor(i);}


			dp.Push_RSActor(TheGame);
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.BoardSize=(System.Int32)dp.Pop_int(); 
			this.IsSinglePlayer=(System.Boolean)dp.Pop_bool(); 
			NextGameType=(EvilGame.Game.GameType)dp.Pop_byte();
			NextTeamSetup=(EvilGame.Lounge.TeamSetup)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Players=new EvilGame.Player[length];
			for (int i=0;i<length;i++)
				this.Players[i]=(EvilGame.Player)dp.Pop_RSActor(); }
			this.TheGame=(EvilGame.Game)dp.Pop_RSActor(); 
		}
	} 
	public class rs_Wrap_Game : EvilGame.Game 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_InfTime : EvilGame.Game.GameMode_InfTime 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_War : EvilGame.Game.GameMode_War 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_DuelSurvival : EvilGame.Game.GameMode_DuelSurvival 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Survival : EvilGame.Game.GameMode_Survival 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Classic : EvilGame.Game.GameMode_Classic 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Short : EvilGame.Game.GameMode_Short 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_RemoveRandom : EvilGame.Game.GameMode_RemoveRandom 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_TwentyFour : EvilGame.Game.GameMode_TwentyFour 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Puzzle : EvilGame.Game.GameMode_Puzzle 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);

			dp.Push_int(Steps);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Steps=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Envy : EvilGame.Game.GameMode_Envy 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Feed : EvilGame.Game.GameMode_Feed 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_BattleSector : EvilGame.Game.BattleSector 
	{
		private EvilGame.Team rs_pvs_Owner;
		private System.Int32 rs_pvs_Points;
		private System.Double rs_pvs_TickTime;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_Owner=( this.Owner );
			rs_pvs_Points=( this.Points );
			rs_pvs_TickTime=( this.TickTime );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_Owner !=( this.Owner)) ||(rs_pvs_Points !=( this.Points)) ||(rs_pvs_TickTime !=( this.TickTime)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_RSActor(Owner);

				dp.Push_int(Points);
				dp.Push_float( (float)TickTime );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.Owner=(EvilGame.Team)dp.Pop_RSActor(); 
			this.Points=(System.Int32)dp.Pop_int(); 
			this.TickTime=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{

			dp.Push_int(MaxX);

			dp.Push_int(MaxY);

			dp.Push_int(MinX);

			dp.Push_int(MinY);

			dp.Push_RSActor(Owner);

			dp.Push_int(Points);

			dp.Push_RSActor(ScoreTile);
			dp.Push_float( (float)TickTime );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.MaxX=(System.Int32)dp.Pop_int(); 
			this.MaxY=(System.Int32)dp.Pop_int(); 
			this.MinX=(System.Int32)dp.Pop_int(); 
			this.MinY=(System.Int32)dp.Pop_int(); 
			this.Owner=(EvilGame.Team)dp.Pop_RSActor(); 
			this.Points=(System.Int32)dp.Pop_int(); 
			this.ScoreTile=(EvilGame.Tile)dp.Pop_RSActor(); 
			this.TickTime=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_GameMode_Battle : EvilGame.Game.GameMode_Battle 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);
			dp.Push_ushort( (ushort)Sectors.Length);
			foreach ( EvilGame.Game.BattleSector i in Sectors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
		{
				int length=dp.Pop_ushort();
			Sectors=new EvilGame.Game.BattleSector[length];
			for (int i=0;i<length;i++)
				this.Sectors[i]=(EvilGame.Game.BattleSector)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_Piece : EvilGame.Piece 
	{
		private EvilGame.Tile rs_pvs_PreviousLoc;
		private EvilGame.DieState rs_pvs_PreviousState;
		private System.Double rs_pvs_StateStartTime;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_PreviousLoc=( this.PreviousLoc );
			rs_pvs_PreviousState=( this.PreviousState );
			rs_pvs_StateStartTime=( this.StateStartTime );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_PreviousLoc !=( this.PreviousLoc)) ||(rs_pvs_PreviousState !=( this.PreviousState)) ||(rs_pvs_StateStartTime !=( this.StateStartTime)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_RSActor(PreviousLoc);
				dp.Push_byte( (byte)PreviousState);
				dp.Push_float( (float)StateStartTime );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{

			dp.Push_RSActor(PreviousLoc);
			dp.Push_byte( (byte)PreviousState);
			dp.Push_float( (float)StateStartTime );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_Team : EvilGame.Team 
	{
		private System.Boolean[] rs_pvs_Envies;
		private System.Int32 rs_pvs_Score;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_Envies=( this.Envies );
			rs_pvs_Score=( this.Score );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_Envies !=( this.Envies)) ||(rs_pvs_Score !=( this.Score)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_ushort( (ushort)Envies.Length);
				foreach ( System.Boolean i in Envies)
				{

					dp.Push_bool(i);}


				dp.Push_int(Score);
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
		{
				int length=dp.Pop_ushort();
			Envies=new System.Boolean[length];
			for (int i=0;i<length;i++)
				this.Envies[i]=(System.Boolean)dp.Pop_bool(); }
			this.Score=(System.Int32)dp.Pop_int(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_int( Color.ToArgb() );
			dp.Push_ushort( (ushort)Envies.Length);
			foreach ( System.Boolean i in Envies)
			{

				dp.Push_bool(i);}


			dp.Push_int(Score);
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			Color = System.Drawing.Color.FromArgb( dp.Pop_int() );
		{
				int length=dp.Pop_ushort();
			Envies=new System.Boolean[length];
			for (int i=0;i<length;i++)
				this.Envies[i]=(System.Boolean)dp.Pop_bool(); }
			this.Score=(System.Int32)dp.Pop_int(); 
		}
	} 
	public class rs_Wrap_Cursor : EvilGame.Cursor 
	{
		private System.Double rs_pvs_FloorTime;
		private EvilGame.Tile rs_pvs_PreviousLoc;
		private EvilGame.DieState rs_pvs_PreviousState;
		private System.Double rs_pvs_StateStartTime;
		private EvilGame.Dir rs_pvs_WantDir;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_FloorTime=( this.FloorTime );
			rs_pvs_PreviousLoc=( this.PreviousLoc );
			rs_pvs_PreviousState=( this.PreviousState );
			rs_pvs_StateStartTime=( this.StateStartTime );
			rs_pvs_WantDir=( this.WantDir );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_FloorTime !=( this.FloorTime)) ||(rs_pvs_PreviousLoc !=( this.PreviousLoc)) ||(rs_pvs_PreviousState !=( this.PreviousState)) ||(rs_pvs_StateStartTime !=( this.StateStartTime)) ||(rs_pvs_WantDir !=( this.WantDir)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)FloorTime );

				dp.Push_RSActor(PreviousLoc);
				dp.Push_byte( (byte)PreviousState);
				dp.Push_float( (float)StateStartTime );
				dp.Push_byte( (byte)WantDir);
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.FloorTime=(System.Double)dp.Pop_float(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
			this.StateStartTime=(System.Double)dp.Pop_float(); 
			WantDir=(EvilGame.Dir)dp.Pop_byte();
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)FloorTime );

			dp.Push_RSActor(Player);

			dp.Push_RSActor(PreviousLoc);
			dp.Push_byte( (byte)PreviousState);
			dp.Push_float( (float)StateStartTime );

			dp.Push_RSActor(Team);
			dp.Push_byte( (byte)WantDir);
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.FloorTime=(System.Double)dp.Pop_float(); 
			this.Player=(EvilGame.Player)dp.Pop_RSActor(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
			this.StateStartTime=(System.Double)dp.Pop_float(); 
			this.Team=(EvilGame.Team)dp.Pop_RSActor(); 
			WantDir=(EvilGame.Dir)dp.Pop_byte();
		}
	} 
	public class rs_Wrap_Die : EvilGame.Die 
	{
		private System.Boolean rs_pvs_IsAlive;
		private EvilGame.Cursor rs_pvs_LastMover;
		private EvilGame.Dir rs_pvs_LastRotDir;
		private System.Int32 rs_pvs_MaxCombo;
		private EvilGame.Tile rs_pvs_PreviousLoc;
		private EvilGame.DieState rs_pvs_PreviousState;
		private System.Int32[] rs_pvs_Sides;
		private System.Double rs_pvs_StateStartTime;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_IsAlive=( this.IsAlive );
			rs_pvs_LastMover=( this.LastMover );
			rs_pvs_LastRotDir=( this.LastRotDir );
			rs_pvs_MaxCombo=( this.MaxCombo );
			rs_pvs_PreviousLoc=( this.PreviousLoc );
			rs_pvs_PreviousState=( this.PreviousState );
			rs_pvs_Sides=( this.Sides );
			rs_pvs_StateStartTime=( this.StateStartTime );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_IsAlive !=( this.IsAlive)) ||(rs_pvs_LastMover !=( this.LastMover)) ||(rs_pvs_LastRotDir !=( this.LastRotDir)) ||(rs_pvs_MaxCombo !=( this.MaxCombo)) ||(rs_pvs_PreviousLoc !=( this.PreviousLoc)) ||(rs_pvs_PreviousState !=( this.PreviousState)) ||(rs_pvs_Sides !=( this.Sides)) ||(rs_pvs_StateStartTime !=( this.StateStartTime)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_bool(IsAlive);

				dp.Push_RSActor(LastMover);
				dp.Push_byte( (byte)LastRotDir);

				dp.Push_int(MaxCombo);

				dp.Push_RSActor(PreviousLoc);
				dp.Push_byte( (byte)PreviousState);
				dp.Push_ushort( (ushort)Sides.Length);
				foreach ( System.Int32 i in Sides)
				{

					dp.Push_int(i);}

				dp.Push_float( (float)StateStartTime );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.IsAlive=(System.Boolean)dp.Pop_bool(); 
			this.LastMover=(EvilGame.Cursor)dp.Pop_RSActor(); 
			LastRotDir=(EvilGame.Dir)dp.Pop_byte();
			this.MaxCombo=(System.Int32)dp.Pop_int(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Sides=new System.Int32[length];
			for (int i=0;i<length;i++)
				this.Sides[i]=(System.Int32)dp.Pop_int(); }
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_byte( (byte)DieType);

			dp.Push_bool(IsAlive);

			dp.Push_RSActor(LastMover);
			dp.Push_byte( (byte)LastRotDir);

			dp.Push_int(MaxCombo);

			dp.Push_RSActor(PreviousLoc);
			dp.Push_byte( (byte)PreviousState);
			dp.Push_ushort( (ushort)Sides.Length);
			foreach ( System.Int32 i in Sides)
			{

				dp.Push_int(i);}

			dp.Push_float( (float)StateStartTime );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			DieType=(EvilGame.DieType)dp.Pop_byte();
			this.IsAlive=(System.Boolean)dp.Pop_bool(); 
			this.LastMover=(EvilGame.Cursor)dp.Pop_RSActor(); 
			LastRotDir=(EvilGame.Dir)dp.Pop_byte();
			this.MaxCombo=(System.Int32)dp.Pop_int(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Sides=new System.Int32[length];
			for (int i=0;i<length;i++)
				this.Sides[i]=(System.Int32)dp.Pop_int(); }
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_TwentyFour : EvilGame.Die.TwentyFour 
	{
		private System.Boolean rs_pvs_IsAlive;
		private EvilGame.Cursor rs_pvs_LastMover;
		private EvilGame.Dir rs_pvs_LastRotDir;
		private System.Int32 rs_pvs_MaxCombo;
		private EvilGame.Tile rs_pvs_PreviousLoc;
		private EvilGame.DieState rs_pvs_PreviousState;
		private System.Int32[] rs_pvs_Sides;
		private System.Double rs_pvs_StateStartTime;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_IsAlive=( this.IsAlive );
			rs_pvs_LastMover=( this.LastMover );
			rs_pvs_LastRotDir=( this.LastRotDir );
			rs_pvs_MaxCombo=( this.MaxCombo );
			rs_pvs_PreviousLoc=( this.PreviousLoc );
			rs_pvs_PreviousState=( this.PreviousState );
			rs_pvs_Sides=( this.Sides );
			rs_pvs_StateStartTime=( this.StateStartTime );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_IsAlive !=( this.IsAlive)) ||(rs_pvs_LastMover !=( this.LastMover)) ||(rs_pvs_LastRotDir !=( this.LastRotDir)) ||(rs_pvs_MaxCombo !=( this.MaxCombo)) ||(rs_pvs_PreviousLoc !=( this.PreviousLoc)) ||(rs_pvs_PreviousState !=( this.PreviousState)) ||(rs_pvs_Sides !=( this.Sides)) ||(rs_pvs_StateStartTime !=( this.StateStartTime)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_bool(IsAlive);

				dp.Push_RSActor(LastMover);
				dp.Push_byte( (byte)LastRotDir);

				dp.Push_int(MaxCombo);

				dp.Push_RSActor(PreviousLoc);
				dp.Push_byte( (byte)PreviousState);
				dp.Push_ushort( (ushort)Sides.Length);
				foreach ( System.Int32 i in Sides)
				{

					dp.Push_int(i);}

				dp.Push_float( (float)StateStartTime );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.IsAlive=(System.Boolean)dp.Pop_bool(); 
			this.LastMover=(EvilGame.Cursor)dp.Pop_RSActor(); 
			LastRotDir=(EvilGame.Dir)dp.Pop_byte();
			this.MaxCombo=(System.Int32)dp.Pop_int(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Sides=new System.Int32[length];
			for (int i=0;i<length;i++)
				this.Sides[i]=(System.Int32)dp.Pop_int(); }
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_byte( (byte)DieType);

			dp.Push_bool(IsAlive);

			dp.Push_RSActor(LastMover);
			dp.Push_byte( (byte)LastRotDir);

			dp.Push_int(MaxCombo);

			dp.Push_RSActor(PreviousLoc);
			dp.Push_byte( (byte)PreviousState);
			dp.Push_ushort( (ushort)Sides.Length);
			foreach ( System.Int32 i in Sides)
			{

				dp.Push_int(i);}

			dp.Push_float( (float)StateStartTime );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			DieType=(EvilGame.DieType)dp.Pop_byte();
			this.IsAlive=(System.Boolean)dp.Pop_bool(); 
			this.LastMover=(EvilGame.Cursor)dp.Pop_RSActor(); 
			LastRotDir=(EvilGame.Dir)dp.Pop_byte();
			this.MaxCombo=(System.Int32)dp.Pop_int(); 
			this.PreviousLoc=(EvilGame.Tile)dp.Pop_RSActor(); 
			PreviousState=(EvilGame.DieState)dp.Pop_byte();
		{
				int length=dp.Pop_ushort();
			Sides=new System.Int32[length];
			for (int i=0;i<length;i++)
				this.Sides[i]=(System.Int32)dp.Pop_int(); }
			this.StateStartTime=(System.Double)dp.Pop_float(); 
		}
	} 
	public class rs_Wrap_Tile : EvilGame.Tile 
	{
		private EvilGame.Die rs_pvs_DieHeld;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_DieHeld=( this.DieHeld );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_DieHeld !=( this.DieHeld)) ||false)
			{
				dp.Push_RSActor( this );

				dp.Push_RSActor(DieHeld);
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.DieHeld=(EvilGame.Die)dp.Pop_RSActor(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{

			dp.Push_bool(CalcScreenPos);

			dp.Push_RSActor(DieHeld);

			dp.Push_RSActor(Game);

			dp.Push_bool(IsWalkable);

			dp.Push_int(PosX);

			dp.Push_int(PosY);

			dp.Push_RSActor(TeamOwner);
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.CalcScreenPos=(System.Boolean)dp.Pop_bool(); 
			this.DieHeld=(EvilGame.Die)dp.Pop_RSActor(); 
			this.Game=(EvilGame.Game)dp.Pop_RSActor(); 
			this.IsWalkable=(System.Boolean)dp.Pop_bool(); 
			this.PosX=(System.Int32)dp.Pop_int(); 
			this.PosY=(System.Int32)dp.Pop_int(); 
			this.TeamOwner=(EvilGame.Team)dp.Pop_RSActor(); 
		}
	} 
	public class rs_Wrap_GameMode_PuzzleEditor : EvilGame.GameMode_PuzzleEditor 
	{
		private System.Double rs_pvs_AbsoluteTime;
		private EvilGame.Die[] rs_pvs_Dice;
		private System.Boolean rs_pvs_IsPaused;
		private System.Double rs_pvs_Time;

		public override void rs_UpdatePvs() 
		{
			rs_pvs_AbsoluteTime=( this.AbsoluteTime );
			rs_pvs_Dice=( this.Dice );
			rs_pvs_IsPaused=( this.IsPaused );
			rs_pvs_Time=( this.Time );
		}
		public override void rs_UpdatePack(IDataPacker dp) 
		{
			if ((rs_pvs_AbsoluteTime !=( this.AbsoluteTime)) ||(rs_pvs_Dice !=( this.Dice)) ||(rs_pvs_IsPaused !=( this.IsPaused)) ||(rs_pvs_Time !=( this.Time)) ||false)
			{
				dp.Push_RSActor( this );
				dp.Push_float( (float)AbsoluteTime );
				dp.Push_ushort( (ushort)Dice.Length);
				foreach ( EvilGame.Die i in Dice)
				{

					dp.Push_RSActor(i);}


				dp.Push_bool(IsPaused);
				dp.Push_float( (float)Time );
			}
		}
		public override void rs_UpdateUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
		public override void rs_FullPack(IDataPacker dp) 
		{
			dp.Push_float( (float)AbsoluteTime );
			dp.Push_ushort( (ushort)Cursors.Length);
			foreach ( EvilGame.Cursor i in Cursors)
			{

				dp.Push_RSActor(i);}

			dp.Push_ushort( (ushort)Dice.Length);
			foreach ( EvilGame.Die i in Dice)
			{

				dp.Push_RSActor(i);}


			dp.Push_bool(IsPaused);

			dp.Push_int(Steps);
			dp.Push_ushort( (ushort)Teams.Length);
			foreach ( EvilGame.Team i in Teams)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileHeight);
			dp.Push_ushort( (ushort)Tiles.Length);
			foreach ( EvilGame.Tile i in Tiles)
			{

				dp.Push_RSActor(i);}


			dp.Push_int(TileWidth);
			dp.Push_float( (float)Time );
		}
		public override void rs_FullUnPack(IDataUnPacker dp) 
		{
			this.AbsoluteTime=(System.Double)dp.Pop_float(); 
		{
				int length=dp.Pop_ushort();
			Cursors=new EvilGame.Cursor[length];
			for (int i=0;i<length;i++)
				this.Cursors[i]=(EvilGame.Cursor)dp.Pop_RSActor(); }
		{
				int length=dp.Pop_ushort();
			Dice=new EvilGame.Die[length];
			for (int i=0;i<length;i++)
				this.Dice[i]=(EvilGame.Die)dp.Pop_RSActor(); }
			this.IsPaused=(System.Boolean)dp.Pop_bool(); 
			this.Steps=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Teams=new EvilGame.Team[length];
			for (int i=0;i<length;i++)
				this.Teams[i]=(EvilGame.Team)dp.Pop_RSActor(); }
			this.TileHeight=(System.Int32)dp.Pop_int(); 
		{
				int length=dp.Pop_ushort();
			Tiles=new EvilGame.Tile[length];
			for (int i=0;i<length;i++)
				this.Tiles[i]=(EvilGame.Tile)dp.Pop_RSActor(); }
			this.TileWidth=(System.Int32)dp.Pop_int(); 
			this.Time=(System.Double)dp.Pop_float(); 
		}
	} 
}
