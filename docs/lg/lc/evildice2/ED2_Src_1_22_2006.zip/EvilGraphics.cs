using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Collections;
using Microsoft.DirectX;
using DX = Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;
//using PCT = Microsoft.DirectX.Direct3D.CustomVertex.PositionTextured;
//using PNT = Microsoft.DirectX.Direct3D.CustomVertex.PositionNormalTextured;
using MVF = Microsoft.DirectX.Direct3D.CustomVertex.PositionNormalTextured;
using Microsoft.DirectX.DirectSound;
using Microsoft.DirectX.AudioVideoPlayback;

namespace EvilGame
{
	public struct PNT
	{
		public float X;
		public float Y;
		public float Z;
		public float Nx;
		public float Ny;
		public float Nz;
		public UInt32 Color;
		public float Tu0;
		public float Tv0;

		public PNT(MVF m)
		{
			X = m.X; Y = m.Y; Z = m.Z;
			Nx = m.Nx; Ny = m.Ny; Nz = m.Nz;
			Color = 0xFFffFFff;
			Tu0 = m.Tu; Tv0 = m.Tv;
		}

		public PNT(Vector3 p, Vector3 n, float u, float v)
		{
			X = p.X; Y = p.Y; Z = p.Z;
			Nx = n.X; Ny = n.Y; Nz = n.Z;
			Color = 0xFFFFFFFF;
			Tu0 = u; Tv0 = v;
		}

		public Vector3 Position
		{
			get {return new Vector3(X,Y,Z);}
			set
			{
				X = value.X;
				Y = value.Y;
				Z = value.Z;
			}
		}

		public Vector3 Normal
		{
			get { return new Vector3(Nx,Ny,Nz); }
			set
			{
				Nx = value.X;
				Ny = value.Y;
				Nz = value.Z;
			}
		}

		public Vector2 Texture0
		{
			get { return new Vector2(Tu0,Tv0); }
			set
			{
				Tu0 = value.X;
				Tv0 = value.Y;
			}
		}

		public UInt32 Diffuse
		{
			get { return Color; }
			set { Color = value; }
		}

		public static readonly D3D.VertexFormats Format
			= D3D.VertexFormats.Position | D3D.VertexFormats.Normal | D3D.VertexFormats.Diffuse
			| D3D.VertexFormats.Texture1;

		public static readonly int StrideSize
			= DXHelp.GetTypeSize( typeof( PNT ) );
	}

	public class EvilMesh
	{
		public PNT[] Vertices;
		public ushort[] Indices;

		public PNT[] TempVertices;
		public ushort[] TempIndices;

		public void CopyIntoTemp()
		{
			for (int i=0; i<Vertices.Length; i++)
				TempVertices[i] = Vertices[i];
			for (int j=0; j<Indices.Length; j++)
				TempIndices[j] = Indices[j];
		}

		public void ApplyToMeshes(Matrix m)
		{
			Matrix norm = DynamicBuffer.WithoutEdges( m );
			for (int i=0; i<Vertices.Length; i++)
			{
				PNT vert = Vertices[i];
				vert.Position = DynamicBuffer.Transform( m, vert.Position );
				Vector3 n = DynamicBuffer.Transform( norm, vert.Normal );
				n.Normalize();
				vert.Normal = n;
				Vertices[i] = vert;
			}
		}

		public void ApplyToTextures(Matrix m)
		{
			for (int i=0; i<Vertices.Length; i++)
			{
				PNT vert = Vertices[i];
				float u = vert.Tu0;
				float v = vert.Tv0;
				Vector4 vc = Vector3.Transform( new Vector3(u,v,1), m );
				vert.Tu0 = u / 2;
				vert.Tv0 = v / 2;
				Vertices[i] = vert;
			}
		}

		public EvilMesh(D3D.Mesh mesh)
		{
			int rank = mesh.NumberVertices;
			if ( mesh.VertexFormat == MVF.Format )
			{
				MVF[] verts = (MVF[])mesh.LockVertexBuffer( typeof(MVF), 
					D3D.LockFlags.None, rank );
				Vertices = new PNT[ verts.Length ];
				for (int i=0; i<verts.Length; i++)
				{
					Vertices[i] = new PNT( verts[i] );
				}
				mesh.UnlockVertexBuffer();
			}
			else if ( mesh.VertexFormat == PNT.Format )
			{
				Vertices = (PNT[])mesh.LockVertexBuffer( typeof(PNT),
					D3D.LockFlags.None, rank );
				mesh.UnlockVertexBuffer();
			}
			else
				Code.TODO();

			rank = mesh.NumberFaces * 3;
			Indices = (ushort[])mesh.LockIndexBuffer( typeof(ushort),
				D3D.LockFlags.None, rank );
			mesh.UnlockIndexBuffer();

			TempVertices = new PNT[ Vertices.Length ];
			TempIndices = new ushort[ Indices.Length ];
		}

		public EvilMesh(PNT[] bs, ushort[] inds, int from, int length)
		{
			ushort[] cache = new ushort[ length ];
			int numcache = 0;
			Indices = new ushort[ length ];

			for (int i=0; i<length; i++)
			{
				ushort oldi = inds[ from + i ];

				int found = -1;
				for (int j=0; j<numcache; j++)
				{
					if ( cache[j] == oldi )
						found = j;
				}
				if ( found < 0 )
				{
					cache[ numcache ] = oldi;
					found = numcache;
					numcache++;
				}

				Indices[ i ] = (ushort)found;
			}

			Vertices = new PNT[ numcache ];
			for (int k=0; k<numcache; k++)
			{
				Vertices[ k ] = bs[ cache[ k ] ];
			}

			TempVertices = new PNT[ Vertices.Length ];
			TempIndices = new ushort[ Indices.Length ];
		}
	}

	public class DynamicBuffer
	{
		private D3D.Device Device;
		private D3D.VertexBuffer VertexBuff = null;
		private D3D.IndexBuffer IndexBuff = null;
		public EvilGraphics Graphics;
		public int Batches = 0;
		public uint CurrentColor = White;
		public Vector2 CurrentTextureOffset = new Vector2( 0, 0 );

		public const uint White = 0xFFffFFff;

		private const int MaxVerts = 9000;
		private const int VertsPerPoly = 3;
		private const int MaxIndices = 20000;

		private int CurNumVerts = 0;
		private int CurNumIndices = 0;
		private bool IsLocked = false;
		private GraphicsStream CurrentBuffer = null;
		private GraphicsStream CurrentIndexBuffer = null;

		public DynamicBuffer(D3D.Device device, EvilGraphics eg)
		{
			Graphics = eg;
			Device = device;
			VertexBuff = new Microsoft.DirectX.Direct3D.VertexBuffer( typeof(PNT),
				MaxVerts, Device, D3D.Usage.Dynamic|D3D.Usage.WriteOnly,
				PNT.Format, D3D.Pool.Default );

			IndexBuff = new D3D.IndexBuffer( typeof( ushort ),
				MaxIndices, Device, 
				D3D.Usage.Dynamic|D3D.Usage.WriteOnly, 
				D3D.Pool.Default );
		}

		public void BeginDrawing()
		{
			Code.Assert( !IsLocked );
			IsLocked = true;

			CurNumVerts = 0;
			CurNumIndices = 0;
			CurrentBuffer = VertexBuff.Lock( 0, 0, D3D.LockFlags.Discard );
			CurrentIndexBuffer = IndexBuff.Lock( 0, 0, D3D.LockFlags.Discard );
		}

		public static Matrix WithoutEdges(Matrix m)
		{
			Matrix ans = m;
			ans.M14 = 0;
			ans.M24 = 0;
			ans.M34 = 0;
			ans.M44 = 1;
			ans.M43 = 0;
			ans.M42 = 0;
			ans.M41 = 0;
			return ans;
		}

		public static Vector3 Transform(Matrix m, Vector3 p)
		{
			Vector4 vf = Vector3.Transform( p, m );
			return new Vector3( vf.X, vf.Y, vf.Z );
		}

		public void CalcTemp(EvilMesh em, Matrix m)
		{
			Matrix norm = WithoutEdges( m );

			for (int i=0; i<em.Vertices.Length; i++)
			{
				PNT op = em.Vertices[i];
				op.Position = Transform( m, op.Position );
				//op.Normal = Transform( m, op.Normal );
				Vector3 n = Transform( m, op.Normal );
				n.Normalize();
				op.Normal = n;

				op.Color = CurrentColor;
				op.Texture0 = op.Texture0 + CurrentTextureOffset;
				em.TempVertices[i] = op;
			}
			ushort offset = (ushort)CurNumVerts;
			for (int i=0; i<em.Indices.Length; i++)
			{
				em.TempIndices[i] = (ushort)( offset + em.Indices[i] );
			}
		}

		public void CheckPush(EvilMesh em)
		{
			if ( ( em.Vertices.Length >= MaxVerts )
				|| ( em.Indices.Length >= MaxIndices ) )
			{
				string er = "Mesh has met or exceeded the batching limits: ";
				er += "\nMax Verts = "+MaxVerts;
				er += "\nMax Inds = "+MaxIndices;
				throw new ArgumentException( er );
			}

			if ( ( CurNumVerts + em.Vertices.Length >= MaxVerts )
				|| ( CurNumIndices + em.Indices.Length >= MaxIndices ) )
			{
				EndDrawing();
				BeginDrawing();
			}
		}

		public void PushTemp(EvilMesh em)
		{
			CheckPush( em );

			CurrentBuffer.Write( em.TempVertices );
			CurrentIndexBuffer.Write( em.TempIndices );

			CurNumIndices += em.Indices.Length;
			CurNumVerts += em.Vertices.Length;
		}

		public void Push(EvilMesh em, Matrix m)
		{
			CheckPush( em );
			CalcTemp( em, m );
			PushTemp( em );
		}

		public void EndDrawing()
		{
			Code.Assert( ( CurNumIndices % VertsPerPoly ) == 0 );
			Code.Assert( IsLocked );

			CurrentBuffer = null;
			CurrentIndexBuffer = null;
			VertexBuff.Unlock();
			IndexBuff.Unlock();
			IsLocked = false;

			//Graphics.UpdateMatrices( true );
			Device.VertexFormat = PNT.Format;
			Device.Indices = IndexBuff;
			Device.SetStreamSource( 0, VertexBuff, 0 );
			Device.DrawIndexedPrimitives( D3D.PrimitiveType.TriangleList, 
				0, 0, CurNumVerts, 0, 
				CurNumIndices / VertsPerPoly );

			Batches++;
		}
	}

	public class EvilGraphics
	{
		public D3D.Device Device;
		public EvilApp.EvilDiceApp AppOwner;
		public static Vector3 IdealCameraPos
		{
			get
			{
				Vector3 dir = new Vector3( 3.5f, 4, 4 );
				dir.Normalize();
				dir *= 3.0f;
				return dir;
			}
		}
		public bool UseEffects = false;
		public Vector3 CameraPos = IdealCameraPos;
		public Vector3 CameraLookAt = new Vector3( 0, 0, 0 );
		public Vector3 CameraUp = new Vector3( 0, 0, 1 );
		public D3D.CubeTexture EnvTexture;
		protected D3D.BaseTexture DiceTexture2;
		//public D3D.BaseTexture TileTexture;
		public EvilUI EUI = null;
		private ProjectState LastProjectState = new ProjectState();
		public D3D.Effect DieEffect = null;
		public bool IsReady = true;
		public const int DieTypesCount = 4;
		public bool IsShowStats = false;

		public double FadeInTime = 20.0;
		public float BackgroundDarkness = 0.5f;

		public Matrix WorldMatrix = Matrix.Identity;
		public Matrix WorldPreScale = Matrix.Identity;

		public DynamicBuffer DynamicBuffer = null;
		public EvilMesh Mesh_Tile;
		public EvilModel Model_NormalDie;
		public EvilModel Model_Cursor;
		public Scene[] Scenes = new Scene[0];

		public D3D.BaseTexture TileTexture
		{
			get
			{
				return CurrentScene.TileTexture;
			}
		}

		private static System.Collections.Specialized.HybridDictionary LoadedTextures = new System.Collections.Specialized.HybridDictionary();
		public static D3D.BaseTexture LoadTexture(D3D.Device device, string name)
		{
			name = name.ToLower();
			name = name.Replace( " ", "" );
			name = name.Replace( "\\", "/" );

			D3D.BaseTexture tex = (D3D.BaseTexture)LoadedTextures[ name ];
			if ( tex != null )
				return tex;

			tex = D3D.TextureLoader.FromFile( device, name );
			tex.GenerateMipSubLevels();
			LoadedTextures[ name ] = tex;
			return tex;
		}

		public void LoadGraphics()
		{
			System.Xml.XmlTextReader tr = new System.Xml.XmlTextReader( "Data/graphics.xml" );
			tr.WhitespaceHandling = System.Xml.WhitespaceHandling.None;

			tr.Read();
			tr.Read();

			Code.ReadSingleField( tr, this, this.GetType().GetField( "FadeInTime" ));
			Code.ReadSingleField( tr, this, this.GetType().GetField( "BackgroundDarkness" ));

			tr.Read();
			System.Reflection.FieldInfo fi = this.GetType().GetField( "Scenes" );
			Code.ReadSingleArray( tr, fi, this );

			tr.Close();

			if ( Profile.Default.ScenePreference < 0 )
			{
				foreach( Scene s in Scenes )
					s.GetMeshCollection( Device );
			}
			else
			{
				Scenes[ Profile.Default.ScenePreference % Scenes.Length ].GetMeshCollection( Device );
			}
		}

		public MeshCollection CurrentScene
		{
			get
			{
				int i = Profile.Default.ScenePreference;
				if ( i < 0 )
				{
					i = Profile.Default.GamesCount;
					if ( i < 0 )
						i = 0;
				}
				i %= Scenes.Length;

				return Scenes[i].GetMeshCollection( Device );
			}
		}

		public void SetTexture(D3D.BaseTexture tex)
		{
			if ( UseEffects )
			{
				D3D.EffectHandle teh;
				teh = DieEffect.GetParameterBySemantic( null, "TEXTURE0" );
				DieEffect.SetValue( teh, tex );
				DieEffect.EndPass();
				DieEffect.BeginPass(0);
			}
			else
			{
				Device.SetTexture( 0, tex );
				Device.SamplerState[0].MagFilter = D3D.TextureFilter.Linear;
				Device.SamplerState[0].MinFilter = D3D.TextureFilter.Linear;
				Device.SamplerState[0].MipFilter = D3D.TextureFilter.Linear;
			}
		}

		private Vector3[] cameraPath = null;
		public Vector3[] CameraPath()
		{
			if ( cameraPath != null )
				return cameraPath;
			Vector3[] cp = new Vector3[ 6 ];
			int to=0;
			float s = 2;
			cp[to++] = new Vector3( -s, -s, 20 );
			cp[to++] = new Vector3( -s, -s, 15 );
			cp[to++] = new Vector3( -s, -s, 5 );
			cp[to++] = new Vector3( -s, -s, 1 );
			cp[to++] = new Vector3( s, -s, 1 );
			cp[to++] = IdealCameraPos;

			for (int i=1; i<cp.Length; i++)
			{
				cp[i] = ( cp[i] + ( cp[i] - cp[i-1] ) );
			}

			cameraPath = cp;
			return cameraPath;
		}

		public Vector3 InterpolatePath(Vector3[] path, float f)
		{
			if ( f <= 0.0f )
				return path[0];
			if ( f >= 1.0f )
				return path[ path.Length-1 ];
			float p = f * (path.Length - 2);
			int i = (int)p;
			float t = p - ((float)i);

			Vector3 a = Vector3.Lerp( path[i], path[i+1], t );
			Vector3 b = Vector3.Lerp( path[i+1], path[i+2], t );
			return ( a + b )*0.5f;
		}

		public void OnDispose()
		{
			DiceTexture2.Dispose();
			EnvTexture.Dispose();
		}

		private class ProjectState
		{
			public Matrix World, View, Projection;
			public D3D.Viewport Viewport;

			public Vector3 Project(Vector3 v)
			{
				return Vector3.Project( v, Viewport, Projection, View, World );
			}

			public void UnSet(EvilGraphics eg)
			{
				eg.Device.Transform.World = World;
				eg.Device.Transform.View = View;
				eg.Device.Transform.Projection = Projection;
				eg.Device.Viewport = Viewport;
			}

			public void Set(EvilGraphics eg)
			{
				World = eg.Device.Transform.World;
				View = eg.Device.Transform.View;
				Projection = eg.Device.Transform.Projection;
				Viewport = eg.Device.Viewport;
			}
		}

		public Point WorldToScreen(Vector3 pos)
		{
			Vector3 s = LastProjectState.Project( pos );
			return new Point( (int)s.X, (int)s.Y );
		}

		private static Vector3[] mUnitDirs = {
			new Vector3( 1, 0, 0 ),
			new Vector3( 0, 1, 0 ),
			new Vector3( 0, 0, 1 )	 };
		public static Vector3 UnitDir(int dir)
		{
			Vector3 ans = mUnitDirs[ dir % 3 ];
			if ( dir >= 3 )
				ans *= -1.0f;
			return ans;
		}

		public void UnPrepDX()
		{
			if ( UseEffects )
			{
				DieEffect.EndPass();
				DieEffect.End();
			}

			Device.Indices = null;
		}

		private ProjectState ps = new ProjectState();
		public void UnPrepSubRender()
		{
			ps.UnSet( this );
			Device.RenderState.ZBufferEnable = true;
		}
		public void PrepSubRender(Rectangle r)
		{
			ps.Set( this );
			Device.RenderState.ZBufferEnable = false;

			D3D.Viewport vp = Device.Viewport;
			vp.Width = r.Width;
			vp.Height = r.Height;
			vp.X = r.X;
			vp.Y = r.Y;
			Device.Viewport = vp;

			//float s = 1.2f;
			//WorldMatrix = Matrix.Translation( -1, -1, -1 );
			//WorldMatrix *= Matrix.Scaling( s, s, s );
			Device.Transform.World = Matrix.Identity;

			CalcCamera( null );
			Device.Transform.View = Matrix.LookAtLH( CameraPos*1.5f, CameraLookAt, CameraUp );
			float ratio = ((float)r.Height) / ((float)r.Width);
			Matrix proj;
			proj = DX.Matrix.PerspectiveFovLH( ratio*(float)(Math.PI/4), 1.0f/ratio, 20.0f, 0.1f );
			Device.Transform.Projection = proj;

			UpdateMatrices(true);
		}

		public void CalcCamera(Game game)
		{
			if ( game == null )
			{
				CameraPos = IdealCameraPos;
				return;
			}
			if ( game.GameOver )
			{
				game.CamOffsets.Clear();
				game.FloatingTexts.Clear();

				double f = ( game.AbsoluteTime - game.Time );
				f = ( f - game.DefPreGameTime )*0.5;
				Matrix m = Matrix.RotationZ( (float)f );
				Vector4 v = Vector3.Transform( IdealCameraPos, m );
				CameraPos = new Vector3( v.X, v.Y, v.Z );
			}
			else if ( game.IsPreGame )
			{
				double t = game.AbsoluteTime;
				t /= game.DefPreGameTime;
				CameraPos = InterpolatePath( CameraPath(), (float)t );
			}
			else
				CameraPos = IdealCameraPos;

			for (int j=0; j<game.CamOffsets.Count; )
			{
				GameCamOffset ft = (GameCamOffset)game.CamOffsets[j];
				double f = ft.Progress( game );

				float dx, dy;
				ft.GetOffset( game, out dx, out dy );
				
				CameraPos.X += dx;
				CameraPos.Z += dy;

				if ( f >= 1.0 )
					game.CamOffsets.RemoveAt( j );
				else
					j++;
			}
		}

		public void PrepLiquidShader()
		{
			if ( UseEffects )
			{
				DieEffect.EndPass();
				DieEffect.End();
			}

			Device.TextureState[0].TextureTransform = D3D.TextureTransform.Count2;

			Device.RenderState.AlphaBlendEnable = true;
			Device.RenderState.SourceBlend = D3D.Blend.SourceAlpha;
			Device.RenderState.DestinationBlend = D3D.Blend.InvSourceAlpha;
		}

		public void UnPrepLiquidShader()
		{
			Device.RenderState.AlphaBlendEnable = false;
			Device.TextureState[0].TextureTransform = D3D.TextureTransform.Disable;
			Device.Transform.Texture0 = Matrix.Identity;

			if ( UseEffects )
			{
				DieEffect.Begin(D3D.FX.None);
				DieEffect.BeginPass(0);
			}
		}

		public void PrepDX(int width, int height, bool istwo)
		{
			UseEffects = Profile.Default.UseShaders;

			WorldMatrix = Matrix.Identity;
			Device.Transform.World = DX.Matrix.Identity;
			Device.Transform.View = DX.Matrix.LookAtLH( CameraPos,
				CameraLookAt, CameraUp );
			float ratio = ((float)Code.TheApp.ClientSize.Width) / ((float)Code.TheApp.ClientSize.Height);
			
			Device.Transform.Projection = DX.Matrix.PerspectiveFovLH( (float)(Math.PI/4.0), ratio, CurrentScene.ZFar, CurrentScene.ZNear );

			if ( DieEffect == null )
			{
				string errors = null;
				DieEffect = D3D.Effect.FromFile( Device, "Data/output.fx", 
					null, null, null, D3D.ShaderFlags.None, null, out errors );
				if ( errors != "" )
				{
					MessageBox.Show( errors, "Solid Shader Compile Error" );
				}
			}

			//Device.RenderState.FillMode = D3D.FillMode.WireFrame;

			Device.RenderState.CullMode = D3D.Cull.CounterClockwise;
			//Device.RenderState.ZBufferWriteEnable = true;
			//Device.RenderState.ZBufferEnable = true;
			Device.RenderState.ZBufferFunction = D3D.Compare.GreaterEqual;

			D3D.BaseTexture texture;
			texture = DiceTexture2;

			if ( UseEffects )
			{
				D3D.EffectHandle teh = DieEffect.GetParameterBySemantic( null, "TEXTURE0" );
				DieEffect.SetValue( teh, texture );

				teh = DieEffect.GetParameterBySemantic( null, "CUBETEXTURE0" );
				DieEffect.SetValue( teh, EnvTexture );
			}
			else
			{
				Device.SetTexture( 0, texture );
			}

			Device.SamplerState[0].MinFilter = D3D.TextureFilter.Linear;
			Device.SamplerState[0].MagFilter = D3D.TextureFilter.Linear;

			int size = Math.Max( width, height );
			float sc = 1.0f / ((float)(size));
			WorldMatrix = Matrix.Translation( 1.0f, 1.0f, 0.0f );
			WorldPreScale = WorldMatrix;
			WorldMatrix *= Matrix.Scaling( sc, sc, sc );
			WorldMatrix *= Matrix.Translation( -1, -1, sc );

			Device.Transform.World = WorldMatrix;
			WorldMatrix = Matrix.Identity;

			if ( UseEffects )
			{
				DieEffect.Begin( D3D.FX.None );
				DieEffect.BeginPass( 0 );
			}

			UpdateMatrices(true);
		}

		public void UpdateMatrices(D3D.Effect effect)
		{
			if ( UseEffects )
				effect.EndPass();

			Matrix world = Device.Transform.World;
			Matrix view = Device.Transform.View;
			Matrix proj = Device.Transform.Projection;

			Matrix final = world * view * proj;
			D3D.EffectHandle eh = effect.GetParameterBySemantic( 
				null, "MODELPROJECTION_MATRIX" );
			effect.SetValue( eh, final );

			eh = effect.GetParameterBySemantic( null, "MODELVIEW_MATRIX" );
			if ( eh != null ) effect.SetValue( eh, world );

			eh = effect.GetParameterBySemantic( null, "CAMERA_POS" );
			Vector4 campos = new Vector4( CameraPos.X, CameraPos.Y, CameraPos.Z, 1.0f );
			if ( eh != null ) effect.SetValue( eh, campos );

			if ( UseEffects )
				effect.BeginPass( 0 );
		}

		public void UpdateMatrices(bool really)
		{
			if ( !really )
				return;

			UpdateMatrices( DieEffect );
		}

		public double[] RandVals = {
		0.026334085
		,0.34608307
		,0.807806974
		,0.656584289
		,0.171656859
		,0.398459785
		,0.555986775
		,0.248275767
		,0.805925954
		,0.478120744
		,0.934863159
		,0.421955392
		,0.123860792
		,0.846040501
		,0.707820188
		,0.978808961
		,0.515875669
		,0.223446871
		,0.531755155
		,0.481892237
		,0.829675141
		,0.729971407
		,0.210500312
		,0.769939379
		,0.327700162
								   };

		public void GraphicsThink(double dt)
		{
			myRotX += ((float)(dt * 0.5));
			AnimTime += dt;

		}

		private float myRotX=0;
		public double AnimTime=0;
		public void DrawBackground2(double fade)
		{
			Matrix start = WorldMatrix;
			Matrix st = Matrix.Translation( -7, -9.5f, -0.5f ) * start;

			uint m = (uint)( fade * BackgroundDarkness * 0xFF );
			m = ( m ) | ( m << 8 ) | ( m << 16 ) | ( m << 24 );

			Model_NormalDie.SetTexture( this );
			DynamicBuffer.CurrentColor = m;
			DynamicBuffer.BeginDrawing();

			float len = 2.5f;

			double p = ( AnimTime / 2.0 );
			int step = (int)p;
			float dy = len * (float)( p - step );

			for (int y=0; y<6; y++)
			{
				for (int x=0; x<5; x++)
				{
					float r = ((float)(RandVals[ ( x+((y+step*4)%5)*5 )%RandVals.Length ] * Math.PI));
					if ( ( x + y + step )%2 == 0 )
						r *= -1.0f;
					r += myRotX;

					float fx = 0.5f + ((float)x)*len;
					float fy = 0.5f + ((float)y)*len + dy;
					Matrix rot = Matrix.RotationYawPitchRoll( r, r, r );
					Matrix trans = Matrix.Translation( fx, fy, 0 );
					WorldMatrix = rot * trans * st;
					DrawDie2( DieType.Dark );
					//DrawCursor2();
				}
			}

			DynamicBuffer.EndDrawing();
			DynamicBuffer.CurrentColor = DynamicBuffer.White;

			WorldMatrix = start;
		}

		public void DrawCursor2()
		{
			//DynamicBuffer.Push( Mesh_Cursor, WorldMatrix );
			DynamicBuffer.Push( Model_Cursor.EvilMesh, WorldMatrix );
			/*
			int offset = CursIndsStart;
			int count = CursIndsCount;
			Device.DrawIndexedPrimitives(
				D3D.PrimitiveType.TriangleList,
				0, 0, CursVertStart+CursVertsCount*2, offset, count/3 );
			*/
		}

		public void DrawTile2()
		{
			DynamicBuffer.Push( Mesh_Tile, WorldMatrix );
			/*
			int offset = TileIndsStart;
			int count = TileIndsCount;
			Device.DrawIndexedPrimitives( D3D.PrimitiveType.TriangleList,
				0, 0, TileVertsStart+TileVertsCount, offset, count/3 );
			*/
		}

		public void DrawDie2(DieType tp)
		{
			switch ( tp )
			{
				case DieType.Dark:
					DynamicBuffer.CurrentTextureOffset = new Vector2( 0, 0.5f );
					DynamicBuffer.Push( Model_NormalDie.EvilMesh, WorldMatrix );
					//DynamicBuffer.Push( Mesh_DarkDie, WorldMatrix );
					break;
				case DieType.Fifteen:
					DynamicBuffer.CurrentTextureOffset = new Vector2( 0.5f, 0.5f );
					DynamicBuffer.Push( Model_NormalDie.EvilMesh, WorldMatrix );
					//DynamicBuffer.Push( Mesh_FifteenDie, WorldMatrix );
					break;
				case DieType.Inverted:
					DynamicBuffer.CurrentTextureOffset = new Vector2( 0.5f, 0.0f );
					DynamicBuffer.Push( Model_NormalDie.EvilMesh, WorldMatrix );
					//DynamicBuffer.Push( Mesh_InvDie, WorldMatrix );
					break;
				case DieType.Normal:
					DynamicBuffer.Push( Model_NormalDie.EvilMesh, WorldMatrix );
					//DynamicBuffer.Push( Mesh_NormalDie, WorldMatrix );
					break;
			}
			DynamicBuffer.CurrentTextureOffset = new Vector2( 0, 0 );

			/*
			int offset = ((int)tp) * IndicesPerDie2;
			int count = IndicesPerDie2;
			Device.DrawIndexedPrimitives(
				D3D.PrimitiveType.TriangleList,
				0, 0, VertsPerDie2*NumDiePacks, offset, count/3 );
				*/
		}

		public Vector3 TilePos(Tile t)
		{
			return new Vector3( (float)(t.PosX*2), (float)(t.PosY*2), 0 );
		}

		public Vector3 DirVec(Dir d)
		{
			switch ( d )
			{
				case Dir.East:
					return new Vector3( 1, 0, 0 );
				case Dir.West:
					return new Vector3( -1, 0, 0 );
				case Dir.South:
					return new Vector3( 0, 1, 0 );
				case Dir.North:
					return new Vector3( 0, -1, 0 );
				default:
					Code.BadPlace();
					return new Vector3( 0, 0, 0 );
			}
		}

		public void DrawFullDie(Die d, Matrix start, bool translate)
		{
			if ( d.IsAlive )
				Code.Assert( d.TileLoc.DieHeld == d );
			Vector3 offset = TilePos( d.TileLoc );
			Matrix animrot = Matrix.Identity;
			if ( d.State==DieState.Sliding || d.State==DieState.Rolling )
			{
				Vector3 from = TilePos( d.PreviousLoc );
				float p = d.Progress;
				offset = offset*p + from*(1.0f-p);
			}
			if ( d.State==DieState.Rolling )
			{
				Vector3 v = DirVec( d.LastRotDir );
				v = Vector3.Cross( v, new Vector3( 0, 0, 1 ) );
				float ang = ((float)(Math.PI/2)) * ( 1.0f - d.Progress);
				animrot = Matrix.RotationAxis( v, ang );
			}
			if ( d.State == DieState.Rising )
			{
				float p = d.Progress;
				float len = 0.1f;
				if ( p < len )
				{
					p = 1.0f - ( p / len );

					offset += new Vector3( 0, 0, p*8.0f );

					float r = p*-2.0f;
					animrot *= Matrix.RotationYawPitchRoll( r, r, r );
					float s = 1.0f - p;
					animrot *= Matrix.Scaling( s, s, s );
				}
				else
				{
					float t = (float)Math.Sin( Math.PI * p * 9 );
					t = 1.0f + t*0.05f;
					animrot *= Matrix.Scaling( t, t, t );
				}
			}
			if ( d.State == DieState.Sinking )
			{
				float p = d.Progress;
				if ( 1.0f - p > d.Game.DefSquashHeight )
				{
					float pi = (float)Math.PI;
					float tilt = ((float)Math.Sin( p*pi*6.0f ))*(0.05f);
					float ang = p*pi*40.0f + d.RandFloat;

					Vector3 about = new Vector3(
						(float)Math.Cos(ang), (float)Math.Sin(ang), 0 );
					Matrix warp = Matrix.RotationAxis( about, tilt );
					animrot = warp*animrot;
				}
				else
				{
					p = ( 1.0f - p ) / d.Game.DefSquashHeight;
					float s = 0.5f + p*0.5f;
					animrot = Matrix.Scaling( s, s, 1 );
				}
			}

			Matrix world = d.Rotation * animrot;
			if ( translate )
			{
				offset += new Vector3( 0, 0, d.VisualHeight-2.0f );
				Matrix trans = Matrix.Translation( offset );
				world *= trans;
			}
			WorldMatrix = world * start;
			//UpdateMatrices();
			DrawDie2( d.DieType );
		}

		public void DrawBoard(Game game)
		{
			Matrix start = WorldMatrix;
			LastProjectState.Set( this );

			DynamicBuffer.Batches = 0;
			Model_Cursor.SetTexture( this );
			DynamicBuffer.BeginDrawing();

			foreach ( Cursor c in game.Cursors )
			{
				Vector3 offset = TilePos( c.TileLoc );
				if ( c.State != DieState.Idle )
				{
					Vector3 from = TilePos( c.PreviousLoc );
					float p = c.Progress;
					offset = offset*p + from*(1.0f-p);
				}
				if ( c.TileLoc.DieHeld != null )
				{
					float h = c.TileLoc.DieHeld.VisualHeight;
					if ( c.TileLoc.DieHeld.State == DieState.Rolling )
					{
						h = ( h - 1.0f );
						h = ( h * 2.0f );
					}
					offset += new Vector3( 0, 0, h );
				}
				c.ScreenPos = WorldToScreen( offset + (new Vector3(0,0,1.75f)) );
				Matrix rot = Matrix.RotationZ( c.Spin );
				Matrix trans = Matrix.Translation( offset );
				WorldMatrix = rot * trans * start;

				Color cr = c.Team.Color;
				if ( game.Cursors.Length == 1 )
					cr = Color.LightSkyBlue;
				DynamicBuffer.CurrentColor = (uint)cr.ToArgb();

				DrawCursor2();
			}
			DynamicBuffer.CurrentColor = DynamicBuffer.White;

			DynamicBuffer.EndDrawing();
			Model_NormalDie.SetTexture( this );
			DynamicBuffer.BeginDrawing();

			for (int i=game.Tiles.Length-1; i>=0; i--)
			{
				Tile t = (Tile)game.Tiles[i];
				if ( t.DieHeld != null )
					DrawFullDie( t.DieHeld, start, true );
			}

			DynamicBuffer.EndDrawing();
			SetTexture( TileTexture );
			DynamicBuffer.BeginDrawing();

			for (int i=game.Tiles.Length-1; i>=0; i--)
			{
				Tile t = (Tile)game.Tiles[i];
				Vector3 tp = TilePos( t );
				Matrix trans = Matrix.Translation( tp );
				if ( !t.IsWalkable )
				{
					float s = 0.5f;
					trans = Matrix.Scaling(s,s,1.0f) * trans;
				}
				WorldMatrix = trans * start;
				if ( t.CalcScreenPos )
				{
					Vector3 p = tp + new Vector3( 0, 0, 2.5f );
					t.ScreenPos = WorldToScreen( p );
				}
				DrawTile2();
			}
			WorldMatrix = start;
			DynamicBuffer.EndDrawing();
			Matrix oldworld = Device.Transform.World;
			Device.Transform.World = WorldPreScale;

			if ( Profile.Default.ShowBackground )
				CurrentScene.Draw( this );

			Device.Transform.World = oldworld;
			Model_NormalDie.SetTexture( this );
			UpdateMatrices( true );

			DrawGameUI(game);

			//Code.Status = "Batches="+DynamicBuffer.Batches;
		}

		public void DrawGameHUD(Game game)
		{
			if ( game.HUDNode == null )
			{
				VNode.VList right, left;
				EvilUI ui = this.EUI;

				right = new EvilGame.VNode.VList( ui );
				right.IsVertical = true;
				left = new EvilGame.VNode.VList( ui );
				left.IsVertical = true;

				game.HUDNode = new VNode.VSides( left, right, ui );

				int index = 0;
				Size diesize = new Size( 65, 65 );
				foreach (Team t in game.Teams)
				{
					t.HUDDie = new VNode.VFixedSize( null, diesize, ui );
					t.HUDText = new VNode.VText( "Not yet", ui );
					TextType tt = new TextType( 1 );
					tt.Color = t.Color;
					((VNode.VText)t.HUDText).TextType = tt;
					VNode text = t.HUDText;

					if ( game.Teams.Length > 1 )
					{
						string s = "";
						int count = 0;
						foreach (Cursor c in game.Cursors)
						{
							if ( c.Team == t )
							{
								if ( count%2 == 1 )
									s += ", ";
								if ( count!=0 && (count%2==0) )
									s += "\n";
								if ( c.Player!=null )
									s += c.Player.Name;
								count++;
							}
						}

						TextType nt = new TextType( 0 );
						VNode.VText vt = new VNode.VText( s, ui );
						vt.TextType = nt;
						nt.Color = t.Color;
						VNode.VList nl = new VNode.VList( ui );
						nl.IsVertical = true;
						nl.Add( vt );
						nl.Add( text );
						text = nl;
					}

					VNode.VList list = new EvilGame.VNode.VList( ui );
					list.IsVertical = false;
					if ( index%2 == 0 )
					{
						list.Add( t.HUDDie );
						list.Add( text );
						left.Add( list );
					}
					else
					{
						list.Add( text );
						list.Add( t.HUDDie );
						right.Add( list );
					}
					index++;
				}
			}

			foreach (Team t in game.Teams)
			{
				((VNode.VText)t.HUDText).Text = game.TeamHUD( t );
			}

			VNode root = game.HUDNode;
			root.CalcPlacement( EUI.FullRect );

			foreach (Team t in game.Teams)
			{
				Die d = null;
				foreach ( Cursor c in game.Cursors )
				{
					if ( c.Team == t )
						d = c.TileLoc.DieHeld;
				}
				if ( d != null )
				{
					Rectangle r = t.HUDDie.Placement;
					PrepSubRender( r );
					DynamicBuffer.BeginDrawing();
					DrawFullDie( d, Device.Transform.World, false );
					DynamicBuffer.EndDrawing();
					UnPrepSubRender();
				}
			}
		}

		public void DrawGameUI(Game game)
		{
			if ( EUI == null )
				EUI = new EvilUI( Device );

			DrawGameHUD( game );

			EUI.PrepDX();

			game.HUDNode.Draw();
			game.CustomUI( EUI );

			TextType tt = new TextType(1);
			tt.SelectAlignment( 0, -1 );
			EUI.DrawText( game.TitleString, EUI.FullRect, tt );
			tt.SelectAlignment( 1, -1 );
			tt.Size = 0;
			EUI.DrawText( game.TopRightString, EUI.FullRect, tt );
			tt.SelectAlignment( 1, 1 );
			EUI.DrawText( game.BottomRightString, EUI.FullRect, tt );
			tt.Size = 1;

			bool isover = game.GameOver;
			if ( isover )
			{
				tt.SelectAlignment( 0, 1 );
				tt.Color = Color.YellowGreen;
				EUI.DrawText( game.EndGameString, EUI.FullRect, tt );

			}

			if ( isover || IsShowStats )
			{
				VNode stats = game.GetStatsHUD( EUI, IsShowStats );
				stats.CalcPlacement( EUI.FullRect );
				stats.Draw();
			}

			/*
			if ( game.IsShowScores )
			{
				int[] alignments = { -1, -1, 1, -1,
									-1, 1, 1, 1 };
				for (int i=0; i<game.Teams.Length; i++)
				{
					Team team = game.Teams[i];
					string s = game.TeamHUD( team );
					tt.SelectAlignment( alignments[i*2], alignments[i*2+1] );
					tt.Color = Color.FromArgb( team.Color.ToArgb() | 0x7F000000 );
					EUI.DrawText( s, EUI.FullRect, tt );
				}
			}
			*/

			tt.Size = 0;
			if ( !Code.TheApp.IsSinglePlayer )
			{
				foreach ( Cursor c in game.Cursors )
				{
					tt.Color = c.Team.Color;
					string name = c.Player.Name;
					EUI.DrawTextAt( name, tt, c.ScreenPos );
				}
			}

			for (int j=0; j<game.FloatingTexts.Count; )
			{
				FloatingText ft = (FloatingText)game.FloatingTexts[j];
				double f = ft.Progress( game );
				tt.Color = ft.Color;
				tt.Size = 0;
				Point p = ft.ScreenPos;
				p = new Point(p.X, p.Y + (int)(f*-100.0) );
				EUI.DrawTextAt( ft.Name, tt, p );

				if ( f >= 1.0 )
					game.FloatingTexts.RemoveAt( j );
				else
					j++;
			}

			VNode screen = game.ScreenMenu;
			if ( screen != null )
			{
				screen.CalcPlacement( EUI.FullRect );
				screen.Draw();
			}

			EUI.UnPrepDX();
		}

		public EvilGraphics(D3D.Device device, EvilUI ui, EvilApp.EvilDiceApp app)
		{
			Code.TheApp = app;
			AppOwner = app;
			Device = device;

			DiceTexture2 = LoadTexture( device, "Data/Meshes/Combined_Diffuse.png" );
			DiceTexture2.GenerateMipSubLevels();

			string envtex = "Data/uffizi_cross.dds";
			envtex = "Data/stpeters_cross.dds";
			EnvTexture = D3D.TextureLoader.FromCubeFile( device, envtex );
			EnvTexture.GenerateMipSubLevels();

			EUI = ui;

			Device.Disposing += new EventHandler(device_Disposing);

			DynamicBuffer = new DynamicBuffer( Device, this );

			//Mesh_Tile = new EvilMesh( DiceVerts2(), DiceIndexArray(), TileIndsStart, TileIndsCount );
			PNT[] tilev = { new PNT(new Vector3(-1,-1,-1),new Vector3(0,0,1),0,0),
							  new PNT(new Vector3( 1,-1,-1),new Vector3(0,0,1),1,0),
							  new PNT(new Vector3( 1, 1,-1),new Vector3(0,0,1),1,1),
							  new PNT(new Vector3(-1, 1,-1),new Vector3(0,0,1),0,1) };
			ushort[] tilei = { 0, 1, 2, 2, 3, 0 };
			Mesh_Tile = new EvilMesh( tilev, tilei, 0, tilei.Length );

			float halfpi = (float)( Math.PI / 2 );
			Matrix m;

			Model_Cursor = new EvilModel( "Data/Meshes/Pointer.x", Device, null );
			m = Matrix.RotationX( halfpi );
			Model_Cursor.EvilMesh.ApplyToMeshes( m );

			Model_NormalDie = new EvilModel( "Data/Meshes/Dice.x", Device, null );
			Model_NormalDie.Texture = this.DiceTexture2;
			m = Matrix.RotationX( halfpi );
			m = m * Matrix.RotationZ( (float)Math.PI );
			float s = 1.0f / 1.15f;
			m *= Matrix.Scaling( s, s, s );
			Model_NormalDie.EvilMesh.ApplyToMeshes( m );
			Model_NormalDie.EvilMesh.ApplyToTextures( Matrix.Scaling(0.5f,0.5f,1.0f) );
		}

		private void device_Disposing(object sender, EventArgs e)
		{
			this.IsReady = false;
			//OnDispose();
		}
	}

	public class MeshInstance
	{
		public string MeshFile = "NOT_A_FILE";
		public float Scale = 1.0f;
		public float TransX=0, TransY=0, TransZ=0;

		public float TexShift = 1.0f;
		public double TexRate = 1.0;
		public float TexDU = 1.0f;
		public float TexDV = 1.0f;

		public EvilModel Model = null;
		public Matrix Transform = Matrix.Identity;

		public static Matrix TextureTranslation(float du, float dv)
		{
			Matrix m = Matrix.Identity;
			m.M31 = du;
			m.M32 = dv;
			return m;
		}

		public Matrix TextureMatrix(double time)
		{
			float cosx = (float)Math.Cos( TexRate * time );
			float siny = (float)Math.Sin( TexRate * time );
			cosx = ( cosx * TexShift ) + ( TexDU * ((float)time) );
			siny = ( siny * TexShift ) + ( TexDV * ((float)time) );

			return TextureTranslation( cosx, siny );
		}

		public void Init(MeshCollection mc, D3D.Device device)
		{
			Model = new EvilModel( MeshFile, device, mc );

			Matrix m = Matrix.RotationX( (float)( Math.PI / 2.0 ) );
			m *= Matrix.Scaling( Scale, Scale, Scale );
			m *= Matrix.Translation( TransX, TransY, TransZ );
			Transform = m;
		}
	}

	public class Scene
	{
		public string Name = "NONE";
		public string XmlFile = "NONE";

		private MeshCollection MeshCol = null;
		public MeshCollection GetMeshCollection(D3D.Device device)
		{
			if ( MeshCol != null )
				return MeshCol;
			MeshCol = new MeshCollection();
			MeshCol.LoadFromFile( XmlFile, device );
			return MeshCol;
		}
	}

	public class MeshCollection
	{
		public MeshInstance[] Instances = new MeshInstance[0];
		public MeshInstance[] Animated = new MeshInstance[0];
		public float ZNear = 0.1f;
		public float ZFar = 20.0f;
		public string Tile;
		public D3D.BaseTexture TileTexture = null;

		public void Draw(EvilGraphics eg)
		{
			Matrix world = eg.Device.Transform.World;

			foreach (MeshInstance mi in Instances)
			{
				mi.Model.SetTexture( eg );
				eg.Device.Transform.World = mi.Transform * world;
				eg.UpdateMatrices( true );

				mi.Model.Mesh.DrawSubset( 0 );
			}
			if ( Animated.Length > 0 )
			{
				eg.PrepLiquidShader();

				foreach (MeshInstance mi in Animated)
				{
					eg.Device.SetTexture( 0, mi.Model.Texture );
					eg.Device.Transform.Texture0 = mi.TextureMatrix( eg.AnimTime );
					eg.Device.Transform.World = mi.Transform * world;
					mi.Model.Mesh.DrawSubset( 0 );
				}

				eg.UnPrepLiquidShader();
			}

			eg.Device.Transform.World = world;
		}

		public void LoadFromFile(string filename, D3D.Device device)
		{
			System.Xml.XmlTextReader tr = new System.Xml.XmlTextReader( filename );
			tr.WhitespaceHandling = System.Xml.WhitespaceHandling.None;

			tr.Read();
			tr.Read();

			Code.ReadFields( tr, this );
			Code.ReadArrays( tr, this );

			tr.Close();

			foreach (MeshInstance mi in Instances)
			{
				mi.Init( this, device );
			}
			foreach (MeshInstance mi in Animated)
			{
				mi.Init( this, device );
			}
			TileTexture = EvilGraphics.LoadTexture( device, Tile );
		}
	}

	public class EvilModel
	{
		public D3D.Mesh Mesh;
		public D3D.BaseTexture Texture;
		public D3D.Material Material;
		public D3D.Device Device;
		public EvilMesh EvilMesh;
		public string TexFileName;

		public void SetTexture(EvilGraphics eg)
		{
			eg.SetTexture( Texture );
		}

		public EvilModel(string filename, D3D.Device device, MeshCollection mc)
		{
			Device = device;
			D3D.ExtendedMaterial[] materials;
			Mesh = D3D.Mesh.FromFile( filename, D3D.MeshFlags.SystemMemory, Device, out materials );
			Material = materials[0].Material3D;

			string tex = materials[0].TextureFilename;
			Texture = null;
			TexFileName = tex;
			if ( mc != null )
			{
				foreach (MeshInstance mi in mc.Instances)
				{
					if ( mi.Model!=null && mi.Model.TexFileName==tex )
					{
						Texture = mi.Model.Texture;
						break;
					}
				}
				foreach (MeshInstance mi in mc.Animated)
				{
					if ( mi.Model!=null && mi.Model.TexFileName==tex )
					{
						Texture = mi.Model.Texture;
						break;
					}
				}
			}
			if ( Texture==null )
			{
				Texture = EvilGraphics.LoadTexture( Device, "Data/Meshes/" + tex );
				Texture.GenerateMipSubLevels();
			}

			EvilMesh = new EvilMesh( Mesh );
			filename = null;
		}
	}

	public class MusicTrack
	{
		public string FileName;
		public string TrackName = "NONE";
		public Audio LoadedFile = null;
		public EvilMusic Owner;

		public void Ensure(EvilMusic em)
		{
			Owner = em;
			if ( LoadedFile != null )
				return;
			LoadedFile = new Audio( FileName );
			LoadedFile.Ending += new EventHandler(LoadedFile_Ending);
		}

		private void LoadedFile_Ending(object sender, EventArgs e)
		{
			Owner.PlayNext();
		}
	}

	public class EvilMusic
	{
		public string TitleTrack = "?";
		public bool IsNewTrackPerGame = false;
		public bool IsShuffle = false;
		public bool IsRepeat = false;
		public MusicTrack[] Tracks;
		public EvilAudio Controller;
		public MusicTrack LastPlayed;

		public void OnTitle()
		{
			PlayTrack( TitleTrack );
		}

		public void OnNewGame()
		{
			if ( IsNewTrackPerGame )
				PlayNext();
		}

		public void OnVolumeChanged()
		{
			if ( LastPlayed!=null && LastPlayed.LoadedFile!=null )
			{
				LastPlayed.LoadedFile.Volume = MusicVolume;
			}
		}

		protected MusicTrack FindTrack(string name)
		{
			foreach ( MusicTrack mt in Tracks )
			{
				if ( mt.TrackName == name )
					return mt;
			}
			return null;
		}

		public int MusicVolume
		{
			get
			{
				int mv = Controller.MusicVolume;
				return Controller.MathVolume( mv );
			}
		}

		protected void PlayThisTrack(MusicTrack mt)
		{
			if ( !Controller.EnableSounds )
				return;

			foreach ( MusicTrack m in Tracks )
			{
				if ( m.LoadedFile != null )
					m.LoadedFile.Stop();
			}
			
			mt.Ensure(this);
			Code.Assert( mt.LoadedFile != null );
			mt.LoadedFile.Volume = MusicVolume;
			mt.LoadedFile.Play();
			LastPlayed = mt;
		}

		public void PlayTrack(string name)
		{
			if ( Tracks.Length == 0 )
				return;

			MusicTrack mt = FindTrack( name );
			if ( mt == null )
				mt = Tracks[0];
			PlayThisTrack( mt );
		}

		public void PlayNext()
		{
			if ( IsRepeat )
			{
				Code.AssertOnNull( LastPlayed );
				PlayThisTrack( LastPlayed );
				return;
			}

			int next = 0;
			for (int i=0; i<Tracks.Length; i++)
			{
				if ( Tracks[i] == LastPlayed )
					next = i + 1;
			}
			if ( IsShuffle )
				next = Code.Random.Next( Tracks.Length );
			PlayThisTrack( Tracks[ next % Tracks.Length ] );
		}

		public void LoadFromFile(string filename, EvilAudio ea)
		{
			Controller = ea;
			System.Xml.XmlTextReader tr = new System.Xml.XmlTextReader( filename );
			tr.WhitespaceHandling = System.Xml.WhitespaceHandling.None;

			tr.Read();
			tr.Read();

			Code.ReadFields( tr, this );
			Code.ReadArrays( tr, this );

			tr.Close();
		}

	}

	public class EvilAudio
	{
		public Microsoft.DirectX.DirectSound.Device AudioDevice = null;
		public SecondaryBuffer MatchSound = null;
		public SecondaryBuffer RolledSound = null;
		public SecondaryBuffer ClickSound = null;
		public SecondaryBuffer ShortClickSound = null;
		public SecondaryBuffer LevelStartSound = null;
		public SecondaryBuffer MP_NewLeaderSound = null;
		public bool EnableSounds = true;
		public int Volume;
		public int MusicVolume;
		public const int VolumeLevels = 5;
		public EvilMusic Music;

		public void FromProfile(Profile p, bool justvolume)
		{
			Volume = p.SoundVolume;
			MusicVolume = p.MusicVolume;
			if ( !justvolume )
			{
				EnableSounds = p.EnableSounds;
			}
			Music.OnVolumeChanged();
		}

		public int MathVolume(int v)
		{
			int min = (int)DX.DirectSound.Volume.Min;
			int max = (int)DX.DirectSound.Volume.Max;
			min += ( max - min ) / 2;
			int d = ( max - min ) / VolumeLevels;
			return min + d*v;
		}

		private void NewPlay(SecondaryBuffer sb)
		{
			if ( !EnableSounds )
				return;
			BufferPlayFlags bpf = BufferPlayFlags.Default;
			sb.Stop();
			sb.Volume = MathVolume( Volume );
			sb.Play( 0, bpf );
		}

		public void Play(Sounds s)
		{
			switch ( s )
			{
				case Sounds.Rolled:
					NewPlay( RolledSound );
					break;
				case Sounds.Sunk:
					NewPlay( MatchSound );
					break;
				case Sounds.Click:
					NewPlay( ClickSound );
					break;
				case Sounds.ShortClick:
					NewPlay( ShortClickSound );
					break;
				case Sounds.LevelStart:
					NewPlay( LevelStartSound );
					break;
				case Sounds.MP_NewLeader:
					NewPlay( MP_NewLeaderSound );
					break;
				default:
					Code.TODO();
					break;
			}
		}

		public SecondaryBuffer LoadSound(string filename)
		{
			Code.Assert( EnableSounds == true );
			Stream m_stream = File.Open( filename, FileMode.Open );
			BufferDescription bd = new BufferDescription();
			bd.BufferBytes = (int)m_stream.Length;
			bd.ControlEffects = false;
			bd.ControlVolume = true;

			SecondaryBuffer sound = new SecondaryBuffer( m_stream, bd, AudioDevice );
			m_stream.Close();
			return sound;
		}

		public EvilAudio(EvilApp.EvilDiceApp app, Profile p)
		{
			Music = new EvilMusic();
			FromProfile( p, false );

			if ( EnableSounds )
			{
				AudioDevice = new Device( );
				AudioDevice.SetCooperativeLevel( app.Handle, CooperativeLevel.Priority );

				MatchSound = LoadSound( "Data/DiceMatch.wav" );
				RolledSound = LoadSound( "Data/DiceMove.wav" );
				ClickSound = LoadSound( "Data/Click.wav" );
				ShortClickSound = LoadSound( "Data/ShortClick.wav" );
				LevelStartSound = LoadSound( "Data/LevelStart.wav" );
				MP_NewLeaderSound = LoadSound( "Data/MP_NewLeader.wav" );

				Music.LoadFromFile( "Data/Music/music.xml", this );
			}
		}
	}
}
