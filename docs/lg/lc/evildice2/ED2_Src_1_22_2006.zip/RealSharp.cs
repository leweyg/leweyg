using System;
using System.Reflection;
using System.IO;
using System.Collections;
using System.CodeDom.Compiler;

//Changes:
//	Allowed it to load the wrapped types from the main assembly

namespace RealSharp
{
	public class replicateAttribute : Attribute
	{
	}

	public class transientAttribute : Attribute
	{
	}
	public class simulateAttribute : Attribute
	{
	}

	public interface IDataPacker
	{
		void Push_string(string s);
		void Push_int(int i);
		void Push_ushort(ushort v);
		void Push_RSActor(RSActor a);
		void Push_byte(byte b);
		void Push_float(float f);
		void Push_bool(bool b);

		void StartList();
		void EndList();
		

	}

	public interface IDataUnPacker
	{
		string Pop_string();
		int Pop_int();
		ushort Pop_ushort();
		RSActor Pop_RSActor();
		byte Pop_byte();
		float Pop_float();
		bool Pop_bool();
		
		void UnStartList();
		bool IsMoreInList();
		void UnEndList();
	}

	public class RSActor
	{
		[transient] public ushort NetId;
		[transient] public RSManager Manager;
		[transient] public RSType NetType;

		public virtual void OnTick(double dt) {}

		public virtual void rs_FullPack(IDataPacker ip){}
		public virtual void rs_FullUnPack(IDataUnPacker ip){}
		public virtual void rs_UpdatePvs(){}
		public virtual void rs_UpdatePack(IDataPacker dp){}
		public virtual void rs_UpdateUnPack(IDataUnPacker ip){}
		public virtual void rs_CallFunction(byte id, IDataUnPacker args){}
		
		public RSActor()
		{
			if ( RSManager.NextSpawnType != GetType() )
				throw new InvalidOperationException( "You must use Manager.NewActor instead of new" );
			RSManager.NextSpawnType = null;
		}
	}

	public class RSField : IComparable
	{
		public FieldInfo BasisField;
		public byte Id;
		public string Name;

		public RSField(FieldInfo fi)
		{
			BasisField = fi;
			Name = fi.Name;
		}

		public int CompareTo(object obj)
		{
			RSField other = (RSField)obj;
			return ( Name.CompareTo( other.Name ) );
		}
	}

	public class RSType
	{
		public Type BasisType;
		public Type WrappedType;
		public ushort NetTypeId;
		public string Name;
		public ArrayList Fields = new ArrayList();
		public ArrayList RepFields = new ArrayList();
		public ArrayList SimFields = new ArrayList();
		public RSType(Type t)
		{
			BasisType = t;
			Name = t.Name;
		}

		public string PackTypeName(Type t)
		{
			if ( t == typeof( int ) )
				return "int";
			if ( t == typeof( string ) )
				return "string";
			if ( t.IsSubclassOf( typeof( RSActor ) ) )
				return "RSActor";
			if ( t == typeof( ushort ) )
				return "ushort";
			if ( t == typeof( float ) )
				return "float";
			if ( t == typeof( double ) )
				return "float";
			if ( t == typeof( bool ) )
				return "bool";
			if ( t.IsSubclassOf(typeof (Array)))
				 throw new ArgumentException() ;
			return "TODO";
		}

		public string UnPackCastName(Type t)
		{
			return "("+CorrectFullName(t)+")";
		}
		public string CorrectFullName(Type t)
		{
			string s = t.FullName;
			return s.Replace( "+", "." );
		}
		public string PackLines(string name, Type t)
		{
			if ( t.IsSubclassOf(typeof (Array)))
			{
				Type el = t.GetElementType();
				string arrline="dp.Push_ushort( (ushort)"+name+".Length);\n";
				string feline="foreach ( "+CorrectFullName(el)+" i in "+name+")\n";
				string inside=PackLines( "i", el );
				return (arrline+feline+"{\n"+inside+"}\n");

			}
			if ( t.IsEnum )
			{
				return ("dp.Push_byte( (byte)"+name+");");
			}
			if ( t == typeof( System.Drawing.Color ) )
			{
				return "dp.Push_int( "+name+".ToArgb() );";
			}
			if ( t == typeof( double ) )
			{
				return "dp.Push_float( (float)"+name+" );";
			}
			string line=PackTypeName( t );
			line="\n\t\t\t\tdp.Push_"+line;
			line+="("+name+");";
			//System.Console.WriteLine(line);
			return line;
			
		}
		public string UnPackLines(string name, Type t) 
		{
			/*string tn = PackTypeName( fi.BasisField.FieldType );
			string line = "\t\t\tthis."+fi.Name+"=";*/
			
			if ( t.IsSubclassOf(typeof (Array)))
			{
				Type el =t.GetElementType();
				string len="{ int length=dp.Pop_ushort();\n";
				string elline=name+"=new "+CorrectFullName(el)+"[length];\n";
				string feline="for (int i=0;i<length;i++)\n";
				string uline=UnPackLines(name+"[i]",el);
				return (len+elline+feline+uline+"}");
			}
			if ( t.IsEnum )
			{
				string ans=name+"=("+CorrectFullName(t)+")dp.Pop_byte();";
				return (ans);
			}
			if ( t == typeof( System.Drawing.Color ) )
			{
				return name+" = System.Drawing.Color.FromArgb( dp.Pop_int() );";

			}
			string tn= PackTypeName(t);
			string line = "\t\t\tthis."+name+"=";
			line+=UnPackCastName(t);
			line +="dp.Pop_"+tn;
			line += "(); ";
			return line;
		}
		public void WriteWrapper(TextWriter tw)
		{
			tw.WriteLine( "\tpublic class rs_Wrap_"+Name + " : "+CorrectFullName(this.BasisType)+" {" );

			foreach ( FieldInfo fi in BasisType.GetFields() )
			{
				bool good = true;
				bool isrep = false;
				bool issim =false;
				if ( fi.IsLiteral )
					good = false;
				if ( fi.IsStatic )
					good = false;
				foreach (object art in fi.GetCustomAttributes(true))
				{
					if ( art is transientAttribute )
						good = false;
					if ( art is replicateAttribute )
						isrep = true;
					if ( art is simulateAttribute )
						issim = true;
				}

				if ( good )
				{
					RSField rf = new RSField( fi );
					Fields.Add( rf );
					if ( isrep )
					{
						RepFields.Add( rf );
						
					}
					if ( issim )
					{
						SimFields.Add( rf );
					}
				}
			}
			Fields.Sort();
			RepFields.Sort();
			SimFields.Sort();

			int index=0;
			foreach (object ob in RepFields)
			{
				((RSField)ob).Id = (byte)(index++);
				RSField fi = (RSField)ob;
				string line="\t\t"+"private "+CorrectFullName( fi.BasisField.FieldType )+" rs_pvs_"+fi.Name+ ";";
				tw.WriteLine( line);
			}
			
			//update->save pvs 
			tw.WriteLine( "\n\t\tpublic override void rs_UpdatePvs() {" );
			foreach (object ob in RepFields)
			{
				((RSField)ob).Id = (byte)(index++);
				RSField fi = (RSField)ob;
				string line="\t\t\t"+"rs_pvs_"+fi.Name+ "=( this." + fi.Name + " );";
				tw.WriteLine(line);
			}
			tw.WriteLine( "\t\t}" );
			//extend check for updates
			tw.WriteLine( "\t\tpublic override void rs_UpdatePack(IDataPacker dp) {" );
			tw.Write("\t\tif (");
			foreach (object ob in RepFields)
			{
				((RSField)ob).Id = (byte)(index++);
				RSField fi = (RSField)ob;
				string line="(rs_pvs_"+fi.Name+" !=( this." + fi.Name + ")) ";
				string line2="||";
				tw.Write(line+line2);
			}
			tw.Write("false)\n");
			tw.WriteLine("\t\t{");
			string line5 = "\t\t\tdp.Push_RSActor( this );";
			tw.WriteLine(line5);
			foreach (object ob in RepFields)
			{
				((RSField)ob).Id = (byte)(index++);
				RSField fi = (RSField)ob;
				tw.WriteLine(PackLines(fi.Name, fi.BasisField.FieldType));
			}
			tw.WriteLine("\t\t}");
			tw.WriteLine( "\t\t}" );
			tw.WriteLine( "\t\tpublic override void rs_UpdateUnPack(IDataUnPacker dp) {" );
			foreach (object ob in RepFields)
			{
				RSField fi = (RSField)ob;
				tw.WriteLine(UnPackLines(fi.Name, fi.BasisField.FieldType));
			}
			tw.WriteLine( "\t\t}" );	
			//fullpack
			tw.WriteLine( "\t\tpublic override void rs_FullPack(IDataPacker dp) {" );
			foreach (object ob in Fields)
			{
				RSField fi = (RSField)ob;
				tw.WriteLine( PackLines(fi.Name,fi.BasisField.FieldType));
			}

			tw.WriteLine( "\t\t}" );
			//fullunpack
			tw.WriteLine( "\t\tpublic override void rs_FullUnPack(IDataUnPacker dp) {" );
			foreach (object ob in Fields)
			{
				RSField fi = (RSField)ob;
				/*string tn = PackTypeName( fi.BasisField.FieldType );
				string line = "\t\t\tthis."+fi.Name+"=";
				line += UnPackCastName(fi.BasisField.FieldType)+" dp.Pop_"+tn;
				line += "(); ";*/ 
				tw.WriteLine( UnPackLines(fi.Name,fi.BasisField.FieldType));
			}
			tw.WriteLine( "\t\t}" );
			tw.WriteLine( "\t} " );
		}
	
	}

	public class RSManager
	{
		public ArrayList Objects = new ArrayList();
		public ArrayList Types = new ArrayList();
		public RSActor GameRoot = null;
		private TextWriter CodeOut;

		public const byte Msg_FullPack = 1;
		public const byte Msg_UpdatePack = 2;
		//public const byte Msg_SimPack = 3;

		public void BadReset()
		{
			Objects.Clear();
		}

		public void RecieveData(IDataUnPacker dp)
		{
			byte id = dp.Pop_byte();
			switch ( id )
			{
				case Msg_FullPack:
					ReadFullPack( dp );
					break;
				case Msg_UpdatePack:
					ReadUpdatePack( dp );
					break;
				default:
					throw new ArgumentException();
					break;
			}
		}

		public void ReadFullPack(IDataUnPacker dp)
		{
			Objects.Clear();
			int count = dp.Pop_ushort();
			ArrayList newones = new ArrayList();
			for (int i=0; i<count; i++)
			{
				ushort typeid = dp.Pop_ushort();
				ushort netid = dp.Pop_ushort();
				RSActor na = NewActor2( GetTypeByNetId(typeid), netid );
				newones.Add( na );
			}
			GameRoot = dp.Pop_RSActor();
			foreach ( object ob in newones )
			{
				((RSActor)ob).rs_FullUnPack( dp );
			}
		}

		public void WriteFullPack(IDataPacker dp)
		{
			dp.Push_byte( Msg_FullPack );
			dp.Push_ushort( (ushort)Objects.Count );
			foreach (object ob in Objects)
			{
				RSActor actor = (RSActor)ob;
				dp.Push_ushort( actor.NetType.NetTypeId );
				dp.Push_ushort( actor.NetId );
			}
			dp.Push_RSActor( this.GameRoot );
			foreach (object ob in Objects)
			{
				RSActor actor = (RSActor)ob;
				actor.rs_FullPack( dp );
			}
		}
		public void WriteUpdatePack(IDataPacker dp)
		{
			
			dp.Push_byte( Msg_UpdatePack );
			dp.StartList();
			foreach (object ob in Objects)
			{
				((RSActor)ob).rs_UpdatePack( dp );
			}
			dp.EndList();
		}
		public void ReadUpdatePack(IDataUnPacker dp)
		{
			//updateunpack
			//Objects.Clear();
			ArrayList newones = new ArrayList();
			dp.UnStartList();
			while(dp.IsMoreInList())
			{
				RSActor actor= dp.Pop_RSActor();
				actor.rs_UpdateUnPack( dp );
			}
			dp.UnEndList();
		}


		public RSActor GetActorByNetId(ushort id)
		{
			foreach (object ob in Objects)
				if ( ((RSActor)ob).NetId == id )
					return ((RSActor)ob);
			return null;
		}

		public RSType GetTypeByNetId(ushort id)
		{
			foreach (object ob in Types)
			{
				if ( ((RSType)ob).NetTypeId == id )
					return ((RSType)ob);
			}
			return null;
		}

		/// <summary>
		/// Initialize the wrapper types
		/// </summary>
		/// <param name="asmb"></param>
		public void Init(Assembly asmb, bool docompile)
		{
			string prefix = "rs_Wrap_";
			if ( docompile )
			{
				Type acttype = typeof( RSActor );
				StringWriter sw = new StringWriter();
				CodeOut = sw;
				CodeOut.WriteLine( "using System;" );
				CodeOut.WriteLine( "using RealSharp;" );
				bool isfirst = true;
				//CodeOut.WriteLine( "namespace "+asmb.GetTypes()[0].Namespace+" {" );
				foreach (Type t in asmb.GetTypes() )
				{
					if ( t!=acttype && t.IsSubclassOf( acttype )
						&& ( ! t.Name.StartsWith(prefix) ) )
					{
						RSType rt = new RSType( t );
						Types.Add( rt );
						rt.NetTypeId = (ushort)Types.Count;

						if ( isfirst )
						{
							CodeOut.WriteLine( "namespace "+t.Namespace+" {" );
							isfirst = false;
						}
						rt.WriteWrapper( CodeOut );
					}
				}
				CodeOut.WriteLine( "}" );

				string source = sw.ToString();
				StreamWriter tw = new StreamWriter( "rs_Wrappers.cs" );
				tw.Write( source );
				tw.Close();
				Console.Write( "Source Code:\n" + source );

				Assembly ca = WrappersCompile( source, "bin/Debug/EvilDice2.exe" );
				foreach (object ob in Types)
				{
					RSType rt = (RSType)ob;
					foreach (Type gened in ca.GetTypes())
					{
						if ( gened.Name == ( "rs_Wrap_" + rt.Name ) )
						{
							rt.WrappedType = gened;
						}
					}
				}
			}
			else
			{
				Type acttype = typeof( RSActor );
				foreach (Type t in asmb.GetTypes())
				{
					if ( t.IsSubclassOf( acttype ) )
					{
						if ( t!=acttype && ( ! t.Name.StartsWith( prefix ) ) )
						{
							RSType rt = new RSType( t );
							Types.Add( rt );
							rt.NetTypeId = (ushort)Types.Count;

							//rt.WrappedType = asmb.GetType( prefix + t.Name );
							foreach (Type wt in asmb.GetTypes())
							{
								if ( ( prefix + t.Name ) == wt.Name )
									rt.WrappedType = wt;
							}
							if ( rt.WrappedType == null )
								throw new ArgumentException("No Wrapper");
						}
					}
				}
			}
		}

		private Assembly WrappersCompile(string src, string appname)
		{
			System.Reflection.Assembly thisas = Assembly.GetCallingAssembly();
			Microsoft.CSharp.CSharpCodeProvider cp = new Microsoft.CSharp.CSharpCodeProvider();
			ICodeCompiler cc = cp.CreateCompiler();

			CompilerParameters pars = new CompilerParameters( );
			pars.GenerateInMemory = true;
			pars.IncludeDebugInformation = true;
			pars.ReferencedAssemblies.Add( appname );
			pars.ReferencedAssemblies.Add( "System.Drawing.dll" );

			CompilerResults cr = cc.CompileAssemblyFromSource( pars, src );

			if ( cr.Errors.HasErrors || cr.Errors.HasWarnings )
			{
				string ermsg = "";
				foreach (object ob in cr.Errors)
				{
					ermsg = ob.ToString() + "\n";
				}
				throw new InvalidOperationException( "Wrapper Compile Errors/Warnings:\n" + ermsg );
							}

			return cr.CompiledAssembly;
		}

		public RSType GetWrapperType(Type t)
		{
			foreach ( object ob in Types )
			{
				RSType rt = (RSType)ob;
				if ( rt.BasisType == t )
					return rt;
			}
			throw new ArgumentException();
			return null;
		}

		private RSType LastSpawnType = null;
		/// <summary>
		/// Make a new instance of the given type
		/// </summary>
		/// <param name="t"></param>
		/// <returns></returns>
		public RSActor NewActor(Type t)
		{
			RSType rt;
			if ( LastSpawnType!=null && LastSpawnType.BasisType==t )
				rt = LastSpawnType;
			else
			{
				rt = GetWrapperType( t );
				LastSpawnType = rt;
			}
			return NewActor2( rt, (ushort)(Objects.Count+1) );
		}

		public static Type NextSpawnType = null;

		private RSActor NewActor2(RSType tp, ushort netid)
		{
			//TODO: spawn wrapper type instead of logic type
			NextSpawnType = tp.WrappedType;
			RSActor ob = (RSActor)System.Activator.CreateInstance( tp.WrappedType );
			if ( NextSpawnType != null )
				throw new InvalidOperationException();
			Objects.Add( ob );
			ob.NetId = netid;
			ob.Manager = this;
			ob.NetType = tp;
			return ob;

		}
	}
}
