using System;
using System.Reflection;
using System.IO;
using System.Collections;

namespace RealSharp
{
	
	public class MemoryUnPacker : IDataUnPacker
	{
		public MemoryStream ms;
		public BinaryReader br;
		private long endlist=-1;
		public RSManager Manager;


		public MemoryUnPacker(byte[] data, RSManager man)
		{
			ms = new MemoryStream( data );
			br = new BinaryReader( ms );
			Manager = man;
		}

		public bool Pop_bool()
		{
			byte b = Pop_byte();
			return ( b != 0 );
		}

		public float Pop_float()
		{
			return br.ReadSingle();
		}

		public string Pop_string()
		{
			int len = (int)Pop_byte();
			string ans = "";
			for (int i=0; i<len; i++)
			{
				char c = (char)Pop_byte();
				ans += c;
			}
			return ans;
		}

		public int Pop_int()
		{
			return br.ReadInt32();
		}

		public ushort Pop_ushort()
		{
			return br.ReadUInt16();
		}

		public RSActor Pop_RSActor()
		{
			ushort netid = Pop_ushort();
			if ( netid == 0 )
				return null;
			return Manager.GetActorByNetId( netid );
		}

		public byte Pop_byte()
		{
			return br.ReadByte();
		}

		
		public void UnStartList()
		{
			if (endlist!=-1)
				throw new ArgumentException();
			else
			{
				ushort length=Pop_ushort();
				endlist=ms.Position+length-2;
			}
        }
		public bool IsMoreInList()
		{
			if (ms.Position<endlist)
				return true;
			else
				return false;
		}
		public void UnEndList()
		{
			endlist=-1;
		}
	}


	public class MemoryPacker : IDataPacker
	{
		public MemoryStream ms;
		public BinaryWriter bw;
		private long startlist=-1;
		public MemoryPacker()
		{
			ms = new MemoryStream();
			bw = new BinaryWriter( ms );
		}

		public byte[] Flush()
		{
			byte[] full = ms.GetBuffer();
			int len = (int)ms.Length;
			byte[] ans = new byte[ len ];
			for (int i=0; i<len; i++)
				ans[i] = full[i];
			return ans;
		}

		public void Push_bool(bool b)
		{
			if ( b )
				Push_byte( 1 );
			else
				Push_byte( 0 );
		}

		public void Push_byte(byte b)
		{
			bw.Write( b );
		}

		public void Push_float(float f)
		{
			bw.Write( f );
		}

		public void Push_string(string s)
		{
			Push_byte( (byte)s.Length );
			foreach (char c in s)
			{
				Push_byte( (byte)c );
			}
		}

		public void Push_int(int i)
		{
			bw.Write( i );
		}

		public void Push_ushort(ushort v)
		{
			bw.Write( v );
		}

		public void Push_RSActor(RSActor a)
		{
			if ( a == null )
				Push_ushort( 0 );
			else
				Push_ushort( a.NetId );
		}
		public void StartList()
		{
			startlist=ms.Position;
			Push_ushort(0);

		}
		public void EndList()
		{
			long listend=ms.Position;
			ms.Position=startlist;
			Push_ushort((ushort)(listend-startlist));
			ms.Position=listend;
		}
	}

}
