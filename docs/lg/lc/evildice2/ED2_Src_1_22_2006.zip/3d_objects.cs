//
// 3d_objects.cs - Drunken Hyena 3D Objects Tutorial
//
// Copyright (c) 2005 Kenneth Paulson
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the Drunken Hyena License.  If a copy of the license was
// not included with this software, you may get a copy from:
// http://www.drunkenhyena.com/docs/DHLicense.txt

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.Collections;
using DX = Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;
using DXI = Microsoft.DirectX.DirectInput;
using Microsoft.DirectX;
using EvilGame;
using EvilGame.Puzzle;
using DrunkenHyena;


namespace EvilApp
{
	public class EvilDiceApp : D3DApp 
	{

		protected static new string m_name="Evil Dice 2 - v" + Code.Version;
		EvilGame.EvilGraphics mEvilDraw = null;
		EvilUI mEvilUI = null;
		EvilGame.EvilAudio mAudio = null;
		public Lounge TheLounge = null;
		public EvilGame.VNode.MenuManager mMenu = null;
		public bool ShowingMenu = true;
		public Game.GameType LastGameType = Game.GameType.None;
		public EvilGame.Puzzle.Level CurrentLevel = null;
		public bool IsPuzzleMode = false;
		public bool IsEditorMode = false;
		public bool IsSinglePlayer = true;
		public GameJoyStick[] Sticks = new GameJoyStick[0];
		public RealSharp.RSManager Manager;

		public class GameJoyStick
		{
			public DXI.Device JoyDevice = null;
			public DXI.JoystickState JoyState;
			public Dir JoyDir = Dir.None;
			public int Index = 1;
			public int Buttons = 0;
		}

		public void GotoMainMenu()
		{
			ShowingMenu = true;
			TheLounge.Exit();
			mMenu.Menu = GenMainMenu( mEvilDraw.EUI );
		}

		public const string ProfileFileName = "profile.xml";

		public EvilDiceApp(string p_name,Size p_size,bool p_fullscreen) : 
			base(p_name,p_size,p_fullscreen)
		{
			if ( System.IO.File.Exists( ProfileFileName ) )
				Profile.Default.LoadFromFile( ProfileFileName );

			string cmds = Environment.CommandLine;

			if ( cmds.IndexOf( "-noshaders" ) >= 0 )
				Profile.Default.UseShaders = false;
			if ( cmds.IndexOf( "-noaudio" ) >= 0 )
				Profile.Default.EnableSounds = false;

			init_matrices();

			init_device_states();

			init_data();

			init_joysticks();
		}

		private void init_single_joystick(DXI.Device device)
		{
			// Set the data format to the c_dfDIJoystick pre-defined format.
			device.SetDataFormat(DXI.DeviceDataFormat.Joystick);
			// Set the cooperative level for the device.
			device.SetCooperativeLevel(this, DXI.CooperativeLevelFlags.Exclusive | DXI.CooperativeLevelFlags.Foreground);
			// Enumerate all the objects on the device.
			foreach (DXI.DeviceObjectInstance d in device.Objects)
			{
				// For axes that are returned, set the DIPROP_RANGE property for the
				// enumerated axis in order to scale min/max values.

				if ((0 != (d.ObjectId & (int)DXI.DeviceObjectTypeFlags.Axis)))
				{
					// Set the range for the axis.
					device.Properties.SetRange(DXI.ParameterHow.ById, d.ObjectId, new DXI.InputRange(-100, +100));
				}
			}
		}

		public void init_joysticks()
		{
			ArrayList ar = new ArrayList();
			foreach (DXI.DeviceInstance instance in DXI.Manager.GetDevices(DXI.DeviceClass.GameControl, DXI.EnumDevicesFlags.AttachedOnly))
			{
				// Create the device.  Just pick the first one
				ar.Add( new DXI.Device(instance.InstanceGuid) );
			}

			Sticks = new GameJoyStick[ ar.Count ];
			for (int i=0; i<ar.Count; i++)
			{
				GameJoyStick st = new GameJoyStick();
				Sticks[i] = st;
				st.JoyDevice = (DXI.Device)ar[i];
				st.Index = i+1;
				init_single_joystick( st.JoyDevice );
			}
		}

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
		{
			Profile.Default.SaveToFile( ProfileFileName );

			mEvilDraw.IsReady = false;
		}


		protected void init_matrices()
		{
			//NOTE: The device's viewport is set up like this by default.
			//If you want to be thorough you can set it yourself rather than
			//depending on the device default.  It certainly won't hurt.
			D3D.Viewport view_port = new D3D.Viewport();

			view_port.X = 0;
			view_port.Y = 0;
			view_port.Width = ClientSize.Width;
			view_port.Height = ClientSize.Height;
			view_port.MinZ = 0.0f;
			view_port.MaxZ = 1.0f;

			m_device.Viewport = view_port;

		}

		protected void init_device_states()
		{
			//Turn off lighting
			m_device.RenderState.Lighting = false;
		}

		/// <summary>
		/// OnDeviceReset - The device has been successfully Reset.
		///   Settings lost by the Reset should be set here and any resources
		///   that were freed in OnDeviceLost should be reallocated.
		/// </summary>
		/// <param name="sender">not used</param>
		/// <param name="e">not used</param>
		override protected void OnDeviceReset(object sender, EventArgs e)
		{

			base.OnDeviceReset(sender,e);

			//Device Transforms are lost when the device is Reset
			init_matrices();

			//Device states are also lost
			init_device_states();

		}

		protected void init_data()
		{
			try
			{
			}
			catch( Exception e)
			{
				MessageBox.Show( e.Message );
				throw e;
			}

			//mGame = new Game.GameMode_Classic();
			EvilGame.Puzzle.Campaign c = new EvilGame.Puzzle.Campaign();
			CurrentLevel = new EvilGame.Puzzle.Level();
			c.Add( CurrentLevel );
		}

		private int FrameIndex=0;
		protected override void Render()
		{
			Color colour = Color.Black; //Color.FromArgb( 70, 0, 0 );
			Code.TheApp = this;

			FrameIndex++;
			if ( mEvilUI == null )
				mEvilUI = new EvilUI( m_device );
			if ( FrameIndex == 1 )
			{
				m_device.Clear(D3D.ClearFlags.Target|D3D.ClearFlags.ZBuffer,Color.Black,0.0f,0);
				m_device.BeginScene();
				TextType tt = new TextType( 2 );
				mEvilUI.CurTextAlpha = 100;
				tt.Color = Color.DarkRed;
				mEvilUI.DrawText( "Loading...", mEvilUI.FullRect, tt );
				mEvilUI.CurTextAlpha = 255;
				m_device.EndScene();
				m_device.Present();
				return;
			}


			if ( mEvilDraw == null )
			{
				Manager = new RealSharp.RSManager();
				Manager.Init( typeof( Game ).Assembly, false );

				TheLounge = (Lounge)Manager.NewActor( typeof( Lounge ) );

				mEvilDraw = new EvilGame.EvilGraphics( m_device, mEvilUI, this );
				mEvilDraw.LoadGraphics();
			
				VNode.MenuSet main = GenMainMenu( mEvilDraw.EUI );
				mMenu = new VNode.MenuManager( main, mEvilDraw.EUI, true );
				mMenu.SelectedNewGame += new EvilGame.VNode.MenuManager.SelectedNewGameEvent(mMenu_SelectedNewGame);
				ShowingMenu = true;

				mAudio = new EvilAudio( this, Profile.Default );
				mAudio.Music.OnTitle();
			}
			if ( !mEvilDraw.IsReady )
				return;

			//Clear the render target
			m_device.Clear(D3D.ClearFlags.Target|D3D.ClearFlags.ZBuffer,colour,0.0f,0);

			EvilUI ui = mEvilDraw.EUI;
			if ( !ShowingMenu )
			{
				if ( TheLounge.TheGame != null )
				{
					int w = TheLounge.TheGame.TileWidth;
					int h = TheLounge.TheGame.TileHeight;
					m_device.BeginScene();
					mEvilDraw.CalcCamera( TheLounge.TheGame );
					mEvilDraw.PrepDX( w, h, true );
					mEvilDraw.DrawBoard( TheLounge.TheGame );
					mEvilDraw.UnPrepDX();
				}
			}
			else
			{
				double t = mEvilDraw.AnimTime;
				t = ( t / mEvilDraw.FadeInTime );
				if ( t >= 1 )
				{
					mEvilUI.CurTextAlpha = 255;
					t = 1;
				}
				else if ( t <= 0 )
				{
					mEvilUI.CurTextAlpha = 0;
					t = 0;
				}
				else
				{
					t *= t*t*t;
					mEvilUI.CurTextAlpha = (int)( 255.0 * t );
				}

				m_device.BeginScene();
				mEvilDraw.CalcCamera( null );
				mEvilDraw.PrepDX( 2, 2, true );
				if ( Profile.Default.ShowBackground )
					mEvilDraw.DrawBackground2(t);
				mEvilDraw.UnPrepDX();

				ui.PrepDX();
				mMenu.CalcPlacement( ui.FullRect );
				mMenu.Draw();
				ui.UnPrepDX();

				mEvilUI.CurTextAlpha = 255;
			}

			//Signal the device that we're done with our scene
			m_device.EndScene();

			//Show the results to the user
			m_device.Present();
		}

		private void InputActivated(InputDef id, Dir d, bool isdown)
		{
			if ( !ShowingMenu )
			{
				TheLounge.LocalDirActivated( id, d, isdown );
			}
			else
			{
				if ( isdown )
				{
					mMenu.Menu.OnInput( mMenu, id, d );
				}
			}
		}

		private void CheckKeys(KeyEventArgs e, int p, Keys[] ar, bool isdown)
		{
			foreach (InputDef id in InputDef.Inputs)
			{
				if ( id.KeyBoard != null )
				{
					for (int i=0; i<id.KeyBoard.Length; i++)
					{
						if ( id.KeyBoard[i] == e.KeyCode )
						{
							Dir dir = (Dir)( i % 4 );
							InputActivated( id, dir, isdown );
							break;
						}
					}
				}
			}
		}

		protected override void OnMouseUp(MouseEventArgs e)
		{
			VNode.MenuManager menu = ActiveMenu;
			if ( menu != null )
			{
				Point pt = new Point( e.X, e.Y );
				int i = menu.GetFromMouse( pt );
				if ( i >= 0 )
				{
					menu.Menu.SetSelectedIndex( menu, i );
					menu.Menu.OnInput( menu, null, Dir.East );
					//menu.Selected.OnSelected( menu, menu.Menu );
				}
				else
				{
					VNode v = menu.ExtraHolder.FindHit( pt );
					if ( v != null )
					{
						v.DoClick();
						PlaySound( Sounds.Click );
					}
				}
			}
			else
			{
				this.ShowingMenu = true;
			}

			base.OnMouseUp (e);
		}

		public VNode.MenuManager ActiveMenu
		{
			get
			{
				if ( ShowingMenu )
					return mMenu;
				if ( TheLounge.TheGame!=null && TheLounge.TheGame.ScreenMenu!=null )
					return TheLounge.TheGame.ScreenMenu;
				return null;
			}
		}

		protected override void OnMouseMove(MouseEventArgs e)
		{
			VNode.MenuManager menu = ActiveMenu;
			if ( menu != null )
			{
				int i = menu.GetFromMouse( new Point( e.X, e.Y ) );
				if ( i >= 0 && menu.Menu.SelectedIndex!=i )
				{
					menu.Menu.SetSelectedIndex( menu, i );
					PlaySound( Sounds.ShortClick );
				}
			}

			base.OnMouseMove (e);
		}

		public static Keys[] Keys_Player0 = { Keys.Up, Keys.Down, Keys.Right, Keys.Left};
		public static Keys[] Keys_Player1 = { Keys.W, Keys.S, Keys.D, Keys.A };

		public void OnSpecialKey(Keys k)
		{
			if ( k == Keys.Enter )
			{
				VNode.MenuManager mm = this.ActiveMenu;
				if ( mm != null )
				{
					mm.Menu.OnInput( mm, null, Dir.East );
				}
			}
			if ( k == Keys.Escape )
			{
				if ( IsEditorMode )
				{
					OpenPuzzleEditor();
				}
				else
				{
					ShowingMenu = !ShowingMenu;
					if ( TheLounge.TheGame == null || TheLounge.TheGame.GameOver )
						ShowingMenu = true;
				}
			}
		}

		protected override void OnKeyUp(KeyEventArgs e)
		{
			CheckKeys( e, 0, Keys_Player0, false );
			base.OnKeyDown (e);

			if ( e.KeyCode == Keys.Space )
			{
				if ( mEvilDraw != null )
					mEvilDraw.IsShowStats = false;
			}
		}

		protected override void OnKeyDown(KeyEventArgs e)
		{
			CheckKeys( e, 0, Keys_Player0, true );
			base.OnKeyDown (e);
			OnSpecialKey( e.KeyCode );

			if ( e.KeyCode == Keys.Space )
			{
				if ( mEvilDraw != null )
					mEvilDraw.IsShowStats = true;
			}
		}

		private Dir subJoyDir(int x, int y)
		{
			float mag = (float)Math.Sqrt( x*x + y*y );
			if ( mag < 70.0f )
				return Dir.None;

			double ang = Math.Atan2( y, x );
			ang += Math.PI/6;
			if ( ang > Math.PI )
				ang = -( Math.PI*2 - ang);
			if ( ang < -Math.PI )
				ang = ( Math.PI*2 + ang );

			if ( ang >= 0 )
			{
				if ( ang <= Math.PI/2 )
					return Dir.East;
				else
					return Dir.South;
			}
			else
			{
				if ( ang <= -Math.PI/2 )
					return Dir.West;
				else
					return Dir.North;
			}
		}

		public Dir JoyDir(GameJoyStick js)
		{
			Dir t;

			t = subJoyDir( js.JoyState.X, js.JoyState.Y );
			if ( t != Dir.None )
				return t;

			t = subJoyDir( js.JoyState.Rx, js.JoyState.Ry );
			if ( t != Dir.None )
				return t;

			int[] povs = js.JoyState.GetPointOfView();
			if ( povs.Length!=0 && povs[0]!=-1 )
			{
				int pov = povs[0] / 1000;
				switch ( pov )
				{
					case 0:
						return Dir.North;
					case 9:
						return Dir.East;
					case 18:
						return Dir.South;
					case 27:
						return Dir.West;
				}
			}

			return Dir.None;
		}

		protected bool GetJoyState(DXI.Device device, ref DXI.JoystickState state)
		{
			try
			{
				// Poll the device for info.
				device.Poll();
			}
			catch(DXI.InputException inputex)
			{
				if ((inputex is DXI.NotAcquiredException) || (inputex is DXI.InputLostException))
				{
					// Check to see if either the app
					// needs to acquire the device, or
					// if the app lost the device to another
					// process.
					try
					{
						// Acquire the device.
						device.Acquire();
					}
					catch(DXI.InputException)
					{
						// Failed to acquire the device.
						// This could be because the app
						// doesn't have focus.
						return false;
					}
				}
                
			} //catch(InputException inputex)

			// Get the state of the device.
			try {state = device.CurrentJoystickState;}
				// Catch any exceptions. None will be handled here, 
				// any device re-aquisition will be handled above.  
			catch(DXI.InputException)
			{
				return false;
			}

			return true;
		}

		private void DoJoyPad(DXI.JoystickState state, ref Dir olddir, int index)
		{
		}

		protected void OnCheckJoypads()
		{
			foreach ( GameJoyStick st in Sticks )
			{
				if ( GetJoyState( st.JoyDevice, ref st.JoyState ) )
				{
					byte[] buttons = st.JoyState.GetButtons();
					int next = 0;
					for (int i=0; i<buttons.Length; i++)
					{
						if ( ( buttons[i]&0x80 ) != 0 )
							next |= ( 1 << i );
					}
					int select = ( 1 << 6 ) | ( 1 << 8 );
					int A = ( 1 << 0 ) | ( 1 << 2 );
					int start = ( 1 << 7 ) | ( 1 << 9 );
					if ( ( (next & select)==0 ) && ( (st.Buttons & select) != 0 ) )
						OnSpecialKey( Keys.Escape );
					if ( ( (next & A)==0 ) && ( (st.Buttons & A) != 0 ) )
						OnSpecialKey( Keys.Enter );
					if ( ( (next & start)==0 ) && ( (st.Buttons & start) != 0 ) )
						OnSpecialKey( Keys.Enter );
					st.Buttons = next;

					Dir d = JoyDir( st );
					bool isdown = true;
					if ( d == st.JoyDir )
						break;
					if ( d == Dir.None )
					{
						isdown = false;
						d = st.JoyDir;
						st.JoyDir = Dir.None;
					}
					else
					{
						st.JoyDir = d;
					}

					foreach (InputDef id in InputDef.Inputs)
					{
						if ( id.JoyIndex == st.Index )
						{
							InputActivated( id, d, isdown );
						}
					}
				}
				else
					Code.Status = "Couldn't Poll Joystick";
			}
		}

		protected override void OnThink(double dt)
		{
			OnCheckJoypads();
			if ( !ShowingMenu )
				TheLounge.OnTick( dt );
			if ( mEvilDraw != null )
				mEvilDraw.GraphicsThink( dt );
			base.OnThink (dt);

			string s = ( 1.0 / dt ).ToString();
			if ( s.Length > 6 )
				s = s.Substring( 0, 6 );
			//Code.Status = "FPS="+s;
		}



		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			//The size of our render target, or drawing area
			System.Drawing.Size size=new Size(800,600);

			//Ask the user if the application should run in full-screen or windowed mode
			bool fullscreen = Utility.AskFullscreen(m_name);

			//Create a new instance of our application
			EvilDiceApp app=new EvilDiceApp(m_name,size,fullscreen);

			//Show the window
			app.Show();

			System.Windows.Forms.Application.Idle += new EventHandler(app.OnApplicationIdle);
			System.Windows.Forms.Application.Run(app);

		}

		public VNode.MenuSet GenCampaignMenu()
		{
			EvilUI ui = mEvilDraw.EUI;
			VNode.MenuSet ms = new EvilGame.VNode.MenuSet();
			VNode.MenuItem mi;

			mi = new EvilGame.VNode.MenuItem( "Resume", "Resume your game" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Resume);
			ms.Add( mi );

			Campaign c = CurrentLevel.Campaign;
			foreach ( Level el in c.Levels )
			{
				Profile.Beaten b = Profile.Default.GetBeaten( c.Name, el.Name );
				string name = el.Name;
				if ( b != null )
				{
					if ( b.Steps <= el.MaxSteps || el.MaxSteps==0 )
						name = "[*] "+name;
					else
						name = "[" + b.Steps + "] " + name;
				}
				else
					name = "[ ] " + name;
				mi = new EvilGame.VNode.MenuItem( name, el.Description );
				mi.Param = el;
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_SelectedLevel);
				ms.Add( mi );
			}

			ms.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );
			return ms;
		}

		private VNode.MenuSet mInGameMenu = null;
		public VNode.MenuSet GenInGameMenu(EvilUI ui)
		{
			if ( mInGameMenu != null )
				return mInGameMenu;

			VNode.MenuItem mi;
			VNode.MenuSet menu = new EvilGame.VNode.MenuSet();
			mInGameMenu = menu;

			mi = new EvilGame.VNode.MenuItem( "Resume", "Resume your game" );
			((VNode.MenuItem)mi).Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Resume);
			menu.Add( mi );
			mi = new EvilGame.VNode.MenuItem( "New Game", "Start a new game of this type" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_NewGameOfThis);
			menu.Add( mi );
			menu.Add( new VNode.MenuItem( "Options", "Configure Evil", GenOptionsMenu( ui ) ) );
			menu.Add( new VNode.MenuItem( "Main Menu", "Exit the game and return to the main menu", GenMainMenu(ui) ) );

			return mInGameMenu;
		}

		private VNode.MenuSet mOptionsMenu = null;
		public VNode.MenuSet GenOptionsMenu(EvilUI ui)
		{
			if ( mOptionsMenu != null )
				return mOptionsMenu;
			VNode.MenuItem mi;

			VNode.MenuSet options = new EvilGame.VNode.MenuSet();
			VNode.MenuSet credits = new EvilGame.VNode.MenuSet();
			VNode.MenuSet profile = new EvilGame.VNode.MenuSet();
			VNode.MenuSet graphics = new EvilGame.VNode.MenuSet();
			VNode.MenuSet audio = new EvilGame.VNode.MenuSet();
			VNode.MenuSet scores = new EvilGame.VNode.MenuSet();
			mOptionsMenu = options;

			VNode.MenuSet askclear = new EvilGame.VNode.MenuSet();
			VNode.MenuSet askclearpz = new EvilGame.VNode.MenuSet();

			askclear.Add( new VNode.MenuItem( "Cancel", "Don't clear the high scores", true ) );
			mi = new VNode.MenuItem( "Continue", "Remove all the high scores", true );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ClearHighScores);
			askclear.Add( mi );

			askclearpz.Add( new VNode.MenuItem( "Cancel", "Don't clear the puzzle records", true ) );
			mi = new VNode.MenuItem( "Continue", "Remove all the puzzle records", true );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ClearPuzzles);
			askclearpz.Add( mi );

			scores.OnActivated += new EvilGame.VNode.MenuSet.ActivatedEvent(menu_OpenScoresMenu);

			profile.Add( new VNode.MenuItem( "View High Scores", "See what scores have been achieved", scores ) );
			profile.Add( new VNode.MenuItem( "Clear High Scores", "Clear all high scores (non-reversable)", askclear ) );
			profile.Add( new VNode.MenuItem( "Clear Puzzles", "Clear all records of completed puzzles (non-reversable)", askclearpz ) );
			profile.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );

			mi = new VNode.MenuItem( "Lewey Geselowitz", "Designer and Programming" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_URL_Lewey);
			credits.Add( mi );
			credits.Add( new VNode.MenuItem( "Jean-Pierre Allers", "Modeler" ) );
			credits.Add( new VNode.MenuItem( "James Mathew", "Music" ) );
			credits.Add( new VNode.MenuItem( "Lissette Berlanga", "Tester and Girlfriend" ) );
			credits.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );

			mi = new VNode.MenuItemList( "Die Skin:", "Set the default Die skin (changes on new game)", "Normal", "White", "Dark" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangedSkin);
			graphics.Add( mi );
			mi = new VNode.MenuItemList( "Shaders:", "Shaders provide better graphics but may run slower", "Off", "On" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangedUseShaders);
			graphics.Add( mi );
			mi = new VNode.MenuItemList( "Scene:", "Which scene to always use, or cycle through them" );
			((VNode.MenuItemList)mi).AddStringValue( "[cycle]" );
			foreach (Scene s in mEvilDraw.Scenes)
				((VNode.MenuItemList)mi).AddStringValue( s.Name );
			((VNode.MenuItemList)mi).SelectedIndex = Profile.Default.ScenePreference+1;
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_SetScene);
			graphics.Add( mi );
			mi = new VNode.MenuItemList( "Simple:", "Doesn't draw the background", "Off", "On" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ToggleBackground);
			graphics.Add( mi );
			graphics.OnActivated += new EvilGame.VNode.MenuSet.ActivatedEvent(menu_StartGraphics);
			graphics.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );

			mi = new EvilGame.VNode.MenuItemList( "Sounds:", "Should sounds be played (requires restart)", "Yes", "No" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ToggleSounds);
			if ( !Profile.Default.EnableSounds )
				((VNode.MenuItemList)mi).SelectedIndex = 1;
			audio.Add( mi );
			mi = new EvilGame.VNode.MenuItemList( "Volume:", "Sound effects volume", "1", "2", "3", "4", "5" );
			((VNode.MenuItemList)mi).SelectedIndex = Profile.Default.SoundVolume-1;
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeVolume);
			audio.Add( mi );
			mi = new EvilGame.VNode.MenuItemList( "Music:", "Music volume", "1", "2", "3", "4", "5" );
			((VNode.MenuItemList)mi).SelectedIndex = Profile.Default.MusicVolume-1;
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeMusic);
			audio.Add( mi );
			audio.Add( new VNode.MenuItem( "Back", "Return to the previous menu", true ) );

			options.Add( new VNode.MenuItem( "Controls", "How you control your Evil" ) );
			options.Add( new VNode.MenuItem( "Graphics", "Adjust the quality of the graphics", graphics ) );
			options.Add( new VNode.MenuItem( "Audio", "Volume controls", audio ) );
			options.Add( new VNode.MenuItem( "Records", "Manage your high scores and campaign records", profile ) );
			options.Add( new VNode.MenuItem( "Credits", "Those who brought the Evil among us", credits ) );
			options.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );

			return options;
		}

		private VNode.MenuSet mMultiMode = null;
		public VNode.MenuSet GenMultiModeMenu(EvilUI ui)
		{
			if ( mMultiMode != null )
				return mMultiMode;

			VNode.MenuItem mi;
			VNode.MenuSet ms = new EvilGame.VNode.MenuSet( );
			mMultiMode = ms;

			mi = new VNode.MenuItem( "Single Screen", "Start a local game" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_SelectedSingleScreen);
			ms.Add( mi );

			ms.Add( new VNode.MenuItem( "Join Internet Game", "Find a game on LeweyG.com" ) );
			ms.Add( new VNode.MenuItem( "Join LAN Game", "Join a match on your local LAN" ) );
			ms.Add( new VNode.MenuItem( "Join I P Game", "Join a match at a specific I.P." ) );
			ms.Add( new VNode.MenuItem( "Host Game", "Host your own game" ) );
			ms.Add( new VNode.MenuItem( "Back", "Return to main menu", GenMainMenu(ui) ) );

			return ms;
		}

		public void GenInputMenu(VNode.MenuItemMenu mim)
		{
			VNode.MenuItem mi;
			InputDef id = (InputDef)mim.Param;
			mim.MenuSet.Clear();
			if ( !id.HasProfile )
			{
				mi = new VNode.MenuItem( "[n/a]", "Not playing" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Nada);
				mim.Add( mi );
				mi = new VNode.MenuItem( "[login]", "Login this input device" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_LoginInput);
				mi.Param = mim;
				mim.Add( mi );
				mi = new VNode.MenuItem( "[exit]", "Not playing" );
				mi.Link = GenMainMenu( mEvilUI );
				mim.Add( mi );
			}
			else
			{
				string name = " ("+id.ProfileName+")";
				mi = new VNode.MenuItem( "[start]"+name, "Start the game" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_StartLounge);
				mim.Add( mi );
				mi = new VNode.MenuItem( "[logout]"+name, "Don't use this input" );
				mi.Param = mim;
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_LogoutInput);
				mim.Add( mi );
				mi = new VNode.MenuItem( "[exit]"+name, "Not playing" );
				mi.Link = GenMainMenu( mEvilUI );
				mim.Add( mi );
			}
			mim.Value = mim.MenuSet.Selected.Name;
		}

		private VNode.MenuSet mRootMenu = null;
		public VNode.MenuSet GenMainMenu(EvilUI ui)
		{
			if ( mRootMenu != null )
				return mRootMenu;

			VNode.MenuItem mi;
			VNode.MenuSet main = new VNode.MenuSet();
			VNode.MenuSet single = new EvilGame.VNode.MenuSet();
			VNode.MenuSet timed = new EvilGame.VNode.MenuSet();
			VNode.MenuSet multilogin = new VNode.LocalMenuSet();
			VNode.MenuSet dynamic = new EvilGame.VNode.MenuSet();
			mRootMenu = main;

			dynamic.Add( new VNode.MenuItem( "Eradicate Evil", "No new Die, you must score with what you have", Game.GameType.RemoveRandom ) );
			dynamic.Add( new VNode.MenuItem( "The Evil Number", "8 dice, each with only one face... an 8", Game.GameType.TwentyFour ) );
			dynamic.Add( new VNode.MenuItem( "Eternal Evil", "Indulge yourself and play for as long as you like (no time limit, no high scores)", Game.GameType.Infinite ) );
			dynamic.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );

			/*
			mi = new VNode.MenuItem( "Start...", "Enter the multiplayer lounge" );
			if ( true )
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_StartLounge);
			multilogin.Add( mi );
			foreach (InputDef id in InputDef.Inputs)
			{
				mi = new EvilGame.VNode.MenuItem( id.InputName+":", "Use these controls" );
				mi.Value = "[login]";
				mi.Param = id;
				if ( id.HasProfile )
					mi.Value = id.ProfileName;
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Login);
				multilogin.Add( mi );
			}
			*/
			multilogin.TextSize = 0;
			multilogin.GuideText = Lounge.MultiGuideText;
			foreach (InputDef id in InputDef.Inputs)
			{
				VNode.MenuItemMenu subm;
				subm = new EvilGame.VNode.MenuItemMenu( id.InputName+":", "Use these controls" );
				subm.Param = id;
				GenInputMenu( subm );
				multilogin.Add( subm );
			}
			multilogin.Add( new VNode.MenuItem( "Back", "Return to the main menu", main ) );

			timed.Add( new VNode.MenuItem( "Ancient Evil", "Score the highest you can in 3-minutes of classic Evil action", Game.GameType.Classic ) );
			timed.Add( new VNode.MenuItem( "Overwhelming Evil", "Stand as long as you can against the Die invasion", Game.GameType.Survival ) );
			timed.Add( new VNode.MenuItem( "Feed The Evil", "Keep a combo chain going as long as you can", Game.GameType.Feed ) );
			timed.Add( new VNode.MenuItem( "Rush Of Evil", "A 15 second surge of Evil, score as high as you can", Game.GameType.Short ) );
			timed.Add( new VNode.MenuItem( "Back", "Return to the Single Player menu", single ) );

			single.Add( new VNode.MenuItem( "Time Trials", "Classic Evil action against the clock", timed ) );
			mi = new VNode.MenuItem( "Puzzle Campaigns", "Play through collections of pre-written puzzles" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_PuzzleCampaign);
			single.Add( mi );
			single.Add( new VNode.MenuItem( "Dynamic Puzzles", "Randomly generated brain busters", dynamic ) );
			mi = new EvilGame.VNode.MenuItem( "Puzzle Editor", "Create and edit your own puzzle collections" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_StartEditor);
			single.Add( mi );
			single.Add( new VNode.MenuItem( "Back", "Return to the main menu", main ) );

			main.Add( new VNode.MenuItem( "Single Player", "Play a time-trial or puzzle mode", single ) );
			main.Add( new VNode.MenuItem( "Multiplayer", "Internet, LAN or single-screen multiplayer action", multilogin ) );
			mi = new VNode.MenuItem( "Tutorial", "Learn how to play Evil Dice 2" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_StartTutorial);
			main.Add( mi );
			main.Add( new VNode.MenuItem( "Options", "Customize your inner Evil", GenOptionsMenu( ui ) ) );
			mi = new VNode.MenuItem( "Exit", "Free yourself from Evil" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(mi_Selected);
			main.Add( mi );

			mRootMenu = main;
			return mRootMenu;
		}

		private void mi_Selected(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			this.Close();
		}

		private void StartNewGame(Game g)
		{
			IsSinglePlayer = true;
			Manager.BadReset();
			TheLounge.TheGame = g;
			TheLounge.TheGame.Init(0);
			TheLounge.TheGame.InitSinglePlayer();
			TheLounge.Players = new Player[0];
			ShowingMenu= false;
			Profile.Default.GamesCount++;
		}

		public void StartPuzzleCampaign(string filename)
		{
			EvilGame.Puzzle.Campaign c = new EvilGame.Puzzle.Campaign();
			c.LoadFromFile( filename );
			CurrentLevel = c.Levels[0];

			mMenu.Menu = GenCampaignMenu();
			TheLounge.TheGame = null;
		}

		public void StartPuzzleEditor(EvilGame.Puzzle.Level lvl)
		{
			IsPuzzleMode = false;
			IsEditorMode = true;
			StartNewGame( Game.GenPuzzleGame( lvl, true ) );
			((GameMode_PuzzleEditor)TheLounge.TheGame).InitEditor( this.mEvilDraw.EUI );
		}

		public void StartPuzzleNewGame(EvilGame.Puzzle.Level level)
		{
			IsPuzzleMode = true;
			IsEditorMode = false;
			StartNewGame( Game.GenPuzzleGame( level, false ) );
		}

		public void StartMultiPlayerNewGame(Lounge el)
		{
			LastGameType = el.NextGameType;
			IsPuzzleMode = false;
			IsEditorMode = false;
			IsSinglePlayer = false;
			Game g = Game.GenGame( el.NextGameType );
			TheLounge.TheGame = g;
			TheLounge.TheGame.Init( el.BoardSize );
			TheLounge.TheGame.InitMultiPlayer( el );
			ShowingMenu= false;
			mMenu.Menu = TheLounge.InGameMenu();
			Profile.Default.GamesCount++;
		}

		public void StartSinglePlayerNewGame(Game.GameType type)
		{
			LastGameType = type;
			IsPuzzleMode = false;
			IsEditorMode = false;
			StartNewGame( Game.GenGame( type ) );
			mMenu.Menu = GenInGameMenu( mEvilDraw.EUI );
			mAudio.Music.OnNewGame();
		}

		private void mMenu_SelectedNewGame(EvilGame.VNode.MenuManager man, EvilGame.Game.GameType type)
		{
			StartSinglePlayerNewGame( type );
		}

		private void menu_Resume(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			if ( TheLounge.TheGame != null )
				ShowingMenu = false;
		}

		private void menu_NewGameOfThis(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			StartSinglePlayerNewGame( LastGameType );
		}

		public void OpenPuzzleEditor()
		{
			threed_objects.PuzzleEditer pe = new threed_objects.PuzzleEditer(CurrentLevel);
			pe.ShowDialog( );
		}

		private void menu_StartEditor(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			OpenPuzzleEditor();
		}

		private void menu_PuzzleCampaign(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			EvilGame.VNode.MenuSet ms = new EvilGame.VNode.MenuSet();

			string[] files = System.IO.Directory.GetFiles( Environment.CurrentDirectory, "*.PZL" );
			foreach ( string s in files )
			{
				string f = System.IO.Path.GetFileNameWithoutExtension( s );
				VNode.MenuItem mi = new EvilGame.VNode.MenuItem( f, "Play the "+f+" campaign" );
				mi.Param = s;
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_SelectedCampaign);
				ms.Add( mi );
			}

			ms.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );
			this.mMenu.Menu = ms;
		}

		private void menu_SelectedCampaign(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			string file = (string)item.Param;
			StartPuzzleCampaign( file );
		}

		private void menu_SelectedLevel(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Level el = (Level)item.Param;
			StartPuzzleNewGame( el );
		}

		private void menu_StartTutorial(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			StartPuzzleCampaign( "Tutorial.pzl" );
		}

		private void menu_Login(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			InputDef id = (InputDef)item.Param;
			if ( id.HasProfile )
			{
				id.HasProfile = false;
				item.TempValueVisual.Text = "[login]";
			}
			else
			{
				id.ProfileName = threed_objects.SelectName.UserSelect("Select Profile Name");
				item.TempValueVisual.Text = id.ProfileName;
			}
		}

		private void menu_StartLounge(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			int count = 0;
			foreach ( InputDef id in InputDef.Inputs )
			{
				if ( id.HasProfile )
					count++;
			}
			if ( count == 0 )
			{
				MessageBox.Show( this, "At least one player must login", "No Players", MessageBoxButtons.OK, MessageBoxIcon.Error );
				return;
			}
			this.mMenu.Menu = GenMultiModeMenu( mEvilDraw.EUI );
		}

		private void menu_SelectedSingleScreen(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			if ( InputDef.NumInputs < 2 )
			{
				MessageBox.Show( this, "You need at least 2 people to play multiplayer", "Not enough players", MessageBoxButtons.OK, MessageBoxIcon.Error );
				return;
			}
			this.mMenu.Menu = TheLounge.LoungeMenu(menu.EUI);
		}

		public void PlaySound(Sounds s)
		{
			mAudio.Play(s);
		}

		private void menu_ChangedSkin(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			int i = mil.SelectedIndex;
			DieType dt = (DieType)i;
			Profile.Default.DefDieType = dt;
		}

		private void menu_ClearHighScores(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Profile.Default.HighScores = new Profile.HighScore[0];
			Profile.Default.PuzzleBeaten = new Profile.Beaten[0];
		}

		private void menu_OpenScoresMenu(EvilGame.VNode.MenuManager mm, EvilGame.VNode.MenuSet ms)
		{
			ms.Items = new VNode.MenuItem[0];
			ms.TextSize = 0;
			VNode.MenuItem mi;

			foreach (Profile.HighScore hs in Profile.Default.HighScores)
			{
				string name = Game.GameTypeName( hs.Type ) + ":";
				string hint = "";
				string val = hs.Score.ToString() + " by " + hs.Name;
				mi = new EvilGame.VNode.MenuItem( name, hint, true );
				mi.Value = val;
				ms.Add( mi );
			}

			ms.Add( new VNode.MenuItem( "Back", "Return to previous menu", true ) );
		}

		private void menu_ChangedUseShaders(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.UseShaders = ( mil.SelectedIndex != 0 );
		}

		private void menu_StartGraphics(EvilGame.VNode.MenuManager mm, EvilGame.VNode.MenuSet ms)
		{
			int d = (int)Profile.Default.DefDieType;
			int s = ( Profile.Default.UseShaders ? 1 : 0 );
			int b = ( Profile.Default.ShowBackground ? 0 : 1 );
			((VNode.MenuItemList)ms.Items[ 0 ]).SelectedIndex = d;
			((VNode.MenuItemList)ms.Items[ 1 ]).SelectedIndex = s;
			((VNode.MenuItemList)ms.Items[ 3 ]).SelectedIndex = b;
		}

		private void menu_URL_Lewey(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Code.ShellExecute( "http://www.leweyg.com/" );
		}

		private void menu_URL_DevilDice(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Code.ShellExecute( "http://www.mobygames.com/game/devil-dice" );
		}

		private void menu_LoginInput(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemMenu mim = (VNode.MenuItemMenu)(item.Param);
			InputDef id = (InputDef)mim.Param;

			id.ProfileName = threed_objects.SelectName.UserSelect("Select Profile Name");
			GenInputMenu( mim );
		}

		private void menu_LogoutInput(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemMenu mim = (VNode.MenuItemMenu)(item.Param);
			InputDef id = (InputDef)mim.Param;

			id.HasProfile = false;
			GenInputMenu( mim );
		}

		private void menu_Nada(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			//does nothing
		}

		private void menu_ToggleSounds(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.EnableSounds = ( mil.SelectedIndex == 0 );
		}

		private void menu_ChangeVolume(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.SoundVolume = mil.SelectedIndex+1;
			mAudio.FromProfile( Profile.Default, true );
		}

		private void menu_ChangeMusic(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.MusicVolume = mil.SelectedIndex+1;
			mAudio.FromProfile( Profile.Default, true );
		}

		private void menu_ClearPuzzles(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Profile.Default.PuzzleBeaten = new Profile.Beaten[0];
		}

		private void menu_ToggleBackground(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.ShowBackground = ( mil.SelectedIndex == 0 );
		}

		private void menu_SetScene(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemList mil = (VNode.MenuItemList)item;
			Profile.Default.ScenePreference = mil.SelectedIndex-1;
		}
	}  //EvilDiceApp

}  //namespace
