//
// utility.cs - Drunken Hyena utility toolbox
//
// Copyright � 2004-2005 Kenneth Paulson
//
// This program is free software; you can redistribute it and/or modify it
// under the terms of the Drunken Hyena License.  If a copy of the license was
// not included with this software, you may get a copy from:
// http://www.drunkenhyena.com/docs/DHLicense.txt

using System;
using System.Collections;
using System.Windows.Forms;
using Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;

namespace DrunkenHyena{

   /// <summary>
   /// Summary description for Utility.
   /// </summary>
   public class Utility{

      /// <summary>
      /// Queries user to find out preference for Full-Screen vs. Windowed.
      /// </summary>
      /// <returns>true == Full-Screen, false == Windowed</returns>
      public static bool AskFullscreen(string p_name){
      DialogResult result = DialogResult.No;

		  /*
         result=MessageBox.Show("Run in Full-Screen mode?",    //Message Text
                                p_name,                        //MBox Title
                                MessageBoxButtons.YesNo,       //Buttons to show
                                MessageBoxIcon.Question,       //Icon shown
                                MessageBoxDefaultButton.Button2); //Default button
		  */

         if(result == DialogResult.Yes){

            return true;

         }else{

            return false;

         }
      }

      /// <summary>
      /// Find16BitMode - Tests for 16-bit buffer formats for compatibility with
      /// the current display adapter in full-screen.
      /// </summary>
      /// <returns>The chosen format, or D3D.Format.Unknown if one isn't found</returns>
      public static D3D.Format Find16BitMode(){
      D3D.Format[] poss_formats={D3D.Format.R5G6B5, D3D.Format.X1R5G5B5};
      D3D.DeviceType dev=D3D.DeviceType.Hardware;

         foreach(D3D.Format format in poss_formats){

            if (D3D.Manager.CheckDeviceType(0,dev,format,format,false)){
               return format;
            }
         }

         return D3D.Format.Unknown;
         
      }

      public static System.Drawing.Icon LoadFirstIconFromResource()
      {
         // Get the assembly that is calling this method
         System.Reflection.Assembly currentAssembly = System.Reflection.Assembly.GetCallingAssembly();
         foreach(string s in currentAssembly.GetManifestResourceNames())
         {
               try
               {
                  // See if there are any .icos
                  System.IO.Stream resourceStream = currentAssembly.GetManifestResourceStream(s);
                  return new System.Drawing.Icon(resourceStream);
               }
               catch 
               {
                  // No icon yet, try reading the resources in a different way
                  try
                  {
                     System.Resources.ResourceReader reader = new System.Resources.ResourceReader(currentAssembly.GetManifestResourceStream(s));
                     IDictionaryEnumerator en = reader.GetEnumerator();
                     while(en.MoveNext())
                     {
                           System.Drawing.Icon test = en.Value as System.Drawing.Icon;
                           if (test != null)
                              return test;
                     }
                  }
                  catch 
                  {
                     // Didn't find an icon yet, continue
                     continue;
                  }
               }   
         }
         // It's no big deal if we can't load the icon, just return null instead
         return null;
      }

   }//class Utility

}//namespace DrunkenHyena
