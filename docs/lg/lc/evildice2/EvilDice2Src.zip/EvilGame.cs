using System;
using System.Drawing;
using System.Collections;
using Matrix = Microsoft.DirectX.Matrix;
using System.Xml;
using System.IO;
using System.Windows.Forms;

namespace EvilGame
{
	public class replicateAttribute : Attribute
	{
	}

	public class transientAttribute : Attribute
	{
	}

	public class simulateAttribute : Attribute
	{
	}

	public class RSObject
	{
		public virtual void OnTick(double dt)
		{
		}

		public bool IsAuthority { get{ return true; } }
	}

	public enum Dir
	{
		North=0, 
		South=1,
		East=2, 
		West=3,
		Up=4,
		Down=5, 
		None=6,
	}

	public enum DieState
	{
		Idle=0,
		Rolling,
		Sliding,
		Rising,
		Sinking,
	}

	public enum Sounds
	{
		Sunk=0,
		Rolled,
		Click,
		ShortClick,
		LevelStart,
		MP_NewLeader,
	}

	public class Player : RSObject
	{
		[replicate] public Cursor Cursor = null;
		[transient] public InputDef LocalInputDef = null;
		[replicate] public string Name;
		[replicate] public int TeamPref;

		public void Init(InputDef id)
		{
			LocalInputDef = id;
			Name = id.ProfileName;
		}
	}

	public class Lounge : RSObject
	{
		[replicate] public Game TheGame = null;
		[replicate] public Player[] Players = new Player[0];
		[replicate] public Game.GameType NextGameType = Game.GameType.Classic;
		[replicate] public int BoardSize = 7;
		[replicate] public TeamSetup NextTeamSetup = TeamSetup.Individual;
		public static Game.GameType[] GameTypes = { 
			Game.GameType.Classic,  Game.GameType.War, Game.GameType.Battle,
			Game.GameType.Envy, Game.GameType.DuelSurvival };
		public static int[] GameSizes = { 5, 7, 9, 11 };
		public bool IsSinglePlayer = true;
		[transient] private VNode.VText GameTypeText;
		[transient] private VNode.VText GameSizeText;
		[transient] private VNode.VText GameTeamText;

		public Player InputDefToPlayer(InputDef id)
		{
			foreach (Player p in Players)
			{
				if ( p.LocalInputDef == id )
					return p;
			}
			return null;
		}

		public void LocalDirActivated(InputDef id, Dir dir, bool isdown)
		{
			if ( TheGame == null )
				return;
			Cursor c;
			if ( Players.Length != 0 )
			{
				Player p = InputDefToPlayer( id );
				if ( p == null || p.Cursor==null )
					return;
				c = p.Cursor;
			}
			else
				c = TheGame.Cursors[0];

			if ( !isdown )
			{
				if ( c.WantDir == dir )
					dir = Dir.None;
				else
					return;
			}
			TheGame.LocalPlayerMove( c, dir );
		}

		public enum TeamSetup
		{
			Choice,
			Individual,
			Coop,
		}

		public static string TeamSetupDescrip(TeamSetup ts)
		{
			switch ( ts )
			{
				case TeamSetup.Choice:
					return "Choose any team combinations";
				case TeamSetup.Individual:
					return "Everyone for themselves";
				case TeamSetup.Coop:
					return "All For One!";
				default:
					Code.TODO();
					return "";
			}
		}

		public void UpdateGameDesc()
		{
			GameTypeText.Text = Game.GameTypeName( this.NextGameType );
			GameSizeText.Text = this.BoardSize.ToString();
			GameTeamText.Text = this.NextTeamSetup.ToString();
		}

		public void Exit()
		{
			TheGame = null;
		}

		public override void OnTick(double dt)
		{
			if ( TheGame != null )
				TheGame.OnTick( dt );
		}

		private VNode.MenuSet ingameMenu = null;
		public VNode.MenuSet InGameMenu()
		{
			if ( ingameMenu != null )
				return ingameMenu;

			VNode.MenuItem mi;
			ingameMenu = new EvilGame.VNode.MenuSet();

			mi = new VNode.MenuItem( "Resume", "Resume this multiplayer match" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Resume);
			ingameMenu.Add( mi );

			mi = new VNode.MenuItem( "End Match", "End this multiplayer match" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_EndMatch);
			ingameMenu.Add( mi );

			return ingameMenu;
		}

		public const string MultiGuideText = "Up/Down=Change   Left/Right/Click=Select";

		public void SetupLoungeMenu(VNode.MenuSet ms)
		{
			ms.Clear();
			ms.GuideText = MultiGuideText;

			VNode.MenuItem mi;

			foreach (Player p in Players)
			{
				//mi = new EvilGame.VNode.MenuItem( p.Name, "Player settings" );
				VNode.MenuItemMenu mim = new EvilGame.VNode.MenuItemMenu( p.Name+":", "Player settings" );
				mim.Param = p.LocalInputDef;
				mim.Color = Game.TeamColors[ p.TeamPref % Game.TeamColors.Length ];

				mi = new EvilGame.VNode.MenuItem( "[start]", "Start the game" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_StartGame);
				mim.Add( mi );

				mi = new EvilGame.VNode.MenuItem( "[my team]", "Prefered team" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeMyTeam);
				mi.Param = mim;
				mim.Add( mi );

				mi = new EvilGame.VNode.MenuItem( "[game type]", "Select game type" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeType);
				mim.Add( mi );

				mi = new EvilGame.VNode.MenuItem( "[game size]", "Select game size" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeSize);
				mim.Add( mi );

				mi = new EvilGame.VNode.MenuItem( "[team config]", "Select team configuration" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeTeamSetup);
				mim.Add( mi );

				mi = new EvilGame.VNode.MenuItem( "[exit]", "Exit multiplayer" );
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Exit);
				mim.Add( mi );

				mim.Value = mim.MenuSet.Selected.Name;
				ms.Add( mim );
			}

			mi = new EvilGame.VNode.MenuItem( "Quit", "Leave the multiplayer lounge" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Exit);
			ms.Add( mi );

			ms.mSelectedIndex = ms.Items.Length-1;
		}

		[transient] private VNode.MenuSet loungeMenu = null;
		public VNode.MenuSet LoungeMenu(EvilUI ui)
		{
			if ( loungeMenu != null )
				return loungeMenu;

			loungeMenu = new EvilGame.VNode.LocalMenuSet();
			loungeMenu.TextSize = 0;

			VNode.VList across = new EvilGame.VNode.VList( ui );
			across.IsVertical = false;
			across.Offset = 20;
			VNode.VList down = new EvilGame.VNode.VList( ui );
			down.IsVertical = true;
			down.IsCenter = false;
			down.Add( new VNode.VText( "Game Type:", ui, 0 ) );
			down.Add( new VNode.VText( "Game Size:", ui, 0 ) );
			down.Add( new VNode.VText( "Team Config:", ui, 0 ) );
			across.Add( down );
			
			down = new EvilGame.VNode.VList( ui );
			down.IsVertical = true;
			down.IsCenter = false;
			GameTypeText = new VNode.VText( "Not yet", ui, 0 );
			GameTypeText.OnClicked += new EvilGame.VNode.ClickedEvent(menu_Click_GameType);
			GameSizeText = new VNode.VText( "Not given", ui, 0 );
			GameSizeText.OnClicked += new EvilGame.VNode.ClickedEvent(menu_Click_GameSize);
			GameTeamText = new VNode.VText( "Not said", ui, 0 );
			GameTeamText.OnClicked += new EvilGame.VNode.ClickedEvent(menu_Click_TeamConfig);
			down.Add( GameTypeText );
			down.Add( GameSizeText );
			down.Add( GameTeamText );
			across.Add( down );

			down = new EvilGame.VNode.VList( ui );
			down.IsVertical = true;
			down.IsCenter = true;
			VNode.VText vt = new EvilGame.VNode.VText( "Start Game", ui, 1 );
			vt.TextType.SelectAlignment( 0, 0 );
			vt.OnClicked += new EvilGame.VNode.ClickedEvent(menu_Click_StartGame);
			down.Add( vt );
			down.Add( across );

			loungeMenu.ExtraNode = down;

			SetupLoungeMenu( loungeMenu );

			loungeMenu.OnActivated += new EvilGame.VNode.MenuSet.ActivatedEvent(menu_Activated);

			return loungeMenu;
		}


		private void menu_Exit(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			menu.Menu = Code.TheApp.GenMainMenu( menu.EUI );
			this.TheGame = null;
		}

		private void menu_StartGame(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Code.TheApp.StartMultiPlayerNewGame( this );
		}

		private void menu_ChangeType(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			for (int i=0; i<GameTypes.Length; i++)
			{
				if ( GameTypes[i] == NextGameType )
				{
					int j = Code.Mod( i+1, GameTypes.Length );
					if ( item!=null && ( ! item.Owner.IsForward ) )
						j = Code.Mod( i-1, GameTypes.Length );
					NextGameType = GameTypes[ j ];
					//item.Value = Game.GameTypeName( NextGameType );
					//item.Hint = Game.GameTypeHint( NextGameType );
					menu.HintText.Text = Game.GameTypeHint( NextGameType );
					UpdateGameDesc();
					return;
				}
			}
			Code.BadPlace();
		}

		private void menu_ChangeSize(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			for (int i=0; i<GameSizes.Length; i++)
			{
				if ( GameSizes[i] == BoardSize )
				{
					int j = ( i + 1 ) % GameSizes.Length;
					if ( item!=null && ( ! item.Owner.IsForward ) )
						j = Code.Mod( i-1, GameSizes.Length );
					BoardSize = GameSizes[ j ];
					menu.HintText.Text = "Board size of "+BoardSize;
					//item.Value = BoardSize.ToString();
					UpdateGameDesc();
					return;
				}
			}
		}

		private void menu_EndMatch(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			this.TheGame = null;
			menu.Menu = this.LoungeMenu(menu.EUI);
		}

		private void menu_Activated(EvilGame.VNode.MenuManager mm, EvilGame.VNode.MenuSet ms)
		{
			Players = new Player[0];
			foreach (InputDef id in InputDef.Inputs)
			{
				if ( id.HasProfile )
				{
					Player p = new Player();
					p.Init( id );
					Players = (Player[])Code.ArrayAppend( Players, p );
				}
			}
			SetupLoungeMenu( ms );
			UpdateGameDesc();
		}

		private void menu_Resume(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Code.TheApp.ShowingMenu = false;
		}

		private void menu_ChangeTeamSetup(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			TeamSetup[] setups = { TeamSetup.Choice, TeamSetup.Individual, TeamSetup.Coop };
			int curi = -1;
			for (int i=0; i<setups.Length; i++)
				if ( NextTeamSetup == setups[i] )
					curi = i;
			if ( item==null || ( item.Owner.IsForward ) )
				curi = ( curi + 1 ) % setups.Length;
			else
				curi = Code.Mod( curi-1, setups.Length );
			NextTeamSetup = setups[ curi ];
			menu.HintText.Text = TeamSetupDescrip( NextTeamSetup );
			UpdateGameDesc();
		}

		private void menu_Click_GameType()
		{
			menu_ChangeType( Code.TheApp.mMenu, null );
		}

		private void menu_Click_GameSize()
		{
			menu_ChangeSize( Code.TheApp.mMenu, null );
		}

		private void menu_Click_TeamConfig()
		{
			menu_ChangeTeamSetup( Code.TheApp.mMenu, null );
		}

		private void menu_ChangeMyTeam(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			VNode.MenuItemMenu mim = (VNode.MenuItemMenu)item.Param;
			InputDef id = (InputDef)mim.Param;
			if ( id == null )
				return;
			Player p = InputDefToPlayer( id );
			if ( item.Owner.IsForward )
				p.TeamPref = Code.Mod( p.TeamPref+1, Game.TeamColors.Length );
			else
				p.TeamPref = Code.Mod( p.TeamPref-1, Game.TeamColors.Length );
			mim.Color = Game.TeamColors[ p.TeamPref ];
			mim.TempValueVisual.TextType.Color = mim.Color;
			mim.TempVisual.TextType.Color = mim.Color;
		}

		private void menu_Click_StartGame()
		{
			menu_StartGame( Code.TheApp.mMenu, null );
		}
	}

	public class FloatingText
	{
		public string Name;
		public Point ScreenPos;
		public double TimeStart;
		public Color Color;
		public static double DefFloatTime = 2.0;

		public FloatingText(Game g, string s, Point p, Color c)
		{
			TimeStart = g.Time;
			Name = s;
			ScreenPos = p;
			Color = c;
		}

		public double Progress(Game g)
		{
			double t = ( g.Time - TimeStart ) / DefFloatTime;
			if ( t > 1.0 ) t = 1.0;
			if ( t < 0.0 ) t = 0.0;
			t = Math.Sqrt( t );
			return t;
		}
	}

	public class Game : RSObject
	{
		public Tile[] Tiles;
		[replicate] public Die[] Dice = new Die[0];
		public Team[] Teams = new Team[0];
		public Cursor[] Cursors = new Cursor[0];
		public int TileWidth, TileHeight;
		[replicate] public double Time;
		[replicate] public double AbsoluteTime;
		[transient] private int FrameCount=0;
		[replicate] public bool IsPaused = false;
		[transient] public ArrayList FloatingTexts = new ArrayList();
		[transient] public VNode HUDNode = null;	

		public virtual void CustomUI(EvilUI ui)
		{
		}

		public virtual int RelativeTeamScore(Team t)
		{
			return t.Score;
		}

		public Team Leader()
		{
			Team bt = Teams[0];
			int bs = RelativeTeamScore( bt );
			foreach (Team ct in Teams)
			{
				int cs = RelativeTeamScore( ct );
				if ( cs > bs )
				{
					bt = ct;
					bs = cs;
				}
			}
			return bt;
		}
	
		public virtual bool IsPreGame
		{
			get
			{
				if ( AbsoluteTime < DefPreGameTime )
					return true;
				return false;
			}
		}

		public void AddFloating(Point p, string text, Color c)
		{
			FloatingText ft = new FloatingText( this, text, p, c );
			FloatingTexts.Add( ft );
		}

		public void PlaySound(Sounds s)
		{
			Code.TheApp.PlaySound( s );
		}

		public Cursor FindCursor(InputDef input)
		{
			foreach ( Cursor c in Cursors )
			{
				if ( c.Input == input )
					return c;
			}
			return null;
		}

		public virtual void OnDieSunk(int top, int score, string msg, Cursor c)
		{
			c.Team.Score += score;
			if ( IsShowScores )
				AddFloating( c.ScreenPos, msg, c.Team.Color );
			PlaySound( Sounds.Sunk );
		}

		public virtual void OnDieMoved(Die d)
		{
		}

		public virtual void OnMovedCursor(Cursor c)
		{
		}

		public virtual bool FreeCursor
		{
			get { return false; }
		}

		public virtual VNode.MenuManager ScreenMenu
		{
			get { return null; }
		}

		public virtual bool IsFloorRespawn
		{
			get { return true; }
		}

		public virtual bool GameOver
		{
			get { return false; }
		}

		public class GameMode_InfTime : Game
		{

		}

		public class GameMode_War : Game
		{
			public int Rows
			{
				get
				{
					int r = TileWidth/2 - 1;
					return r;
				}
			}

			public override bool IsShowScores
			{
				get
				{
					return false;
				}
			}


			public override string TitleString
			{
				get
				{
					return "";
				}
			}

			public DieType TeamDieType(Team t)
			{
				if ( t == Teams[0] )
					return DieType.Normal;
				if ( t == Teams[1] )
					return DieType.Inverted;
				Code.TODO();
				return DieType.Fifteen;
			}

			public int DiceLeft(Team t)
			{
				DieType dt = TeamDieType( t );
				int count = 0;
				foreach (Die d in Dice)
				{
					if ( d.DieType == dt
						&& d.State != DieState.Sinking )
						count++;
				}
				return count;
			}

			public override int RelativeTeamScore(Team t)
			{
				return DiceLeft( t );
			}


			private bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					foreach (Team t in Teams)
					{
						if ( DiceLeft( t ) == 0 )
						{
							wasGameOver = true;
							return true;
						}
					}
					return false;
				}
			}

			public override string TeamHUD(Team t)
			{
				int left = DiceLeft( t );
				string ans = left.ToString() + " Left";
				if ( wasGameOver && left != 0 )
					ans += "\nWinner!";
				return ans;
			}

			public override int DefNormalDie
			{
				get
				{
					return 0;
				}
			}

			protected override void CheckDieCount(double dt)
			{
				return;
			}

			public override void InitMultiPlayer(Lounge el)
			{
				base.InitMultiPlayer (el);

				Code.Assert( Teams.Length == 2 );

				int max = Dice.Length/2;
				foreach (Cursor c in Cursors)
				{
					int offset = Code.Random.Next(max)*2;
					if ( c.Team == Teams[1] )
						offset += 1;
					c.ForceMovedTo( Dice[offset].TileLoc );
					c.PreviousLoc = c.TileLoc;
				}
			}


			public override void Init(int size)
			{
				base.Init (size);

				for (int x=0; x<Rows; x++)
				{
					for (int y=0; y<TileHeight; y++)
					{
						Die d = new Die();
						AddUnInitedDie( d, Tiles[ x + y*TileWidth ] );
						this.StartRandomDie( d, false );
						d.DieType = DieType.Normal;

						int ox = TileWidth-x-1;
						Die nd = new Die();
						AddUnInitedDie( nd, Tiles[ ox + y*TileWidth ] );
						int up = d.Sides[ (int)Dir.Up ];
						int south = d.Sides[ (int)Dir.South ];
						nd.SetUpAndSouth( up, south );
						nd.DieType = DieType.Inverted;
					}
				}
			}

		}

		public class GameMode_DuelSurvival : Game
		{
			public override int DefNormalDie
			{
				get
				{
					return 0;
				}
			}

			public override bool IsShowScores
			{
				get
				{
					return false;
				}
			}

			public override bool IsFloorRespawn
			{
				get
				{
					return false;
				}
			}


			public override string TeamHUD(Team t)
			{
				int c = GetNumFree( t );
				string s = c.ToString();
				if ( wasGameOver )
				{
					if ( c != 0 )
						s += "\nWinner!";
				}
				return s;
			}

			public override int RelativeTeamScore(Team t)
			{
				return GetNumFree( t );
			}

			public override string TitleString
			{
				get
				{
					return "";
				}
			}

			private bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					if ( wasGameOver )
						return true;
					foreach (Team t in Teams)
					{
						if ( GetNumFree(t) == 0 )
						{
							wasGameOver = true;
							return true;
						}
					}
					return false;
				}
			}


			public int GetNumFree(Team t)
			{
				int free = 0;
				int used = 0;
				foreach (Tile tile in Tiles)
				{
					if ( tile.TeamOwner == t )
					{
						if ( tile.DieHeld != null )
							used++;
						else
							free++;
					}
				}
				return free;
			}

			private int boardsize = 0;
			public override void Init(int size)
			{
				boardsize = size;
				base.Init( 1 );
			}

			public override void InitMultiPlayer(Lounge el)
			{
				base.InitMultiPlayer( el );

				int teams = Teams.Length;
				base.Init( boardsize*teams );

				for (int y=0; y<TileHeight; y++)
				{
					int my = (teams - ( y / boardsize ))-1;
					for (int x=0; x<TileWidth; x++)
					{
						int mx = ( x / boardsize );
						if ( mx != my )
							Tiles[ x + y*TileWidth ].IsWalkable = false;
						else
							Tiles[ x + y*TileWidth ].TeamOwner = Teams[ mx ];
					}
				}

				int m = boardsize/2 + 1;
				foreach ( Cursor c in Cursors )
				{
					int i = FindFirstTile( c.Team );
					while ( Tiles[i].DieHeld != null )
						i++;

					Die d = new Die();
					AddUnInitedDie( d, Tiles[i] );
					StartRandomDie( d, false );
					c.ForceMovedTo( Tiles[i] );
					c.PreviousLoc = c.TileLoc;
				}
			}

			public int FindFirstTile(Team t)
			{
				int index=-1;
				for (int j=0; j<Teams.Length; j++)
					if ( Teams[j] == t )
						index = j;
				int y = ( Teams.Length - index - 1 )*boardsize*TileWidth;
				return (index * boardsize) + y;
			}

			public override double DefStateLength(DieState st)
			{
				double len = base.DefStateLength (st);
				if ( st==DieState.Sinking )
					len *= 0.3f;
				return len;
			}

			public int RandomTileIndex(int team)
			{
				int y = Code.Random.Next( boardsize );
				int x = Code.Random.Next( boardsize );
				y += (Teams.Length - team - 1)*boardsize;
				x += team*boardsize;
				return x + y*TileWidth;
			}

			public override Die AddRandomDie(bool isrising)
			{
				if ( !isrising )
					return base.AddRandomDie (isrising);

				int shift = TileWidth*boardsize - boardsize;
				ArrayList open = new ArrayList();
				for (int i=0; i<boardsize*TileWidth; i++)
				{
					bool isopen = true;
					if ( !Tiles[i].IsWalkable )
						isopen = false;
					if ( Tiles[i].DieHeld != null )
						isopen = false;
					for (int j=0; j<Teams.Length; j++)
					{
						if ( Tiles[ i + j*shift ].DieHeld != null )
							isopen = false;
					}
					if ( isopen )
						open.Add( i );
				}
				if ( open.Count != 0 )
				{
					int i = (int)open[ Code.Random.Next( open.Count ) ];
					Die lastd = null;
					for (int j=0; j<Teams.Length; j++)
					{
						Die d = new Die();
						Tile t = Tiles[ i + j*shift ];
						this.AddUnInitedDie( d, t );
						if ( lastd == null )
						{
							StartRandomDie( d, true );
							lastd = d;
						}
						else
						{
							d.SetUpAndSouth( lastd.Sides[(int)Dir.Up], lastd.Sides[(int)Dir.South] );
							d.State = DieState.Rising;
						}
					}
					return null;
				}
				else
				{
					int index = 0;
					foreach (Team tm in Teams)
					{
						if ( GetNumFree( tm ) != 0 )
						{
							int tile = RandomTileIndex( index );
							while ( Tiles[tile].DieHeld != null )
								tile = RandomTileIndex( index );
							
							Die d = new Die();
							AddUnInitedDie( d, Tiles[tile] );
							StartRandomDie( d, true );
						}
						index++;
					}
					return null;
				}
			}


			[replicate] double AddNewDieCheck = 0.0;
			[transient] double AddNewDieTime = 1.0;
			protected override void CheckDieCount(double dt)
			{
				AddNewDieCheck += dt;
				if ( AddNewDieCheck > AddNewDieTime )
				{
					AddNewDieCheck -= AddNewDieTime;
					AddRandomDie( true );
				}
			}
		}

		public class GameMode_Survival : Game
		{
			public override double DefStateLength(DieState st)
			{
				double len = base.DefStateLength (st);
				if ( st==DieState.Sinking )
					len *= 0.3f;
				return len;
			}

			public override bool IsFloorRespawn
			{
				get
				{
					return false;
				}
			}

			public override void Init(int size)
			{
				base.Init(size);

				if ( Tiles.Length < 9 )
					return;

				int w = TileWidth;
				int m = w/2;
				ArrayList tiles = new ArrayList();
				tiles.Add( Tiles[ (m+0) + (m+0)*w ] );
				tiles.Add( Tiles[ (m+1) + (m+0)*w ] );
				tiles.Add( Tiles[ (m+0) + (m+1)*w ] );
				tiles.Add( Tiles[ (m-1) + (m+0)*w ] );
				tiles.Add( Tiles[ (m+0) + (m-1)*w ] );

				foreach ( object ob in tiles )
				{
					Tile t = (Tile)ob;
					if ( t.DieHeld == null )
					{
						foreach ( Die d in Dice )
						{
							if ( !tiles.Contains( d.TileLoc ) )
							{
								d.MoveTo( t, null, null );
								break;
							}
						}
					}
				}
			}

			public override int DefNormalDie
			{
				get
				{
					return 5;
				}
			}


			public int SpotsLeft
			{
				get
				{
					return Tiles.Length - Dice.Length;
				}
			}

			public override bool IsShowScores
			{
				get
				{
					return false;
				}
			}

			public override string TopRightString
			{
				get
				{
					if ( !Code.TheApp.IsSinglePlayer )
						return "";
					Profile.HighScore hs = Profile.Default.GetHighScore( Game.GameType.Survival, false );
					if ( hs != null )
						return hs.Name + " got " + Code.SecondsToString( hs.Score );
					else
						return "No High Score";
				}
			}


			private bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					if ( SpotsLeft == 0 )
					{
						if ( !wasGameOver )
						{
							wasGameOver = true;
							int score = (int)this.Time;
							Profile.Default.TestAddHighScore( Game.GameType.Survival, score, false );
						}
						return true;
					}
					return false;
				}
			}

			public override string TitleString
			{
				get
				{
					string s = base.TitleString;
					s += " with "+SpotsLeft+" left";
					return s;
				}
			}

			[replicate] double AddNewDieCheck = 0.0;
			[transient] double AddNewDieTime = 1.0;
			protected override void CheckDieCount(double dt)
			{
				AddNewDieCheck += dt;
				if ( AddNewDieCheck > AddNewDieTime )
				{
					AddNewDieCheck -= AddNewDieTime;
					AddRandomDie( true );
				}
			}
		}

		public class GameMode_Short : GameMode_Classic
		{
			public override double GameLength
			{
				get
				{
					return 15;
				}
			}

		}

		public static Game GenPuzzleGame(Puzzle.Level el, bool iseditor)
		{
			GameMode_Puzzle pz;
			if ( iseditor )
				pz = new GameMode_PuzzleEditor();
			else
				pz = new GameMode_Puzzle();
			pz.PuzzleInit( el );
			return pz;
		}

		public static bool IsBetterScore(GameType type, int old, int nw)
		{
			return ( nw >= old );
		}

		public static string GameTypeHint(GameType t)
		{
			switch ( t )
			{
				case GameType.Classic:
					return "Score as much as you can in 3 minutes";
				case GameType.Envy:
					return "Get 4 different Die types";
				case GameType.Survival:
					return "Survive as long as you can in this Co-op mode";
				case GameType.DuelSurvival:
					return "Survive longer than your opponents";
				case GameType.War:
					return "Make the other Dice die for their country";
				case GameType.Battle:
					return "Don't let their Evil win. Best on big boards.";
				default:
					Code.TODO();
					return "A game type";
			}
		}

		public static string GameTypeName(GameType t)
		{
			switch ( t )
			{
				case GameType.Classic:
					return "Ancient Evil";
				case GameType.Feed:
					return "Feed The Evil";
				case GameType.Infinite:
					return "Eternal Evil";
				case GameType.Survival:
					return "Overwhelming Evil";
				case GameType.Envy:
					return "Clamoring For Evil";
				case GameType.DuelSurvival:
					return "Overwhelming Evil";
				case GameType.War:
					return "Lesser Of Two Evils";
				case GameType.RemoveRandom:
					return "Eradicate Evil";
				case GameType.Short:
					return "Rush Of Evil";
				case GameType.TwentyFour:
					return "The Evil Number";
				case GameType.Battle:
					return "Battling Evil";
				default:
					Code.TODO();
					return "NO NAME";
			}
		}

		public enum GameType
		{
			None=0,
			Classic=1,
			Infinite=2,
			Short=3,
			Survival=4,
			DuelSurvival=5,
			RemoveRandom=6,
			TwentyFour=7,
			Feed=8,
			Envy=9,
			War=10,
			Battle=11,
		}

		public static Game GenGame(GameType mode)
		{
			switch ( mode )
			{
				case GameType.Classic:
					return new GameMode_Classic();
				case GameType.Infinite:
					return new GameMode_InfTime();
				case GameType.Short:
					return new GameMode_Short();
				case GameType.Survival:
					return new GameMode_Survival();
				case GameType.RemoveRandom:
					return new GameMode_RemoveRandom();
				case GameType.TwentyFour:
					return new GameMode_TwentyFour();
				case GameType.Feed:
					return new GameMode_Feed();
				case GameType.Envy:
					return new GameMode_Envy();
				case GameType.DuelSurvival:
					return new GameMode_DuelSurvival();
				case GameType.War:
					return new GameMode_War();
				case GameType.Battle:
					return new GameMode_Battle();
				default:
					Code.TODO();
					return null;
			}
		}

		public class GameMode_TwentyFour : GameMode_RemoveRandom
		{
			public GameMode_TwentyFour()
			{
				DefBoardSize = 4;
			}

			public override string EndGameString
			{
				get
				{
					return "Solved!";
				}
			}

			public override bool UseHighScores
			{
				get
				{
					return false;
				}
			}


			public override bool IsShowScores
			{
				get
				{
					return false;
				}
			}

			public override string TopRightString
			{
				get
				{
					return "";
				}
			}


			public override int DefNormalDie
			{
				get
				{
					return 0;
				}
			}

			public override double DefStateLength(DieState st)
			{
				double len = base.DefStateLength (st);
				if ( st == DieState.Sinking )
					len *= 0.5;
				return len;
			}


			public override string TitleString
			{
				get
				{
					return "";
				}
			}

			public override void Init(int size)
			{
				base.Init (DefBoardSize);

				int count = DefBoardSize*DefBoardSize - 1;
				for (int i=0; i<count; i++)
				{
					Die d = new Die.TwentyFour(count);
					AddUnInitedDie( d, null );
				}

				Tile t = null;
				foreach ( Tile s in Tiles )
				{
					if ( s.DieHeld == null )
						t = s;
				}

				Dir last = Dir.None;
				int times = Tiles.Length*10;
				for (int i=0; i<times; i++)
				{
					Dir dir = Dir.None;
					Tile other = null;
					while ( other == null )
					{
						dir = Die.FourDirs[ Code.Random.Next(4) ];
						if ( dir != last )
							other = t.GetNeighbor( dir );
					}
					last = dir;

					other.DieHeld.Rotate( Die.OppositeDir( dir ) );
					other.DieHeld.MoveTo( t, null, null );
					t = other;
				}

				foreach (Die d in Dice)
					d.DieType = DieType.Fifteen;
			}

		}

		public int NumDieAlive
		{
			get
			{
				int c = 0;
				foreach ( Die d in Dice )
				{
					if ( d.State != DieState.Sinking )
						c++;
				}
				return c;
			}
		}

		public class GameMode_Puzzle : Game
		{
			public Puzzle.Level Level = null;
			public int Steps = 0;

			public override void OnDieMoved(Die d)
			{
				base.OnDieMoved (d);
				Steps++;
			}

			public override bool IsFloorRespawn
			{
				get
				{
					return false;
				}
			}


			public override void InitSinglePlayer()
			{
				base.InitSinglePlayer ();

				Cursor c = Cursors[0];
				c.ForceMovedTo( Tiles[ Level.StartTile ] );
				c.State = DieState.Idle;
			}


			public override void Init(int size)
			{
				this.TileHeight = Level.Height;
				this.TileWidth = Level.Width;
				Tiles = new Tile[ Level.Tiles.Length ];
				for (int y=0; y<Level.Height; y++)
				{
					for (int x=0; x<Level.Width; x++)
					{
						Puzzle.PzTile pt = Level.Tiles[ x + y*Level.Width ];
						//if ( pt.IsWalkable )
						{
							Tile t = new Tile();
							Tiles[ x + TileWidth*y ] = t;
							t.PosX = x;
							t.PosY = y;
							t.Game = this;
							t.DieHeld = null;
							t.PzTile = pt;
							t.IsWalkable = pt.IsWalkable;

							if ( pt.DieHeld != null )
							{
								Puzzle.PzDie pd = pt.DieHeld;
								
								Die d = new Die();
								d.SetUpAndSouth( pd.Top, pd.South );
								AddUnInitedDie( d, t );
							}
						}
					}
				}
			}

			public override string EndGameString
			{
				get
				{
					if ( Level.MaxSteps == 0 
						|| Level.MaxSteps >= this.Steps )
						return "Solved!";
					else
						return "Good";
				}
			}


			public override string TitleString
			{
				get
				{
					return Steps.ToString() + " / " + Level.MaxSteps;
				}
			}

			public override int DefNormalDie
			{
				get { return 0; }
			}


			public override bool IsShowScores
			{
				get { return Level.showScore; }
			}

			[transient] private bool wasGameOver = false;
			public override bool GameOver
			{
				get 
				{
					if ( Cursors[0].State != DieState.Idle )
						return false;
					bool isover = ( NumDieAlive == 0 );
					if ( isover && !wasGameOver )
					{
						wasGameOver = true;
						if ( Level.MaxSteps==0 || Level.MaxSteps>=Steps )
						{
							Profile.Default.AddBeaten( Level.Campaign.Name, Level.Name, Steps );
							string s = "["+Steps+"] "+Level.Name;
							if ( Steps <= Level.MaxSteps || Level.MaxSteps==0 )
								s = "[*] "+Level.Name;
							Code.TheApp.mMenu.UpdateItemName( Level.Name, s );
						}
					}
					return isover; 
				}
			}

			public void PuzzleInit(Puzzle.Level el)
			{
				Level = el;
			}

			protected override void CheckDieCount(double dt)
			{
				//don't do anything
				return;
			}

		}

		public class GameMode_RemoveRandom : Game
		{
			public GameMode_RemoveRandom()
			{
				DefBoardSize = 5;
			}

			public override int DefNormalDie
			{
				get
				{
					return DefBoardSize*DefBoardSize - 1;
				}
			}

			public virtual bool UseHighScores
			{
				get { return false; }
			}

			private bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					if ( NumDieAlive == 0 )
					{
						if ( !wasGameOver && UseHighScores )
						{
							wasGameOver = true;
							int score = Teams[0].Score;
							Profile.Default.TestAddHighScore( Game.GameType.RemoveRandom, score, false );
						}
						return true;
					}
					else
						return false;
				}
			}

			public override bool IsShowScores
			{
				get
				{
					return true;
				}
			}

			public override string TopRightString
			{
				get
				{
					Profile.HighScore hs = Profile.Default.GetHighScore( Game.GameType.RemoveRandom, false );
					if ( hs != null )
						return hs.Name + " got " + hs.Score;
					return "No High Score";
				}
			}


			public override string TitleString
			{
				get
				{
					return "";
				}
			}

			protected override void CheckDieCount(double dt)
			{
				//never add die
				return;
			}
		}

		public class GameMode_Envy : Game
		{
			public override bool GameOver
			{
				get
				{
					foreach( Team t in Teams )
					{
						if ( t.NumEnvies >= 4 )
							return true;
					}
					return false;
				}
			}

			public override bool IsShowScores
			{
				get
				{
					return false;
				}
			}


			public override void OnDieSunk(int top, int score, string msg, Cursor c)
			{
				base.OnDieSunk (top, score, msg, c);


				int side = top-1;
				
				if ( c.Team.Envies[ side ] == false )
					AddFloating( c.ScreenPos, "Taken "+top, c.Team.Color );

				foreach (Team t in Teams)
				{
					t.Envies[ side ] = false;
				}
				c.Team.Envies[ side ] = true;
			}


			public override string TitleString
			{
				get
				{
					return "";
				}
			}

			public override int RelativeTeamScore(Team t)
			{
				return t.NumEnvies;
			}

			public override string TeamHUD(Team t)
			{
				string s = "";
				for (int i=0; i<6; i++)
				{
					if ( i != 0 )
						s += "-";
					if ( t.Envies[i] )
						s += (i+1).ToString();
					else
						s += "-";
				}
				if ( t.NumEnvies >= 4 )
					s += "\nWinner!";
				return s;
			}
		}

		public class GameMode_Feed : Game
		{
			public override bool IsShowScores
			{
				get { return false; }
			}

			public int HighestCombo
			{
				get
				{
					int high = 0;
					foreach ( Die d in Dice )
					{
						if ( d.MaxCombo > high )
							high = d.MaxCombo;
					}
					return high;
				}
			}

			public override string TitleString
			{
				get
				{
					if ( PreviousCombo == 0 )
						return "Start a combo...";
					return PreviousCombo.ToString();
				}
			}

			public override string TopRightString
			{
				get
				{
					Profile.HighScore hs = Profile.Default.GetHighScore( Game.GameType.Feed, false );
					if ( hs == null )
						return "No High Score";
					return hs.Name + " reached " + hs.Score;
				}
			}


			[transient] public int PreviousCombo = 0;
			[transient] public bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					int high = HighestCombo;
					if ( high < PreviousCombo )
					{
						if ( !wasGameOver )
						{
							wasGameOver = true;
							int score = PreviousCombo;
							Profile.Default.TestAddHighScore( Game.GameType.Feed, score, false );
						}
						return true;
					}
					PreviousCombo = high;
					return false;
				}
			}

		}

		public class BattleSector : RSObject
		{
			public int MinX, MinY;
			public int MaxX, MaxY;
			public Tile ScoreTile;
			[replicate] public int Points;
			[replicate] public Team Owner;
			[replicate] public double TickTime = 0.0;

			public void SetPos(Game g, int x, int y, int s)
			{
				MinX = x;
				MinY = y;
				MaxX = x+s;
				MaxY = y+s;

				int mx = ( x==0 ? 0 : g.TileWidth-1 );
				int my = ( y==0 ? 0 : g.TileHeight-1 );
				ScoreTile = g.Tiles[ mx + my*g.TileWidth ];
				ScoreTile.CalcScreenPos = true;
			}

			public void OnTick(Game g, double dt)
			{
				base.OnTick (dt);

				double ratio = 1.0;
				int l = (int)( TickTime * ratio );
				TickTime += dt;
				int c = (int)( TickTime * ratio );

				if ( l != c && Owner!=null )
				{
					int s = 1;
					if ( s == 0 )
						s = 1;
					if ( s > Points )
						s = Points;
					Points -= s;
					Owner.Score += s;

					g.AddFloating( this.ScoreTile.ScreenPos,
						"+ "+s, Owner.Color );
					
					if ( Points < 0 )
						Points = 0;
					if ( Points == 0 )
						Owner = null;
				}
			}

			public bool Includes(int x, int y)
			{
				if ( ( x < MinX ) || ( x > MaxX ) )
					return false;
				if ( ( y < MinY ) || ( y > MaxY ) )
					return false;
				return true;
			}

			public bool Includes(Tile t)
			{
				return Includes( t.PosX, t.PosY );
			}
		}

		public class GameMode_Battle : Game
		{
			private int defNumDie=0;
			public BattleSector[] Sectors;
			public const int MaxScore = 500;

			public override bool GameOver
			{
				get
				{
					foreach ( Team t in Teams )
					{
						if ( t.Score >= MaxScore )
							return true;
					}
					return false;
				}
			}

			public override string TitleString
			{
				get
				{
					return "Target\n" + MaxScore;
				}
			}


			public override string TeamHUD(Team t)
			{
				string s = base.TeamHUD (t);
				if ( t.Score >= MaxScore )
					s += "\nWinner";
				return s;
			}

			public override void OnTick(double dt)
			{
				if ( !GameOver )
				{
					foreach (BattleSector bs in Sectors)
					{
						bs.OnTick( this, dt );
					}
				}

				base.OnTick (dt);
			}


			public override void CustomUI(EvilUI ui)
			{
				TextType tt = new TextType( 1 );
				foreach (BattleSector bs in Sectors)
				{
					Point p = bs.ScoreTile.ScreenPos;
					string s = bs.Points.ToString();
					if ( bs.Owner == null )
						tt.Color = Color.White;
					else
						tt.Color = bs.Owner.Color;
					ui.DrawTextAt( s, tt, p );
				}
			}

			public override int RelativeTeamScore(Team t)
			{
				return t.Score;
			}


			public override void OnDieSunk(int top, int score, string msg, Cursor c)
			{
				//base.OnDieSunk (top, score, msg, c);
				PlaySound( Sounds.Sunk );

				BattleSector bs = null;
				foreach (BattleSector b in Sectors)
				{
					if ( b.Includes( c.TileLoc ) )
						bs = b;
				}

				if ( bs == null )
				{
					AddFloating( c.ScreenPos, "Neutral Zone", c.Team.Color );
					return;
				}

				if ( bs.Owner!=null && bs.Owner!=c.Team )
				{
					msg = "( "+msg+" ) * 2";
					score *= 2;
				}

				if ( IsShowScores )
					AddFloating( c.ScreenPos, msg, c.Team.Color );

				if ( bs.Owner==c.Team )
					bs.Points += score;
				else
				{
					if ( bs.Points >= score )
					{
						bs.Points -= score;
					}
					else
					{
						score -= bs.Points;
						bs.Points = score;
						bs.Owner = c.Team;
					}
					if ( bs.Points == 0 )
						bs.Owner = null;
				}
			}

			public override int DefNormalDie
			{
				get
				{
					return defNumDie;
				}
			}


			public override void Init(int size)
			{
				defNumDie = 0;
				base.Init (size);
				defNumDie = ( size*(size-1) ) / 3;

				int m = size/2;
				int q = size/4;
				int w = size - q - 1;

				for (int i=0; i<size; i++)
				{
					bool walk = true;
					if ( size > 5 )
					{
						if ( i==0 || i==size-1 )
							walk = false;
					}
					if ( i==m || i==m-1 || i==m+1 )
						walk = false;
					if ( !walk )
					{
						Tiles[ m + i*TileWidth ].IsWalkable = false;
						Tiles[ i + m*TileWidth ].IsWalkable = false;
					}
				}

				Sectors = new BattleSector[ 4 ];
				for (int j=0; j<Sectors.Length; j++)
					Sectors[j] = new BattleSector();
				Sectors[0].SetPos( this, 0, 0, m-1 );
				Sectors[1].SetPos( this, m+1, 0, m-1 );
				Sectors[2].SetPos( this, 0, m+1, m-1 );
				Sectors[3].SetPos( this, m+1, m+1, m-1 );

				int count = DefNormalDie;
				for (int i=0; i<count; i++)
					AddRandomDie(false);
			}

		}

		public class GameMode_Classic : Game
		{
			public virtual double GameLength 
			{ 
				get { return 3*60; } 
			}

			public override string TopRightString
			{
				get
				{
					if ( !Code.TheApp.IsSinglePlayer )
						return "";
					Profile.HighScore hs = Profile.Default.GetHighScore( Code.TheApp.LastGameType, false );
					if ( hs != null )
					{
						string s = hs.Name+" got "+hs.Score;
						return s;
					}
					return "No High Score";
				}
			}

			public override string TeamHUD(Team t)
			{
				string s = base.TeamHUD (t);
				if ( wasGameOver && !Code.TheApp.IsSinglePlayer )
				{
					bool better = false;
					bool tie = false;
					foreach ( Team other in Teams )
					{
						if ( other != t )
						{
							if ( other.Score == t.Score )
								tie = true;
							if ( other.Score > t.Score )
								better = true;
						}
					}
					if ( !better )
					{
						if ( tie )
							s += "\nTie Winner";
						else
							s += "\nWinner!";
					}
				}
				return s;
			}



			private bool wasGameOver = false;
			public override bool GameOver
			{
				get
				{
					if ( Time >= GameLength )
					{
						if ( !wasGameOver )
						{
							wasGameOver = true;
							int score = Teams[0].Score;
							Profile.Default.TestAddHighScore( Code.TheApp.LastGameType, score, false );
						}
						return true;
					}
					return false;
				}
			}

			public override string TitleString
			{
				get
				{
					int t = (int)( GameLength - Time );
					return Code.SecondsToString( t );
				}
			}

		}

		public virtual string TeamHUD(Team t)
		{
			string s = "";
			if ( !IsShowScores )
				return "";
			int vs = (int)t.VisualScore;
			s += vs.ToString();
			return s;
		}

		public virtual bool IsShowScores { get { return true; } }

		public virtual string EndGameString
		{
			get { return "Game Over"; }
		}

		public virtual string TopRightString
		{
			get { return ""; }
		}

		public virtual string BottomRightString
		{
			get
			{
				string ans = "";
				if ( IsFloorRespawn )
				{
					foreach (Cursor c in Cursors)
					{
						if ( c.FloorTime > DefFloorRespawnTime*0.25 )
						{
							double tl = DefFloorRespawnTime - c.FloorTime;
							int ti = (int)tl;
							if ( c.Player == null )
								ans += "Respawn in "+ti+"...\n";
							else
								ans += c.Player.Name + " respawns in "+ti+"...\n";
						}
					}
				}
				return ans;
			}
		}

		public virtual string TitleString
		{
			get
			{
				return Code.SecondsToString( (int)Time );
			}
		}

		[transient] protected double mCountCheckTime = 0;
		[transient] protected double mNoDieCheckTime = 0;
		[transient] protected int mLastDieCount = 0;
		protected virtual void CheckDieCount(double dt)
		{
			if ( mLastDieCount == Dice.Length )
			{
				mNoDieCheckTime += dt;
				if ( mNoDieCheckTime >= DefMaxNoChange )
				{
					mNoDieCheckTime -= DefMaxNoChange;
					AddRandomDie(true);
				}
			}
			else
			{
				mNoDieCheckTime = 0;
				mLastDieCount = Dice.Length;
			}

			mCountCheckTime += dt;
			if ( mCountCheckTime > DefAddBlockTime )
			{
				mCountCheckTime = 0;
				if ( Dice.Length < DefNormalDie )
				{
					AddRandomDie(true);
				}
			}
		}

		public override void OnTick(double dt)
		{
			AbsoluteTime += dt;

			foreach (Team tm in Teams)
			{
				tm.OnThink( this, dt );
			}

			if ( GameOver )
				return;
			if ( IsPaused )
				return;
			if ( IsPreGame )
				return;

			Time += dt;
			int deadcount = 0;
			FrameCount++;
			Team leader = Leader();

			foreach ( Die d in Dice )
			{
				d.OnTick( dt );
				if ( !d.IsAlive )
					deadcount++;
			}

			foreach ( Cursor c in Cursors )
			{
				c.PreTick( dt );
			}

			if ( ( FrameCount % 2 ) == 0 )
			{
				for (int i=0; i<Cursors.Length; i++)
					Cursors[i].OnTick( dt );
			}
			else
			{
				for (int i=Cursors.Length-1; i>=0; i--)
					Cursors[i].OnTick( dt );
			}

			if ( deadcount != 0 )
			{
				Die[] nr = new Die[ Dice.Length-deadcount ];
				int to = 0;
				foreach ( Die d in Dice )
				{
					if ( d.IsAlive )
						nr[to++] = d;
					else
					{
						Code.Assert( d.TileLoc.DieHeld != d );
					}
				}
				Dice = nr;
			}

			CheckDieCount(dt);

			base.OnTick (dt);

			if ( leader != Leader() )
				PlaySound( Sounds.MP_NewLeader );

			if ( GameOver )
				return;
		}


		public virtual void LocalPlayerMove(Cursor c, Dir dir)
		{
			c.WantDir = dir;
		}

		public virtual void Init(int size)
		{
			if ( size == 0 )
				size = DefBoardSize;
			TileWidth = size;
			TileHeight = size;
			Tiles = new Tile[ TileWidth * TileHeight ];
			for (int i=0; i<TileWidth*TileHeight; i++)
			{
				Tile t = new Tile();
				t.Game = this;
				t.PosX = ( i % TileWidth );
				t.PosY = ( i / TileWidth );
				Tiles[i] = t;
			}

			int count = DefNormalDie;
			for (int i=0; i<count; i++)
				AddRandomDie(false);

			PlaySound( Sounds.LevelStart );
		}

		public static Color[] TeamColors = { Color.LightSkyBlue, Color.Tomato, Color.LightGreen, Color.Pink };

		private Cursor CreateNewCursor(Team t, Player p)
		{
			Cursor c = new Cursor();
			c.Player = p;
			p.Cursor = c;
			Cursors = (Cursor[])Code.ArrayAppend( Cursors, c );
			Tile tile;
			if ( Dice.Length == 0 )
				tile = Tiles[ Code.Random.Next( Tiles.Length ) ];
			else
				tile = Dice[ Code.Random.Next( Dice.Length ) ].TileLoc;
			c.Init( tile, t );
			return c;
		}

		public virtual void InitMultiPlayer(Lounge el)
		{
			if ( el.NextTeamSetup == Lounge.TeamSetup.Individual )
			{
				foreach ( Player p in el.Players )
				{
					int ti = Teams.Length % TeamColors.Length;
					Team t = new Team();
					t.Init( TeamColors[ ti ] );
					Teams = (Team[])Code.ArrayAppend( Teams, t );

					CreateNewCursor( t, p );
				}
				return;
			}
			if ( el.NextTeamSetup == Lounge.TeamSetup.Coop )
			{
				Team t = new Team();
				t.Init( Color.White );
				Teams = new Team[1];
				Teams[0] = t;

				foreach (Player p in el.Players)
					CreateNewCursor( t, p );

				return;
			}
			if ( el.NextTeamSetup == Lounge.TeamSetup.Choice )
			{
				foreach (Player p in el.Players)
				{
					Color tc = Game.TeamColors[ p.TeamPref ];
					Team t = null;
					foreach (Team ft in Teams)
					{
						if ( ft.Color == tc )
							t = ft;
					}
					if ( t == null )
					{
						t = new Team();
						t.Init( tc );
						Teams = (Team[])Code.ArrayAppend( Teams, t );
					}

					CreateNewCursor( t, p );
				}

				return;
			}
			Code.TODO();
			return;
		}

		public virtual void InitSinglePlayer()
		{
			Cursor c;
			Team team;

			c = new Cursor();
			Cursors = (Cursor[])Code.ArrayAppend( Cursors, c );
			team = new Team();
			team.Init( System.Drawing.Color.White );
			Teams = (Team[])Code.ArrayAppend( Teams, team );
			if ( Dice.Length != 0 )
				c.Init( Dice[Code.Random.Next(Dice.Length)].TileLoc, team );
			else
				c.Init( Tiles[Code.Random.Next(Tiles.Length)], team );
		}

		public void AddUnInitedDie(Die d, Tile to)
		{
			if ( Dice.Length >= Tiles.Length )
				return;

			Tile t = to;
			while ( t == null )
			{
				t = Tiles[ Code.Random.Next(Tiles.Length) ];
				if ( t.DieHeld != null || !t.IsWalkable )
					t = null;
			}

			d.Init( t );

			//Append to dice array:
			Dice = (Die[])Code.ArrayAppend( Dice, d );
		}

		public void StartRandomDie(Die d, bool isrising)
		{
			Dir[] dirs = Die.FourDirs;

			for (int i=0; i<this.DefRandomRots; i++)
				d.Rotate( dirs[Code.Random.Next(dirs.Length)] );

			if ( isrising )
				d.State = DieState.Rising;

		}

		public virtual Die AddRandomDie(bool isrising)
		{
			Die d = new Die();
			AddUnInitedDie( d, null );

			StartRandomDie( d, isrising );

			return d;
		}

		public Tile GetTile(int x, int y)
		{
			if ( ( x < 0 ) || ( y < 0 ) )
				return null;
			if ( ( x >= TileWidth ) || ( y >= TileHeight ) )
				return null;
			return Tiles[ x + y*TileWidth ];
		}

		public Game()
		{
		}

		[transient] public int DefBoardSize = 7;
		[transient] public int DefRandomRots = 20;
		[transient] public double DefAddBlockTime = 2.0;
		[transient] public double DefGameLength = 3.0 * 60.0;
		[transient] public double DefMaxNoChange = 5.0;
		[transient] public float DefSquashHeight = 0.4f;
		[transient] public double DefWarningTime = 11.0;
		[transient] public float DefJumpHeight = 0.75f;
		[transient] public double DefPreGameTime = 2.0;
		[transient] public double DefFloorRespawnTime = 10.0;
		public virtual int DefNormalDie
		{
			get { return (TileWidth*TileHeight)/2; }
		}
		public virtual double DefStateLength(DieState st)
		{
			switch ( st )
			{
				case DieState.Idle:
					Code.BadPlace();
					return 0.0;
				case DieState.Rising:
					return 3.0;
				case DieState.Rolling:
					return 0.2;
				case DieState.Sliding:
					return 0.15;
				case DieState.Sinking:
					return 8.0;
				default:
					Code.TODO();
					return 0.0;
			}
		}
	}

	public class Piece : RSObject
	{
		[replicate] private DieState mState = DieState.Idle;
		[replicate] public DieState PreviousState = DieState.Idle;
		[replicate] public double StateStartTime;
		[replicate] protected Tile mTileLoc = null;
		[replicate] public Tile PreviousLoc = null;

		public DieState State
		{
			get { return mState; }
			set
			{
				if ( mState == value )
					return;
				PreviousState = mState;
				mState = value;
				StateStartTime = Game.Time;
			}
		}

		public Tile TileLoc
		{
			get { return mTileLoc; }
		}

		public Game Game
		{
			get { return TileLoc.Game; }
		}

		public bool AnimDone
		{
			get
			{
				if ( State == DieState.Idle )
					return true;
				if ( Progress >= 1.0f )
					return true;
				return false;
			}
		}

		public float Progress
		{
			get
			{
				if ( State == DieState.Idle )
					return 0.0f;
				double len = Game.DefStateLength( State );
				float p = (float)(( Game.Time - StateStartTime ) / len);
				if ( p < 0.0f )
					p = 0.0f;
				if ( p > 1.0f )
					p = 1.0f;
				return p;
			}
		}
	}

	public class Team
	{
		[replicate] public int Score = 0;
		[replicate] public Color Color = Color.White;
		[replicate] public bool[] Envies = { false, false, false, false, false, false };
		[transient] public VNode HUDDie = null;
		[transient] public VNode HUDText = null;
		[transient] public float VisualScore = 0.0f;

		public void OnThink(Game g, double dt)
		{
			float cs = (float)Score;
			if ( VisualScore != cs )
			{
				float diff = cs - VisualScore;
				float ds = (float)( ( 15.0 + diff ) * dt );
				if ( Math.Abs( diff ) <= ds )
				{
					VisualScore = (float)Score;
				}
				else
				{
					if ( cs > VisualScore )
						VisualScore += ds;
					else
						VisualScore -= ds;
				}
			}
		}

		public int NumEnvies
		{
			get
			{
				int count = 0;
				foreach(bool b in Envies)
					if ( b )
						count++;
				return count;
			}
		}

		public void Init(Color color)
		{
			Color = color;
		}
	}

	public class Cursor : Piece
	{
		[replicate] public Dir WantDir = Dir.None;
		[transient] public float Spin = (float)Code.Random.NextDouble();
		public Team Team;
		[transient] public InputDef Input=null;
		[transient] public Point ScreenPos;
		public Player Player;
		[replicate] public double FloorTime = 0;

		public void PreTick(double dt)
		{
			if ( AnimDone )
				State = DieState.Idle;
		}

		public override void OnTick(double dt)
		{
			if ( State == DieState.Idle && WantDir!=Dir.None )
			{
				AttempToMoveTo( WantDir );
			}

			if ( State == DieState.Idle )
				Spin += (float)( dt * 2 );
			else
				Spin += (float)( dt * 8 );

			if ( this.TileLoc.DieHeld != null )
				FloorTime = 0;
			else
				FloorTime += dt;

			if ( Game.IsFloorRespawn && ( FloorTime >= Game.DefFloorRespawnTime ) )
			{
				if ( Game.Dice.Length != 0 )
				{
					int ri = Code.Random.Next( Game.Dice.Length );
					Die d = Game.Dice[ ri ];
					this.ForceMovedTo( d.TileLoc );
					FloorTime = 0;
				}
				else
					FloorTime = Game.DefFloorRespawnTime;
			}

			base.OnTick (dt);
		}

		public void Init(Tile t, Team team)
		{
			mTileLoc = t;
			Team = team;
		}

		public void ForceMovedTo(Tile t)
		{
			PreviousLoc = mTileLoc;
			mTileLoc = t;
			if ( State == DieState.Idle )
				State = DieState.Sliding;
		}

		public bool AttempToMoveTo(Dir dir)
		{
			if ( State != DieState.Idle )
				return false;
			Tile to = TileLoc.GetNeighbor( dir );
			if ( to == null )
				return false;

			if ( Game.FreeCursor )
			{
				PreviousLoc = mTileLoc;
				mTileLoc = to;
				State = DieState.Sliding;
				return true;
			}

			if ( !to.IsWalkable )
				return false;

			DieState worked = DieState.Idle;
			if ( TileLoc.DieHeld != null )
			{
				//on top of a block:

				Die d = TileLoc.DieHeld;

				//if it's sliding/rolling, can't do anything
				if ( d.LogicalHeight > 1.0f )
					return false;

				Die other = to.DieHeld;
				if ( other == null )
				{
					if ( d.LogicalHeight <= Game.DefJumpHeight )
					{
						//jump down to the ground:
						worked = DieState.Sliding;
					}
					else
					{
						//rolling:
						if ( d.State != DieState.Idle )
							return false;

						d.Rotate( dir );
						d.MoveTo( to, this, null );
						d.State = DieState.Rolling;
						worked = DieState.Rolling;
						Game.OnDieMoved( d );
					}
				}
				else
				{
					float otherheight = other.LogicalHeight;
					if ( ( d.State == DieState.Idle ) && 
						( otherheight <= Game.DefSquashHeight ) )
					{
						//roll onto the spot and swap where the blocks are
						d.Rotate( dir );
						d.MoveTo( to, this, other );
						d.State = DieState.Rolling;
						worked = DieState.Rolling;
						Game.OnDieMoved( d );
					}
					else if ( Math.Abs( otherheight - d.LogicalHeight ) <= Game.DefJumpHeight )
					{
						//walk to the other one:
						worked = DieState.Sliding;
					}
				}
			}
			else
			{
				//walking on the ground:
				if ( to.DieHeld == null )
				{
					//walk to empty spot
					worked = DieState.Sliding;
				}
				else
				{
					Die d = to.DieHeld;
					if ( d.LogicalHeight <= Game.DefJumpHeight )
					{
						//climb up onto the die
						worked = DieState.Sliding;
					}
					else if ( d.State == DieState.Idle )
					{
						//try pushing:
						Tile next = to.GetNeighbor( dir );
						
						if ( next == null || !next.IsWalkable )
							return false;

						if ( next.CollectCursorsOn().Count != 0 )
							return false;

						if ( next.DieHeld == null )
						{
							//pushed it!
							d.MoveTo( next, this, null );
							d.State = DieState.Sliding;
							worked = DieState.Sliding;
							Game.OnDieMoved( d );
							this.FloorTime = 0;

							Code.Assert( d.TileLoc == next );
							Code.Assert( d.PreviousLoc == to );
							Code.Assert( next.DieHeld == d );
							Code.Assert( to.DieHeld == null );
						}
						else
							return false;
					}
					else
					{
						//can't do anything
						return false;
					}
				}
			}

			if ( worked != DieState.Idle )
			{
				PreviousLoc = mTileLoc;
				mTileLoc = to;
				State = worked;
				return true;
			}

			return false;
		}
	}

	public enum DieType
	{
		Normal=0,
		Inverted=1,
		Dark=2,
		Fifteen=3,
	}

	public class Die : Piece
	{
		[replicate] public int[] Sides = { 5, 2, 1, 6, 4, 3 };
		[transient] public Matrix Rotation = Matrix.Identity;
		[replicate] public Dir LastRotDir = Dir.North;
		[replicate] public Cursor LastMover = null;
		[replicate] public bool IsAlive = true;
		[replicate] public int MaxCombo = 0;
		public DieType DieType = Profile.Default.DefDieType;
		[transient] public float RandFloat = 4.0f*(float)Code.Random.NextDouble();

		public void SetUp(int top)
		{
			if ( Sides[(int)Dir.Up] == top )
				return;
			if ( Sides[(int)Dir.Down] == top )
			{
				Rotate( Dir.North );
				Rotate( Dir.North );
				Code.Assert( Sides[(int)Dir.Up] == top );
				return;
			}
			while ( Sides[(int)Dir.South] != top )
			{
				Rotate( Dir.Up );
			}
			Rotate( Dir.North );
			Code.Assert( Sides[(int)Dir.Up] == top );
		}

		public void SetUpAndSouth(int up, int south)
		{
			SetUp( up );
			while ( Sides[(int)Dir.South] != south )
			{
				Rotate( Dir.Up );
			}
		}

		public class TwentyFour : Die
		{
			public TwentyFour(int side)
			{
				for (int i=0; i<Sides.Length; i++)
					Sides[i] = 0;
				Sides[4] = side;
			}
		}

		public static Dir[] FourDirs = { Dir.North, Dir.South, Dir.East, Dir.West };

		private void CollectSimilarNeighbors(ArrayList ar, int top)
		{
			if ( LogicalTopSide != top )
				return;
			if ( ar.IndexOf( this ) >= 0 )
				return;
			ar.Add( this );
			foreach( Dir d in FourDirs )
			{
				Tile t = TileLoc.GetNeighbor( d );
				if ( t!=null && t.DieHeld!=null )
					t.DieHeld.CollectSimilarNeighbors( ar, top );
			}
		}

		public ArrayList CollectSimilarNeighbors()
		{
			ArrayList ar = new ArrayList();
			int top = LogicalTopSide;
			if ( top < 2 )
				return ar;
			CollectSimilarNeighbors( ar, top );
			return ar;
		}

		public int LogicalTopSide
		{
			get
			{
				if ( State==DieState.Rolling || State==DieState.Sliding )
					return 0;
				return RawTopSide;
			}
		}

		public int RawTopSide
		{
			get 
			{
				return Sides[4]; 
			}
		}

		public float LogicalHeight
		{
			get
			{
				if ( State==DieState.Idle )
					return 1.0f;
				if ( State==DieState.Rolling || State==DieState.Sliding )
					return 100.0f;
				if ( State==DieState.Rising )
					return Progress;
				if ( State==DieState.Sinking )
					return 1.0f - Progress;
				Code.TODO();
				return 0.0f;
			}
		}

		public float VisualHeight
		{
			get
			{
				if ( State==DieState.Idle || State==DieState.Sliding )
					return 2.0f;
				if ( State == DieState.Sinking )
					return 2.0f*(1.0f - Progress);
				if ( State == DieState.Rising )
					return 2.0f*Progress;
				if ( State == DieState.Rolling )
				{
					double r = Math.Sqrt( 2 );
					double x = ( ((double)Progress) * 2.0f ) - 1.0f;
					double z = Math.Sqrt( r*r - x*x )+1;
					return (float)z;
				}
				Code.TODO();
				return 2.0f;
			}
		}

		private void MakeSink()
		{
			if ( State == DieState.Idle )
				State = DieState.Sinking;
			else if ( State == DieState.Rising )
			{
				double p = 1.0 - ((double)Progress);
				State = DieState.Sinking;

				//set the time so that the progress is at p
				//p = ( Game.Time - StateStartTime ) / len;
				//StateStartTime = Game.Time - ( p * len )
				double len = Game.DefStateLength( DieState.Sinking );
				StateStartTime = Game.Time - ( p * len );
			}
			else if ( State == DieState.Sinking )
			{
				//already done
			}
			else
				Code.BadPlace();
		}

		private void OnLanded()
		{
			if ( this.LastMover == null )
				return;

			Game.PlaySound( Sounds.Rolled );

			int top = LogicalTopSide;
			if ( top == 1 )
			{
				//special code for die with a 1 on top:

				//look for a sinking die next to this one:
				int maxcombo = 0;
				int maxface = 0;
				for (int i=0; i<Die.FourDirs.Length; i++)
				{
					Tile t = TileLoc.GetNeighbor( Die.FourDirs[i] );
					if ( t!=null && t.DieHeld!=null && t.DieHeld.State==DieState.Sinking )
					{
						if ( t.DieHeld.MaxCombo > maxcombo )
						{
							maxcombo = t.DieHeld.MaxCombo;
							maxface = t.DieHeld.LogicalTopSide;
						}
					}
				}
				if ( maxcombo == 0 )
					return;
				maxcombo++;

				//sinkers found, get all 1s:
				int count = 0;
				foreach ( Die d in Game.Dice )
				{
					bool good = ( d != this );
					if ( this.PreviousState == DieState.Sliding )
						good = true;
					if ( d.State!=DieState.Idle && d.State!=DieState.Rising )
						good = false;

					if ( d.LogicalTopSide==1 && good )
					{
						d.MaxCombo = maxcombo;
						d.MakeSink();
						count++;
					}
				}

				if ( count != 0 )
				{
					Team team = this.LastMover.Team;

					int points = maxface * count * maxcombo;
					string msg = ""+maxface+" * "+count+" * "+ maxcombo + " = "+points;
					Game.OnDieSunk( 1, points, msg, LastMover );
				}

				return;
			}

			ArrayList ns = this.CollectSimilarNeighbors();
			if ( top > 1 && ns.Count >= top )
			{
				int combo = 0;

				foreach ( object ob in ns )
				{
					//TODO: be more complex
					Die od = (Die)ob;
					if ( od.MaxCombo > combo )
						combo = od.MaxCombo;
					od.MakeSink();
				}

				combo++;
				foreach ( object ob in ns )
					((Die)ob).MaxCombo = combo;

				int points = top * ns.Count * combo;
				Team team = this.LastMover.Team;
				string msg = ""+top+" * "+ns.Count+" * "+combo;
				msg += " = "+points;
				Game.OnDieSunk( top, points, msg, LastMover );
			}
		}

		public override void OnTick(double dt)
		{
			if ( AnimDone && State!=DieState.Idle )
			{
				if ( State == DieState.Sinking )
				{
					//kills this die as this should be
					//	the only reference to it.
					TileLoc.DieHeld = null;
					IsAlive = false;
					return;
				}

				State = DieState.Idle;

				//landed on a new place:
				if ( IsAlive )
					OnLanded();
			}

			base.OnTick (dt);
		}

		public void Init(Tile t)
		{
			Code.Assert( t.DieHeld == null );
			mTileLoc = t;
			t.DieHeld = this;
		}

		public int GetSide(Dir d)
		{
			int i = (int)d;
			return this.Sides[ i ];
		}

		protected void SetSide(Dir d, int v)
		{
			int i = (int)d;
			this.Sides[ i ] = v;
		}

		public static Dir OppositeDir(Dir d)
		{
			int i = (int)d;
			i ^= 1;
			return (Dir)i;
		}

		public void Rotate(Dir d)
		{
			LastRotDir = d;
			float ang = ((float)(Math.PI / 2));
			Matrix m;
			switch ( d )
			{
				case Dir.East:
					m = Matrix.RotationY( ang );
					break;
				case Dir.West:
					m = Matrix.RotationY( -ang );
					break;
				case Dir.North:
					m = Matrix.RotationX( ang );
					break;
				case Dir.South:
					m = Matrix.RotationX( -ang );
					break;
				case Dir.Up:
					m = Matrix.RotationZ( ang );
					break;
				default:
					Code.TODO();
					m = Matrix.Identity;
					break;
			}
			Rotation *= m;
			Dir[] spin = { Dir.Up, d, Dir.Down, OppositeDir( d ) };
			if ( d == Dir.Up )
			{
				spin[0] = Dir.North;
				spin[1] = Dir.East;
				spin[2] = Dir.South;
				spin[3] = Dir.West;
			}

			int temp = GetSide( spin[spin.Length-1] );
			for (int i=0; i<4; i++)
			{
				int lv = GetSide( spin[i] );
				SetSide( spin[i], temp );
				temp = lv;
			}
		}

		public void MoveTo(Tile t, Cursor by, Die replaces)
		{
			Code.AssertOnNull( t );
			Code.Assert( mTileLoc.DieHeld == this );
			if ( replaces == null )
				Code.Assert( t.DieHeld == null );
			else
				Code.Assert( t.DieHeld == replaces );
			ArrayList curs = TileLoc.CollectCursorsOn();

			LastMover = by;
			PreviousLoc = mTileLoc;

			t.DieHeld = this;
			mTileLoc.DieHeld = null;
			mTileLoc = t;

			if ( replaces != null )
			{
				PreviousLoc.DieHeld = replaces;
				replaces.mTileLoc = PreviousLoc;
				replaces.PreviousLoc = mTileLoc;

				//if it's sinking, just kill it
				if ( replaces.State == DieState.Sinking )
				{
					replaces.TileLoc.DieHeld = null;
					replaces.IsAlive = false;
				}
			}

			foreach ( object ob in curs )
			{
				Cursor c = (Cursor)ob;
				if ( c != by )
				{
					c.ForceMovedTo( t );
				}
			}
		}
	}

	public class Tile : RSObject
	{
		public int PosX, PosY;
		public Game Game;
		[replicate] public Die DieHeld = null;
		[transient] public Puzzle.PzTile PzTile = null;
		public bool IsWalkable = true;
		public Team TeamOwner = null;
		public bool CalcScreenPos = false;
		[transient] public Point ScreenPos;

		public ArrayList CollectCursorsOn()
		{
			ArrayList ar = new ArrayList();
			foreach ( Cursor c in Game.Cursors )
			{
				if ( c.TileLoc == this )
					ar.Add( c );
			}
			return ar;
		}

		public Tile GetNeighbor(Dir d)
		{
			int x = PosX;
			int y = PosY;
			switch ( d )
			{
				case Dir.North:
					y--;
					break;
				case Dir.South:
					y++;
					break;
				case Dir.East:
					x++;
					break;
				case Dir.West:
					x--;
					break;
				default:
					Code.TODO();
					break;
			}
			return Game.GetTile( x, y );
		}
	}

	namespace Puzzle
	{
		public class Campaign
		{
			public Level[] Levels = new Level[0];
			public string Name = "Campaign";
			public string FileName = "";

			public void Add(Level el)
			{
				el.Campaign = this;
				Levels = (Level[])Code.ArrayAppend( Levels, el );
			}

			public void LoadFromFile(string path)
			{
				Levels = new Level[0];
				FileName = path;
				Name = Path.GetFileNameWithoutExtension( path );
				XmlTextReader tr = new XmlTextReader( path );
				tr.WhitespaceHandling = WhitespaceHandling.None;

				tr.Read();

				tr.Read();

				tr.Read();

				while ( tr.Name == "Level" )
				{
					Level el = new Level();
					el.Campaign = this;
					Levels = (Level[])Code.ArrayAppend( Levels, el );

					el.ReadFromFile( tr );
				}

				tr.Close();
			}

			public void SaveToFile(string path)
			{
				XmlTextWriter tw = new XmlTextWriter( path, System.Text.Encoding.ASCII );
				tw.Formatting = Formatting.Indented;
				tw.WriteStartDocument( true );

				tw.WriteStartElement( "Campaign" );

				foreach ( Level level in Levels )
					level.WriteToFile( tw );

				tw.WriteEndElement();

				tw.WriteEndDocument();

				tw.Close();
			}
		}

		public class PzTile
		{
			public bool IsWalkable = true;
			public PzDie DieHeld = null;
		}

		public class PzDie
		{
			public int Top, South;
			public int Type;

			public void Set(Die d)
			{
				Top = d.Sides[ (int)Dir.Up ];
				South = d.Sides[ (int)Dir.South ];
			}
		}

		public class Level
		{
			public int maxSteps = 0;
			public string name = "Name";
			public string descrip = "Description";
			public Campaign Campaign = null;
			public int width = 5;
			public int height = 5;
			public PzTile[] Tiles = new PzTile[0];
			public int StartTile=0;
			public bool showScore = false;

			public bool ShowScore
			{
				get { return showScore; }
				set { showScore = value; }
			}

			public void ReadFromFile(XmlTextReader tr)
			{
				Code.Assert( tr.Name == "Level" );
				Code.ReadFields( tr, this );
				Tiles = new PzTile[ width * height ];

				tr.Read();
				int to = 0;
				while ( tr.Name == "PzTile" )
				{
					PzTile tile = new PzTile();
					Code.ReadFields( tr, tile );
					tr.Read();

					if ( tr.Name == "PzDie" )
					{
						PzDie pd = new PzDie();
						Code.ReadFields( tr, pd );

						tile.DieHeld = pd;
						tr.Read();
						Code.Assert( tr.NodeType == XmlNodeType.EndElement );
						tr.Read();
					}

					Tiles[ to++ ] = tile;
				}

				Code.Assert( tr.Name=="Level" && tr.NodeType==XmlNodeType.EndElement );
				tr.Read();
			}

			public void WriteToFile(XmlTextWriter tw)
			{
				tw.WriteStartElement( "Level" );
				Code.WriteFields( tw, this );

				foreach ( PzTile t in Tiles )
				{
					tw.WriteStartElement( "PzTile" );
					Code.WriteFields( tw, t );

					if ( t.DieHeld != null )
					{
						tw.WriteStartElement( "PzDie" );
						Code.WriteFields( tw, t.DieHeld );

						tw.WriteEndElement();
					}

					tw.WriteEndElement();
				}

				tw.WriteEndElement();
			}

			public Level()
			{
				ChangedSize();
			}

			public bool IsValid(int x, int y)
			{
				if ( x < 0 || y < 0 )
					return false;
				if ( x >= width || y >= width )
					return false;
				return true;
			}

			private void ChangedSize()
			{
				if ( Tiles.Length != width*height )
				{
					Tiles = new PzTile[ width*height ];
					for (int i=0; i<Tiles.Length; i++)
						Tiles[i] = new PzTile();
				}
			}

			public int Width
			{
				get { return width; }
				set { width = value; ChangedSize(); }
			}

			public int Height
			{
				get { return height; }
				set { height = value; ChangedSize(); }
			}

			public string Description
			{
				get { return descrip; }
				set { descrip = value; }
			}

			public string Name
			{
				get { return name; }
				set { name = value; }
			}

			public int MaxSteps
			{
				get { return maxSteps; }
				set { maxSteps = value; }
			}

			public override string ToString()
			{
				return "Level: " + Name;
			}

		}
	}

	public class InputDef
	{
		public string InputName;
		public string ProfileName="";
		public Keys[] KeyBoard = null;
		public int JoyIndex = 0;

		public void SetKeys(params Keys[] keys)
		{
			//Code.Assert( keys.Length == 4 );
			KeyBoard = keys;
		}

		public bool HasProfile
		{
			get { return ProfileName!=""; }
			set
			{
				if ( value == false )
				{
					ProfileName = "";
				}
				else
					Code.TODO();
			}
		}

		public int Index
		{
			get
			{
				int i = 0;
				foreach (InputDef id in Inputs)
				{
					if ( id == this )
						return i;
					return i;
				}
				Code.BadPlace();
				return -1;
			}
		}

		public InputDef(string name)
		{
			InputName = name;
		}

		public static int NumInputs
		{
			get
			{
				int count = 0;
				foreach ( InputDef id in Inputs )
					if ( id.HasProfile )
						count++;
				return count;
			}
		}

		private static InputDef[] mInputs = null;
		public static InputDef[] Inputs
		{
			get
			{
				if ( mInputs != null )
					return mInputs;
				mInputs = new InputDef[ 6 ];
				mInputs[0] = new InputDef( "Arrow Keys" );
				mInputs[0].SetKeys( Keys.Up, Keys.Down, Keys.Right, Keys.Left );
				mInputs[1] = new InputDef( "W,A,S,D" );
				mInputs[1].SetKeys( Keys.W, Keys.S, Keys.D, Keys.A );
				mInputs[2] = new InputDef( "I,J,K,L" );
				mInputs[2].SetKeys( Keys.I, Keys.K, Keys.L, Keys.J );
				mInputs[3] = new InputDef( "Numpad" );
				mInputs[3].SetKeys( Keys.NumPad8, Keys.NumPad2, Keys.NumPad6, Keys.NumPad4,
					Keys.NumPad2, Keys.NumPad5 );
				mInputs[4] = new InputDef( "Joypad 1" );
				mInputs[4].JoyIndex = 1;
				mInputs[5] = new InputDef( "Joypad 2" );
				mInputs[5].JoyIndex = 2;
				if ( true )
				{
					mInputs[0].ProfileName = "Lewey";
					mInputs[1].ProfileName = "Other";
				}
				return mInputs;
			}
		}
	}
}
