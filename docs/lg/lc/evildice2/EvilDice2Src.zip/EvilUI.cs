using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.DirectX;
using System.IO;
using DX = Microsoft.DirectX;
using D3D = Microsoft.DirectX.Direct3D;
using PCT = Microsoft.DirectX.Direct3D.CustomVertex.PositionColoredTextured;

namespace EvilGame
{
	public class GameMode_PuzzleEditor : Game.GameMode_Puzzle
	{
		[transient] VNode.MenuSet RootMenu = null;
		[transient] VNode.MenuManager Manager = null;
		[transient] int DieSpawnType = 0;

		public void InitEditor(EvilUI ui)
		{
			VNode.MenuItem mi;
			RootMenu = new EvilGame.VNode.MenuSet();
			RootMenu.TextSize = 0;

			mi = new VNode.MenuItem( "Set Start Tile", "Mark this tile as the starting location" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_SetStart);
			RootMenu.Add( mi );
			
			mi = new VNode.MenuItem( "Walkable", "Change if it's walkable or not" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Walkable);
			RootMenu.Add( mi );
			
			mi = new VNode.MenuItemList( "Die Type:", "Type of die", "Normal", "Wood", "Stone" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_ChangeType);
			//RootMenu.Add( mi );

			mi = new VNode.MenuItem( "Rotate Die", "Rotates a die" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Rotate);
			RootMenu.Add( mi );
			
			mi = new VNode.MenuItem( "Remove Die", "Removes a die" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Remove);
			RootMenu.Add( mi );
			
			for (int i=1; i<=6; i++)
			{
				mi = new EvilGame.VNode.MenuItem( "Spawn "+i, "Spawna die with "+i+" on top" );
				mi.Param = i;
				mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Spawn);
				RootMenu.Add( mi );
			}

			mi = new EvilGame.VNode.MenuItem( "Done", "Return to campaign editor" );
			mi.Selected += new EvilGame.VNode.MenuItem.SelectedEvent(menu_Done);
			RootMenu.Add( mi );

			Manager = new VNode.MenuManager( RootMenu, ui, false );
		}

		public override VNode.MenuManager ScreenMenu
		{
			get
			{
				return Manager;
			}
		}


		public override string TitleString
		{
			get { return ""; }
		}

		public override bool GameOver
		{
			get { return false; }
		}

		public override bool FreeCursor
		{
			get { return true; }
		}

		public void ChangedTile(Tile t)
		{
			Code.AssertOnNull( t.PzTile );
			EvilGame.Puzzle.PzTile pzt = t.PzTile;
			pzt.IsWalkable = t.IsWalkable;

			if ( t.DieHeld!=null )
			{
				if ( pzt.DieHeld == null )
					pzt.DieHeld = new EvilGame.Puzzle.PzDie();
				
				pzt.DieHeld.Set( t.DieHeld );
			}
			else
				pzt.DieHeld = null;
		}

		private void menu_Spawn(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Cursor c = Cursors[0];
			if ( c.TileLoc.DieHeld != null )
				return;
			Die d = new Die();
			int up = (int)item.Param;
			d.SetUp( up );
			this.AddUnInitedDie( d, c.TileLoc );

			ChangedTile( c.TileLoc );
		}

		private void menu_Rotate(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Cursor c = Cursors[0];
			Die d = c.TileLoc.DieHeld;
			if ( d == null )
				return;

			d.Rotate( Dir.Up );
			ChangedTile( c.TileLoc );
		}

		private void menu_Walkable(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Cursor c = Cursors[0];
			c.TileLoc.IsWalkable = !c.TileLoc.IsWalkable;
			if ( !c.TileLoc.PzTile.IsWalkable && c.TileLoc.DieHeld!=null )
			{
				c.TileLoc.DieHeld.IsAlive = false;
				c.TileLoc.DieHeld = null;
			}
			ChangedTile( c.TileLoc );
		}

		private void menu_ChangeType(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			DieSpawnType = ((VNode.MenuItemList)item).SelectedIndex;
		}

		private void menu_SetStart(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Tile t = Cursors[0].TileLoc;
			for (int i=0; i<Tiles.Length; i++)
			{
				if ( Tiles[i] == t )
					Level.StartTile = i;
			}
		}

		private void menu_Remove(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Cursor c = Cursors[0];
			Die d = c.TileLoc.DieHeld;
			if ( d != null )
			{
				c.TileLoc.DieHeld.IsAlive = false;
				c.TileLoc.DieHeld = null;
				ChangedTile( c.TileLoc );
			}
		}

		private void menu_Done(EvilGame.VNode.MenuManager menu, EvilGame.VNode.MenuItem item)
		{
			Code.TheApp.OpenPuzzleEditor();
		}
	}

	public class VNode
	{
		public Rectangle Placement;
		protected EvilUI UI;

		public delegate void ClickedEvent();
		public event ClickedEvent OnClicked;

		public void DoClick()
		{
			if ( OnClicked != null )
				OnClicked();
		}

		public VNode(EvilUI ui)
		{
			UI = ui;
		}

		public virtual VNode FindHit(Point p)
		{
			if ( Placement.Contains( p ) )
				return this;
			return null;
		}

		public virtual Size Measure() {return new Size( 10, 10 ); }
		
		public virtual void CalcPlacement(Rectangle into)
		{
			Size s = Measure();
			s = new Size( Math.Min( s.Width, into.Width ),
				Math.Min( s.Height, into.Height ) );
			s = into.Size;
			Placement = new Rectangle( into.Location, s );
		}

		public virtual void Draw()
		{
			Code.TODO();
		}

		public static VList GenLogo(EvilUI ui)
		{
			VList ans = new VList( ui );
			VText name = new VText( "Lewey Geselowitz's", ui );
			name.TextType = new TextType( 1 );
			VText evil = new VText( "EVIL DICE 2", ui );
			evil.TextType = new TextType( 2 );
			ans.Add( name );
			ans.Add( evil );
			return ans;
		}

		public class MenuItemList : MenuItem
		{
			public string[] Values;
			public int SelectedIndex = 0;

			public override string Value
			{
				get
				{
					return Values[ SelectedIndex ];
				}
			}

			public MenuItemList(string name, string hint, params string[] args)
				: base( name, hint )
			{
				Values = args;
			}

			protected override bool OnSubSelected(MenuManager menu, MenuSet menuset)
			{
				if ( menuset.IsForward )
					SelectedIndex = Code.Mod( SelectedIndex+1, Values.Length );
				else
					SelectedIndex = Code.Mod( SelectedIndex-1, Values.Length );
				//SelectedIndex++;
				//SelectedIndex %= Values.Length;
				menuset.Selected.TempValueVisual.Text = Value;
				return true;
			}

		}

		public class MenuItemMenu : MenuItem
		{
			public MenuSet MenuSet = new MenuSet();
			public int SelectedItem = 0;

			public MenuItemMenu(string name, string hint) : base( name, hint )
			{
			}

			protected override bool OnSubSelected(MenuManager menu, MenuSet menuset)
			{
				MenuSet.IsForward = menuset.IsForward;
				MenuSet.Selected.OnItemSelected( menu, menuset );
				return true;
				//return base.OnSubSelected (menu, menuset);
			}


			public void Add(MenuItem mi)
			{
				MenuSet.Add( mi );
			}
		}

		public class MenuItem
		{
			public string Name = "Item Name";
			private string mValue = " ";
			public string Hint = "This is a menu item of course";
			public MenuSet Link = null;
			public Game.GameType GameType = Game.GameType.None;
			public VText TempVisual = null;
			public VText TempValueVisual = null;
			public bool IsGoBack = false;
			public object Param = null;
			public MenuSet Owner = null;
			public Color Color = Color.White;

			public virtual string Value 
			{ 
				get{ return mValue; } 
				set 
				{ 
					mValue = value; 
					if ( TempValueVisual != null )
						TempValueVisual.Text = mValue;
				} 
			}

			public delegate void SelectedEvent(MenuManager menu, MenuItem item);
			public event SelectedEvent Selected;

			public MenuItem(string name, string hint)
			{
				Name = name;
				Hint = hint;
			}

			public MenuItem(string name, string hint, MenuSet link)
				: this( name, hint )
			{
				Link = link;
			}

			public MenuItem(string name, string hint, Game.GameType type)
				: this( name, hint )
			{
				GameType = type;
			}

			public MenuItem(string name, string hint, bool isgoback)
				: this( name, hint )
			{
				Code.Assert( isgoback == true );
				IsGoBack = true;
			}

			protected virtual bool OnSubSelected(MenuManager menu, MenuSet menuset)
			{
				return false;
			}

			public void OnItemSelected(MenuManager menu, MenuSet menuset)
			{
				bool didsomething = false;
				if ( OnSubSelected( menu, menuset ) )
				{
					didsomething = true;
				}
				if ( GameType != Game.GameType.None )
				{
					menu.selectNewGame( GameType );
					didsomething = true;
				}
				if ( Link != null )
				{
					menu.Menu = Link;
					didsomething = true;
				}
				if ( IsGoBack )
				{
					menu.Menu = menuset.PreviousMenu;
					didsomething = true;
				}
				if ( Selected != null )
				{
					Selected( menu, this );
					didsomething = true;
				}
				if ( !didsomething )
				{
					MessageBox.Show( "Under Construction\nCome back soon", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information );
				}
			}
		}

		public class LocalMenuSet : MenuSet
		{
			public override void OnInput(EvilGame.VNode.MenuManager man, InputDef id, Dir d)
			{
				if ( id == null )
				{
					base.OnInput( man, id, d );
					return;
				}
				foreach (VNode.MenuItem mi in this.Items)
				{
					if ( mi.Param==id )
					{
						VNode.MenuItemMenu mim = (VNode.MenuItemMenu)mi;
						mim.MenuSet.OnInput( man, id, d );
						mi.Value = mim.MenuSet.Selected.Name;
					}
				}
			}

		}

		public class MenuSet
		{
			public MenuItem[] Items = new MenuItem[0];
			public MenuSet PreviousMenu = null;
			public bool HasValues = false;
			public int TextSize = 1;
			public bool IsForward = true;
			public int mSelectedIndex = 0;
			public string GuideText = "";
			public VNode ExtraNode = null;

			public void Clear()
			{
				mSelectedIndex = 0;
				Items = new MenuItem[0];
			}

			public delegate void ActivatedEvent(MenuManager mm, MenuSet ms);
			public event ActivatedEvent OnActivated;

			public int SelectedIndex
			{
				get { return mSelectedIndex; }
			}

			public void SetSelectedIndex(MenuManager mm, int i)
			{
				mSelectedIndex = Code.Mod( i, Items.Length );
				mm.OnSelectedIndexChanged();
			}

			public MenuItem Selected
			{
				get
				{
					return Items[ SelectedIndex ];
				}
			}

			public virtual void OnInput(MenuManager man, InputDef id, Dir d)
			{
				switch ( d )
				{
					case Dir.South:
						SetSelectedIndex( man, SelectedIndex+1 );
						Code.TheApp.PlaySound( Sounds.ShortClick );
						break;
					case Dir.North:
						SetSelectedIndex( man, SelectedIndex-1 );
						Code.TheApp.PlaySound( Sounds.ShortClick );
						break;
					case Dir.East:
						IsForward = true;
						Selected.OnItemSelected( man, this );
						Code.TheApp.PlaySound( Sounds.Click );
						break;
					case Dir.West:
						IsForward = false;
						Selected.OnItemSelected( man, this );
						Code.TheApp.PlaySound( Sounds.Click );
						break;
				}
			}

			public void MadeActive(MenuManager mm)
			{
				if ( OnActivated != null )
					OnActivated( mm, this );
			}

			public MenuItem this[int i]
			{
				get { return Items[ i ]; }
			}

			public void Add(MenuItem item)
			{
				item.Owner = this;
				Items = (MenuItem[])Code.ArrayAppend( Items, item );
			}
		}

		public class MenuManager : VHolder
		{
			private MenuSet mSet;
			private VList ListHolder;
			public VList ValueList;
			public VText HintText;
			public VText GuideText;
			public VHolder ExtraHolder;
			public int MaxItems = 6;
			public EvilUI EUI = null;
			public delegate void SelectedNewGameEvent(MenuManager man, Game.GameType type);
			public event SelectedNewGameEvent SelectedNewGame;

			public void selectNewGame(Game.GameType type)
			{
				if ( SelectedNewGame != null )
					SelectedNewGame( this, type );
			}

			public void UpdateItemName(string partname, string newname)
			{
				foreach ( MenuItem mi in mSet.Items )
				{
					if ( mi.Name.IndexOf( partname ) >= 0 )
					{
						mi.Name = newname;
						mi.TempVisual.Text = newname;
					}
				}
			}

			public int GetFromMouse(Point p)
			{
				int index = 0;
				foreach ( VNode v in ListHolder.Nodes )
				{
					if ( v.Placement.Contains( p ) )
					{
						return index;
					}
					index++;
				}
				index = 0;
				foreach ( VNode v in ValueList.Nodes )
				{
					if ( v.Placement.Contains( p ) )
					{
						return index;
					}
					index++;
				}
				return -1;
			}

			public void OnSelectedIndexChanged()
			{
				foreach ( MenuItem mi in mSet.Items )
				{
					mi.TempVisual.TextType.Color = mi.Color;
					mi.TempValueVisual.TextType.Color = mi.Color;

					mi.TempVisual.TextType.Size = mSet.TextSize;
					mi.TempValueVisual.TextType.Size = mSet.TextSize;
				}
				Menu.Selected.TempVisual.TextType.Color = Color.Yellow;
				Menu.Selected.TempValueVisual.TextType.Color = Color.Yellow;
				HintText.Text = Menu.Selected.Hint;
			}

			public MenuSet Menu
			{
				get { return mSet; }
				set
				{
					if ( mSet != null )
					{
						foreach ( MenuItem mi in mSet.Items )
						{
							mi.TempVisual = null;
							mi.TempValueVisual = null;
						}
					}

					if ( mSet==null || mSet.PreviousMenu != value )
						value.PreviousMenu = mSet;
					mSet = value;
					mSet.mSelectedIndex = 0;
					mSet.MadeActive( this );
					ListHolder.Clear();
					ValueList.Clear();
					foreach ( MenuItem mi in mSet.Items )
					{
						VText t = new VText( mi.Name, this.UI );
						t.TextType = new TextType( 1 );
						t.TextType.SelectAlignment( -1, 0 );
						t.TextType.Color = mi.Color;
						ListHolder.Add( t );
						mi.TempVisual = t;

						VText v = new VText( mi.Value, this.UI );
						v.TextType = new TextType( 1 );
						v.TextType.SelectAlignment( -1, 0 );
						ValueList.Add( v );
						mi.TempValueVisual = v;
					}
					this.OnSelectedIndexChanged();
					this.GuideText.Text = mSet.GuideText;
					this.ExtraHolder.Child = mSet.ExtraNode;
				}
			}

			public MenuManager(MenuSet menu, EvilUI ui, bool uselogo) : base( null, ui )
			{
				VList list;
				EUI = ui;
				if ( uselogo )
				{
					list = VNode.GenLogo(ui);
					list.IsCenter = true;
				}
				else
				{
					list = new VNode.VList( ui );
				}

				VList across = new VList( ui );
				across.IsVertical = false;
				across.Offset = 10;

				ListHolder = new VList( ui );
				across.Add( ListHolder );

				ValueList = new VList( ui );
				across.Add( ValueList );

				HintText = new VText( "No Hint Yet", ui );
				HintText.TextType = new TextType( 0 );
				HintText.TextType.SelectAlignment( 1, -1 );
				HintText.TextType.Color = Color.Yellow;
				VFixedSize fs = new VFixedSize( HintText, new Size( 180, 180 ), ui );
				across.Add( fs );

				list.Add( across );
				Child = list;

				ExtraHolder = new VHolder( null, ui );
				list.Add( ExtraHolder );

				GuideText = new VText( "", ui );
				GuideText.TextType = new TextType( 0 );
				GuideText.TextType.Color = Color.LightSlateGray;
				list.Add( GuideText );

				Menu = menu;
			}
		}

		public class VHolder : VNode
		{
			public VNode Child;

			public VHolder(VNode child, EvilUI ui) : base( ui )
			{
				Child = child;
			}

			public override VNode FindHit(Point p)
			{
				if ( Child == null )
					return null;
				return Child.FindHit( p );
			}


			public override Size Measure()
			{
				if ( Child == null )
					return new Size( 0, 0 );
				return Child.Measure();
			}

			public override void Draw()
			{
				if ( Child != null )
					Child.Draw();
			}

			public override void CalcPlacement(Rectangle into)
			{
				base.CalcPlacement(into);
				if ( Child != null )
					Child.CalcPlacement( into );
			}
		}

		public class VFixedSize : VHolder
		{
			public Size FixedSize;

			public VFixedSize(VNode child, Size size, EvilUI ui) : base( child, ui )
			{
				FixedSize = size;
			}

			public override Size Measure()
			{
				return FixedSize;
			}
		}

		public class VSides : VNode
		{
			public VNode Left, Right;

			public VSides(VNode l, VNode r, EvilUI ui) : base( ui )
			{
				Left = l;
				Right = r;
			}

			public override Size Measure()
			{
				Code.BadPlace();
				return new Size( 0, 0 );
			}

			public override void Draw()
			{
				Left.Draw();
				Right.Draw();
			}

			public override void CalcPlacement(Rectangle into)
			{
				Size s = Left.Measure();
				Left.CalcPlacement( new Rectangle( into.Location, s ) );

				s = Right.Measure();
				Rectangle r = new Rectangle( 
					into.Width-s.Width, 0,
					s.Width, s.Height );
				Right.CalcPlacement( r );
			}

		}

		public class VList : VNode
		{
			public VNode[] Nodes = new VNode[0];
			public int Offset = 0;
			public bool IsVertical = true;
			public bool IsCenter = false;

			public void Add(VNode item)
			{
				Nodes = (VNode[])Code.ArrayAppend( Nodes, item );
			}

			public override VNode FindHit(Point p)
			{
				foreach (VNode v in Nodes)
				{
					VNode ans = v.FindHit( p );
					if ( ans != null )
						return ans;
				}
				return base.FindHit( p );
			}


			public void Clear()
			{
				Nodes = new VNode[0];
			}

			public VList(EvilUI ui) : base( ui )
			{
			}

			public override void Draw()
			{
				foreach ( VNode n in Nodes )
					n.Draw();
			}

			public override void CalcPlacement(Rectangle into)
			{
				base.CalcPlacement(into);
				int x = into.X;
				int y = into.Y;
				int w = into.Width;
				int h = into.Height;
				if ( IsCenter )
				{
					Size whole = Measure();
					x += ( into.Width - whole.Width ) / 2;
					y += ( into.Height - whole.Height ) / 2;
					w = whole.Width;
					h = whole.Height;
				}
				foreach ( VNode n in Nodes )
				{
					Size s = n.Measure();
					Rectangle r;
					if ( IsVertical )
					{
						int dx = ( w - s.Width );
						if ( !IsCenter )
							dx = 0;
						r = new Rectangle( x+dx/2, y, w-dx, s.Height );
						y += Offset + s.Height;
					}
					else
					{
						int dy = ( h - s.Height );
						if ( !IsCenter )
							dy = 0;
						r = new Rectangle( x, y+dy/2, s.Width, h-dy );
						x += Offset + s.Width;
					}
					n.CalcPlacement( r );
				}
			}


			public override Size Measure()
			{
				if ( Nodes.Length==0 )
					return base.Measure();

				Size s = new Size( 0, 0 );
				foreach ( VNode n in Nodes )
				{
					Size ns = n.Measure();
					if ( IsVertical )
					{
						s = new Size( Math.Max( s.Width, ns.Width ),
							s.Height + ns.Height + Offset );
					}
					else
					{
						s = new Size( s.Width + ns.Width + Offset,
							Math.Max( s.Height, ns.Height ) );
					}
				}

				return s;
			}
		}

		public class VText : VNode
		{
			public string Text;
			public TextType TextType;

			public VText(string text, EvilUI ui) : base( ui )
			{
				Text = text;
				TextType = null;
			}

			public VText(string text, EvilUI ui, int size) : this( text, ui )
			{
				TextType = new TextType( size );
				TextType.SelectAlignment( -1, 0 );
			}

			public override Size Measure()
			{
				return UI.MeasureString( Text, TextType );
			}

			public override void Draw()
			{
				UI.DrawText( Text, Placement, TextType );
			}
		}
	}

	public class TextType
	{
		public int Size = 2;
		public Color Color = Color.White;
		public D3D.DrawTextFormat Format = D3D.DrawTextFormat.WordBreak;

		public static TextType Default
		{
			get
			{
				TextType tt = new TextType(1);
				tt.Color = Color.White;
				tt.SelectAlignment( -1, 0 );
				return tt;
			}
		}

		public TextType(int size)
		{
			Size = size;
			Color = Color.White;
			SelectAlignment( 0, 0 );
		}

		public void SelectAlignment(int dx, int dy)
		{
			D3D.DrawTextFormat format = D3D.DrawTextFormat.WordBreak | D3D.DrawTextFormat.ExpandTabs;
			if ( dx > 0 )
				format |= D3D.DrawTextFormat.Right;
			if ( dx < 0 )
				format |= D3D.DrawTextFormat.Left;
			if ( dx == 0 )
				format |= D3D.DrawTextFormat.Center;

			if ( dy < 0 )
				format |= D3D.DrawTextFormat.Top;
			if ( dy > 0 )
				format |= D3D.DrawTextFormat.Bottom;
			if ( dy == 0 )
				format |= D3D.DrawTextFormat.VerticalCenter;

			Format = format;
		}

	}

	public class EvilUI
	{
		D3D.Font MegaFont;
		D3D.Font NormalFont;
		D3D.Font SmallFont;
		D3D.Font NearSmallFont;
		D3D.Font CurrentFont;
		D3D.Device Device;
		Form Window;
		int WidthOffset;
		int HeightOffset;

		private void SelectFont(int i)
		{
			switch ( i )
			{
				case 0:
					CurrentFont = SmallFont;
					break;
				case 1:
					CurrentFont = NormalFont;
					break;
				case 2:
					CurrentFont = MegaFont;
					break;
				case 3:
					CurrentFont = NearSmallFont;
					break;
				default:
					Code.TODO();
					break;
			}
		}

		public const string IdealFont = "ReservoirGrunge";

		public FontFamily EvilFontFamily()
		{
			return new FontFamily( IdealFont );
		}

		public EvilUI(D3D.Device device)
		{
			Device = device;
			this.Window = Code.TheApp;
			//Fonts to consider: Alba, Baby Kruffy, Blackadder ITC, ReservoirGrunge
			System.Drawing.Font font;
			FontFamily ff = EvilFontFamily();

			if ( ff.Name == IdealFont )
			{
				font = new Font( ff, 42, FontStyle.Regular );
				MegaFont = new Microsoft.DirectX.Direct3D.Font( Device, font );

				font = new Font( ff, 25, FontStyle.Regular );
				NormalFont = new Microsoft.DirectX.Direct3D.Font( Device, font );

				font = new Font( ff, 12, FontStyle.Regular );
				NearSmallFont = new Microsoft.DirectX.Direct3D.Font( Device, font );
			}
			else
			{
				font = new Font( ff, 72, FontStyle.Bold );
				MegaFont = new Microsoft.DirectX.Direct3D.Font( Device, font );

				font = new Font( ff, 40, FontStyle.Bold );
				NormalFont = new Microsoft.DirectX.Direct3D.Font( Device, font );

				font = new Font( ff, 16, FontStyle.Regular );
				NearSmallFont = new Microsoft.DirectX.Direct3D.Font( Device, font );
			}

			font = new Font( "Ariel", 16 );
			SmallFont = new Microsoft.DirectX.Direct3D.Font( Device, font );

			CurrentFont = NormalFont;

			Rectangle r = NormalFont.MeasureString( null, "X", D3D.DrawTextFormat.NoClip, Color.White );
			WidthOffset = r.Width;
			HeightOffset = r.Height;
		}

		public Rectangle FullRect
		{
			get
			{
				Rectangle r = new Rectangle( new Point( 0, 0 ),
					this.Window.ClientSize );
				return r;
				/*
				return new Rectangle( 0, 0, Window.Width-WidthOffset,
					Window.Height-HeightOffset);
				*/
			}
		}

		public void PrepDX()
		{
			Device.RenderState.ZBufferEnable = false;
			Device.RenderState.ZBufferWriteEnable = false;
		}

		public void UnPrepDX()
		{
			Device.RenderState.ZBufferEnable = true;
			Device.RenderState.ZBufferWriteEnable = true;
		}

		public void DrawTextAt(string text, TextType tt, Point p)
		{
			Size s = this.MeasureString( text, tt );
			Point top = new Point( p.X-s.Width/2, p.Y-s.Height/2 );
			Rectangle r = new Rectangle( top, s );
			DrawText( text, r, tt );
		}

		public void DrawText(string text, Rectangle r, TextType tt)
		{
			if ( tt == null )
				tt = TextType.Default;
			SelectFont( tt.Size );
			CurrentFont.DrawText( null, text, r, tt.Format, tt.Color );
		}

		public void SimpleDrawText(string text)
		{
			DrawText( text, FullRect, null );
		}

		public Size MeasureString(string text, TextType tt)
		{
			if ( tt == null )
				tt = TextType.Default;
			SelectFont( tt.Size );
			Rectangle r = CurrentFont.MeasureString( null, text, tt.Format, tt.Color );
			Size s = new Size( r.Width, r.Height );
			return s;
		}
	}

}
