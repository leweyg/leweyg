using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace QuickCapture
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			ic = new ImageSelector(this.groupBox1);
			ic.Location = new Point(5,15);
			ic.Size = new Size(this.groupBox1.ClientRectangle.Width-10, this.groupBox1.ClientRectangle.Height-20);
		}
		ImageSelector ic;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.button6 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(344, 224);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "The Picture";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(296, 296);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(64, 32);
			this.button1.TabIndex = 1;
			this.button1.Text = "Exit";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(224, 296);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(64, 32);
			this.button2.TabIndex = 2;
			this.button2.Text = "Save";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.button6,
																					this.button3,
																					this.textBox1});
			this.groupBox2.Location = new System.Drawing.Point(8, 240);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(352, 48);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "File To Save As";
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(304, 16);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(40, 24);
			this.button6.TabIndex = 2;
			this.button6.Text = "Next";
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(264, 16);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(32, 24);
			this.button3.TabIndex = 1;
			this.button3.Text = "...";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 16);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(248, 20);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "";
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(160, 296);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(56, 32);
			this.button4.TabIndex = 4;
			this.button4.Text = "Copy";
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(96, 296);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(56, 32);
			this.button5.TabIndex = 5;
			this.button5.Text = "Refresh";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(32, 296);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(56, 32);
			this.button7.TabIndex = 6;
			this.button7.Text = "Unselect";
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(368, 334);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button7,
																		  this.button5,
																		  this.button4,
																		  this.groupBox2,
																		  this.button2,
																		  this.button1,
																		  this.groupBox1});
			this.Name = "Form1";
			this.Text = "Quick Capture";
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			Close();
		}

		private void button5_Click(object sender, System.EventArgs e)
		{
			ic.RefreshImage();
			ic.Invalidate();
		}

		private void button4_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.Clipboard.SetDataObject( ic.SelectedImage, true );
		//	Bitmap b = ic.SelectedImage;

			ic.Invalidate();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			SaveFileDialog fd = new SaveFileDialog();
			fd.Filter = "Bitmap (*.bmp)|*.bmp|JPEG (*.jpeg)|*.jpeg|All Types (*.*)|*.*";
			fd.AddExtension = true;
			
			if (fd.ShowDialog()==DialogResult.OK)
			{
				this.textBox1.Text = fd.FileName;
				this.textBox1.SelectionStart = this.textBox1.Text.Length-1;
			}
		}

		public bool IsNumber(char let)
		{
			return ((let >= '0') && (let <= '9'));
		}

		public string NextString(string str)
		{
			int end = str.Length-1;
			while ((end >= 0) && (!IsNumber(str[end])))
				end--;
			if (end < 0)
				return str;
			int start = end-1;
			while (IsNumber(str[start]))
				start--;
			start++;
			string s = str.Substring(start, (end-start)+1 );
			int i = Int32.Parse( s );
			i++;
			string num = ""+i;
			while (num.Length < s.Length)
				num = "0"+num;
			s  = str.Substring(0, start);
			s += num;
			s += str.Substring(end+1, (str.Length-end)-1);
			return s;
		}

		private void button6_Click(object sender, System.EventArgs e)
		{
			this.textBox1.Text = NextString( this.textBox1.Text );
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			if (this.textBox1.Text == "")
			{
				SaveFileDialog fd = new SaveFileDialog();
				fd.Filter = "Bitmap (*.bmp)|*.bmp|JPEG (*.jpeg)|*.jpeg|All Types (*.*)|*.*";
				fd.AddExtension = true;
			
				if (fd.ShowDialog()==DialogResult.OK)
				{
					this.textBox1.Text = fd.FileName;
					this.textBox1.SelectionStart = this.textBox1.Text.Length-1;

					ic.SaveTo( this.textBox1.Text );
				}
			}
			else
				ic.SaveTo( this.textBox1.Text );
		}

		private void button7_Click(object sender, System.EventArgs e)
		{
			ic.SelectedRect = false;
			ic.Invalidate();
		}
	}

	public class ImageSelector : System.Windows.Forms.Control
	{
		private Bitmap bmp;
		private bool hasrect;
		private bool isdrawing;
		private Rectangle rect;
		private Point point;

		public bool SelectedRect
		{
			get { return hasrect; }
			set { hasrect = value; }
		}

		public void SaveTo(string file)
		{
			Bitmap b = SelectedImage;
			string low = file.ToLower();
			System.Drawing.Imaging.ImageFormat format = System.Drawing.Imaging.ImageFormat.Bmp;
			if (low.EndsWith(".bmp"))
				format = System.Drawing.Imaging.ImageFormat.Bmp;
			if (low.EndsWith(".jpeg") || low.EndsWith(".jpg"))
				format = System.Drawing.Imaging.ImageFormat.Jpeg;
			if (low.EndsWith(".gif"))
				format = System.Drawing.Imaging.ImageFormat.Gif;
			b.Save(file, format );
		}

		private Point TranslatedPoint(Point from)
		{
			int x = ( from.X * bmp.Width ) / this.ClientRectangle.Width;
			int y = ( from.Y * bmp.Height) / this.ClientRectangle.Height;
			return new Point(x,y);
		}

		public Bitmap SelectedImage
		{
			get
			{
				if (!hasrect)
					return bmp;
				Point tl = TranslatedPoint( rect.Location );
				Point br = TranslatedPoint( new Point(rect.Right, rect.Bottom) );

				Size s = new Size( (br.X-tl.X)-1, (br.Y-tl.Y)-1 );
				Bitmap b = new Bitmap( s.Width, s.Height );
				Graphics g = Graphics.FromImage( b );
				Rectangle srcr = new Rectangle( tl, s);
				g.DrawImage( bmp, 0, 0, srcr, System.Drawing.GraphicsUnit.Pixel );

				return b;
			}
		}

		public ImageSelector(Control parent)
		{
			this.Parent = parent;

			this.SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			hasrect = false;
			isdrawing = false;

			RefreshImage();
		}

		public void RefreshImage()
		{
			bmp = null;
			IDataObject ob = System.Windows.Forms.Clipboard.GetDataObject();
			if (ob.GetDataPresent(typeof(Bitmap)))
			{
				bmp = (Bitmap)ob.GetData( System.Windows.Forms.DataFormats.Bitmap );
			}
		}

		protected override void OnPaint(System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.FillRectangle(Brushes.CornflowerBlue, this.ClientRectangle );
			if (bmp != null)
				e.Graphics.DrawImage(bmp, this.ClientRectangle );
			if (hasrect)
			{
				e.Graphics.DrawRectangle(Pens.Green, rect.X, rect.Y, rect.Width, rect.Height );
			}
		}

		protected override void OnMouseDown(MouseEventArgs mea)
		{
			hasrect = true;
			isdrawing = true;
			rect.X = mea.X;
			rect.Y = mea.Y;
			rect.Width = 10;
			rect.Height = 10;
			point = new Point(mea.X, mea.Y);
			Invalidate();
		}

		public static int Lesser(int a, int b)
		{
			if (a < b)
				return a;
			return b;
		}

		public static int Greater(int a, int b)
		{
			if (a > b)
				return a;
			return b;
		}

		protected override void OnMouseMove(MouseEventArgs mea)
		{
			if (isdrawing)
			{
				rect.X = Lesser(mea.X, point.X);
				rect.Y = Lesser(mea.Y, point.Y);
				rect.Width = Greater(mea.X, point.X) - rect.X;
				rect.Height = Greater(mea.Y, point.Y) - rect.Y;
				Invalidate();
			}
		}

		protected override void OnMouseUp(MouseEventArgs mea)
		{
			isdrawing = false;
		}
	}
}
