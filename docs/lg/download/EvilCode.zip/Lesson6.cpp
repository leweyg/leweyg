/*
 *		This Code Was Created By Jeff Molofee 2000
 *		A HUGE Thanks To Fredric Echols For Cleaning Up
 *		And Optimizing The Base Code, Making It More Flexible!
 *		If You've Found This Code Useful, Please Let Me Know.
 *		Visit My Site At nehe.gamedev.net
 */

#include "resource.h"
#include <windows.h>		// Header File For Windows
#include <winuser.h>
#include <mmsystem.h>
#include <time.h>
#include <fstream.h>
#include <stdio.h>			// Header File For Standard Input/Output
#include <gl\gl.h>			// Header File For The OpenGL32 Library
#include <gl\glu.h>			// Header File For The GLu32 Library
#include <gl\glaux.h>		// Header File For The Glaux Library
#include "ctimer.h"
#include "c:/cstuff/cppforref/matrixclass.cpp"	//my own matrix math libary
#include "c:/cstuff/cppforref/barray.cpp"
#include "c:/cstuff/cppforref/seed.cpp"
#include "c:/cstuff/cppforref/str2.cpp"

HDC			hDC=NULL;		// Private GDI Device Context
HGLRC		hRC=NULL;		// Permanent Rendering Context
HWND		hWnd=NULL;		// Holds Our Window Handle
HINSTANCE	hInstance;		// Holds The Instance Of The Application

bool	keys[256];			// Array Used For The Keyboard Routine
bool	active=TRUE;		// Window Active Flag Set To TRUE By Default
bool	fullscreen=TRUE;	// Fullscreen Flag Set To Fullscreen Mode By Default

GLfloat	xrot=180-45;				// X Rotation ( NEW )
GLfloat	yrot=0;				// Y Rotation ( NEW )
GLfloat	zrot=35;				// Z Rotation ( NEW )

GLuint	texture[1];			// Storage For One Texture ( NEW )
GLuint	List_Die;
GLuint	List_Cursor;
GLfloat LightAmbientFalling[]= { 9.0f, 1.0f, 1.0f, 1.0f }; 
GLfloat LightAmbientLifting[]= { 0.0f, 1.0f, 9.0f, 1.0f }; 
GLfloat LightDiffuse[]= { 0.0f, 0.0f, 0.0f, 1.0f };
GLfloat LightPosition[]= { 0.0f, 0.0f, 0.0f, 1.0f };

typedef unsigned int uint;
typedef unsigned char uchar;
#define FlagOn(f,m)			(f)|=(m)
#define FlagOff(f,m)		(f)&=(~(m))
#define FlagToggle(f,m)		(f)^=(m)
#define IsFlag(f,m)			(((f)&(m))!=0)
#define NotFlag(f,m)		(((f)&(m))==0)

float GRateOfTime = 1;
bool GPaused = 0;
float DTime;
//int LastTime=-1;
float LastTime=-1;

CTimer GTimer;

float Clock()
{
	return GTimer.GetTime();
}

int OldClock()
{
	return GetTickCount();
}

int OlderClock()
{
	SYSTEMTIME st;
	GetSystemTime(&st);
	int ans = st.wMilliseconds;
	ans += (1000 * st.wSecond);
	ans += (1000 * 60 * st.wMinute);
	ans += (1000 * 60 * 60 * st.wHour);
	ans += (1000 * 60 * 60 * 24 * st.wDay);
	return ans;
}


void SetDTime()
{
//	int cur = Clock();
	float cur = Clock();
	if (LastTime==-1)
	{
		LastTime = Clock();
		DTime = 0;
		return;
	}
//	if (keys['F'])
//	{
//		cur=Clock();
//		LastTime=cur;
//	}
	DTime = (cur - LastTime);
	DTime /= 1000.0;
	DTime *= GRateOfTime;
	if (GPaused)
		DTime = 0;
	LastTime = cur;
}

bool IsFile(char * name)
{
    WIN32_FIND_DATA wfd;
	HANDLE file=FindFirstFile(name,&wfd);
	return (file!=(HANDLE)0xffffffff);
}

void MyPlaySound(char * filename)
{
	sndPlaySound(filename, SND_NOSTOP | SND_ASYNC);
}

/***************************START DICE CODE****************************/

//forward declarations:
class Board;
class CCursor;
class Die;
class Square;

void Show(char * text);

int GBoardSize = 10;
float GRollTime = 0.2; //seconds
float GMoveTime = 0.15;
float GLiftingTime = 5;
float GFallingTime = 7;
float GJumpHeight = 0.75;
float GCursorHeight = 0.1;
int GNumRandomRot = 20;
bool Cheat_NoClipping = 0;
bool Cheat_NoTwos	= 0;
bool Cheat_DidSlowTime = 0;
int GNormalNumDie = ((GBoardSize*GBoardSize) / 4);
float GAddBlockTime = 2;
float GGameLength = (60 * 3); //3 minutes
float GMaxNoChange = 5;
float GPushOutHeight = 0.3;
float GWarningTime = 11;
bool GHasJoyStick = 0;
bool GAngleView = 1;
int GJoyDir=-1;
Str GSndMove = "Data/DiceMove.wav";
Str GSndMatch = "Data/DiceMatch.wav";

float Abs(float f)
{
	if (f < 0)
		return -f;
	return f;
}

int IAbs(int f)
{
	if (f < 0)
		return -f;
	return f;
}

float Diff(float one, float two)
{
	return Abs(one-two);
}

int IDiff(int one, int two)
{
	return IAbs(one-two);
}

#define Front	0
#define Back	1
#define Right	2
#define Left	3
#define Top		4
#define Bottom	5

//Die Flags:
#define DF_Active	0x01
#define DF_Moving	0x02
#define DF_Rolling	0x04
#define DF_Lifting	0x08
#define DF_Falling	0x10
#define DF_DelMe	0x20
#define DF_Match	0x40
#define DF_FlatRoll	0x80

class Die
{
public:
	int Pos[2];	//x, y
	int Sides[6];
	Matrix Rot;
	uint Flags;

	//Die rotation animation data:
	int AniRotDir; //direction dice rotated, do opposite to rotate correctly
	float AniPos; //from 0 to 1

	float GetHeight();
	int GetTop();

	Die();
};

int Die::GetTop()
{
	if (IsFlag(Flags, DF_Rolling))
		return 0;
	return Sides[Top];
}

float Die::GetHeight()
{
	float ret = 1;
	if (IsFlag(Flags, DF_Lifting))
	{
		ret = AniPos;
	}
	if (IsFlag(Flags, DF_Falling))
	{
		ret = 1-AniPos;
	}
	return ret;
}

Die::Die()
{
	Flags = DF_Active;

	int i;

//	for (i=0; i!=6; i++)
//		Sides[i] = i+1;
/*	Sides[0] = 6;
	Sides[1] = 2;
	Sides[2] = 3;
	Sides[3] = 1;
	Sides[4] = 4;
	Sides[5] = 5; */
	Sides[Top] = 6;
	Sides[Left] = 5;
	Sides[Back] = 2;
	Sides[Bottom] = 1;
	Sides[Right] = 3;
	Sides[Front] = 4;


	Rot.Identity();
}

int RDBack[] = { Top, Front, Bottom, Back };
int RDFront[] = { Top, Back, Bottom, Front };
int RDLeft[] = { Top, Right, Bottom, Left };
int RDRight[] = { Top, Left, Bottom, Right };
int * RDAll[4];

void InitRD()
{
	RDAll[Front] = RDFront;
	RDAll[Back] = RDBack;
	RDAll[Right] = RDRight;
	RDAll[Left] = RDLeft;
}

void GetRotVec(Vector * vec, int dir)
{
	//dir == Front | Back | Right | Left
	vec->Set(0,0,0,1);
	if (dir == Front)
		(*vec)[0] = -90;
	if (dir == Back)
		(*vec)[0] = 90;
	if (dir == Left)
		(*vec)[1] = 90;
	if (dir == Right)
		(*vec)[1] = -90;
}

void RotateDie(Die * die, int dir)
{
	//dir == Front | Back | Right | Left
	int * rotdata = RDAll[dir];
	int temp = die->Sides[rotdata[0]];

	for (int i=0; i!=4; i++)
	{
		die->Sides[ rotdata[i] ] = die->Sides[ rotdata[(i+1)%4] ];
	}

	die->Sides[rotdata[3]] = temp;

	Vector vec;
	GetRotVec(&vec, dir);
	die->Rot.RotateX(vec[0]);
	die->Rot.RotateY(vec[1]);
}

//Square Flags
#define SF_Valid	0x01
#define SF_Taken	0x02

struct Square
{
	Die * TheDie;
	uchar Flags;

	float GetHeight();

	Square() {Flags=0; TheDie=0;};
};

float Square::GetHeight()
{
	if (TheDie)
		return TheDie->GetHeight();
	return 0;
}

//Cursor flags
#define CF_Moving	0x01

class CCursor
{
public:
	uint Flags;
	int Pos[2];
	float DPos[2];
	float AniPos;
	bool IsMoving();

	CCursor() {Pos[0]=0; Pos[1]=0; DPos[0]=0; DPos[1]=0; Flags=0;};
};

class Board
{
public:
	Square * Squares; //2d board in single array
	BArray<Die> Dice;
	int Width, Height;
	CCursor Cursor;
	int CurrentScore;
	float TimeLeft;
	bool GameOver;

	bool MoveDie(Square * from, int dx, int dy, bool flatroll);
	bool MoveCursor(int dir);
	void NewDie();
	void FallDie(Die * die);
	void RemoveDie(Die * die);
	void RecCheckHere(int x, int y, int match, int & count);
	void CheckHere(int x, int y);
	bool IsFalling(int x, int y);

	void Init(int width, int height);
	bool IsValid(int x, int y) { if ((x < 0) || (y < 0)) return 0; if ((x >= Width) || (y >= Height)) return 0; return 1;};
	Square * Axs(int x, int y) {return (Squares+(x+(y*Width)));};
	Square * SafeAxs(int x, int y) {if (!IsValid(x,y)) return 0; return Axs(x,y);};
	Square * operator [] (int i) {return (Squares+(i*Width));};

	Board() {Squares=0; Width=0; Height=0; CurrentScore=0; TimeLeft=GGameLength; GameOver=0;};
	~Board() {if (Squares) delete [] Squares;};
};

Matrix DMat;
float CursorSpin=0;
float CursorShade=0;
Board GBoard;
Matrix GMatrix;

bool CCursor::IsMoving()
{
	if (IsFlag(Flags, CF_Moving))
		return 1;
	Square * square = GBoard.Axs(Pos[0],Pos[1]);
	if (!square->TheDie)
		return 0;
	if (IsFlag(square->TheDie->Flags,DF_Rolling))
		return 1;
	return 0;
}

bool Board::IsFalling(int x, int y)
{
	Square * square = SafeAxs(x,y);
	if (!square)
		return 0;
	if (!square->TheDie)
		return 0;
	return (IsFlag(square->TheDie->Flags, DF_Falling));
}

void Board::RecCheckHere(int x, int y, int match, int & count)
{
	if (!IsValid(x,y))
		return;
	Square * square = Axs(x,y);
	if (!square->TheDie)
		return;
	if (IsFlag(square->TheDie->Flags, DF_Match))
		return;
	if (square->TheDie->GetTop() == match)
	{
		FlagOn(square->TheDie->Flags, DF_Match);
		count++;
		RecCheckHere(x-1,y,match,count);
		RecCheckHere(x+1,y,match,count);
		RecCheckHere(x,y-1,match,count);
		RecCheckHere(x,y+1,match,count);
	}
}

void Board::CheckHere(int x, int y)
{
	BAMem<Die> *work=Dice.Base;
	while (work)
	{
		FlagOff(work->Val.Flags, DF_Match);
		work=work->Next;
	}

	int count=0;
	Square * square = Axs(x,y);
	if (!square->TheDie)
		return;
	int match = square->TheDie->GetTop();
	if ((Cheat_NoTwos) && (match == 2))
		return;
	if (match == 1)
	{
		bool test=0;
		test |= IsFalling(x-1,y);
		test |= IsFalling(x+1,y);
		test |= IsFalling(x,y-1);
		test |= IsFalling(x,y+1);
		if (!test)
			return;
		work=Dice.Base;
		count=0;
		while (work)
		{
			if (work->Val.GetTop() == 1)
			{
				FlagOn(work->Val.Flags, DF_Match);
				count++;
			}
			work=work->Next;
		}
	}
	else
	{
		RecCheckHere(x,y,match,count);
		if (count < match)
			return;
	}

	work=Dice.Base;
	while (work)
	{
		if (IsFlag(work->Val.Flags, DF_Match))
		{
			FallDie(&work->Val);
		}
		work=work->Next;
	}

	CurrentScore += (count * match);
	Str score;
	score = (count * match);
	score.AddThisBefore("last score: ");
	Show(score.word);

//	sndPlaySound(GSndMatch.word,SND_ASYNC);
	MyPlaySound(GSndMatch.word);
}

void Board::RemoveDie(Die * die)
{
	Square * square = Axs(die->Pos[0], die->Pos[1]);
	square->TheDie = 0;
	Dice.DelCell(Dice.FindCell(die));
}

void Board::FallDie(Die * die)
{
	if (IsFlag(die->Flags, DF_Falling))
		return;
	if (IsFlag(die->Flags, DF_Lifting))
		die->AniPos = 1 - die->AniPos;
	else
		die->AniPos = 0;
	FlagOn(die->Flags, DF_Moving);
	FlagOn(die->Flags, DF_Falling);
	FlagOff(die->Flags, DF_Lifting);
	FlagOff(die->Flags, DF_Rolling);
	FlagOff(die->Flags, DF_Active);
}

void Board::NewDie()
{
	int x, y;
	Square * square;
	Die * die;
	while (1)
	{
		x = rand()%Width;
		y = rand()%Height;
		square = Axs(x,y);
		if (IsFlag(square->Flags, SF_Valid))
		{
			if (!square->TheDie)
			{
				die = Dice.AddMember();
				die->Pos[0] = x;
				die->Pos[1] = y;
				square->TheDie = die;
				for (x=0; x!=GNumRandomRot; x++)
					RotateDie(die, rand()%4);

				if ((Cursor.Pos[0] == x)  && (Cursor.Pos[1] == y))
				{
					FlagOff(Cursor.Flags,CF_Moving);
				}

				die->AniPos = 0;
				FlagOn(die->Flags, DF_Moving);
				FlagOn(die->Flags, DF_Lifting);
				return;
			}
		}
	}
}

void DirToDelta(int dir, int * d)
{
	d[0]=0;
	d[1]=0;
	switch (dir)
	{
	case Front:
		d[1] = -1;
		break;
	case Back:
		d[1] = 1;
		break;
	case Left:
		d[0] = -1;
		break;
	case Right:
		d[0] = 1;
		break;
	}
}

int DeltaToDir(int dx, int dy)
{
	switch (dx + 3*dy)
	{
	case -1:
		return Left;
	case 1:
		return Right;
	case -3:
		return Front;
	case 3:
		return Back;
	}
	return -1;
}

bool Board::MoveDie(Square * from, int dx, int dy, bool flatroll)
{
	Die * die = from->TheDie;

	if (!die)
		return 0;

	int tx = die->Pos[0]+dx, ty = die->Pos[1]+dy;

	if (!IsValid(tx,ty))
		return 0;

	Square * square = Axs(tx,ty);
	
	if (NotFlag(square->Flags,SF_Valid))
		return 0;

	if (square->TheDie)
		return 0;

	from->TheDie = 0;
	square->TheDie = die;

	die->Pos[0] = tx;
	die->Pos[1] = ty;

	int dir = DeltaToDir(dx,dy);
	if (!flatroll)
		RotateDie(die, dir);
	die->AniPos = 0;
	die->AniRotDir = dir;
	FlagOn(die->Flags, DF_Moving);
	FlagOn(die->Flags, DF_Rolling);
	FlagOff(die->Flags, DF_Active);
	if (flatroll)
		FlagOn(die->Flags, DF_FlatRoll);
	else
		FlagOff(die->Flags, DF_FlatRoll);

	return 1;
}

bool Board::MoveCursor(int dir)
{
	int to[2], d[2];
	DirToDelta(dir, d);
	to[0] = Cursor.Pos[0] + d[0];
	to[1] = Cursor.Pos[1] + d[1];

	if (!IsValid(to[0],to[1]))
		return 0;

	if (Cheat_NoClipping)
	{
		Cursor.DPos[0]=0;
		Cursor.DPos[1]=0;
		Cursor.Pos[0] = to[0];
		Cursor.Pos[1] = to[1];
		FlagOff(Cursor.Flags, CF_Moving);
		return 1;
	}

	if (IsFlag(Cursor.Flags, CF_Moving))
		return 0;

	Square * sfrom = Axs(Cursor.Pos[0],Cursor.Pos[1]);
	Square * sto = Axs(to[0], to[1]);
	Square * snext;
	Die * swapdie;

	if (NotFlag(sto->Flags, SF_Valid))
		return 0;

	if (sfrom->TheDie)
	{
		//on dice
		if (IsFlag(sfrom->TheDie->Flags,DF_Rolling))
			return 0;
		if (sto->TheDie)
		{
			if ((sfrom->GetHeight() == 1) && (sto->GetHeight() <= GPushOutHeight))
			{
				swapdie = sto->TheDie;
				sto->TheDie = 0;
				MoveDie(sfrom, d[0], d[1], 0);
				sfrom->TheDie = swapdie;
				swapdie->Pos[0] = Cursor.Pos[0];
				swapdie->Pos[1] = Cursor.Pos[1];
				if (IsFlag(swapdie->Flags, DF_Falling))
					FlagOn(swapdie->Flags, DF_DelMe);
				Cursor.DPos[0] = to[0] - Cursor.Pos[0];
				Cursor.DPos[1] = to[1] - Cursor.Pos[1];
				Cursor.Pos[0] = to[0];
				Cursor.Pos[1] = to[1];
				return 1;
			}
			else
			{
				if (Diff(sfrom->GetHeight(),sto->GetHeight()) > GJumpHeight)
					return 0;
			}

			Cursor.AniPos = 0;
			FlagOn(Cursor.Flags, CF_Moving);

			Cursor.DPos[0] = to[0] - Cursor.Pos[0];
			Cursor.DPos[1] = to[1] - Cursor.Pos[1];
			Cursor.Pos[0] = to[0];
			Cursor.Pos[1] = to[1];
			return 1;
		}
		else
		{
			if (IsFlag(sfrom->TheDie->Flags, DF_Moving))
			{
				if (Diff(sfrom->GetHeight(),sto->GetHeight()) > GJumpHeight)
					return 0;

				Cursor.AniPos = 0;
				FlagOn(Cursor.Flags, CF_Moving);

				Cursor.DPos[0] = to[0] - Cursor.Pos[0];
				Cursor.DPos[1] = to[1] - Cursor.Pos[1];
				Cursor.Pos[0] = to[0];
				Cursor.Pos[1] = to[1];
				return 1;
			}

			MoveDie(sfrom, d[0], d[1], 0);
			Cursor.DPos[0] = to[0] - Cursor.Pos[0];
			Cursor.DPos[1] = to[1] - Cursor.Pos[1];
			Cursor.Pos[0] = to[0];
			Cursor.Pos[1] = to[1];
			return 1;
		}
	}
	else
	{
		//off dice
		if (sto->TheDie)
		{
			//from ground to die
			if (sto->TheDie->GetHeight() <= GJumpHeight)
			{
				Cursor.AniPos = 0;
				FlagOn(Cursor.Flags, CF_Moving);
				Cursor.DPos[0] = to[0] - Cursor.Pos[0];
				Cursor.DPos[1] = to[1] - Cursor.Pos[1];
				Cursor.Pos[0] = to[0];
				Cursor.Pos[1] = to[1];
				return 1;
			}
			if (IsFlag(sto->TheDie->Flags,DF_Moving))
				return 0;
			snext = SafeAxs(to[0]+d[0],to[1]+d[1]);
			if ((!snext) || (NotFlag(snext->Flags, SF_Valid)))
				return 0;
			if (snext->TheDie)
				return 0;

			Cursor.AniPos = 0;
			FlagOn(Cursor.Flags, CF_Moving);
			Cursor.DPos[0] = to[0] - Cursor.Pos[0];
			Cursor.DPos[1] = to[1] - Cursor.Pos[1];
			Cursor.Pos[0] = to[0];
			Cursor.Pos[1] = to[1];

			MoveDie(sto, d[0], d[1], 1);
			return 1;
		}
		else
		{
			Cursor.AniPos = 0;
			FlagOn(Cursor.Flags, CF_Moving);

			Cursor.DPos[0] = to[0] - Cursor.Pos[0];
			Cursor.DPos[1] = to[1] - Cursor.Pos[1];
			Cursor.Pos[0] = to[0];
			Cursor.Pos[1] = to[1];
			return 1;
		}
	}

	return 0;
}

void Board::Init(int width, int height)
{
	if (Squares)
		delete [] Squares;
	Width = width;
	Height = height;
	Squares = new Square [width*height];
}

//int CurWidth = 10;
//int CurHeight = 10;

/****************************END DICE CODE*****************************/

LRESULT	CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);	// Declaration For WndProc

AUX_RGBImageRec *LoadBMP(char *Filename)				// Loads A Bitmap Image
{
	FILE *File=NULL;									// File Handle

	if (!Filename)										// Make Sure A Filename Was Given
	{
		return NULL;									// If Not Return NULL
	}

	File=fopen(Filename,"r");							// Check To See If The File Exists

	if (File)											// Does The File Exist?
	{
		fclose(File);									// Close The Handle
		return auxDIBImageLoad(Filename);				// Load The Bitmap And Return A Pointer
	}

	return NULL;										// If Load Failed Return NULL
}

int LoadGLTextures()									// Load Bitmaps And Convert To Textures
{
	int Status=FALSE;									// Status Indicator

	AUX_RGBImageRec *TextureImage[1];					// Create Storage Space For The Texture

	memset(TextureImage,0,sizeof(void *)*1);           	// Set The Pointer To NULL

	// Load The Bitmap, Check For Errors, If Bitmap's Not Found Quit
	if (TextureImage[0]=LoadBMP("Data/DiceTexture.bmp"))
	{
		Status=TRUE;									// Set The Status To TRUE

		glGenTextures(1, &texture[0]);					// Create The Texture

		// Typical Texture Generation Using Data From The Bitmap
		glBindTexture(GL_TEXTURE_2D, texture[0]);
		glTexImage2D(GL_TEXTURE_2D, 0, 3, TextureImage[0]->sizeX, TextureImage[0]->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, TextureImage[0]->data);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
	}

	if (TextureImage[0])									// If Texture Exists
	{
		if (TextureImage[0]->data)							// If Texture Image Exists
		{
			free(TextureImage[0]->data);					// Free The Texture Image Memory
		}

		free(TextureImage[0]);								// Free The Image Structure
	}

	return Status;										// Return The Status
}

GLvoid ReSizeGLScene(GLsizei width, GLsizei height)		// Resize And Initialize The GL Window
{
	if (height==0)										// Prevent A Divide By Zero By
	{
		height=1;										// Making Height Equal One
	}

	glViewport(0,0,width,height);						// Reset The Current Viewport

	glMatrixMode(GL_PROJECTION);						// Select The Projection Matrix
	glLoadIdentity();									// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
//	gluPerspective(45.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);
	gluPerspective(20.0f,(GLfloat)width/(GLfloat)height,0.1f,100.0f);

	glMatrixMode(GL_MODELVIEW);							// Select The Modelview Matrix
	glLoadIdentity();									// Reset The Modelview Matrix
}

int InitGL(GLvoid)										// All Setup For OpenGL Goes Here
{
	if (!LoadGLTextures())								// Jump To Texture Loading Routine ( NEW )
	{
		return FALSE;									// If Texture Didn't Load Return FALSE
	}

	glEnable(GL_TEXTURE_2D);							// Enable Texture Mapping ( NEW )
	glShadeModel(GL_FLAT );							// Enable Smooth Shading
	glClearColor(0.0f, 0.0f, 0.0f, 0.5f);				// Black Background
	glClearDepth(1.0f);									// Depth Buffer Setup
	glEnable(GL_DEPTH_TEST);							// Enables Depth Testing
	glDepthFunc(GL_LEQUAL);								// The Type Of Depth Testing To Do
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST );	// Really Nice Perspective Calculations

	glLightfv(GL_LIGHT1, GL_AMBIENT, LightAmbientFalling);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, LightDiffuse);
	glLightfv(GL_LIGHT1, GL_POSITION,LightPosition);
	glEnable(GL_LIGHT1);

//	glEnable(GL_LIGHTING);
    /* Culling. */
    glCullFace( GL_BACK );
    glFrontFace( GL_CCW );
    glEnable( GL_CULL_FACE );

	List_Die = glGenLists(2);
	List_Cursor = List_Die+1;

	return TRUE;										// Initialization Went OK
}

void MakeDieList()
{
	glNewList(List_Die,GL_COMPILE);

		glBegin(GL_QUADS);

			float d = (20.0f / 64.0f); //set ratio of block size on texture

			// Front Face
			glTexCoord2f(0.0f, 2*d); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(d, 2*d); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(0.0f, d); glVertex3f(-1.0f,  1.0f,  1.0f);
			// Back Face
			glTexCoord2f(2*d, d); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(3*d, d); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(3*d, 0); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(2*d, 0); glVertex3f( 1.0f, -1.0f, -1.0f);
			// Top Face
			glTexCoord2f(d, 2*d); glVertex3f(-1.0f,  1.0f, -1.0f);
			glTexCoord2f(2*d, 2*d); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(2*d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(d, d); glVertex3f( 1.0f,  1.0f, -1.0f);
			// Bottom Face
			glTexCoord2f(0, d); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(d, d); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(d, 0); glVertex3f( 1.0f, -1.0f,  1.0f);
			glTexCoord2f(0, 0); glVertex3f(-1.0f, -1.0f,  1.0f);
			// Right face
			glTexCoord2f(2*d, 2*d); glVertex3f( 1.0f, -1.0f, -1.0f);
			glTexCoord2f(3*d, 2*d); glVertex3f( 1.0f,  1.0f, -1.0f);
			glTexCoord2f(3*d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
			glTexCoord2f(2*d, d); glVertex3f( 1.0f, -1.0f,  1.0f);
			// Left Face
			glTexCoord2f(d, d); glVertex3f(-1.0f, -1.0f, -1.0f);
			glTexCoord2f(2*d, d); glVertex3f(-1.0f, -1.0f,  1.0f);
			glTexCoord2f(2*d, 0); glVertex3f(-1.0f,  1.0f,  1.0f);
			glTexCoord2f(d, 0); glVertex3f(-1.0f,  1.0f, -1.0f);

		glEnd();

	glEndList();
}

bool HasList_Die=0;

void RenderDie()
{
	if (HasList_Die)
		glCallList(List_Die);
	else
	{
		MakeDieList();
		HasList_Die=1;
	}
}

void RenderBoard()
{
	float d = (20.0f / 64.0f); //set ratio of block size on texture

	glDisable(GL_TEXTURE_2D);

//	glPushMatrix();

	float b = 0.5*(1.0+cos(GBoard.TimeLeft*Pi*2));
	if (GBoard.TimeLeft <= GWarningTime)
	//	glClearColor(0.9*b, 0*b, 0*b, 0.5f);
		b *= 0.9;
	else
	//	glClearColor(0*b, 0*b, 0*b, 0.5f);				// Black Background
		b = 0;

	glScalef(10.0f, 10.0f, 1.0f);

	glBegin(GL_QUADS);

		glColor3f(b, 0.0f, 0.0f);

		glVertex3f(-1.0f, 1.0f,  0.0f);
		glVertex3f( 1.0f, 1.0f,  0.0f);
		glVertex3f( 1.0f,  -1.0f,  0.0f);
		glVertex3f(-1.0f,  -1.0f,  0.0f);		

		glColor3f(1.0f, 1.0f, 1.0f);

	glEnd();

//	glPopMatrix();

	glScalef(0.1f, 0.1f, 1.0f);

	glEnable(GL_TEXTURE_2D);
	glDisable(GL_DEPTH_TEST);


	glBegin(GL_QUADS);

		glTexCoord2f(0, 3*d); glVertex3f(-1.0f, 1.0f,  0.0f);
		glTexCoord2f(d, 3*d); glVertex3f( 1.0f, 1.0f,  0.0f);
		glTexCoord2f(d, 2*d); glVertex3f( 1.0f,  -1.0f,  0.0f);
		glTexCoord2f(0, 2*d); glVertex3f(-1.0f,  -1.0f,  0.0f);

	glEnd();

	glEnable(GL_DEPTH_TEST);
}

void RenderCursorList()
{
	glNewList(List_Cursor,GL_COMPILE);

		glShadeModel(GL_SMOOTH);

		glBegin(GL_TRIANGLES);

			float red=0, blue=1;
		/*	if (GBoard.GameOver)
			{
				red=(sin(DegToRad(CursorSpin))+1)/2;
				blue=(cos(DegToRad(CursorSpin))+1)/2;
			} */

			glColor3f(0.0f, 1.0f, 0.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(-1.0f, -1.0f, -1.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(1.0f, -1.0f, -1.0f);

			glColor3f(0.0f, 1.0f, 0.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(1.0f, -1.0f, -1.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(0.0f, 1.0f, -1.0f);

			glColor3f(0.0f, 1.0f, 0.0f); glVertex3f(0.0f, 0.0f, 0.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(0.0f, 1.0f, -1.0f);
			glColor3f(red, 0.0f, blue); glVertex3f(-1.0f, -1.0f, -1.0f);

			glColor3f(red, 0.0f, blue);
			glVertex3f(-1.0f, -1.0f, -1.0f);
			glVertex3f(0.0f, 1.0f, -1.0f);
			glVertex3f(1.0f, -1.0f, -1.0f);

			glColor3f(1.0f, 1.0f, 1.0f);

		glEnd();

		glShadeModel(GL_SMOOTH);

	glEndList();
}

bool HasCursorList = 0;

void RenderCursor()
{
	if (HasCursorList)
	{
	//	if (!GBoard.GameOver)
			glCallList(List_Cursor);
	}
	else
	{
		RenderCursorList();
		HasCursorList=1;
	}
}

float GBoardShrink=0;

void GetBoardPos(Board * board, float x, float y, Vector * pos)
{
	//x and y are board coords, usuall ints but sometimes floats
	pos->Set(0,0,0,1);
	(*pos)[0] = x;
	(*pos)[1] = y;

	(*pos)[0] -= ((float)board->Width)/2.0f;
	(*pos)[1] -= ((float)board->Height)/2.0f;

	(*pos) *= 2;

/*	if (GBoard.GameOver)
	{
		float d = (1+sin(GBoardShrink*Pi*0.05))/2;
		float x = (*pos)[0];
		float y = (*pos)[1];
		(*pos)[2] = (-d)*sqrt((x*x)+(y*y));
	} */
}

void RenderDie(Die * die)
{
	Vector pos;
	if (GBoard.GameOver)
		GBoardShrink += DTime;
	else
		GBoardShrink=0;
	GetBoardPos(&GBoard, die->Pos[0], die->Pos[1], &pos);
	glTranslatef(pos[0],pos[1],pos[2]);
//	if (GBoard.GameOver)
//		glRotatef(GBoardShrink*1, 0.0f, 0.0f, 1.0f);
	int dir;
	float dt;

	if ((IsFlag(die->Flags, DF_Moving)) && (!GBoard.GameOver))
	{
		if (IsFlag(die->Flags, DF_Falling))
		{
		//	glEnable(GL_LIGHTING);
			glColor3f(1.0f, 0.25f, 0.25f);
			glTranslatef(0.0f, 0.0f,  2.0f * (die->AniPos) );

			die->AniPos += (DTime / GFallingTime);

			if (die->AniPos >= 1)
			{
				FlagOff(die->Flags, DF_Moving);
				FlagOff(die->Flags, DF_Falling);
				FlagOn(die->Flags, DF_DelMe);
			}
		}
		if (IsFlag(die->Flags, DF_Lifting))
		{
			glTranslatef(0.0f, 0.0f,  2.0f * (1 - die->AniPos) );

			die->AniPos += (DTime / GLiftingTime);

			if (die->AniPos >= 1)
			{
				FlagOff(die->Flags, DF_Moving);
				FlagOff(die->Flags, DF_Lifting);
			}
		}
		if (IsFlag(die->Flags, DF_Rolling))
		{
			dir = die->AniRotDir;
			dt = 1 - die->AniPos;
			int d[2];
			DirToDelta(dir,d);
			d[0]*=-2;
			d[1]*=-2;
			glTranslatef(((float)d[0])*dt, ((float)d[1])*dt, 0.0f);

			if (NotFlag(die->Flags, DF_FlatRoll))
			{
				float x = 2 * Diff(dt,0.5);
				glTranslatef(0.0f, 0.0f, 1 - sqrt(2.0 - (x*x)) );
			}

			Vector rvec;
			dir = die->AniRotDir;
			dt = 1-die->AniPos;
			GetRotVec(&rvec, dir);
			rvec *= -1;
			if (NotFlag(die->Flags, DF_FlatRoll))
			{
				glRotatef(rvec[0]*dt, 1.0f, 0.0f, 0.0f);
				glRotatef(rvec[1]*dt, 0.0f, 1.0f, 0.0f);
			}

			die->AniPos += (DTime / GRollTime);

			if (die->AniPos >= 1)
			{
				FlagOff(die->Flags, DF_Moving);
				FlagOff(die->Flags, DF_Rolling);
				FlagOn(die->Flags, DF_Active);
				GBoard.CheckHere(die->Pos[0],die->Pos[1]);
			}
		}
	}

	glMultMatrixf(die->Rot.Mat);

	RenderDie();

	if ((IsFlag(die->Flags, DF_Falling)) && (!GBoard.GameOver))
	//	glDisable(GL_LIGHTING);
		glColor3f(1.0f, 1.0f, 1.0f);

	glPopMatrix();
	glPushMatrix();
}

void RenderCursor(CCursor * cursor)
{
	Vector cpos;
	cpos.Set(cursor->Pos[0],cursor->Pos[1],0,0);
	Square * square = GBoard.Axs(cursor->Pos[0], cursor->Pos[1]);
	float d;
	if (IsFlag(cursor->Flags, CF_Moving))
	{
		d = 1 - cursor->AniPos;
		cpos[0] += (d * -cursor->DPos[0]);
		cpos[1] += (d * -cursor->DPos[1]);

		cursor->AniPos += (DTime / GMoveTime);
		if (cursor->AniPos >= 1)
		{
			FlagOff(cursor->Flags, CF_Moving);
		}
	}
	if (square->TheDie)
	{
		if (IsFlag(square->TheDie->Flags, DF_Moving))
		{
			if (IsFlag(square->TheDie->Flags, DF_Rolling))
			{
				d = 1 - square->TheDie->AniPos;
				cpos[0] += (d * -cursor->DPos[0]);
				cpos[1] += (d * -cursor->DPos[1]);
			}
		}
	}

	GetBoardPos(&GBoard, cpos[0], cpos[1], &cpos);
	float h = -(GCursorHeight + square->GetHeight());
	if (GBoard.GameOver)
		h = 1;
	glTranslatef(cpos[0], cpos[1], h);
	glScalef(1.0f, 1.0f, 2.0f);
	if (GBoard.GameOver)
	{
		glTranslatef(0.0f, 0.0f, -1.0f);
		glScalef(1.0f, 1.0f, cos(GBoardShrink*Pi*0.02));
	}
	glDisable(GL_TEXTURE_2D);
	glRotatef(CursorSpin, 0.0f, 0.0f, 1.0f);
	RenderCursor();
	glEnable(GL_TEXTURE_2D);


}

void RenderBoard(Board * board)
{
	BAMem<Die> * work=board->Dice.Base, *other;

	while (work)
	{
		RenderDie(&work->Val);
		if (IsFlag(work->Val.Flags, DF_DelMe))
		{
			other=work->Next;
			board->RemoveDie(&work->Val);
			work=other;
		}
		else
			work=work->Next;
	}

	RenderCursor(&board->Cursor);
}

void MShow(char * text)
{
	MessageBox(hWnd, text, "Evil Dice", MB_OK);
	LastTime = Clock();
}

bool IsCheated()
{
	bool ret=0;
	ret |= Cheat_NoTwos;
	ret |= Cheat_NoClipping;
	ret |= Cheat_DidSlowTime;
	return ret;
}

char GTextBuff[300];

int GHighScore=0;
Str GHighScoreName;
char GMask = 0xB3;

void SaveHighScore()
{
	ofstream fout("EvilDice.data", ios::binary | ios::out);
	fout.write((char*)&GHighScore, sizeof(int));
	int size = GetSize(GHighScoreName.word);
	fout.write(GHighScoreName.word, size);
/*	char buff[4+10];
	int data = GHighScore;
	char * word = GHighScoreName.word;
	int len = GetSize(word);

	int i;
	for (i=0; i!=4; i++)
	{
		buff[i*2] = ((uchar*)&data)[0];
		buff[i*2] ^= GMask;
		data >>= 8;
	}
	int p=0;
	i=1;
	uchar c;
	while (word[p])
	{
		c = word[p];
		c ^= GMask;
		buff[i] = c;
		if (i < 8)
			i++;
		i++;
		p++;
	}
	while (i < 14)
	{
		buff[i] = GMask;
		if (i < 8)
			i++;
		i++;
	}
	fout.write(buff,14); */
}

void GetHighScore()
{
	if (IsFile("EvilDice.data"))
	{
		ifstream fin("EvilDice.data", ios::binary | ios::in);
		fin.read((char*)&GHighScore, sizeof(int) );
		int p=0;
		char c;
		do
		{
			fin.read(&c,1);
			GTextBuff[p]=c;
			p++;
		} while (c != 0);
		GHighScoreName = GTextBuff;

	/*	uchar buff[4+10];
		fin.read(buff,14);
		fin.close();
		int data=0;
		char c;
		GHighScoreName = "";
		int i;
		for (i=0; i!=8; i++)
		{
			c = buff[i];
			c ^= GMask;
			if ((i%2)==0)
			{
				if (c != 0)
					GHighScoreName += c;
			}
			else
			{
				data <<= 8;
				data |= c;
			}
		}
		while (i != 14)
		{
			c = buff[i];
			c ^= GMask;
			if (c != 0)
				GHighScoreName += c;
			i++;
		}

		GHighScore = data; */
	}
	else
	{
		GHighScore=0;
		GHighScoreName="";
	}
}

LRESULT CALLBACK EnterNameProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			JustCopy(GHighScoreName.word, GTextBuff);
			SetDlgItemText(hDlg, IDC_Name_Name, GTextBuff);
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
				GetDlgItemText(hDlg, IDC_Name_Name, GTextBuff, 300);
				EndDialog(hDlg, LOWORD(wParam));
				break;
			case IDCANCEL:
				if (MessageBox(hDlg, "Sure you don't want to enter a name?","Evil Dice",MB_YESNO)==IDYES)
					EndDialog(hDlg, LOWORD(wParam));
				break;
			}
			break;
	}
    return FALSE;
}

void GetPlayerName()
{
	if (DialogBox(hInstance, (LPCTSTR)IDD_EnterName, hWnd, (DLGPROC)EnterNameProc) == IDCANCEL)
		GTextBuff[0]=0;
}

void GameIsOver()
{
	Str str;
	str = GBoard.CurrentScore;
	str.AddThisBefore("Gamve Over!\nScore: ");
	if (IsCheated())
	{
		str += "\nBUT YOU CHEATED!";
	}
	MShow(str.word);
	if (IsCheated())
		return;

	if (GHighScore < GBoard.CurrentScore)
	{
		GetPlayerName();
		if (GTextBuff[0])
		{
			GHighScore = GBoard.CurrentScore;
			GHighScoreName = GTextBuff;
			SaveHighScore();
		}
	}
}

float GAddBlockCheck=0;
float GClockShow=0;
int GLastCount=-1;
float GNoChange=0;

void RenderAll()
{
//	if (GBoard.GameOver)
//		DTime=0;

	if (!GBoard.GameOver)
	{
	GBoard.TimeLeft -= DTime;
	if ((!GBoard.GameOver) && (GBoard.TimeLeft <= 0))
	{
		GBoard.TimeLeft = 0;
		DTime=0;
		GBoard.GameOver = 1;
		GameIsOver();
	}

	if (GLastCount == GBoard.Dice.GetLength())
	{
		GNoChange+=DTime;
		if (GNoChange >= GMaxNoChange)
		{
			GNoChange=0;
			GBoard.NewDie();
		}
	}
	else
	{
		GLastCount = GBoard.Dice.GetLength();
		GNoChange=0;
	}

	GAddBlockCheck += DTime;
	if (GAddBlockCheck > GAddBlockTime)
	{
		GAddBlockCheck -= GAddBlockTime;
		if (GBoard.Dice.GetLength() < GNormalNumDie)
		{
			GAddBlockCheck = 0;
			GBoard.NewDie();
		}
	}

	GClockShow += DTime;
	if (GClockShow > 1)
	{
		GClockShow-=1;
		Show(0);
	}
	}

	float f = 2*sqrt(1.0f/((float)(GBoard.Height * GBoard.Width)));
	glScalef(f,f,f);
	glTranslatef(0.0f, 0.0f, -1.0f);
	glPushMatrix();
	glPushMatrix();

	glTranslatef(-1.0f,-1.0f,1.0f);
	glScalef(1/(f/2),1/(f/2),1/(f/2));
	RenderBoard();
	glPopMatrix();
	glPushMatrix();

//	glBegin(GL_QUADS);
//	RenderDie();
//	glEnd();

	RenderBoard(&GBoard);

	glPopMatrix();

	return;
	//the below is testing code:

	//no changes so no need to push and pop
	glBegin(GL_QUADS);
	RenderDie();
	glEnd();

	Vector pos;
	GetBoardPos(&GBoard, 0, 0, &pos);
	glTranslatef(pos[0],pos[1],0.0f);
	glBegin(GL_QUADS);
	RenderDie();
	glEnd();
	glPopMatrix();
	glPushMatrix();


	DMat.Identity();
	DMat.Translate(2,2,0);
	glMultMatrixf(DMat.Mat);

	DMat.Identity();
	DMat.RotateX(90);
	glMultMatrixf(DMat.Mat);

	glBegin(GL_QUADS);
	RenderDie();
	glEnd();

	glPopMatrix();
	glPushMatrix();


	glPopMatrix();
}

int GCurrentCamera = 2;
int GNumCameras = 3;
Matrix GCameraMatrix;

void CameraAngle()
{
	switch (GCurrentCamera)
	{
	case 0:
		glRotatef(180, 1.0f, 0.0f, 0.0f);
		glRotatef(50, 0.0f, 0.0f, 1.0f);
		glRotatef(50, -1.0f, 1.0f, 0.0f);
		GAngleView=1;
		break;
	case 1:
		glRotatef(180, 1.0f, 0.0f, 0.0f);
		GAngleView=0;
		break;
	case 2:
		glRotatef(yrot,0.0f,1.0f,0.0f);
		glRotatef(xrot,1.0f,0.0f,0.0f);
		glRotatef(zrot,0.0f,0.0f,1.0f);
		GAngleView=1;
		break;
	}
}

int DrawGLScene(GLvoid)									// Here's Where We Do All The Drawing
{
	SetDTime();

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	// Clear The Screen And The Depth Buffer
	glLoadIdentity();									// Reset The View
	glTranslatef(0.0f,0.0f,-13.0f);

	CameraAngle();
//		glRotatef(180, 1.0f, 0.0f, 0.0f);
//	glRotatef(yrot,0.0f,1.0f,0.0f);
//	glRotatef(xrot,1.0f,0.0f,0.0f);
//	glRotatef(zrot,0.0f,0.0f,1.0f);

	glBindTexture(GL_TEXTURE_2D, texture[0]);

//	float d = (20.0f / 64.0f); //set ratio of block size on texture

	RenderAll();

//	xrot+=0.3f;
//	yrot+=0.2f;
//	zrot+=0.4f;
	CursorSpin+=200*DTime;
//	CursorSpin+=0.6;
	if (GBoard.GameOver)
//		CursorSpin+=1.2;
		CursorSpin+=200*DTime;
	return TRUE;

	glBegin(GL_QUADS);
	//	RenderDie();
		RenderAll();
	/*	// Front Face
		glTexCoord2f(0.0f, 2*d); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(d, 2*d); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, d); glVertex3f(-1.0f,  1.0f,  1.0f);
		// Back Face
		glTexCoord2f(2*d, d); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(3*d, d); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(3*d, 0); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(2*d, 0); glVertex3f( 1.0f, -1.0f, -1.0f);
		// Top Face
		glTexCoord2f(d, 2*d); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(2*d, 2*d); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(2*d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(d, d); glVertex3f( 1.0f,  1.0f, -1.0f);
		// Bottom Face
		glTexCoord2f(0, d); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(d, d); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(d, 0); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(0, 0); glVertex3f(-1.0f, -1.0f,  1.0f);
		// Right face
		glTexCoord2f(2*d, 2*d); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(3*d, 2*d); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(3*d, d); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(2*d, d); glVertex3f( 1.0f, -1.0f,  1.0f);
		// Left Face
		glTexCoord2f(d, d); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(2*d, d); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(2*d, 0); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(d, 0); glVertex3f(-1.0f,  1.0f, -1.0f); */
	/*	// Front Face
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		// Back Face
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		// Top Face
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		// Bottom Face
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		// Right face
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 1.0f,  1.0f, -1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 1.0f, -1.0f,  1.0f);
		// Left Face
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-1.0f, -1.0f, -1.0f);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-1.0f, -1.0f,  1.0f);
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-1.0f,  1.0f,  1.0f);
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-1.0f,  1.0f, -1.0f); */
	glEnd();

	return TRUE;										// Keep Going
}

Str LastShow;
void Show(char * text)
{
	Str str = "Evil Dice - Time: ";
	Str score;
	int i = GBoard.TimeLeft;
	if (i < 0)
		i=0;
	if (i == 0)
		str += "OUT";
	else
	{
		score = (i/60);
		str += score.word;
		str += ":";
		score = i%60;
		if (score.word[1]==0)
			score.AddThisBefore("0");
		str += score.word;
	}
	str += " - Score: ";
	score = GBoard.CurrentScore;
	str += score.word;
	if (text)
	{
		LastShow = " - ";
		LastShow += text;
	}
	str += LastShow;
	if (GHighScore != 0)
	{
		score = GHighScore;
		score.AddThisBefore(" - High Score: ");
		score += " by ";
		score += GHighScoreName.word;
		str += score.word;
	}
	SetWindowText(hWnd, str.word);
}

GLvoid KillGLWindow(GLvoid)								// Properly Kill The Window
{
	if (fullscreen)										// Are We In Fullscreen Mode?
	{
		ChangeDisplaySettings(NULL,0);					// If So Switch Back To The Desktop
		ShowCursor(TRUE);								// Show Mouse Pointer
	}

	if (hRC)											// Do We Have A Rendering Context?
	{
		if (!wglMakeCurrent(NULL,NULL))					// Are We Able To Release The DC And RC Contexts?
		{
			MessageBox(NULL,"Release Of DC And RC Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}

		if (!wglDeleteContext(hRC))						// Are We Able To Delete The RC?
		{
			MessageBox(NULL,"Release Rendering Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		}
		hRC=NULL;										// Set RC To NULL
	}

	if (hDC && !ReleaseDC(hWnd,hDC))					// Are We Able To Release The DC
	{
		MessageBox(NULL,"Release Device Context Failed.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hDC=NULL;										// Set DC To NULL
	}

	if (hWnd && !DestroyWindow(hWnd))					// Are We Able To Destroy The Window?
	{
		MessageBox(NULL,"Could Not Release hWnd.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hWnd=NULL;										// Set hWnd To NULL
	}

	if (!UnregisterClass("OpenGL",hInstance))			// Are We Able To Unregister Class
	{
		MessageBox(NULL,"Could Not Unregister Class.","SHUTDOWN ERROR",MB_OK | MB_ICONINFORMATION);
		hInstance=NULL;									// Set hInstance To NULL
	}
}

/*	This Code Creates Our OpenGL Window.  Parameters Are:					*
 *	title			- Title To Appear At The Top Of The Window				*
 *	width			- Width Of The GL Window Or Fullscreen Mode				*
 *	height			- Height Of The GL Window Or Fullscreen Mode			*
 *	bits			- Number Of Bits To Use For Color (8/16/24/32)			*
 *	fullscreenflag	- Use Fullscreen Mode (TRUE) Or Windowed Mode (FALSE)	*/
 
BOOL CreateGLWindow(char* title, int width, int height, int bits, bool fullscreenflag)
{
	GLuint		PixelFormat;			// Holds The Results After Searching For A Match
	WNDCLASS	wc;						// Windows Class Structure
	DWORD		dwExStyle;				// Window Extended Style
	DWORD		dwStyle;				// Window Style
	RECT		WindowRect;				// Grabs Rectangle Upper Left / Lower Right Values
	WindowRect.left=(long)0;			// Set Left Value To 0
	WindowRect.right=(long)width;		// Set Right Value To Requested Width
	WindowRect.top=(long)0;				// Set Top Value To 0
	WindowRect.bottom=(long)height;		// Set Bottom Value To Requested Height

	fullscreen=fullscreenflag;			// Set The Global Fullscreen Flag

	hInstance			= GetModuleHandle(NULL);				// Grab An Instance For Our Window
	wc.style			= CS_HREDRAW | CS_VREDRAW | CS_OWNDC;	// Redraw On Size, And Own DC For Window.
	wc.lpfnWndProc		= (WNDPROC) WndProc;					// WndProc Handles Messages
	wc.cbClsExtra		= 0;									// No Extra Window Data
	wc.cbWndExtra		= 0;									// No Extra Window Data
	wc.hInstance		= hInstance;							// Set The Instance
	wc.hIcon			= LoadIcon(hInstance, (LPCSTR)IDI_ICON1);			// Load The Default Icon
	wc.hCursor			= LoadCursor(NULL, IDC_ARROW);			// Load The Arrow Pointer
	wc.hbrBackground	= NULL;									// No Background Required For GL
	wc.lpszMenuName		= NULL;									// We Don't Want A Menu
	wc.lpszClassName	= "OpenGL";								// Set The Class Name

	if (!RegisterClass(&wc))									// Attempt To Register The Window Class
	{
		MessageBox(NULL,"Failed To Register The Window Class.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;											// Return FALSE
	}
	
	if (fullscreen)												// Attempt Fullscreen Mode?
	{
		DEVMODE dmScreenSettings;								// Device Mode
		memset(&dmScreenSettings,0,sizeof(dmScreenSettings));	// Makes Sure Memory's Cleared
		dmScreenSettings.dmSize=sizeof(dmScreenSettings);		// Size Of The Devmode Structure
		dmScreenSettings.dmPelsWidth	= width;				// Selected Screen Width
		dmScreenSettings.dmPelsHeight	= height;				// Selected Screen Height
		dmScreenSettings.dmBitsPerPel	= bits;					// Selected Bits Per Pixel
		dmScreenSettings.dmFields=DM_BITSPERPEL|DM_PELSWIDTH|DM_PELSHEIGHT;

		// Try To Set Selected Mode And Get Results.  NOTE: CDS_FULLSCREEN Gets Rid Of Start Bar.
		if (ChangeDisplaySettings(&dmScreenSettings,CDS_FULLSCREEN)!=DISP_CHANGE_SUCCESSFUL)
		{
			// If The Mode Fails, Offer Two Options.  Quit Or Use Windowed Mode.
			if (MessageBox(NULL,"The Requested Fullscreen Mode Is Not Supported By\nYour Video Card. Use Windowed Mode Instead?","NeHe GL",MB_YESNO|MB_ICONEXCLAMATION)==IDYES)
			{
				fullscreen=FALSE;		// Windowed Mode Selected.  Fullscreen = FALSE
			}
			else
			{
				// Pop Up A Message Box Letting User Know The Program Is Closing.
				MessageBox(NULL,"Program Will Now Close.","ERROR",MB_OK|MB_ICONSTOP);
				return FALSE;									// Return FALSE
			}
		}
	}

	if (fullscreen)												// Are We Still In Fullscreen Mode?
	{
		dwExStyle=WS_EX_APPWINDOW;								// Window Extended Style
		dwStyle=WS_POPUP;										// Windows Style
		ShowCursor(FALSE);										// Hide Mouse Pointer
	}
	else
	{
		dwExStyle=WS_EX_APPWINDOW | WS_EX_WINDOWEDGE;			// Window Extended Style
		dwStyle=WS_OVERLAPPEDWINDOW;							// Windows Style
	}

	AdjustWindowRectEx(&WindowRect, dwStyle, FALSE, dwExStyle);		// Adjust Window To True Requested Size

	// Create The Window
	if (!(hWnd=CreateWindowEx(	dwExStyle,							// Extended Style For The Window
								"OpenGL",							// Class Name
								title,								// Window Title
								dwStyle |							// Defined Window Style
								WS_CLIPSIBLINGS |					// Required Window Style
								WS_CLIPCHILDREN,					// Required Window Style
								0, 0,								// Window Position
								WindowRect.right-WindowRect.left,	// Calculate Window Width
								WindowRect.bottom-WindowRect.top,	// Calculate Window Height
								NULL,								// No Parent Window
								NULL,								// No Menu
								hInstance,							// Instance
								NULL)))								// Dont Pass Anything To WM_CREATE
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Window Creation Error.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	static	PIXELFORMATDESCRIPTOR pfd=				// pfd Tells Windows How We Want Things To Be
	{
		sizeof(PIXELFORMATDESCRIPTOR),				// Size Of This Pixel Format Descriptor
		1,											// Version Number
		PFD_DRAW_TO_WINDOW |						// Format Must Support Window
		PFD_SUPPORT_OPENGL |						// Format Must Support OpenGL
		PFD_DOUBLEBUFFER,							// Must Support Double Buffering
		PFD_TYPE_RGBA,								// Request An RGBA Format
		bits,										// Select Our Color Depth
		0, 0, 0, 0, 0, 0,							// Color Bits Ignored
		0,											// No Alpha Buffer
		0,											// Shift Bit Ignored
		0,											// No Accumulation Buffer
		0, 0, 0, 0,									// Accumulation Bits Ignored
		16,											// 16Bit Z-Buffer (Depth Buffer)  
		0,											// No Stencil Buffer
		0,											// No Auxiliary Buffer
		PFD_MAIN_PLANE,								// Main Drawing Layer
		0,											// Reserved
		0, 0, 0										// Layer Masks Ignored
	};
	
	if (!(hDC=GetDC(hWnd)))							// Did We Get A Device Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Device Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(PixelFormat=ChoosePixelFormat(hDC,&pfd)))	// Did Windows Find A Matching Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Find A Suitable PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!SetPixelFormat(hDC,PixelFormat,&pfd))		// Are We Able To Set The Pixel Format?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Set The PixelFormat.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if (!(hRC=wglCreateContext(hDC)))				// Are We Able To Get A Rendering Context?
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Create A GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	if(!wglMakeCurrent(hDC,hRC))					// Try To Activate The Rendering Context
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Can't Activate The GL Rendering Context.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	ShowWindow(hWnd,SW_SHOW);						// Show The Window
	SetForegroundWindow(hWnd);						// Slightly Higher Priority
	SetFocus(hWnd);									// Sets Keyboard Focus To The Window
	ReSizeGLScene(width, height);					// Set Up Our Perspective GL Screen

	if (!InitGL())									// Initialize Our Newly Created GL Window
	{
		KillGLWindow();								// Reset The Display
		MessageBox(NULL,"Initialization Failed.","ERROR",MB_OK|MB_ICONEXCLAMATION);
		return FALSE;								// Return FALSE
	}

	return TRUE;									// Success
}

void MovedJoyStick(DWORD lParam)
{
    WORD x, y;

    x = LOWORD(lParam) >> 11;
    y = HIWORD(lParam) >> 11;

	GJoyDir = -1;

	//NOTE: comment out the below line to have "real" movement of with the joystick
///	if (GAngleView)

	if ((IDiff(x,y) > 3) && (IDiff(x,32-y) > 3))
	{
		if (x > y)
		{
			if (x > 32-y)
				GJoyDir = Right;
			else
				GJoyDir = Front;
		}
		else
		{
			if (x > 32-y)
				GJoyDir = Back;
			else
				GJoyDir = Left;
		}
	}

/*	if (0)
	{
		if (x <= 13)
		{
			if (y <= 13)
				GJoyDir = Left;
			if (y >= 19)
				GJoyDir = Back;
		}
		if (x >= 19)
		{
			if (y <= 13)
				GJoyDir = Front;
			if (y >= 19)
				GJoyDir = Right;
		}
	}
	else
	{
		if(x <= 12)
			GJoyDir = Left;
		else if(x >= 20)
			GJoyDir = Right;

		if(y <= 12)
			GJoyDir = Front;
		else if(y >= 20)
			GJoyDir = Back;
	} */
}

LRESULT CALLBACK WndProc(	HWND	hWnd,			// Handle For This Window
							UINT	uMsg,			// Message For This Window
							WPARAM	wParam,			// Additional Message Information
							LPARAM	lParam)			// Additional Message Information
{
	switch (uMsg)									// Check For Windows Messages
	{
		case WM_CREATE:
		{
            joySetCapture(hWnd, JOYSTICKID1, 0, FALSE);
		}
		case WM_ACTIVATE:							// Watch For Window Activate Message
		{
			if (!HIWORD(wParam))					// Check Minimization State
			{
				active=TRUE;						// Program Is Active
			}
			else
			{
				active=FALSE;						// Program Is No Longer Active
			}

			return 0;								// Return To The Message Loop
		}

		case WM_SYSCOMMAND:							// Intercept System Commands
		{
			switch (wParam)							// Check System Calls
			{
				case SC_SCREENSAVE:					// Screensaver Trying To Start?
				case SC_MONITORPOWER:				// Monitor Trying To Enter Powersave?
				return 0;							// Prevent From Happening
			}
			break;									// Exit
		}

		case WM_CLOSE:								// Did We Receive A Close Message?
		{
			joyReleaseCapture(JOYSTICKID1);
			PostQuitMessage(0);						// Send A Quit Message
			return 0;								// Jump Back
		}


        case MM_JOY1MOVE :
		{
			MovedJoyStick(lParam);
		}

        case MM_JOY1BUTTONDOWN :
		{
            if (wParam & JOY_BUTTON1CHG)
			{
				keys['N'] = 1;
			}
            if (wParam & JOY_BUTTON2CHG)
			{
				keys['V'] = 1;
			}
			return 0;
		}

        case MM_JOY1BUTTONUP :
		{
            if (wParam & JOY_BUTTON1CHG)
			{
				keys['N'] = 0;
			}
            if (wParam & JOY_BUTTON2CHG)
			{
				keys['V'] = 0;
			}
			return 0;
		}

		case WM_KEYDOWN:							// Is A Key Being Held Down?
		{
			keys[wParam] = TRUE;					// If So, Mark It As TRUE
			return 0;								// Jump Back
		}

		case WM_KEYUP:								// Has A Key Been Released?
		{
			keys[wParam] = FALSE;					// If So, Mark It As FALSE
			return 0;								// Jump Back
		}

		case WM_SIZE:								// Resize The OpenGL Window
		{
			ReSizeGLScene(LOWORD(lParam),HIWORD(lParam));  // LoWord=Width, HiWord=Height
			return 0;								// Jump Back
		}
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd,uMsg,wParam,lParam);
}

void RandomBoard(Board * board)
{
	//does initial settings:
	board->GameOver = 0;
	board->CurrentScore = 0;
	board->TimeLeft = GGameLength;
	GAddBlockCheck = 0;
	GClockShow=0;
	GLastCount = -1;
	GNoChange = 0;
	LastShow = "";

	board->Init(GBoardSize,GBoardSize);
	board->Dice.DelAll();
	Square * square;

	for (int x=0; x!=GBoardSize; x++)
	{
		for (int y=0; y!=GBoardSize; y++)
		{
			square = board->Axs(x,y);
			square->Flags = 0;
			FlagOn(square->Flags, SF_Valid);
		}
	}

	for (int i=0; i!=GNormalNumDie; i++)
	{
		board->NewDie();
	}
	BAMem<Die>*work=board->Dice.Base;
	while (work)
	{
		work->Val.Flags = DF_Active;
		board->Cursor.Pos[0] = work->Val.Pos[0];
		board->Cursor.Pos[1] = work->Val.Pos[1];
		work=work->Next;
	}
/*	for (int x=0; x!=CurWidth; x++)
	{
		for (int y=0; y!=CurHeight; y++)
		{
			square = board->Axs(x,y);
			square->Flags = 0;
		//	if ((rand() % 5) != 0)
			if (1)
			{
			FlagOn(square->Flags, SF_Valid);
			if ((rand() % 5)==0)
			{
				square->TheDie = board->Dice.AddMember();
				square->TheDie->Pos[0] = x;
				square->TheDie->Pos[1] = y;
				board->Cursor.Pos[0] = x;
				board->Cursor.Pos[1] = y;

				for (int i=0; i!=GNumRandomRot; i++)
				{
					RotateDie(square->TheDie, rand() % 4);
				}
			}
			else
				square->TheDie = 0;
			}
		}
	} */
}

void Debug()
{
	Square * square = GBoard.Axs(GBoard.Cursor.Pos[0], GBoard.Cursor.Pos[1]);

	int i;
	i=square->TheDie->Sides[Top];
	i*=1;
}

int Keys_LastDir=-1;
bool Keys_New=0;
bool Keys_FallDie=0;
bool Keys_NextView = 0;
bool Keys_Pause = 0;
bool Keys_About = 0;

void ShowFPS()
{
//	if (DTime < 0.01)
//		return;
//	if (DTime != 0)
//		DTime *= 1;
	Str str;
	str = 1/DTime;
	str.AddThisBefore("FPS:");
//	MShow(str.word);
	Show(str.word);
}

void KeysFunc(bool k[])
{
	int dir=GJoyDir;

	if (k['N'])
	{
		if (!Keys_New)
			RandomBoard(&GBoard);
	}
	Keys_New = k['N'];

	if (k['V'])
	{
		if (!Keys_NextView)
		{
			GCurrentCamera++;
			GCurrentCamera %= GNumCameras;
		}
	}
	Keys_NextView = k['V'];

	if (k['A'])
	{
		if (!Keys_About)
			MShow("Evil Dice\n\nWritten by Lewey Geselowitz\n\nhttp://plaza.ufl.edu/lewey\nlewey@ufl.edu");
	}
	Keys_About = k['A'];

	if (GBoard.GameOver)
		return;

	k['P'] |= k[VK_PAUSE];
	if (k['P'])
	{
		if (!Keys_Pause)
			GPaused = !GPaused;
	}
	Keys_Pause = k['P'];

	if (k['F'])
	{
	//	if (DTime != 0)
	//	{
	//		k['Q']=0;
	//		DTime *= 1;
	//	}
		if (!Keys_FallDie)
		{
			ShowFPS();
			k['F']=0;
		}
	}
	Keys_FallDie = k['F'];

	if (k['2'])
		Cheat_NoTwos=1;
	Cheat_NoClipping = k['C'];
	if (k['D'])
	{
	//	Debug();
		MShow("A Test");
		k['D']=0;
	}

	if (k['T'])
	{
		GRateOfTime = 0.2;
		Cheat_DidSlowTime=1;
	}
	else
		GRateOfTime = 1;

	if (k['L'])
	{
		glEnable(GL_LIGHTING);
	}
	else
		glDisable(GL_LIGHTING);

	if (k[VK_LEFT])
	{
		dir = Left;
	}
	if (k[VK_RIGHT])
	{
		dir = Right;
	}
	if (k[VK_UP])
	{
		dir = Front;
	}
	if (k[VK_DOWN])
	{
		dir = Back;
	}

	if ((dir!=-1) && (!GBoard.Cursor.IsMoving()))
	{
		if (GBoard.MoveCursor(dir))
		//	sndPlaySound(GSndMove.word,SND_ASYNC);
			MyPlaySound(GSndMove.word);
	}
/*	if ((dir != -1) && (dir != Keys_LastDir))
	{
		if (GBoard.MoveCursor(dir))
			sndPlaySound(GSndMove.word,SND_ASYNC);
	}
	Keys_LastDir = dir; */
}

int WINAPI WinMain(	HINSTANCE	hInstance,			// Instance
					HINSTANCE	hPrevInstance,		// Previous Instance
					LPSTR		lpCmdLine,			// Command Line Parameters
					int			nCmdShow)			// Window Show State
{
	MSG		msg;									// Windows Message Structure
	BOOL	done=FALSE;								// Bool Variable To Exit Loop

	InitRD();
	RandomBoard(&GBoard);
	GetHighScore();
	MaxTextDigits=6;

     GHasJoyStick = ((!joyGetNumDevs())==0);

	// Ask The User Which Screen Mode They Prefer
//	if (MessageBox(NULL,"Would You Like To Run In Fullscreen Mode?", "Start FullScreen?",MB_YESNO|MB_ICONQUESTION)==IDNO)
//	{
		fullscreen=FALSE;							// Windowed Mode
//	}

	// Create Our OpenGL Window
	if (!CreateGLWindow("NeHe's Texture Mapping Tutorial",800,600,16,fullscreen))
	{
		return 0;									// Quit If Window Was Not Created
	}

	Show(0);

	while(!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg,NULL,0,0,PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message==WM_QUIT)				// Have We Received A Quit Message?
			{
				done=TRUE;							// If So done=TRUE
			}
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			// Draw The Scene.  Watch For ESC Key And Quit Messages From DrawGLScene()
			if ((active && !DrawGLScene()) || keys[VK_ESCAPE])	// Active?  Was There A Quit Received?
			{
				done=TRUE;							// ESC or DrawGLScene Signalled A Quit
			}
			else									// Not Time To Quit, Update Screen
			{
				SwapBuffers(hDC);					// Swap Buffers (Double Buffering)
			}

			KeysFunc(keys);

		/*	if (keys[VK_F1])						// Is F1 Being Pressed?
			{
				keys[VK_F1]=FALSE;					// If So Make Key FALSE
				KillGLWindow();						// Kill Our Current Window
				fullscreen=!fullscreen;				// Toggle Fullscreen / Windowed Mode
				// Recreate Our OpenGL Window
				if (!CreateGLWindow("NeHe's Texture Mapping Tutorial",640,480,16,fullscreen))
				{
					return 0;						// Quit If Window Was Not Created
				}
			} */
		}
	}

	// Shutdown
	KillGLWindow();									// Kill The Window
	return (msg.wParam);							// Exit The Program
}
