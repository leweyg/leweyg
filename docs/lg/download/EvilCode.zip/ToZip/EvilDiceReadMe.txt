Evil Dice - Read Me

To run, just make sure the "Data" folder is in the same folder as EvilDice.exe, and then run the program. If the frame rate is too low, try renaming DiceTexture_Low.bmp into DiceTexture.bmp in the "Data" folder (this will require you to rename DiceTexture.bmp into something else). Please note also that Evil Dice is a work in progress, and is often updated. For extended information and the latest version. Please go to http://plaza.ufl.edu/lewey/download/EvilDice.html , here you will find a complete guide (with basic strategy) and some other information about where Evil Dice comes from and such.

Evil Dice was written by Lewey Geselowitz, please feel free to contact him (i.e. me) about anything you would liked changed about the program (or if you'd just like to say thanks or hang out or whatever). I can be contacted at lewey@ufl.edu . Or if your in Gainesville, Florida, feel free to give me a visit.

Evil Dice is a "Devil Dice type" game however it has no legal connection to Devil Dice what-so-ever.