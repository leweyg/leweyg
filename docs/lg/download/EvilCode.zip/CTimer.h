///////////////////////////////////////////////////////////////////////////////
/*

  File:		CTimer.h
  Class:	CTimer
  Purpose:	A high-resolution performance timer. Usable in place of standard 
			multimedia timers (if present on the system). Provides timer 
			information, detailed to a fraction of a millisecond.
  Author:	Peter Kingsbury (also see Thanks)
  Notice:	Use it as you like, let me know if you do!
  Contact:	matrix_cubed@hotmail.com
  Thanks:	NeHe, for the information regarding performance timers

*/
///////////////////////////////////////////////////////////////////////////////

#ifndef _CTIMER_H
#define _CTIMER_H

#include <windows.h>
#include <winbase.h>

///////////////////////////////////////////////////////////////////////////////

const float g_fDefaultResolution = 30.0f;
const float g_fMinimumResolution = 0.0001f;
const float g_fMaximumResolution = 1000.0f;

///////////////////////////////////////////////////////////////////////////////

#define ResolutionToFPS(fResolution)	(float)( fResolution * 1000.0f )
#define FPSToResolution(fFPS)			(float)( 1000.0f / fFPS )

///////////////////////////////////////////////////////////////////////////////

typedef struct _TIMER							// Timer Information
{
	__int64			iFrequency;					// Timer Frequency
	float			fResolution;				// Timer Resolution
	unsigned long	dwTimerStart;				// Multimedia Timer Start Value
	unsigned long	dwTimerElapsed;				// Multimedia Timer Elapsed Time
	bool			bPerformanceTimer;			// Using The Performance Timer?
	__int64			iPerformanceTimerStart;		// Performance Timer Start Value
	__int64			iPerformanceTimerElapsed;	// Performance Timer Elapsed Time

} TIMER, *LPTIMER;								// Structure Is Named timer

///////////////////////////////////////////////////////////////////////////////

class CTimer  
{
public:
	CTimer();
	~CTimer();

	float GetTime(void);

	unsigned long SetResolution(float);
	float GetResolution(void);

protected:
	TIMER		m_Timer;
	float		m_fResolution;

};

///////////////////////////////////////////////////////////////////////////////

#endif


