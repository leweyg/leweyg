///////////////////////////////////////////////////////////////////////////////

#pragma comment(lib, "winmm.lib")
#include "CTimer.h"

///////////////////////////////////////////////////////////////////////////////

CTimer::CTimer()
{

	m_fResolution = g_fDefaultResolution;

	memset(&m_Timer, 0, sizeof(TIMER));

	// If a performance counter isn't available, use timeGetTime()
	if (!QueryPerformanceFrequency((LARGE_INTEGER *) &m_Timer.iFrequency))
	{
		// Multimedia timer is necessary
		m_Timer.bPerformanceTimer	= false;
		m_Timer.dwTimerStart		= timeGetTime();
		m_Timer.fResolution			= 1.0f/1000.0f;		// Resolution is 0.001f
		m_Timer.iFrequency			= 1000;				// Frequency is 1000
		m_Timer.dwTimerElapsed		= m_Timer.dwTimerStart;
	}

	else
	{
		// Performance counter is available; use it to track time
		QueryPerformanceCounter((LARGE_INTEGER *) &m_Timer.iPerformanceTimerStart);
		m_Timer.bPerformanceTimer = true;

		// Timer resolution (using timer frequency)
		m_Timer.fResolution = (float) (((double)1.0f)/((double)m_Timer.iFrequency));
		
		// Set the time elapsed
		m_Timer.iPerformanceTimerElapsed	= m_Timer.iPerformanceTimerStart;
	}

}

///////////////////////////////////////////////////////////////////////////////

CTimer::~CTimer()
{
	// Do nothing
}

///////////////////////////////////////////////////////////////////////////////

float CTimer::GetTime(void)
{

	__int64 iTime;

	// If the performance timer is available
	if (m_Timer.bPerformanceTimer)
	{
		// Examine the current time using the frequency counter
		QueryPerformanceCounter((LARGE_INTEGER *) &iTime);

		// Return the current time (as a float)
		return (((float)(iTime - m_Timer.iPerformanceTimerStart) * m_Timer.fResolution) * 1000.0f);
	}

	// Otherwise
	else
	{
		// Return the normal multimedia timer's time
		return (((float)(timeGetTime() - m_Timer.dwTimerStart) * m_Timer.fResolution) * 1000.0f);
	}

}

///////////////////////////////////////////////////////////////////////////////

unsigned long CTimer::SetResolution(float fResolution)
{

	if (fResolution < g_fMinimumResolution)
	{
		m_fResolution = g_fMinimumResolution;
	}

	else if (fResolution > g_fMaximumResolution)
	{
		m_fResolution = g_fMaximumResolution;
	}

	else
	{
		m_fResolution = fResolution;
	}

	return 0;

}

///////////////////////////////////////////////////////////////////////////////

float CTimer::GetResolution(void)
{

	return m_fResolution;

}

///////////////////////////////////////////////////////////////////////////////
