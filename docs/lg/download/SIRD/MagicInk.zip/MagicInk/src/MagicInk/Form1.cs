using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Ink;
using MagicInk;

/// <summary>
/// This example demonstrates how to use the MagicInkControl class. It is simply a Form with a large
/// MagicInkControl in the middle, which is controlled through the menus.
/// </summary>
namespace MagicInkExample
{
	/// <summary>
	/// This is an example Form which contains within in the MagicInk Control, as you will
	///		see it is very easy to use.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Simply create the MagicInkControl like you would any other
		/// </summary>
		private MagicInkControl mic;

		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;
		private System.Windows.Forms.MenuItem menuItem15;
		private System.Windows.Forms.MenuItem menuItem16;
		private System.Windows.Forms.MenuItem menuItem17;
		private System.Windows.Forms.MenuItem menuItem18;
		private System.Windows.Forms.MenuItem menuItem19;
		private System.Windows.Forms.MenuItem menuItem20;
		private System.Windows.Forms.MenuItem menuItem21;
		private System.Windows.Forms.MenuItem menuItem22;
		private System.Windows.Forms.MenuItem menuItem23;
		private System.Windows.Forms.MenuItem menuItem24;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			//Created like any other control, notice that there is nothing really special
			//	that is needed other than setting the default Width and Height (even though
			//	the default values are decent in and of themselves).
			mic = new MagicInkControl();
			mic.Parent = this;
			mic.Location = new Point(10, 10);
			onSizeChanged(this, null);

			menuItem15_Click(this, null);	//select medium height
			menuItem11_Click(this, null);	//select medium width

			this.SizeChanged += new System.EventHandler( this.onSizeChanged );
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem17 = new System.Windows.Forms.MenuItem();
			this.menuItem19 = new System.Windows.Forms.MenuItem();
			this.menuItem18 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem24 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem15 = new System.Windows.Forms.MenuItem();
			this.menuItem16 = new System.Windows.Forms.MenuItem();
			this.menuItem20 = new System.Windows.Forms.MenuItem();
			this.menuItem21 = new System.Windows.Forms.MenuItem();
			this.menuItem23 = new System.Windows.Forms.MenuItem();
			this.menuItem22 = new System.Windows.Forms.MenuItem();
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem7,
																					  this.menuItem2,
																					  this.menuItem8,
																					  this.menuItem20});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem17,
																					  this.menuItem19,
																					  this.menuItem18,
																					  this.menuItem6});
			this.menuItem1.Text = "File";
			// 
			// menuItem17
			// 
			this.menuItem17.Index = 0;
			this.menuItem17.Text = "New";
			this.menuItem17.Click += new System.EventHandler(this.menuItem17_Click);
			// 
			// menuItem19
			// 
			this.menuItem19.Index = 1;
			this.menuItem19.Text = "Open...";
			this.menuItem19.Click += new System.EventHandler(this.menuItem19_Click);
			// 
			// menuItem18
			// 
			this.menuItem18.Index = 2;
			this.menuItem18.Text = "Save...";
			this.menuItem18.Click += new System.EventHandler(this.menuItem18_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 3;
			this.menuItem6.Text = "Exit";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem5,
																					  this.menuItem4});
			this.menuItem7.Text = "Edit";
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 0;
			this.menuItem5.Text = "Clear";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 1;
			this.menuItem4.Text = "Paste Ink";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 2;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem3,
																					  this.menuItem24});
			this.menuItem2.Text = "View";
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 0;
			this.menuItem3.Text = "View Height";
			this.menuItem3.Click += new System.EventHandler(this.menuItem3_Click);
			// 
			// menuItem24
			// 
			this.menuItem24.Checked = true;
			this.menuItem24.Index = 1;
			this.menuItem24.Text = "Use Z Culling";
			this.menuItem24.Click += new System.EventHandler(this.menuItem24_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 3;
			this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem9,
																					  this.menuItem13});
			this.menuItem8.Text = "Line";
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 0;
			this.menuItem9.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem10,
																					  this.menuItem11,
																					  this.menuItem12});
			this.menuItem9.Text = "Width";
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 0;
			this.menuItem10.Text = "Thin";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 1;
			this.menuItem11.Text = "Medium";
			this.menuItem11.Click += new System.EventHandler(this.menuItem11_Click);
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 2;
			this.menuItem12.Text = "Thick";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 1;
			this.menuItem13.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem14,
																					   this.menuItem15,
																					   this.menuItem16});
			this.menuItem13.Text = "Default Height";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 0;
			this.menuItem14.Text = "Low";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// menuItem15
			// 
			this.menuItem15.Index = 1;
			this.menuItem15.Text = "Medium";
			this.menuItem15.Click += new System.EventHandler(this.menuItem15_Click);
			// 
			// menuItem16
			// 
			this.menuItem16.Index = 2;
			this.menuItem16.Text = "High";
			this.menuItem16.Click += new System.EventHandler(this.menuItem16_Click);
			// 
			// menuItem20
			// 
			this.menuItem20.Index = 4;
			this.menuItem20.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem21,
																					   this.menuItem23,
																					   this.menuItem22});
			this.menuItem20.Text = "Help";
			// 
			// menuItem21
			// 
			this.menuItem21.Index = 0;
			this.menuItem21.Text = "Basic Usage...";
			this.menuItem21.Click += new System.EventHandler(this.menuItem21_Click);
			// 
			// menuItem23
			// 
			this.menuItem23.Index = 1;
			this.menuItem23.Text = "Why is the background chaning?...";
			this.menuItem23.Click += new System.EventHandler(this.menuItem23_Click);
			// 
			// menuItem22
			// 
			this.menuItem22.Index = 2;
			this.menuItem22.Text = "About...";
			this.menuItem22.Click += new System.EventHandler(this.menuItem22_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(504, 358);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Magic Ink";
			this.Load += new System.EventHandler(this.Form1_Load);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void onSizeChanged(object sender, System.EventArgs e)
		{
			Rectangle rect = this.ClientRectangle;
			int w = rect.Width-20;
			int h = rect.Height-20;

			//Resize the MagicInk control
			mic.Size = new Size(w,h);
		}

		private void menuItem3_Click(object sender, System.EventArgs e)
		{
			mic.DrawZBuffer = !mic.DrawZBuffer;
			this.menuItem3.Checked = mic.DrawZBuffer;
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			if (!mic.InkPaste())
				MessageBox.Show("Cannot paste");
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			mic.Ink.DeleteStrokes();
			mic.RedrawZBuff();
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void ClearChecks_Width()
		{
			menuItem10.Checked = false;
			menuItem11.Checked = false;
			menuItem12.Checked = false;
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			mic.LineWidth = 120;
			ClearChecks_Width();
			menuItem10.Checked = true;
		}

		private void menuItem11_Click(object sender, System.EventArgs e)
		{
			mic.LineWidth = 200;
			ClearChecks_Width();
			menuItem11.Checked = true;
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			mic.LineWidth = 300;
			ClearChecks_Width();
			menuItem12.Checked = true;
		}

		private void ClearChecked_LineZ(MenuItem mi)
		{
			menuItem14.Checked = false;
			menuItem15.Checked = false;
			menuItem16.Checked = false;
			mi.Checked = true;
		}

		private void menuItem16_Click(object sender, System.EventArgs e)
		{
			mic.LineZ = 15;
			ClearChecked_LineZ(menuItem16);
		}

		private void menuItem15_Click(object sender, System.EventArgs e)
		{
			mic.LineZ = 10;
			ClearChecked_LineZ(menuItem15);
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			mic.LineZ = 5;
			ClearChecked_LineZ(menuItem14);
		}

		private void menuItem17_Click(object sender, System.EventArgs e)
		{
			mic.Ink.DeleteStrokes();
			mic.RedrawZBuff();
		}

		private void menuItem18_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.SaveFileDialog fd = new System.Windows.Forms.SaveFileDialog();
			fd.Filter = "ISF Ink Files (*.isf)|*.isf|All files (*.*)|*.*";
			fd.InitialDirectory = System.Environment.CurrentDirectory;

			if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK)
				return;

			System.IO.Stream s = fd.OpenFile();
			byte[] data = mic.Ink.Save( Microsoft.Ink.PersistenceFormat.InkSerializedFormat );
			s.Write(data, 0, data.Length);
			s.Close();
		}

		private void menuItem19_Click(object sender, System.EventArgs e)
		{
			System.Windows.Forms.OpenFileDialog fd = new System.Windows.Forms.OpenFileDialog();
			fd.Filter = "ISF Ink Files (*.isf)|*.isf|All files (*.*)|*.*";
			fd.InitialDirectory = System.Environment.CurrentDirectory;
			fd.AddExtension = true;

			if (fd.ShowDialog() != System.Windows.Forms.DialogResult.OK)
				return;

			System.IO.Stream s = fd.OpenFile();
			byte[] data = new byte [ s.Length ];
			s.Read( data, 0, data.Length );
			Ink ink = new Ink();
			ink.Load(data);
			mic.InkCollector.Enabled = false;
			mic.InkCollector.Ink = ink;
			mic.InkCollector.Enabled = true;

			s.Close();
			mic.RedrawZBuff();
		}

		private void menuItem21_Click(object sender, System.EventArgs e)
		{
			string t = "Simply draw on the screen as you would with any normal";
			t += "\ninking application. As you draw you will see your strokes";
			t += "\nspring to 3D life as they are instantly transformed into";
			t += "\na SIRDS image (Single Image Random Dot Stereogram).\n";
			t += "\nIf your using a TabletPC, you will be able to adjust the height";
			t += "\nthat each part of the line appears at by adjusting how hard";
			t += "\nyou press with the pen. If your using a mouse, you will have to";
			t += "\nadjust the height from the 'Line' menu (I suggest trying";
			t += "\nthis program on a TabletPC as it's alot more fun).\n";
			t += "\nHope you enjoy this little app, if you have any questions or";
			t += "\ncomments I would love to hear them at lewey@ufl.edu";
			t += "\n   Enjoy.";
			t += "\n   -Lewey G.";
			System.Windows.Forms.MessageBox.Show(t,"Basic Help:");
		}

		private void menuItem22_Click(object sender, System.EventArgs e)
		{
			string mess = "Written and Developed by Lewey Geselowitz\n�2003 Lewey Geselowitz";
			mess += "\n\nWritten entirely in C# using the all mighty Visual Studio.Net";
			mess += "\nThis software is public domain, which means anyone can use it for whatever you want.";
			mess += "\n (this includes it's inclusion modified or not in proprietary software). If you meantion my";
			mess += "\n name I would be grateful but it is not required, and telling me about it would be great.";
			mess += "\n\nEmail me at: lewey@ufl.edu\nMy webpage: http://plaza.ufl.edu/lewey";
			mess += "\n\nSpecial thanks go to the University of Florida";
			mess += "\n  for allowing me to developed on one of their TabletPCs.";
			mess += "\nTo Microsoft for donating the TabletPC to UF and";
			mess += "\n  writing the .Net Framework and Ink APIs.";
			mess += "\nTo my advisor Dr. Jorg Peters for his help in my research.";
			mess += "\nAnd to my friends who acted as both my testers and test subjects.";
			mess += "\n\nThanks to you all!\n    -Lewey";
			System.Windows.Forms.MessageBox.Show(mess, "About MagicInk");
		}

		private void menuItem23_Click(object sender, System.EventArgs e)
		{
			string mess = "Because if you don't change the background which is";
			mess += "\ntiled across the screen to create the SIRDS effect, and you then";
			mess += "\nadjust the height map (which you do when drawing), then you see";
			mess += "\nthese strange effects occuring all over the screen which distract";
			mess += "\nyour eyes. If your interested in the detailes of why this occures,";
			mess += "\ncheck out http://plaza.ufl.edu/lewey/download/SIRD and click on";
			mess += "\nthe link called 'The Essay'";
			System.Windows.Forms.MessageBox.Show(mess, "Why is the background changing?");
		}

		private void menuItem24_Click(object sender, System.EventArgs e)
		{
			mic.ZCulling = !mic.ZCulling;
			mic.RedrawZBuff();
			menuItem24.Checked = !menuItem24.Checked;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
		
		}
	}
}
