
/// <summary>
/// This is the MagicInk namespace, which namely houses the MagicInkControl class.
/// Someone might also want to use the RawImage class, but thats up to them.
/// </summary>

/*
	I'm releasing this code to the public domain, so do whatever you want with it, and I'm not liable
	for anything that does or does not do. If you do like my program or use it somewhere else, I would
	be interested, so send me a line at lewey@ufl.edu
		-Lewey G.

	6/29/2003
*/

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Ink;

namespace MagicInk
{
	/// <summary>
	/// This is the main Control which you can put in your application and use
	/// as a normal Control. It renders the SIRDS and automatically redraws
	/// it on Idle events. The redrawing is to avoid artifacts caused by
	/// motion in the height map. The rendering is based entirely on Ink strokes
	/// and in this way is sort of an alternative to a normal Ink control, the strokes
	/// rendered can be adjusted and manipulated just as you would a normal Ink
	/// Control.
	/// 
	/// NOTE: This control automatically adjusts itself so that it's Width and Height are always
	/// divisable by 4 (for Bitmap compatibility issues).
	/// </summary>
	class MagicInkControl : System.Windows.Forms.Control
	{
		private InkCollector ic;	//The InkCollector
		private RawImage zbuff;		//The height map
		private RawImage pixelbuff;	//The "back buffer" which the SIRD is rendered into
		private RawImage randback;	//The random image which is tiled across the screen to create the SIRD image
		private System.Drawing.Imaging.ColorPalette palette;	//A grey-scale palette used to render the height map
		private System.Random randgen;	//Random number generator
		public static byte MaxZ = 20;	//The maximum value for the height map, reduced a little here so as
										// to reduce visual artifacts
		private bool zcull = true;	//stores whether z-culling is active or not
		private byte linez = 10;	//The default line depth, used when pen pressure information isn't available
		private bool drawz = false;	//holds whether the z buffer is drawn or not
		private System.Guid zid;	//holds the GUID used to identify the height data in a Strokes extended properties

		/// <summary>
		/// Gives access to the Ink object which is used for rendering, you can perform
		/// all normal Inking operations on this Ink object. Remember to call RedrawZBuff()
		/// after adjusting the Ink object. This is not done automatically so as to reduce
		/// the amount of times this not all too cheap function is called.
		/// </summary>
		public Ink Ink
		{
			get { return ic.Ink; }
		}

		/// <summary>
		/// Lets you access the InkCollector which acts as normal InkCollectors
		/// By adjusting the default drawing attributes of this object you
		/// adjust how new strokes appear in the system, this way all the tricks
		/// you have learnt with normal InkCollectors also work here
		/// </summary>
		public InkCollector InkCollector
		{
			get { return ic; }
		}

		/// <summary>
		/// Get or set whether the ZBuffer is drawn instead of the SIRDS image
		/// Turning this to true gives you a greyscale rendering of the height map
		/// used to create the SIRDS image
		/// </summary>
		public bool DrawZBuffer
		{
			get { return drawz; }
			set { drawz = value; }
		}

		/// <summary>
		/// This is just a quick way to get or set the Default drawing width
		/// of the InkCollector in Ink Coordinates
		/// </summary>
		public float LineWidth
		{
			get 
			{ 
				return this.ic.DefaultDrawingAttributes.Width;
			}
			set
			{
				this.ic.DefaultDrawingAttributes.Width = value;
			}
		}

		/// <summary>
		/// Adjust the default line depth, this depth is used when pen
		/// pressure information isn't given (i.e. you draw with the mouse)
		/// </summary>
		public byte LineZ
		{
			get { return linez; }
			set 
			{ 
				linez = value; 
				if (linez > MaxZ)
					linez = MaxZ;
			}
		}

		/// <summary>
		/// Get or set if ZCulling if active, if it is, then higher lines are drawn
		/// above lower lines, this gives a more natural look, but is slightly limiting
		/// </summary>
		public bool ZCulling
		{
			get { return zcull; }
			set { zcull = value; }
		}

		/// <summary>
		/// This is the recomended way to paste Ink, as opposed to accessing
		/// it through the Ink object.
		/// </summary>
		/// <returns></returns>
		public bool InkPaste()
		{
			if (!ic.Ink.CanPaste())
				return false;
			Renderer rend = new Renderer();
			Point pt = new Point(randback.Size.Width, 0);
			rend.PixelToInkSpace(CreateGraphics(), ref pt);
			ic.Ink.ClipboardPaste(pt);
			RedrawZBuff();
			return true;
		}

		/// <summary>
		/// This actually creates the SIRD image from the height map,
		/// I use a bi-direction method where each line is rendering in a different
		/// direction which helps reduce visual artifacts. I should note that this
		/// is very much a high performance version of the algorithum as opposed to ray-traced
		/// version which is used in non-moving professional SIRDS applications.
		/// </summary>
		unsafe private void calcPixelBuff()
		{
			fixed(byte* zdata=zbuff.Pixels, pdata=pixelbuff.Pixels, rdata=randback.Pixels)
			{
				int w=Size.Width, sw=randback.Size.Width;
				byte* curz, curp, curr;
				int x, y;
				for (y=0; y!=Size.Height; y++)
				{
					curz = (zdata + (w * (y%Size.Height)));
					curp = (pdata + (w * (y%Size.Height)));
					curr = (rdata + (sw * (y%randback.Size.Height)));
					if ((y%2)==0)
					{
						for (x=0; x!=sw; x++)
						{
							curp[x] = curr[ x ];
						}
						for (x=sw; x!=w; x++)
						{
							curp[x] = curp[ x  + curz[ x ] - sw ];
						}
					}
					else
					{
						for (x=w-1; x!=w-sw; x--)
						{
							curp[ x ] = curr[ x%sw ];
						}
						for (x=w-sw; x>=0; x--)
						{
							curp[x] = curp[ x + sw - curz[ x+sw ] ];
						}
					}
				}
			}
		}

		/// <summary>
		/// Randomize the background image which is tiled to create the SIRDS effect
		/// </summary>
		private void randomizeBackground()
		{
			byte[] data = randback.Pixels;
			randgen.NextBytes( data );
		}

		/// <summary>
		/// Make sure that your "back buffer" and heigh map are same size at the control
		/// </summary>
		private void SetBuffs()
		{
			if (zbuff.Size == Size)
			{
				ClearZBuff();
				return;
			}

			zbuff.Size = Size;
			pixelbuff.Size = Size;
			ClearZBuff();
		}

		/// <summary>
		/// Set the height of all pixels to 0
		/// </summary>
		public void ClearZBuff()
		{
			byte[] buff = zbuff.Pixels;
			int i, j;
			for (i=0; i!=buff.Length; i++)
				buff[i] = 0;
		}

		/// <summary>
		/// Makes sure the buffers are the correct size, and redraws the height map
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void onSizeChanged(object sender, System.EventArgs e)
		{
			System.Drawing.Size size = this.Size;
			if ( ((size.Width % 4)!=0) || ((size.Height % 4)!=0) )
			{
				size.Width -= (size.Width % 4);
				size.Height -= (size.Height % 4);
				this.Size = size;
				return;
			}

			SetBuffs();
			RedrawZBuff();
		}

		/// <summary>
		/// Default constructor
		/// </summary>
		public MagicInkControl()
		{
			SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			ic = new InkCollector(this.Handle); 
			ic.DefaultDrawingAttributes.Width = 200;
			ic.DefaultDrawingAttributes.AntiAliased = true;
			ic.DefaultDrawingAttributes.IgnorePressure = true;
			ic.DefaultDrawingAttributes.FitToCurve = true;
			ic.AutoRedraw = false;
			Guid[] props = new Guid[3];
			props[0] = PacketProperty.X;
			props[1] = PacketProperty.Y;
			props[2] = PacketProperty.NormalPressure;
			ic.DesiredPacketDescription = props;

			//	Random number:
			zid = new Guid("defa1337-8298-4952-8583-838349829823");

			this.pixelbuff = new RawImage();
			this.zbuff = new RawImage();
			this.randback = new RawImage();
			randback.Size = new Size(100, 60);
			this.randgen = new System.Random();
			randomizeBackground();

			SetBuffs();

			this.Paint += new System.Windows.Forms.PaintEventHandler(this.onPaint);
			this.SizeChanged += new System.EventHandler( this.onSizeChanged );
			ic.Stroke += new InkCollectorStrokeEventHandler(onStroke);
			ic.NewPackets += new InkCollectorNewPacketsEventHandler( onNewPackets );
			Application.Idle += new System.EventHandler( onIdle );

			ic.Enabled = true;
		}

		private Point lastpos = new Point(-1,-1);

		private void onStroke(object sender, Microsoft.Ink.InkCollectorStrokeEventArgs e)
		{
			lastpos = new Point(-1, -1);
			dontdrawme = null;

			if (e.Cursor.Inverted)
			{
				e.Cancel = true;
			}
			else
			{
				RedrawZBuff();
			}
		}

		/// <summary>
		/// This recalculates the height map from the Ink data, which is a
		/// fairly slow process and so isn't performed each frame
		/// </summary>
		public void RedrawZBuff()
		{
			ClearZBuff();
			drawstrokes(ic.Ink.Strokes);
		}

		/// <summary>
		/// Draws a dot onto the height map
		/// </summary>
		/// <param name="x">X coordinate of middle of dot</param>
		/// <param name="y">Y coordinate of middle of dot</param>
		/// <param name="width">Width of dot</param>
		/// <param name="zval">Z value for dot</param>
		private void drawdot(int x, int y, int width, byte zval)
		{
			width /= 2;
			int dx, dy;

			if (this.zcull)
			{
				for (dy=-width; dy<width; dy++)
				{
					for (dx=-width; dx<width; dx++)
					{
						zbuff.SafeZSet(x+dx, y+dy, zval);
					}
				}
			}
			else
			{
				for (dy=-width; dy<width; dy++)
				{
					for (dx=-width; dx<width; dx++)
					{
						zbuff.SafeSet(x+dx, y+dy, zval);
					}
				}
			}
		}

		/// <summary>
		/// Draws a linear lines of dots, many such lines make up the stroke.
		/// </summary>
		/// <param name="from">Point to draw from</param>
		/// <param name="to">Point to draw to</param>
		/// <param name="width">Width of line</param>
		/// <param name="zval">Z value of line</param>
		private void drawline(Point from, Point to, int width, byte zval)
		{
			int sx = (to.X - from.X);
			int sy = (to.Y - from.Y);
			int dx=1, dy=1, i=0, x, y;
			if (sx < 0)
				dx = -1;
			if (sy < 0)
				dy = -1;
			sx *= dx;
			sy *= dy;

			if (sx >= sy)
			{
				y = from.Y;
				for (x=from.X; x!=to.X; x+=dx)
				{
					drawdot(x, y, width, zval);

					i += sy;
					if (i >= sx)
					{
						y += dy;
						i -= sx;
					}
				}
			}
			else
			{
				x = from.X;
				for (y=from.Y; y!=to.Y; y+=dy)
				{
					drawdot(x, y, width, zval);

					i += sx;
					if (i >= sy)
					{
						x += dx;
						i -= sy;
					}
				}
			}
		}

		/// <summary>
		/// Used internally to avoid drawing stroke which is being used to erase other strokes
		/// </summary>
		private Stroke dontdrawme = null;

		/// <summary>
		/// Draws a stroke onto the height map
		/// </summary>
		/// <param name="st">Stroke to draw</param>
		/// <param name="rend">Renderer to use</param>
		/// <param name="g">Graphics object to use</param>
		/// <param name="newpackets">number of new packets to draw (-1 for all draw all packets)</param>
		private void drawstroke(Stroke st, Renderer rend, Graphics g, int newpackets)
		{
			if ((dontdrawme!=null)&&(st.Id == dontdrawme.Id))
				return;

			TabletPropertyMetrics tpm;
			tpm.Maximum=255;
			tpm.Minimum=0;
			int[] pressure = null;
			byte curz;
			int i;
			int width;
			setStrokeZ(st);
			int epi = st.ExtendedProperties.IndexOf(zid);
			curz = ((Byte)st.ExtendedProperties[epi].Data);

			Point pt = new Point((int)st.DrawingAttributes.Width, 0);
			rend.InkSpaceToPixel(g, ref pt);
			width = pt.X;

			for (i = 0; i < st.PacketDescription.Length; i++) 
			{
				if (st.PacketDescription[i] == PacketProperty.NormalPressure) 
				{ 
					pressure = st.GetPacketValuesByProperty(PacketProperty.NormalPressure); 
					tpm = st.GetPacketDescriptionPropertyMetrics(PacketProperty.NormalPressure);
				} 
			}
			Point[] pts = st.GetPoints();
			rend.InkSpaceToPixel(g, ref pts);

			int frompacket;
			if (newpackets == 0)
				frompacket = 0;
			else
				frompacket = pts.Length-newpackets-2;
			if (frompacket < 0)
				frompacket = 0;

			for (i=frompacket; i<pts.Length-1; i++)
			{
				if (pressure == null)
				{
					drawline(pts[i], pts[i+1], width, curz);
				}
				else
				{
					curz = (byte)((((double)(pressure[i] - tpm.Minimum)) / ((double)(tpm.Maximum - tpm.Minimum)))*((double)MaxZ));
					if (curz >= MaxZ)
						curz = (byte)(MaxZ-1);
					drawline(pts[i], pts[i+1], width, curz);
				}
			}
		}

		/// <summary>
		/// Draws a collection of Strokes
		/// </summary>
		/// <param name="sts">Strokes to draw</param>
		private void drawstrokes(Strokes sts)
		{
			int[] pressure;
			Point[] pts;
			int i;
			byte curz;

			bool hasprops = false;
			Renderer rend = new Renderer();
			Graphics g = this.CreateGraphics();

			foreach(Stroke st in sts)
			{
			//	st.DrawingAttributes.RasterOperation = Microsoft.Ink.RasterOperation.NoOperation;
				drawstroke(st, rend, g, 0);
			}
		}

		/// <summary>
		/// Make sure that each stroke contains a Z value, this value is ignored is pressure
		/// information is available.
		/// </summary>
		/// <param name="s">Stroke to check</param>
		private void setStrokeZ(Stroke s)
		{
			if (!s.ExtendedProperties.DoesPropertyExist(zid))
			{
				Byte b;
				b = linez;
				s.ExtendedProperties.Add(zid, b);
			}
		}

		/// <summary>
		/// Radius around deletion stroke to look for
		/// </summary>
		private float delradius = 200;

		private bool eraseStrokesAt(Point pt)
		{
			bool deled = false;
			foreach(Stroke st in ic.Ink.Strokes)
			{
				if ((dontdrawme==null)||(dontdrawme.Id != st.Id))
				{
					if (st.HitTest(pt, delradius))
					{
						ic.Ink.DeleteStroke(st);
						deled = true;
					}
				}
			}
			return deled;
		}

		private void onNewPackets(object sender, InkCollectorNewPacketsEventArgs e)
		{
			e.Stroke.DrawingAttributes.RasterOperation = Microsoft.Ink.RasterOperation.NoOperation;

			// if using the eraser
			if (e.Cursor.Inverted)
			{
				//make sure not to draw the erasing stroke
				dontdrawme = e.Stroke;

				int packetSize = e.Stroke.PacketSize;
				Point pt = Point.Empty;
				bool redraw = false;
				for (int i = 0; i < e.PacketCount; i++)
				{
					pt.X = e.PacketData[i*packetSize+0];
					pt.Y = e.PacketData[i*packetSize+1];

					if (eraseStrokesAt(pt))
						redraw = true;
				}
				if (redraw)
				{
					RedrawZBuff();
					Invalidate();
				}
			}
			else
			{
				//Only draw the new part of the Stroke:
				drawstroke(e.Stroke, new Renderer(), this.CreateGraphics(), e.PacketCount );

				Invalidate();
			}

		}

		/// <summary>
		/// When Idle simply repaint
		/// </summary>
		/// <param name="ob"></param>
		/// <param name="args"></param>
		private void onIdle(object ob, System.EventArgs args)
		{
			this.Invalidate();
		}

		/// <summary>
		/// For rendering, what I do is rerandomize the background image, and then
		/// recalculate the SIRDS image, which is however stored in a byte[], so I then pin
		/// that data, and wrap a Bitmap around it, which I then copy to the real backbuffer.
		/// This way, I get the safe pixel access I need, and then only use unsafe code copying
		/// the pixel data onto the screen.
		/// 
		/// For depth rendering, I do the same thing, I just pin the zbuffer, and make sure that
		/// the lower bits of the Bitmap palette are greyscale, and thats it.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void onPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			//For rendering I lock down the pixel buffer, wrap it with a bitmap
			//	(this is like making a DIB in Win32) and then copy that to the backbuffer
			//	which is then flipped after this function
			unsafe
			{
				if (!drawz)
				{
					randomizeBackground();
					calcPixelBuff();
				}

				byte[] buff = pixelbuff.Pixels;
				if (drawz)
					buff = zbuff.Pixels;
				fixed(byte* pixels = buff)
				{
					IntPtr ptr = new IntPtr( pixels );
					Bitmap bmp = (new Bitmap(Size.Width, Size.Height, Size.Width, System.Drawing.Imaging.PixelFormat.Format8bppIndexed, ptr));
					if (palette == null)
					{
						palette = bmp.Palette;
						for (int i=0; i!=MaxZ; i++)
						{
							palette.Entries[i] = System.Drawing.Color.FromArgb(i<<3, i<<3, i<<3);
						}
					}
					if (drawz)
						bmp.Palette = palette;
					e.Graphics.DrawImage( bmp, 0, 0, Size.Width, Size.Height);
				}
			}
		}
	}

	/// <summary>
	/// Used to store a 'byte image', which essentially means each
	/// pixel is represented by a single byte in memory
	/// </summary>
	class RawImage
	{
		/// <summary>
		/// Stores the actual pixel data
		/// </summary>
		private byte[] pixels;

		/// <summary>
		/// Stores the size of the image
		/// </summary>
		private Size size;

		/// <summary>
		/// Get or set the size of the image
		/// </summary>
		public Size Size
		{
			get
			{
				return size;
			}
			set
			{
				size = value;
				pixels = new byte[size.Width * size.Height];
			}
		}

		/// <summary>
		/// Gives direct access to the image data
		/// </summary>
		public byte[] Pixels
		{
			get { return pixels; }
		}

		/// <summary>
		/// Sets the pixel at the given (x,y) coordinated to the given value
		/// If the value is lower than the value already at that point, then
		/// no change is made
		/// 
		/// This function also checks to make sure that the given (x,y) point
		/// is valid so that out of bounds errors never occur
		/// </summary>
		/// <param name="x">X coordinate of point</param>
		/// <param name="y">Y coordinate of point</param>
		/// <param name="val">Value to store at that point</param>
		public void SafeZSet(int x, int y, byte val)
		{
			if ((x < 0) || (x >= Size.Width))
				return;
			if ((y < 0) || (y >= Size.Height))
				return;
			int p = x + y*size.Width;
			if (pixels[p] < val)
				pixels[p] = val;
		}

		/// <summary>
		/// Sets the pixel at the given (x,y) coordinated to the given value
		/// 
		/// This function also checks to make sure that the given (x,y) point
		/// is valid so that out of bounds errors never occur
		/// </summary>
		/// <param name="x">X coordinate of point</param>
		/// <param name="y">Y coordinate of point</param>
		/// <param name="val">Value to store at that point</param>
		public void SafeSet(int x, int y, byte val)
		{
			if ((x < 0) || (x >= Size.Width))
				return;
			if ((y < 0) || (y >= Size.Height))
				return;
			SetPixel(x,y,val);
		}

		/// <summary>
		/// Sets the pixel at the given (x,y) coordinated to the given value
		/// 
		/// No bound checking is performed
		/// </summary>
		/// <param name="x">X coordinate of point</param>
		/// <param name="y">Y coordinate of point</param>
		/// <param name="val">Value to store at that point</param>
		public void SetPixel(int x, int y, byte val)
		{
			pixels[x+(y*size.Width)] = val;
		}

		/// <summary>
		/// Returns the value of the image at the given point
		/// </summary>
		/// <param name="x">X coordinate of point</param>
		/// <param name="y">Y coordinate of point</param>
		/// <returns></returns>
		public byte GetPixel(int x, int y)
		{
			return pixels[ x+(y*size.Width) ];
		}

		/// <summary>
		/// Create the image at a given size
		/// </summary>
		/// <param name="asize">Size to create image at</param>
		public RawImage(Size asize)
		{
			Size = asize;
		}

		/// <summary>
		/// Create a new image with size (0,0)
		/// </summary>
		public RawImage()
		{
			size.Width = 0;
			size.Height = 0;
			pixels = new byte[0];
		}
	}
}
