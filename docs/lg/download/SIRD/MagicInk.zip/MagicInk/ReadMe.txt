Just run MagicInk.exe and thats it!

If when you run the program you get an error, try going to windowsupdate.microsoft.com, and making sure you have the .Net Framework and the fairly recently update which allows you to view Windows Journal files (*.jnt files). If you have both of these and MagicInk still isn't working, give me send me an email at lewey@ufl.edu, I probably can't solve your problem but I'd be interested to hear it.

Send any questions, comments, thanks, money, free hardware, job offers, frequent flier miles, etc. to lewey@ufl.edu
	-Lewey Geselowitz