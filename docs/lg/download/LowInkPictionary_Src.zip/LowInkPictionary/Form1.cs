using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Microsoft.Ink;

namespace LowInkPictionary
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private InkCollector ic;
		private MyProgressBar mpb;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.MenuItem menuItem1;
		private System.Windows.Forms.MenuItem menuItem2;
		private System.Windows.Forms.MenuItem menuItem3;
		private System.Windows.Forms.MenuItem menuItem4;
		private System.Windows.Forms.MenuItem menuItem5;
		private System.Windows.Forms.MenuItem menuItem6;
		private System.Windows.Forms.MenuItem menuItem7;
		private System.Windows.Forms.MenuItem menuItem8;
		private System.Windows.Forms.MenuItem menuItem9;
		private System.Windows.Forms.MenuItem menuItem10;
		private System.Windows.Forms.MenuItem menuItem11;
		private System.Windows.Forms.MenuItem menuItem12;
		private System.Windows.Forms.MenuItem menuItem13;
		private System.Windows.Forms.MenuItem menuItem14;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			ic = new InkCollector(this.groupBox1.Handle);

			ic.DefaultDrawingAttributes.AntiAliased = true;
			ic.DefaultDrawingAttributes.IgnorePressure = false;
			ic.DefaultDrawingAttributes.FitToCurve = true;

			ic.Stroke += new InkCollectorStrokeEventHandler(onStroke);
			ic.NewPackets += new InkCollectorNewPacketsEventHandler( onNewPackets );

			ic.Enabled = true;


			mpb = new MyProgressBar();
			mpb.Size = new System.Drawing.Size(256, 24);
			mpb.Location = new System.Drawing.Point(64, 8);
			mpb.Parent = this;
			mpb.Min = 0;
			mpb.Max = 1.0;

			menuItem5_Click(null, null);
		}

		private double Dist(Point one, Point two)
		{
			double dx = one.X - two.X;
			double dy = one.Y - two.Y;
			return Math.Sqrt( (dx*dx) + (dy*dy) );
		}

		private void updateInkLength()
		{
			mpb.Value = (InkLength / InkMax);
		}

		private double InkLength = 0;
		private double InkMax = 15000.0;
		private int nextpacketindex = 0;

		private void onNewPackets(object sender, InkCollectorNewPacketsEventArgs e)
		{
			Point last, cur;
			int len = e.Stroke.GetPoints().Length;

			if (nextpacketindex==0)
				last = e.Stroke.GetPoint(0);
			else
				last = e.Stroke.GetPoint(nextpacketindex-1);

			for (int i=nextpacketindex; i<len; i++)
			{
				cur = e.Stroke.GetPoint(i);
				InkLength += Dist(last, cur);
				last = cur;
			}

			nextpacketindex = len;

			updateInkLength();
		}

		private void onStroke(object sender, Microsoft.Ink.InkCollectorStrokeEventArgs e)
		{
			nextpacketindex = 0;
			if (InkLength > InkMax)
			{
				ic.Enabled = false;
				InkLength = 0;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button1 = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.menuItem7 = new System.Windows.Forms.MenuItem();
			this.menuItem11 = new System.Windows.Forms.MenuItem();
			this.menuItem12 = new System.Windows.Forms.MenuItem();
			this.menuItem3 = new System.Windows.Forms.MenuItem();
			this.menuItem4 = new System.Windows.Forms.MenuItem();
			this.menuItem5 = new System.Windows.Forms.MenuItem();
			this.menuItem6 = new System.Windows.Forms.MenuItem();
			this.menuItem13 = new System.Windows.Forms.MenuItem();
			this.menuItem8 = new System.Windows.Forms.MenuItem();
			this.menuItem14 = new System.Windows.Forms.MenuItem();
			this.menuItem10 = new System.Windows.Forms.MenuItem();
			this.menuItem9 = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(8, 48);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(432, 312);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Draw Here:";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(360, 8);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(72, 24);
			this.button1.TabIndex = 2;
			this.button1.Text = "New";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(48, 24);
			this.label2.TabIndex = 3;
			this.label2.Text = "Ink Left:";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem1,
																					  this.menuItem11,
																					  this.menuItem3,
																					  this.menuItem8});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem2,
																					  this.menuItem7});
			this.menuItem1.Text = "Game";
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 0;
			this.menuItem2.Text = "New";
			this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
			// 
			// menuItem7
			// 
			this.menuItem7.Index = 1;
			this.menuItem7.Text = "Exit";
			this.menuItem7.Click += new System.EventHandler(this.menuItem7_Click);
			// 
			// menuItem11
			// 
			this.menuItem11.Index = 1;
			this.menuItem11.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					   this.menuItem12});
			this.menuItem11.Text = "Edit";
			// 
			// menuItem12
			// 
			this.menuItem12.Index = 0;
			this.menuItem12.Text = "Copy";
			this.menuItem12.Click += new System.EventHandler(this.menuItem12_Click);
			// 
			// menuItem3
			// 
			this.menuItem3.Index = 2;
			this.menuItem3.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem4,
																					  this.menuItem5,
																					  this.menuItem6,
																					  this.menuItem13});
			this.menuItem3.Text = "Amount of Ink";
			// 
			// menuItem4
			// 
			this.menuItem4.Index = 0;
			this.menuItem4.Text = "Low";
			this.menuItem4.Click += new System.EventHandler(this.menuItem4_Click);
			// 
			// menuItem5
			// 
			this.menuItem5.Index = 1;
			this.menuItem5.Text = "Medium";
			this.menuItem5.Click += new System.EventHandler(this.menuItem5_Click);
			// 
			// menuItem6
			// 
			this.menuItem6.Index = 2;
			this.menuItem6.Text = "High";
			this.menuItem6.Click += new System.EventHandler(this.menuItem6_Click);
			// 
			// menuItem13
			// 
			this.menuItem13.Index = 3;
			this.menuItem13.Text = "Set Max to Amount Currently Used";
			this.menuItem13.Click += new System.EventHandler(this.menuItem13_Click);
			// 
			// menuItem8
			// 
			this.menuItem8.Index = 3;
			this.menuItem8.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.menuItem14,
																					  this.menuItem10,
																					  this.menuItem9});
			this.menuItem8.Text = "Help";
			// 
			// menuItem14
			// 
			this.menuItem14.Index = 0;
			this.menuItem14.Text = "Contest Rules";
			this.menuItem14.Click += new System.EventHandler(this.menuItem14_Click);
			// 
			// menuItem10
			// 
			this.menuItem10.Index = 1;
			this.menuItem10.Text = "Help";
			this.menuItem10.Click += new System.EventHandler(this.menuItem10_Click);
			// 
			// menuItem9
			// 
			this.menuItem9.Index = 2;
			this.menuItem9.Text = "About";
			this.menuItem9.Click += new System.EventHandler(this.menuItem9_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(448, 374);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.groupBox1,
																		  this.label2,
																		  this.button1});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "Low Ink Pictionary";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void NewGame()
		{
			InkLength = 0;
			ic.Ink.DeleteStrokes();
			ic.Enabled = true;
			updateInkLength();
			Invalidate(true);
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			NewGame();
		}

		private void correctChecks(MenuItem checkthis)
		{
			menuItem4.Checked = false;
			menuItem5.Checked = false;
			menuItem6.Checked = false;
			menuItem13.Checked = false;

			checkthis.Checked = true;
		}

		private void menuItem2_Click(object sender, System.EventArgs e)
		{
			NewGame();
		}

		private void menuItem4_Click(object sender, System.EventArgs e)
		{
			InkMax = 5000;
			NewGame();
			correctChecks(menuItem4);
		}

		private void menuItem5_Click(object sender, System.EventArgs e)
		{
			InkMax = 15000;
			NewGame();
			correctChecks(menuItem5);
		}

		private void menuItem6_Click(object sender, System.EventArgs e)
		{
			InkMax = 25000;
			NewGame();
			correctChecks(menuItem6);
		}

		private void menuItem7_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}

		private void menuItem8_Click(object sender, System.EventArgs e)
		{
		
		}

		private void menuItem9_Click(object sender, System.EventArgs e)
		{
			string str = "Low Ink Pictionary";
			str += "\nWritten by Lewey Geselowitz";
			str += "\n\nI hope you like my little app here, give me a yell if you do";
			str += "\n  -Lewey - lewey@ufl.edu";
			str += "\n\nI and this program am in no way associated with the Milton Bradly";
			str += "\ncompany or their really cool game Pictionary. I merely recomend this";
			str += "\nprogram as an interesting addition to their game.";
			str += "\n\nMy Homepage: http://plaza.ufl.edu/lewey";
			str += "\nProject Homepage: http://plaza.ufl.edu/download/lowink.html";
			MessageBox.Show(this, str, "Low Ink Pictionary - About");
		}

		private void menuItem10_Click(object sender, System.EventArgs e)
		{
			string str = "As you draw in the box, the amount of 'ink' you have";
			str += "\nwill decrease, try and draw the object that you are asked to";
			str += "\nwith your limited amount of ink. If your ink amount goes into the red";
			str += "\nstop immediatly.";
			MessageBox.Show(this, str, "Low Ink Pictionary - Help");
		}

		private void menuItem12_Click(object sender, System.EventArgs e)
		{
			InkClipboardFormats formats = new InkClipboardFormats();
			formats |= InkClipboardFormats.InkSerializedFormat;
			formats |= InkClipboardFormats.Metafile;
			formats |= InkClipboardFormats.EnhancedMetafile;
			formats |= InkClipboardFormats.Bitmap;
			formats |= InkClipboardFormats.SketchInk;
			formats |= InkClipboardFormats.TextInk;
			ic.Ink.ClipboardCopy(ic.Ink.Strokes,formats, Microsoft.Ink.InkClipboardModes.Copy);
		}

		private void menuItem13_Click(object sender, System.EventArgs e)
		{
			InkMax = InkLength;
			NewGame();
			correctChecks(menuItem13);
		}

		private void menuItem14_Click(object sender, System.EventArgs e)
		{
			string str = "Contest Mode Rules:";
			str += "\nPlay by normal Pictionary rules, however as each round starts,";
			str += "\nset the Amount of Ink to 'High' and play that picture.";
			str += "\nOnce you are done, select 'Set Max to Amount Currently Used'";
			str += "\nthis way the other team has to draw their picture using the";
			str += "\nsame amount of Ink you did.";
			str += "\nIf the one team doesn't get the picture in enough time or ink,";
			str += "\nthe other team gets to set the ink level for the next round.";
			str += "\n\nEnjoy!";
			MessageBox.Show(this, str, "Contest Rules");
		}
	}

	public class MyProgressBar : System.Windows.Forms.Control
	{
		private double min, max, cur;

		public MyProgressBar()
		{
			min = 0.0;
			max = 1.0;
			cur = 0.0;

			this.SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			this.Paint += new System.Windows.Forms.PaintEventHandler(this.onPaint);
		}

		private void onPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{

			double val = ((cur-min)/(max-min));

			if (val < 1.0)
			{
				e.Graphics.FillRectangle( System.Drawing.Brushes.White, e.ClipRectangle );
				e.Graphics.FillRectangle( System.Drawing.Brushes.Black, 0, Size.Height/4, (int)(((double)Size.Width)*(1.0-val)), Size.Height/2);
			}
			if (val >= 1.0)
			{
				e.Graphics.FillRectangle( System.Drawing.Brushes.LightPink, e.ClipRectangle );
				val -= 1.0;
				e.Graphics.FillRectangle( System.Drawing.Brushes.Red, 0, 0, (int)(((double)Size.Width)*val), Size.Height-1);
			}

			Rectangle rect = System.Drawing.Rectangle.FromLTRB(0, 0, Size.Width-1, Size.Height-1);
			e.Graphics.DrawRectangle( System.Drawing.Pens.Black, rect );
		}

		public double Min
		{
			get { return min; }
			set { min = value; update(); }
		}

		public double Max
		{
			get { return max; }
			set { max = value; update(); }
		}

		public double Value
		{
			get { return cur; }
			set { cur = value; update(); }
		}

		private void update()
		{
			Invalidate();
		}
	}
}
