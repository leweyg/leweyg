Check out my website for the info on this program, or look in the Help and About section of the program.

Written by Lewey Geselowitz
lewey@ufl.edu
http://plaza.ufl.edu/lewey