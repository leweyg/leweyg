// LewCheck.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <fstream.h>
#include <shellapi.h>
#include <commdlg.h>

HINSTANCE hInst;
HWND MainDlg;

char CurDir[MAX_PATH];
char CurFileName[MAX_PATH];

#define FileType_Executables	1
#define FileType_All			2
#define FileType_Input			3

void GetOpenFile(int filetype)
{
	OPENFILENAME of;
	of.lStructSize=sizeof(OPENFILENAME);
	of.hwndOwner=NULL;
	of.hInstance=hInst;
	if (filetype == FileType_Executables)
		of.lpstrFilter="Executables (.EXE)\000 *.exe\000All Files (*.*)\000 *.*\000\000";
	if (filetype == FileType_Input)
		of.lpstrFilter="Input Files (.INP)\000 *.inp\000Text Files (.TXT)\000 *.txt\000All Files (*.*)\000 *.*\000\000";
	if (filetype == FileType_All)
		of.lpstrFilter="All Files (*.*)\000 *.*\000\000";
	of.lpstrCustomFilter=NULL;
	of.nMaxCustFilter=0;
	of.nFilterIndex=0;
	of.lpstrFile=CurFileName;
	of.nMaxFile=MAX_PATH;
	of.lpstrFileTitle=NULL;
	of.nMaxFileTitle=0;
	of.lpstrInitialDir=".";
	of.lpstrTitle=NULL;
	of.Flags=OFN_HIDEREADONLY;
	of.nFileOffset=0;
	of.nFileExtension=0;
	of.lpstrDefExt=NULL;
	of.lCustData=0;
	of.lpfnHook=NULL;
	of.lpTemplateName=NULL;
	if (!GetOpenFileName(&of))
		CurFileName[0]=0;
}

void Compare()
{
	char input[MAX_PATH];
	char student[MAX_PATH];
	char example[MAX_PATH];

	GetDlgItemText(MainDlg, IDC_FileName_Input, input, MAX_PATH);
	GetDlgItemText(MainDlg, IDC_FileName_Student, student, MAX_PATH);
	GetDlgItemText(MainDlg, IDC_FileName_Example, example, MAX_PATH);

	SetCurrentDirectory(CurDir);
	ofstream fout("quickcompare.bat");

	if (SendDlgItemMessage(MainDlg,IDC_Main_SafeCheck,BM_GETCHECK,0,0)!=0)
	{
		fout << '"' << example << "\" < \"" << input << "\"" << endl;
		fout << '"' << student << "\" < \"" << input << "\"" << endl;
		fout << endl;
		fout << "@echo Output will now be routed to files for comparison" << endl;
	}

	fout << "@echo Creating example output..." << endl;
	fout << '"' << example << "\" < \"" << input << "\" > example_out.txt" << endl;
	fout << "@echo Creating your output..." << endl;
	fout << '"' << student << "\" < \"" << input << "\" > student_out.txt" << endl;
	fout << "fc example_out.txt student_out.txt > compare_out.txt" << endl;
	fout << "notepad compare_out.txt" << endl;

	fout.close();
	ShellExecute(0, "open", "quickcompare.bat", 0, 0, SW_SHOWNORMAL);
}

LRESULT CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
			case IDCANCEL:
				EndDialog(hDlg, LOWORD(wParam));
				return TRUE;
				break;
			}
			break;
	}
    return FALSE;
}

void NewInputFile()
{
	ofstream fout("input.inp");
	fout.close();
	SetDlgItemText(MainDlg, IDC_FileName_Input, "input.inp");
	ShellExecute(0, "open", "Notepad", "input.inp", 0, SW_SHOWNORMAL);
}

LRESULT CALLBACK MainProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			GetCurrentDirectory(MAX_PATH, CurDir);
			MainDlg = hDlg;
			SendDlgItemMessage(hDlg,IDC_Main_SafeCheck,BM_CLICK,1,1); 
			return TRUE;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
				Compare();
				break;
			case IDC_Browse_Input:
				GetOpenFile(FileType_Input);
				if (CurFileName[0])
					SetDlgItemText(hDlg, IDC_FileName_Input, CurFileName);
				break;
			case IDC_Browse_Student:
				GetOpenFile(FileType_Executables);
				if (CurFileName[0])
					SetDlgItemText(hDlg, IDC_FileName_Student, CurFileName);
				break;
			case IDC_Browse_Example:
				GetOpenFile(FileType_Executables);
				if (CurFileName[0])
					SetDlgItemText(hDlg, IDC_FileName_Example, CurFileName);
				break;
			case ID_HELP_HOWTOUSEIT:
				DialogBox(hInst, (LPCTSTR)IDD_Help, hDlg, (DLGPROC)AboutProc);
				break;
			case ID_HELP_ABOUT:
				DialogBox(hInst, (LPCTSTR)IDD_About, hDlg, (DLGPROC)AboutProc);
				break;
			case ID_FILE_NEWINPUTFILE:
				NewInputFile();
				break;
			case ID_FILE_EDITINPUTFILE:
				GetDlgItemText(hDlg, IDC_FileName_Input, CurFileName, MAX_PATH);
				ShellExecute(0, "open", "Notepad", CurFileName, 0, SW_SHOWNORMAL);
				break;
			case ID_FILE_RUNSTUDENTPROGRAM:
				GetDlgItemText(hDlg, IDC_FileName_Student, CurFileName, MAX_PATH);
				ShellExecute(0, "open", CurFileName, 0, 0, SW_SHOWNORMAL);
				break;
			case ID_FILE_RUNEXAMPLEPROGRAM:
				GetDlgItemText(hDlg, IDC_FileName_Example, CurFileName, MAX_PATH);
				ShellExecute(0, "open", CurFileName, 0, 0, SW_SHOWNORMAL);
				break;
			case ID_FILE_EXIT:
			case IDCANCEL:
				EndDialog(hDlg, IDCANCEL);
				return TRUE;
				break;
			}
			break;
	}
    return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	hInst = hInstance;

	DialogBox(hInst, (LPCTSTR)IDD_MainDlg, 0, (DLGPROC)MainProc);

	return 0;
}



