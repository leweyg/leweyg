//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LewCheck.rc
//
#define IDD_MainDlg                     101
#define IDR_MENU1                       102
#define IDD_Help                        103
#define IDD_About                       104
#define IDI_ICON1                       105
#define IDC_FileName_Input              1000
#define IDC_Browse_Input                1001
#define IDC_FileName_Student            1002
#define IDC_Browse_Student              1003
#define IDC_FileName_Example            1004
#define IDC_Browse_Example              1005
#define IDC_Main_SafeCheck              1006
#define ID_FILE_EXIT                    40001
#define ID_HELP_HOWTOUSEIT              40002
#define ID_HELP_ABOUT                   40003
#define ID_FILE_NEWINPUTFILE            40005
#define ID_FILE_EDITINPUTFILE           40006
#define ID_FILE_RUNSTUDENTPROGRAM       40007
#define ID_FILE_RUNEXAMPLEPROGRAM       40008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40009
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
