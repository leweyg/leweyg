//using namespace std;

#ifndef HasSeed
#define HasSeed

//This program is here just out of my shear lazyness, as long as you include this file, you will
//	get a different seed value (for rand()) each time you execute your program.
//No need to do anything other than include this file

bool SetSeed()
{
	unsigned int var;
	ifstream fin("random.txt");
	if (!fin)
	{
		ofstream fout("random.txt");
		if (!fout)
			return 0;
		fout << 0;
		fout.close();
		var=0;
		srand(var);
		return 1;
	}
	else
	{
		fin >> var;
		var++;
		if (var>1000000)
			var=0;
		srand(var);
		fin.close();
		ofstream fout2("random.txt");
		if (!fout2)
			return 0;
		fout2 << var;
		fout2.close();
	}
	return 1;
}

class SeedSetter
{
public:
	bool IsSet;
	SeedSetter() {IsSet=SetSeed();short num; num=rand();};
};

SeedSetter SeedSet;

#endif