//using namespace std;

//TArray (Twin Array) is exactly like (and written from) DArray, but two values in each cell
//	(Val <X>, and Other <Y>)
//
//It however lacks certain functions which returned individual members.

#ifndef HasTArray
#define HasTArray

template <class X, class Y> struct TAMem
{
	TAMem<X,Y> * Next, * Prev;

	X Val;
	Y Other;

	TAMem<X,Y>() {Next=0; Prev=0;};
};

template <class X, class Y> class TArray
{
public:
	TAMem<X,Y> * Base, * Last;

	void DelAll();

	TAMem<X,Y> * AddCell();
	TAMem<X,Y> * AddCell(TAMem<X,Y> * after);
	TAMem<X,Y> * AddBefore(TAMem<X,Y> * before);
	TAMem<X,Y> * AxsCell(int num);
	void DelCell(TAMem<X,Y> * work);
	void DelMember(int num) {DelCell(AxsCell(num));};
	void Switch(TAMem<X,Y> * one, TAMem<X,Y> * two);
	int GetLength();
	void RemoveCell(TAMem<X,Y> * one);
	void InsertCell(TAMem<X,Y> * cell, TAMem<X,Y> * before);
	void InsertAfter(TAMem<X,Y> * cell, TAMem<X,Y> * before);

	TAMem<X,Y> * AddTop() {return AddCell();};
	TAMem<X,Y> * AddBottom();
	void DelTop();
	void DelBottom();

	TArray() {Base=0; Last=0;};
	~TArray() {DelAll();};
};

template <class X, class Y> void TArray<X,Y>::InsertAfter(TAMem<X,Y>*cell, TAMem<X,Y>*before)
{
	if (!Base)
	{
		Base=cell;
		Last=cell;
		cell->Next=0;
		cell->Prev=0;
		return;
	}
	if (!before)
	{
		cell->Next=Base;
		cell->Prev=0;
		Base->Prev=cell;
		Base=cell;
		return;
	}
	cell->Next=before->Next;
	cell->Prev=before;
	before->Next=cell;
	if (!cell->Next)
		Last=cell;
	else
		cell->Next->Prev=cell;
}

template <class X, class Y> TAMem<X,Y> * TArray<X,Y>::AddBefore(TAMem<X,Y> * before)
{
	if ((!Base) || (!before))
		return AddCell();
	TAMem<X,Y> *work=new TAMem<X,Y>;
	if (before->Prev)
		before->Prev->Next=work;
	else
		Base=work;
	work->Next=before;
	work->Prev=before->Prev;
	before->Prev=work;
	return work;
}

template <class X, class Y> TAMem<X,Y> * TArray<X,Y>::AddCell(TAMem<X,Y> * after)
{
	if ((!Base) || (!after))
		return AddCell();
	TAMem<X,Y> * work=new TAMem<X,Y>;
	if (after->Next)
		after->Next->Prev=work;
	else
		Last=work;
	work->Prev=after;
	work->Next=after->Next;
	after->Next=work;
	return work;
}

template <class X, class Y> void TArray<X,Y>::InsertCell(TAMem<X,Y> * cell, TAMem<X,Y> * before)
{
	//give cell, then cell infront (or 0 for the new cell at the end
	//	of the list)
	if (!Base)
	{
		cell->Prev=0;
		cell->Next=0;
		Base=cell;
		Last=cell;
		return;
	}
	if (!before)
	{
		Last->Next=cell;
		cell->Prev=Last;
		cell->Next=0;
		Last=cell;
		return;
	}
	if (before->Prev)
		before->Prev->Next=cell;
	else
		Base=cell;
	cell->Prev=before->Prev;
	cell->Next=before;
	before->Prev=cell;
}

template <class X, class Y> void TArray<X,Y>::RemoveCell(TAMem<X,Y> * work)
{
	//removes from list, but doesn't delete
	if (!work)
		return;
	if (work==Base)
		Base=work->Next;
	if (work==Last)
		Last=work->Prev;
	if (work->Next)
		work->Next->Prev=work->Prev;
	if (work->Prev)
		work->Prev->Next=work->Next;
}

template <class X, class Y> void TArray<X,Y>::Switch(TAMem<X,Y> * one, TAMem<X,Y> * two)
{
	//Switchs the two (must be in this list)
	if (((!one) || (!two)) || (one==two))
		return;
	TAMem<X,Y> * work;

	work=one->Next;
	one->Next=two->Next;
	two->Next=work;
	if (two->Next)
		two->Next->Prev=two;
	else
		Last=two;
	if (one->Next)
		one->Next->Prev=one;
	else
		Last=one;

	work=one->Prev;
	one->Prev=two->Prev;
	two->Prev=work;
	if (two->Prev)
		two->Prev->Next=two;
	else
		Base=two;
	if (one->Prev)
		one->Prev->Next=one;
	else
		Base=one;

}

template <class X, class Y> void TArray<X,Y>::DelBottom()
{
	//deletes bottom cell
	if (!Base)
		return;
	TAMem<X,Y> * work=Base;
	if (work->Next)
	{
		Base=work->Next;
		Base->Prev=0;
	}
	else
	{
		Base=0;
		Last=0;
	}
	delete work;
}

template <class X, class Y> void TArray<X,Y>::DelTop()
{
	//deletes top
	if (!Last)
		return;
	TAMem<X,Y> * work=Last;
	if (work->Prev)
	{
		Last=work->Prev;
		Last->Next=0;
	}
	else
	{
		Last=0;
		Base=0;
	}
	delete work;
}

template <class X, class Y> TAMem<X,Y> * TArray<X,Y>::AddBottom()
{
	//adds new one at bottom of list
	TAMem<X,Y> * work=new TAMem<X,Y>;
	if (!Base)
	{
		Base=work; Last=work;
		work->Next=0;
		work->Prev=0;
		return work;
	}
	work->Next=Base;
	work->Prev=0;
	Base=work;
	return work;
}

template <class X, class Y> int TArray<X,Y>::GetLength()
{
	//returns the number of members in list
	TAMem<X,Y> * work=Base;
	int len=0;
	while (work)
	{
		work=work->Next;
		len++;
	}
	return len;
}

template <class X, class Y> void TArray<X,Y>::DelCell(TAMem<X,Y> * work)
{
	//deletes a cell
	if (!work)
		return;
	if (work==Base)
		Base=work->Next;
	if (work==Last)
		Last=work->Prev;
	if (work->Next)
		work->Next->Prev=work->Prev;
	if (work->Prev)
		work->Prev->Next=work->Next;
	delete work;
}

template <class X, class Y> TAMem<X,Y> * AxsCell(int num)
{
	//gets a cell from the list
	TAMem<X,Y> * work=Base;
	while ((num>0) && (work))
	{
		work=work->Next;
		num--;
	}
	return work;
}

template <class X, class Y> TAMem<X,Y> * TArray<X,Y>::AddCell()
{
	//adds a cell to the top of the list
	TAMem<X,Y> * work;
	work=new TAMem<X,Y>;
	if (!Base)
	{
		Base=work; Last=work;
		work->Next=0;
		work->Prev=0;
		return work;
	}
	Last->Next=work;
	work->Next=0;
	work->Prev=Last;
	Last=work;
	return work;
}

template <class X, class Y> void TArray<X,Y>::DelAll()
{
	//deletes all cells
	TAMem<X,Y> * next=Base, * work;
	while (next)
	{
		work=next;
		next=next->Next;
		delete work;
	}
	Base=0; Last=0;
}


#endif