//#include <iostream>
//#include <fstream>
//using namespace std;

#ifndef HasStr2
#define HasStr2

#include <math.h>
#include <stdio.h>

//The new Str string class (4-30-2001), similar to the old Str class
//	but is more "global function based", using a series of global 
//	string functions the are mixed in with the code.
//
//the class is total dynamic not wasting any space and uses pointer
//	movement to enhance speed
//
//The number of decimal values after the period can be
//	set by giving a value to MaxTextDigits, if it is -1
//	then the max is 50. The absolute max will allways be 50
//
//Remember: the number leans toward the highest side (i.e. -1 means
//	the one on the left was higher.
//
//The list of member functions can be found in the class declaration,
//	but here is a list of global functions:
//
//CONSOLE APPS: Make sure to include the operator overload functoins
//	for cin and cout.
//
//	int FindLet(char *, char) - finds a character in a string
//	char * FromDigit(int) - returns string of that number
//	int GetDigit(int,int2) - return the int2th digit of int
//	int GetNumDigits(int)
//	int GetSize(char *) - returns the size of string
//	bool IsNumber(char *)
//	bool IsNumber_Float(char *)
//	char * MakeCopy(char *) - copies a string
//	int TenToThe(int) - returns 10^arg
//	int ToNumber(char *) - returns a number for the string
//	float ToNumber_Float(char *) - returns a float for the string

/*
//Include the 2 below function for use int console apps

inline istream operator >> (istream & cin2, Str & st)
{
	char buff[MaxOIBufferSize];
	cin2 >> buff;
	st=buff;
	return cin2;
}

inline ostream operator << (ostream & cout2, Str & st)
{
	cout2 << st.word;
	return cout2;
}

inline ifstream operator >> (ifstream & fin2, Str & st)
{
	char buff[MaxOIBufferSize];
	fin2 >> buff;
	if (fin2.good())
		st=buff;
	return fin2;
}

inline ofstream operator << (ofstream & fout2, Str & st)
{
	fout2 << st.word;
	return fout2;
}
*/

#define MaxOIBufferSize 100
#define MaxIOBufferSize 100
int MaxLengthAfterPeriod=6;
int MaxTextDigits=-1;
bool ZeroBeforePeriod=1;

void CopyBits(char * from, char * to, int fs, int ts, int len)
{
	from += fs;
	to += ts;
	while (len > 0)
	{
		*to = *from;
		from++; to++;
		len--;
	}
}

int GetSize(char * other)
{
	int num=0;
	while (*other != 0)
	{
		num++;
		other++;
	}
	return num+1;
}

void PasteOnto(char * from, char * to, int sf, int st)
{
	from += sf;
	to += st;
	while (*from)
	{
		*to = *from;
		to++; from++;
	}
}

void JustCopy(char * from, char * to)
{
	while (*from)
	{
		*to = *from;
		to++; from++;
	}
	*to=0;
}

#define IsEqual_NoCase IsEqual_NC
#define IsEqualNoCase IsEqual_NC

//#define NoCaseComp(a,b) ((((a)^(b))&(0x1F))!=0)
bool NoCaseComp(char one, char two)
{
	if ((one>='A') && (one <='Z'))
		one -= ('A' - 'a');
	if ((two>='A') && (two <='Z'))
		two -= ('A' - 'a');
	return (one == two);
}
	//1=equal 0=not

bool IsEqual(char * one, char * two)
{
	while (*one)
	{
		if (*one != *two)
			return 0;
		one++; two++;
	}
	if (*one != *two)
		return 0;
	return 1;
}

bool LetIsNumber(char let)
{
	return ((let >= '0') && (let <= '9'));
}

void ReplaceBackSlashValues(char * text)
{
	int from=0, to=0;
	while (text[from])
	{
		if (text[from]=='\\')
		{
			switch (text[from+1])
			{
			case '\\':
				text[to]='\\';
				break;
			case 'n':
				text[to]='\n';
				break;
			case 't':
				text[to]='\t';
				break;
			case '"':
				text[to]='"';
				break;
			default:
				text[to]=text[from+1];
				break;
			}
			from++;
		}
		else
			text[to]=text[from];
		from++;
		to++;
	}
	text[to]=0;
}

bool IsEqual_NC(char * one, char * two)
{
	while (*one)
	{
		if (!NoCaseComp(*one,*two))
			return 0;
		one++; two++;
	}
	if (*two)
		return 0;
	return 1;
}

char * MakeCopy(char * other)
{
	int len=GetSize(other);
	char * ans=new char [len];
	char * work=ans;

	while (*other)
	{
		*work = *other;
		other++;
		work++;
	}
	*work=0;
	return ans;
}

int TenToThe(int num)
{
	int ans=1;
	while (num > 0)
	{
		ans *= 10;
		num--;
	}
	return ans;
}

int FindLet(char * other, char let)
{
	int num=0;
	while (*other)
	{
		if (*other == let)
			return num;
		num++;
		other++;
	}
	return -1;
}

int ToNumber(char * other)
{
	bool isneg=0;
	if (*other=='-')
	{
		isneg=1;
		other++;
	}
	int ans = 0;
	while (*other)
	{
		ans *= 10;
		ans += (*other - '0');
		other++;
	}
	return ans;
/*	int ten = GetSize(other)-2;
	ten=TenToThe(ten);
	int ans=0;
	while (*other)
	{
		ans += ((*other - '0') * ten);
		ten /= 10;
		other++;
	}
	if (isneg)
		ans *= -1;
	return ans; */
}

double ToNumber_Float(char * other)
{
	double ten = FindLet(other,'.')-1;
	if (ten==-2)
		return (double)ToNumber(other);

	bool isneg=0;
	if (*other=='-')
	{
		isneg=1;
		other++;
		ten--;
	}
	ten=TenToThe(ten);
	if (*other == '.')
		ten = 0.1;
	double ans=0;
	while (*other)
	{
		if (*other != '.')
		{
			ans += ((*other - '0') * ten);
			ten /= 10;
		}
		other++;
	}
	if (isneg)
		ans *= -1;
	return ans;
}

int GetDigit(int num, int dig)
{
	dig=TenToThe(dig) * 10;
	num %= dig;
	dig /= 10;
	num -= (num % dig);
	num /= dig;
	return num;
}

int GetNumDigits(int num)
{
	int ten=9, len=1;
	while (ten <= num)
	{
		ten *= 10;
		len++;
	}
	len--;
	return len;
}

char * FromUnNumber(unsigned int num)
{
	char * ans;
	if (num==0)
	{
		ans=new char [2];
		ans[0]='0';
		ans[1]=0;
		return ans;
	}
	int len=1, m;
	while (TenToThe(len) < num)
		len++;
	ans=new char [len+1];
	ans[len-1]=0;
	ans[len]=0;
	int i=0;
	while (num != 0)
	{
		m=(num % 10);
		ans[i]=(m + '0');
		i++;
		num -= m;
		num /= 10;
	}
	char c;
	for (i=0; i < len/2; i++)
	{
		c=ans[i];
		ans[i]=ans[len-i-1];
		ans[len-i-1]=c;
	}
	return ans;
}

char * FromNumber(int num)
{
	if (num==0)
		return MakeCopy("0");
	int work;
	char buff[50];
	if (((abs(num)==10) || (abs(num)==100)) || (abs(num)==1000))
	{
		work=0;
		if (num < 0)
		{
			buff[work]='-';
			work++;
			num *= -1;
		}
		buff[work]='1';
		work++;
		while (num != 1)
		{
			buff[work]='0';
			work++;
			num /= 10;
		}
		buff[work]=0;
		return MakeCopy(buff);
	}
	int isneg=0;
	if (num < 0)
	{
		isneg=1;
		num *= -1;
	}
	int mask;
	if (num==0)
	{
		buff[0]='0';
		buff[1]=0;
		return MakeCopy(buff);
	}
	int wpos=1;
	mask=10;
	while (mask < num)
	{
		mask *= 10;
		wpos++;
	}
	buff[wpos+isneg]=0;
	if (isneg==1)
		buff[0]='-';
	wpos--;
	mask=10;
	while ((mask / 100) < num)
	{
		work=(num % mask);
		num -= work;
		work /= (mask / 10);

		buff[wpos+isneg]=((char)work) + '0';
		wpos--;

		mask *= 10;
	}
	return MakeCopy(buff);
}

void FlipBytes(char * text, int len)
{
	int i=0;
	char c;
	while (i < (len/2))
	{
		c=text[i];
		text[i]=text[len-i-1];
		text[len-i-1]=c;
		i++;
	}
}

char * FromNumber_Float2(double f)
{
	char buff[50];

	bool isneg=0;
	int bp=0;
	if (f < 0)
	{
		isneg=1;
		buff[bp]='-';
		bp++;
		f*=-1;
	}
	int i, curi;
	double cur;
	i=f;
	if ((i==0) && (ZeroBeforePeriod))
	{
		buff[bp]='0';
		bp++;
	}
	while (i != 0)
	{
		curi=(i % 10);
		i-=curi;
		i/=10;
		buff[bp]=('0' + curi);
		bp++;
	}
	if (!isneg)
		FlipBytes(buff,bp);
	else
		FlipBytes(buff+1,bp-1);
	i=f;
	cur=i;
	f-=cur;
	if (f < 0.0000001)
	{
		if (bp==0)
		{
			buff[bp]='0';
			bp++;
		}
		buff[bp]=0;
		return MakeCopy(buff);
	}
	buff[bp]='.';
	bp++;
	curi=0;
	while (f>0.0000001)
	{
		f*=10;
		i=f;
		buff[bp]=('0'+i);
		bp++;
		cur=i;
		f-=cur;
		cur=0;
		if (MaxTextDigits != -1)
		{
			curi++;
			if (curi >= MaxTextDigits)
				f=0;
		}
		if (bp==48)
			f=0;
	}

	buff[bp]=0;
	return MakeCopy(buff);
}

char * FromNumber_Float(double f)
{
	bool isneg=0;
	if (f < 0)
	{
		isneg=1;
		f *= -1;
	}
	char * base=FromNumber(f);
	char ans[MaxIOBufferSize];
	int p=GetSize(base)-1;
	if (isneg)
	{
		CopyBits(base,ans,0,1,p);
		ans[0]='-';
		p++;
	}
	else
		CopyBits(base,ans,0,0,p);
	delete [] base;
	ans[p]='.';
	p++;
	unsigned int top=f;
	f-=top;
	int i=1;
	while (f > 0)
	{
		f *= 10;
		top=f;
		f -= top;
		ans[p]=('0' + top);
		p++;
		i++;
		if (i > MaxLengthAfterPeriod)
			f=0;
	}
	ans[p]=0;
	return MakeCopy(ans);
}

bool IsNumber_Float(char * work)
{
	if (*work==0)
		return 0;
	if (*work == '-')
	{
		if (*(work+1)==0)
			return 0;
		work++;
	}
	bool hasdot=0;
	while (*work)
	{
		if ((*work < '0') || (*work > '9'))
		{
			if (*work == '.')
			{
				if (hasdot)
					return 0;
				hasdot=1;
			}
			else
				return 0;
		}
		work++;
	}
	return 1;
}

bool IsNumber(char * work)
{
	if (*work == '-')
		work++;
	while (*work)
	{
		if ((*work < '0') || (*work > '9'))
				return 0;
		work++;
	}
	return 1;
}

//
// *************** The Str Class ***************
//

class Str
{
public:
	char * word;

	Str() {word=new char [1]; word[0]=0;};
	Str(char * other) {word=MakeCopy(other);};
	~Str() {delete [] word;};

//Actual functions
	void operator =(char * other) {delete [] word; word=MakeCopy(other);};
	void operator =(Str & other) {delete [] word; word=MakeCopy(other.word);};
	void operator =(int num) {delete [] word; word=FromNumber(num);};
	void operator =(double num) {delete [] word; word=FromNumber_Float2(num);};
	operator char *() {return word;};

	int Compare(char * other);
	bool operator ==(char * other);
	bool operator !=(char * other) {return !(*this==other);};
	bool operator <(char * other);
	bool operator >(char * other);
	bool operator >=(char * other) {if (Compare(other)==1) return 1; return 0;};
	bool operator <=(char * other) {if (Compare(other)==-1) return 1; return 0;};
	
	void operator += (char * other);
	void operator += (char let);
	bool operator -= (char * other);
	void GetFrag(char * other, int start, int len);
	void AddThisBefore(char * other);
	void AddThisBefore(char let);
	int Find(char * other);
	int Find(char let);
	bool Includes(char * other) {return (Find(other)!=-1);};
	bool Includes(char let) {return (Find(let)!=-1);};
	void ToLower();
	void ToUpper();
	void Fill(int len, char let);
	void ReplaceBackSlashes() {ReplaceBackSlashValues(word);};
	void RemoveQuotes();

	bool IsNum() {return IsNumber(word);};
	bool IsFloat() {return IsNumber_Float(word);};
	int   ToNum() {return ToNumber(word);};
	float ToFloat() {return ToNumber_Float(word);};

//Masks for using between Str's
	int Compare(Str & other) {return Compare(other.word);};
	int Find(Str & other) {return Find(other.word);};
	void GetFrag(Str & other, int start, int len) {GetFrag(other.word,start,len);};
	bool Includes(Str & other) {return Includes(other.word);};

	bool operator !=(Str & other) {return (*this)!=other.word;};
	bool operator ==(Str & other) {return (*this)==other.word;};
	void operator +=(Str & other) {(*this)+=other.word;};
	bool operator -=(Str & other) {(*this)-=other.word;};

	Str & operator << (char * other) {(*this)+=other; return *this;};
	Str & operator << (int i) {Str str; str=i; (*this)+=str.word; return *this;};
	Str & operator << (float f) {Str str; str=f; (*this)+=str.word; return *this;};
//	template <class X> Str & operator << (X val) {Str str; str=val; (*this)+=str.word; return *this;};

	bool operator >(Str & other) {return (*this)>other.word;};
	bool operator <(Str & other) {return (*this)<other.word;};
	bool operator >=(Str & other) {if (Compare(other.word)==1) return 1; return 0;};
	bool operator <=(Str & other) {if (Compare(other.word)==-1) return 1; return 0;};
};

void Str::RemoveQuotes()
{
	if (word[0]!='"')
		return;
	int len = GetSize(word);
	char * ans = new char [len-2];
	int i=1;
	while (word[i]!='"')
	{
		ans[i-1]=word[i];
		i++;
	}
	ans[i-1]=0;
	delete [] word;
	word = ans;
}

void Str::AddThisBefore(char let)
{
	int size = GetSize(word);
	char * work = new char [size + 1];
	JustCopy(word,work+1);
	work[0]=let;
	delete [] word;
	word=work;
}

void Str::AddThisBefore(char * other)
{
	int olen=GetSize(other), tlen=GetSize(word);
	char * ans=new char [olen + tlen - 1];
	int i;
	for (i=0; i<olen; i++)
		ans[i]=other[i];
	olen--;
	for (i=0; i < tlen; i++)
		ans[i+olen]=word[i];
	delete [] word;
	word=ans;
}

void Str::operator +=(char let)
{
	char * work=new char [GetSize(word)+1];
	char * from=word, *to=work;
	while (*from)
	{
		*to = *from;
		to++; from++;
	}
	*to = let;
	to[1]=0;
	delete [] word;
	word=work;
}

void Str::Fill(int len, char let)
{
	int tlen=GetSize(word);
	if (tlen >= len)
		return;
	char * ans=new char [len+1], * w=word;
	char * a=ans;

	while (*w)
	{
		*a = *w;
		a++; w++;
		len--;
	}

	while (len > 0)
	{
		*a = let;
		a++;
		len--;
	}
	*a=0;

	delete [] word;
	word=ans;
}

int Str::Find(char let)
{
	char * work=word;
	int num=0;
	while (*work)
	{
		if (*work == let)
			return num;
		work++;
		num++;
	}
	return -1;
}

void Str::ToUpper()
{
	char * work=word;
	while (*work)
	{
		if ((*work >= 'a') && (*work <= 'z'))
			*work += ('A' - 'a');
		work++;
	}
}

void Str::ToLower()
{
	char * work=word;
	while (*work)
	{
		if ((*work >= 'A') && (*work <= 'Z'))
			*work -= ('A' - 'a');
		work++;
	}
}

void Str::GetFrag(char * other, int start, int len)
{
	char * ans=new char [len+1];
	delete [] word;
	word=ans;

	other += start;

	while (len > 0)
	{
		*ans = *other;
		other++;
		ans++;
		len--;
	}
	*ans=0;
}

bool Str::operator -=(char * other)
{
	int pos=Find(other);
	if (pos==-1)
		return 0;
	int len=GetSize(other), tlen=GetSize(word);
	char * ans=new char [tlen - len + 1];
	char * work=ans, * b=word;

	while (*b)
	{
		if (pos==0)
		{
			b += (len-1);
			pos=-1;
		}
		else
		{
			*work = *b;
			b++;
			work++;
			pos--;
		}
	}
	*work=0;

	delete [] word;
	word=ans;

	return 1;
}

int Str::Find(char * other)
{
	int oi=0, ti=0;
	int lastti;
	while (word[ti])
	{
		if (other[oi] == word[ti])
		{
			if (oi == 0)
				lastti=ti;
			oi++;
			if (other[oi]==0)
				return lastti;
		}
		else
		{
			if (oi != 0)
				ti = lastti;
			oi=0;
		}
		ti++;
	}
	return -1;

/*	char * work=word, * keep=0, * ot=other;
	int num=0, onum;
	while (*work)
	{
		if (*work == *ot)
		{
			if (!keep)
			{
				keep=work;
				onum=num;
			}
			ot++;
		}
		else
		{
			if (keep)
			{
				num=onum-1;
				work=keep-1;
				keep=0;
				ot=other;
			}
		}
		if (!(*ot))
			return onum;
		work++;
		num++;
	}
	return -1; */
}

void Str::operator += (char * other)
{
	char * ans=new char [GetSize(word)+GetSize(other)-1];
	char * w=word, * s=ans;

	while (*w)
	{
		*ans = *w;
		ans++;
		w++;
	}
	while (*other)
	{
		*ans = *other;
		ans++;
		other++;
	}
	*ans=0;

	delete [] word;
	word=s;
}

int Str::Compare(char * other)
{
	char * ans=word;
	while ((*other == *ans) && (*ans))
	{
		other++;
		ans++;
	}
	if (*other == *ans)
		return 0;
	if (*ans < *other)
		return 1;
	return -1;
}

bool Str::operator >(char * other)
{
	char * ans=word;
	while ((*other > *ans) && (*ans))
	{
		other++;
		ans++;
	}
	if (*other > *ans)
		return 1;
	return 0;
}

bool Str::operator <(char * other)
{
	char * ans=word;
	while ((*other < *ans) && (*ans))
	{
		other++;
		ans++;
	}
	if (*other < *ans)
		return 1;
	return 0;
}

bool Str::operator ==(char * other)
{
	return IsEqual(word,other);
}

#endif
