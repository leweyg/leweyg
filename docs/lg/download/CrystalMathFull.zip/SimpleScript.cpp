//SimpleScript
//	A simplified version of Script, this class is also
//		called Script.
//	Create an instance of Script
//	Add functions with AddFunc()
//	call FromText(char*)
//	Ops with be in Script::Ops
//	Each op is the name of two argments, one answer,
//		and one function

#ifndef HasSimpleScript
#define HasSimpleScript

#include <math.h>
#include "Str2.cpp"
#include "DArray.cpp"
#include "TArray.cpp"


bool IsWhite(char let)
// returns true if let is a whitespace character
{
	switch (let)
	{
	case ' ':    // space
	case '\n':   // newline
	case '\t':   // tab
	case 0x0d:
		return true;
	default:
		return false;
	}
}


bool IsActualNumber(char let)
// returns true if let is a digit [0-9]
{
	return ((let>='0') && (let<='9'));
}


bool IsDoubleOp(char op1, char op2)
// returns true if op1+op2 constitute a "double-op" (an operator consisting of two characters)
// (and thus the sequence op1+op2 should be evaluated together rather than individually)
{
	if (op1 == op2)	// a doubled character
	{
		// check for operations consisting of an operand repeated twice
		switch (op1)
		{
		// below is the list of operands that can be doubled to form a double-op
		case '+':   // ++
		case '-':   // --
		case '&':   // &&
		case '|':   // ||
		case '=':   // ==
		case '<':   // <<
		case '>':   // >>
			return true;
		default:
			return false;
		}
	}
	else if (op2 == '=') // an operand followed by '='
	{
		switch (op1)
		{
		// below is the list of operands that form a double-op with '='
		case '<':   // <=
		case '>':   // >=
		case '!':   // !=
		case '+':   // +=
		case '-':   // -=
		case '*':   // *=
		case '/':   // /=
		case '^':   // ^=
			return true;
		default:
			return false;
		}
	}
	else	// look for special double-ops
	{
		// Right now only one such double-op, so use a simple check.
		// If more are added in the future, a more modular check might
		// enhance efficiency and readability
		if ((op1 == '-') && (op2 == '>'))   // ->
			return true;
	}

	return false;  // default; nothing above matched
}

bool IsOp(char let)
// returns true if let is an operator character
{
	switch (let)
	{
	// below is a list of all recognized operator characters
	case '.':
	case '+':
	case '-':
	case '*':
	case '^':
	case '/':
	case '<':
	case '>':
	case '!':
	case '(':
	case ')':
	case ',':
	case ';':
	case '&':
	case '|':
	case '=':
	case '[':
	case ']':
	case '{':
	case '}':
		return true;
	default:
		return false;
	}
}

bool IsLetter(char let)
// returns true if let is a letter ([a-z] or [A-Z] or '_')
{
	return ((let >= 'a') && (let <= 'z')) ||
	       ((let >= 'A') && (let <= 'Z')) ||
		   (let == '_');
}


#define NonmatchingParentheses 1
#define EmptyParentheses 2
#define NonmatchingBrackets 3
#define NonmatchingQuotes 4
#define EmptyQuotes 5
#define InputTextErrors 5   // the number of different errors above
// (and the highest value that CheckText should be able to return)

int CheckText(char *text)
/*
 Checks text for non-matching parentheses, brackets, and quotes.
 (We can add any other precompilation check we like here, 
 i.e. malformations in the input string that will prevent it 
 from being successfully compiled.)
 Returns 0 if everything is OK, otherwise returns one of the error codes
 defined above 
*/
{
	int i = 0, parens = 0, brackets = 0, quotes = 0;

	// tests for whether opened parenthesis or quotes
	// have non-whitespace between them and the closing
	bool openP = false, openQ = false;

	while ( text[i] )
	{
		switch( text[i] )
		{
		case '(':
			parens++;
			openP = true;
			openQ = false;
			break;
		case ')':
			if (parens < 1)   // a closing parenthesis not preceded by an opening one
				return NonmatchingParentheses;
			if (openP)   // nothing between an opening and closing parenthesis
				return EmptyParentheses;
			parens--;
			openQ = false;
			break;
		case '[':
			brackets++;
			openP = false;
			openQ = false;
			break;
		case ']':
			if (brackets < 1)   // a closing bracket not preceded by an opening one
				return NonmatchingBrackets;
			brackets--;
			openP = false;
			openQ = false;
			break;
		case '"':
			quotes++;
			if (openQ)   // a closing quote with nothing between it and the opening one
				return EmptyQuotes;
			openQ = ((quotes % 2) != 0);  // odd-numbered quote is an opening quote
			openP = false;
			break;
		default:
			// non-whitespace means something is between
			// an opening and closing parentheses/quote
			if ( !IsWhite(text[i]) )
			{
				openP = false;
				openQ = false;
			}
		}
		
		i++;
	}

	if (parens != 0)
		return NonmatchingParentheses;
	if (brackets != 0)
		return NonmatchingBrackets;
	if ((quotes % 2) != 0 )
		return NonmatchingQuotes;
	return 0;
}


#define IsFlag(f,m)		(((f) & (m)) != 0 )
#define FlagOn(f,m)		((f)|=(m))
#define FlagOff(f,m)	(f)&=(~(m))
#define FlagToggle(f,m)	(f)^=(m)

void ParseString(char * text, DArray<Str> * to)
// string tokenizer function, tokenizes input string *text
// and puts tokens into stack *to
{
	int i=0, start, beg;
	bool test;

	while (text[i])  // while there are more characters
	{
		beg=i;

		// parse text between quotes
		if (text[i] == '"')
		{
			start = i;
			bool quotedText = true;
			while (quotedText)
			{
				i++;
				if (text[i] == 0)   // a single quote with nothing following
				{
					i--;
					quotedText = false;
				}
				if ((text[i] == '"') && (text[i-1] != '\\'))   // make sure it's not a literal quote character (\")
				{
					quotedText = false;
				}
			}
			i++;
			to->AddMember()->GetFrag(text,start,i-start);
			if (text[i]==0)
				to->Last->Val += '"';
			to->Last->Val.ReplaceBackSlashes();
		}

		if ((IsActualNumber(text[i])) || (text[i]=='.'))
		{
			start=i;
			test=1;
			i--;
			while (test)
			{
				i++;
				if (!IsActualNumber(text[i]))
				{
					if (text[i]=='.')
					{
						if (i!=0)
							test=((IsActualNumber(text[i-1])) || (IsActualNumber(text[i+1])));
						else
							test=IsActualNumber(text[i+1]);
					}
					else
						test=0;
				}
			}
			if (i!=start)
			{
				i--;
				to->AddMember()->GetFrag(text,start,i-start+1);
				i++;
			}
		}
		
		if (IsLetter(text[i]))
		{
			start=i;
			i++;
			while (IsLetter(text[i]))
				i++;
			i--;
			to->AddMember()->GetFrag(text,start,i-start+1);
			i++;
		}
		if (IsOp(text[i]))
		{
			if (IsDoubleOp(text[i],text[i+1]))
			{
				to->AddMember()->GetFrag(text,i,2);
				i++;
			}
			else
				to->AddMember()->GetFrag(text,i,1);
			i++;
		}
		if (IsWhite(text[i]))
		{
			i++;
			while (IsWhite(text[i]))
				i++;
		}
		if (beg==i)
			i++;
	}
}

#define SingleNeg		"__SINGLENEG__"
#define MakeIntoVec			"__MAKEVEC__"

//Function Flags (FuncFlag_?)
//	Use these for AddFunc()
//	Use 0 (or FuncFlag_2ArgsAndReturn) for a 2 arguement, 1 return
//		value functions (such as + and *)
//	You can OR them together (eg: FuncFlag_SingleArg|FuncFlag_NoReturn)

#define FuncFlag_2ArgsAndReturn 0x0000
	//2 aguements 1 return value
#define FuncFlag_SingleArg 0x0001
	//1 arguement
#define FuncFlag_NoReturn 0x0002
	//no return value
#define FuncFlag_NoArgs 0x0004
	//no arguements
#define FuncFlag_ShowBefore 0x0008
	//use for functions like sin(), cos(), nder()

class _Func
{
public:
	Str Name;
	int Importance;
	int Flags;
};

class Op
{
public:
	Str Arg1, Arg2;
	Str Fnc, Ans;
};

class Script
{
public:
	DArray<Str> Strs;
	DArray<_Func> Funcs;
	DArray<Op> Ops;
	int Hidden;
	Str LastHidden;
	TArray<Str,int> FuncStack;
	DArray<Str> ArgStack;

	void FromText(char * text);
	void ClearCurrent();

	void DoSystemComs();
	void DoShuntingYard();
	void AddOp();
	void AddArgOp();
	void AddFunc(char * name, int importance, int flags);
	char * AddHidden();
	_Func * GetFunc(char * name);

	Script() {Hidden=0; AddFunc(MakeIntoVec,50,FuncFlag_SingleArg|FuncFlag_ShowBefore);};
};

void Script::ClearCurrent()
{
	Ops.DelAll();
	ArgStack.DelAll();
	FuncStack.DelAll();
	Hidden=0;
	Strs.DelAll();
}

void Script::FromText(char * text)
{
	ClearCurrent();
//	CheckText( text );
	ParseString(text,&Strs);
	DoSystemComs();
	DoShuntingYard();
}


void Script::DoSystemComs()
{
	DAMem<Str>*work;

	//put extra '(' at end of statement is needed:
	int nump=0;
	work=Strs.Base;
	while (work)
	{
		if (work->Val == "(")
			nump++;
		if (work->Val == ")")
			nump--;
		work=work->Next;
	}
	while (nump > 0)
	{
		nump--;
		(*Strs.AddMember()) = ")";
	}

	/*** SINGLENEG *****************************************/

	//convert negative with single arguement to SingleNeg
	_Func * f = GetFunc("-");   // look for a '-' function already present in Funcs stack
	
	if (!f)
		return;   // no such function

	if (!GetFunc(SingleNeg))   // it hasn't already been converted to SingleNeg
		AddFunc(SingleNeg,f->Importance,FuncFlag_SingleArg|FuncFlag_ShowBefore);

	work=Strs.Base;
	while (work)
	{
		if (work->Val == "-")
		{
			// '-' as beginning character, or "(-" or ",-", is a SingleNeg
			if (((!work->Prev) || (work->Prev->Val=="(")) || (work->Prev->Val==","))
				work->Val = SingleNeg;
		}
		work=work->Next;
	}
	/*** END SINGLENEG *****************************************/


	/*** MAKE VECTORS *****************************************/

	// convert "[" into "MakeIntoVec" with "(" and replace "]" with ")"
	work=Strs.Base;
	while (work)
	{
		if (work->Val == "]")
			work->Val = ")";
		if (work->Val == "[")
		{
			work->Val = "(";
			Strs.AddCellBefore(work)->Val = MakeIntoVec;
		}
		work=work->Next;
	}
	/*** END MAKE VECTORS *****************************************/
}

void Script::DoShuntingYard()
{
	DAMem<Str>*work=Strs.Base,*other;
	TAMem<Str,int>*nf;
	_Func * func;
	while (work)
	{
		func=GetFunc(work->Val.word);
		if (func)
		{
			while ((FuncStack.Base) && (FuncStack.Base->Other >= func->Importance))
				AddOp();
			nf=FuncStack.AddBottom();
			nf->Val=func->Name.word;
			nf->Other=func->Importance;
		}
		else
		{
			if (work->Val=="(")
			{
				nf=FuncStack.AddBottom();
				nf->Val=work->Val;
				nf->Other=0;
			}
			else
			{
				if (work->Val==")")
				{
					while ((FuncStack.Base) && (FuncStack.Base->Val!="("))
						AddOp();
					FuncStack.DelBottom();
				}
				else
				{
					if (work->Val==";")
					{
						while (FuncStack.Base)
							AddOp();
						while (ArgStack.Base)
							AddArgOp();
					}
					else
						ArgStack.AddBottom()->Val=work->Val.word;
				}
			}
		}
		work=work->Next;
	}
	while (FuncStack.Base)
		AddOp();
	while (ArgStack.Base)
		AddArgOp();
}

_Func * Script::GetFunc(char * name)
// given the name of a function, searches the Funcs stack for that
// function, and returns it if present; returns 0 if it's not present
{
	DAMem<_Func>*work=Funcs.Base;
	while (work)
	{
		if (work->Val.Name == name)
			return &work->Val;
		work=work->Next;
	}
	return 0;
}

void Script::AddArgOp()
{
	Op * op = Ops.AddMember();
	op->Ans = "";
	op->Arg1 = ArgStack.Base->Val.word;
	op->Arg2 = "";
	op->Fnc = "";
	ArgStack.DelBottom();
}

void Script::AddOp()
{
	Op * op=Ops.AddMember();
	op->Fnc=FuncStack.Base->Val.word;
	FuncStack.DelBottom();
	_Func * fun=GetFunc(op->Fnc.word);
	if (!IsFlag(fun->Flags,FuncFlag_NoArgs))
	{
		if (!IsFlag(fun->Flags,FuncFlag_SingleArg))
		{
			if (ArgStack.Base)
				op->Arg2=ArgStack.Base->Val.word;
			ArgStack.DelBottom();
		}
		if (ArgStack.Base)
			op->Arg1=ArgStack.Base->Val.word;
		ArgStack.DelBottom();
	}
	if (!IsFlag(fun->Flags,FuncFlag_NoReturn))
	{
		op->Ans=AddHidden();
		ArgStack.AddBottom()->Val=op->Ans.word;
	}
	if (op->Fnc == SingleNeg)
		op->Fnc = "-";
}

char * Script::AddHidden()
{
	Str other;
	other=Hidden;
	LastHidden="__h";
	LastHidden+=other.word;
	Hidden++;
	return LastHidden.word;
}

void Script::AddFunc(char * name, int importance, int flags)
// adds a new _Func to the Funcs stack
{
	_Func * fun=Funcs.AddMember();
	fun->Name=name;
	fun->Importance=importance;
	fun->Flags=flags;
}

#endif
