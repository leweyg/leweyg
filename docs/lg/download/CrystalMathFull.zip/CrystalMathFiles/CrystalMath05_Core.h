
//*****************************Crystal Math 0.5 - Kernel******************************

//In this file is the Kernel for Cystal Math, it declares all the types, exception handeling
//	and system utilites, such as GarbageCollection() (NOTE: collection is done at certain points
//	not all the time like Java)

// Current Build: 0.5.7

#include <fstream.h>
#include <math.h>
#include <stdlib.h>
#include "../SimpleScript.cpp"
#include "../BArray.cpp"
#include "../Seed.cpp"

bool PartEquals(char * full, char * part)
{
	while ((*part) && (*part == *full))
	{
		part++;
		full++;
	}
	return (!(*part));
}

double Rand()
{
	double f=rand();
	f /= RAND_MAX;
	return f;
}

double Abs(float f)
{
	if (f < 0)
		return -f;
	return f;
}

#define LESS		-1
#define EQUAL		0
#define MORE		1

//forward class declarations
class Func;	//holds real functions
class Type;	//base class for variable types
class Var; //holds variable name and such, so type can change without chaning address
class Form; //holds a pattern (so you can say "of the Form")

class String;	//a string
class Real;		//a real number
class List;		//a list of variables (of any type) (used to store multiple arguments for functions)
class Exp;		//an expression
class Vec;		//a list vector of values

typedef unsigned int uint;
typedef Var* (*RealFunc)(Var * arg);
typedef Var* (*RecFunc)(Var * arg, uint flags);
double AngleRatio=1;
	//1			means radian mode
	//ConstPi/180.0 means degrees mode

//Recursive Function Flags:
#define RFF_Default		0x00000000
#define RFF_SubFirst	0x00000001
#define RFF_NotKeepers	0x00000002

#define Type_None	0
#define Type_Real	1
#define Type_String	2
#define Type_List	3
#define Type_Exp	4
#define Type_Vec	5

//Exception handeling system:

//Error ID's
const int Error_WrongType=1;
const int Error_NotANumber=2;
const int Error_Text=3;
const int Error_WrongArgs=4;
const int Error_FuncError=5;
const int Error_DivZero=6;
const int Error_VecSize=7;

class Error
{
public:
	int ID;
	Str Text;
	Type * Target;
	RealFunc CurFunc;

	void operator = (const Error & other) {ID=other.ID; Text=other.Text.word; Target=other.Target; CurFunc=other.CurFunc;};

	Error();
	Error(int id) {ID=id; Target=0; CurFunc=0;};
	Error(int id, char * text, Type * target) {ID=id; Text=text; Target=target; CurFunc=0;};
	Error(int id, char * text) {ID=id; Text=text; Target=0; CurFunc=0;};
	Error(int id, Type * target) {ID=id; Target=target; CurFunc=0;};
	Error(int id, RealFunc func, Type * target) {ID=id; CurFunc=func; Target=target;};
//	Error(Error & other) {(*this) = other;};
	Error(const Error & other) {(*this) = other;};
};

class Func
{
public:
	Str Name;
	RealFunc FuncP;
	int Importance;
	uint Flags;
	//more func info
};

//base Type class
class Type
{
public:
	int TypeID;
	Var * Owner;

	//casting functions;
	virtual Type * GetType() {return this;};
	virtual Real * GetReal() {/*has to be one for each*/ throw Error(Error_WrongType,this);};
	virtual String * GetString() {/*has to be one for each*/ throw Error(Error_WrongType,this);};
	virtual List * GetList();	//standard one for most classes
	virtual Exp * GetExp(); //standard one for most classes
	virtual Vec * GetVec(); //standard one for most classes

	virtual void MakeEqual(Var * other) {/*has to be one for each*/ throw Error(Error_WrongType,this);}; //make other equal to this
	virtual void Display(Str * str) {/*has to be one for each*/ throw Error(Error_WrongType,this);};
	virtual void MarkUsed() {/*not giving a function means there are no links*/};
	virtual bool IsConst() {return 1;};
	virtual int  Compare(Var * other) {/*has to be one for each*/ throw Error(Error_WrongType,this);};
	virtual void Replace(Var * from, Var * to) {};
	virtual void TypeName(Str * str) {*str = "type";};
	virtual bool IsExactForm(Form * form) {/*has to be one for each*/ return 0;}; 
		//can assume that form is ExactSame, and that TypeID are the same 
		//(only called by Var::IsOfForm() )
	virtual void CallRecFuncOnSubs(RecFunc rf, uint flags) {/*do nothing*/};
		//by default doesn't do anything, i.e. no Subs

	Type() {TypeID=Type_None;};
	virtual ~Type() {};
};

//Var Flags
#define VF_Keep 	0x01
	//never delete (until end of program)
#define VF_Temp 	0x02
	//delete is not used at end of each statement
#define VF_IsUsed	0x04
	//if is being used, don't delete

class Var
{
public:
	Str Name;
	Str OtherName;
	Type * Val;
	uint Flags;

	Type * Init(int type);
	bool IsConst();
	bool IsOfForm(Form * form);
	Var * CallRecFunc(RecFunc rf, uint flags);

	Var(int type, uint flags) {Val=0; Flags=flags; Init(type); Name="def";};
	Var() {Val=0; Flags=VF_Temp; Name="def";};
	~Var() {delete Val;};
};

#define Form_ExactSame		1
	//requires correct arguements to look further
#define Form_SameType		2
	//doesn't look any further
#define Form_Any			3
	//doesn't look any further
#define Form_AbstractExp			4
	//abstract expression, means any expression, it checks the arguements for validity

//The Form class is what some may consider a rule, it is a pattern which can be matched to a function

class Form
{
public:
	int Comparison;
	Var * Arg; //is an instance of the type to match (is Exp, only Exp::TheFunc matters, ignore Exp::Arg)
	Var * Equiv;	//can be null (used to store equivalent value in current equation)
	BArray<Form> Extra;

	Form() {Arg=0; Equiv=0; Comparison=Form_Any;};
};

//different Type derivatives

class Real : public Type
{
public:
	double Value;

	virtual Real * GetReal() {return this;};
	virtual String * GetString();
	virtual void MakeEqual(Var * other);
	virtual void Display(Str * str) /*{(*str) = Value;}*/;
	virtual bool IsConst() {return 1;};
	virtual void TypeName(Str * str) {*str = "real";};
	virtual int Compare(Var * var);
	virtual bool IsExactForm(Form * form);

	Real() {TypeID=Type_Real; Value=0;};
};

class String : public Type
{
public:
	Str Value;

	virtual Type * GetType();
	virtual String * GetString() {return this;};
	virtual Real * GetReal();
	virtual Exp * GetExp(); //this is the main compiler!
	virtual List * GetList();
	virtual void MakeEqual(Var * other);
	virtual void Display(Str * str) {(*str) = Value.word;};
	virtual bool IsConst() {return 1;};
	virtual void TypeName(Str * str) {*str = "string";};
	virtual int Compare(Var * var);
	virtual bool IsExactForm(Form * form);

	String() {TypeID=Type_String;};
};

class List : public Type
{
public:
	BArray<Var*> Values;

	virtual List * GetList() {return this;};
	virtual String * GetString();
	virtual Real * GetReal();
	virtual Vec * GetVec();
	virtual void MakeEqual(Var * other);
	virtual void Display(Str * str);
	virtual void MarkUsed();
	virtual bool IsConst();
	virtual void Remove(Var * var);
	virtual void Clear() {Values.DelAll();};

	virtual Var * operator [] (int i);
	virtual void Join(Var * var); //adds to listtor, if it's a listtor, adds individual members
	virtual void Add(Var * var) {(*Values.AddMember()) = var;};
	virtual void AddBegining(Var * var) {(*Values.AddBottom()) = var;};
	virtual int GetSize() {return Values.GetLength();};
	virtual void Replace(Var * from, Var * to);
	virtual void TypeName(Str * str) {*str = "list";};
	virtual int Compare(Var * other);
	virtual bool IsExactForm(Form * form);
	virtual void CallRecFuncOnSubs(RecFunc rf, uint flags);

	List() {TypeID=Type_List;};
};

class Vec : public Type
{
public:
	BArray<Var*> Values;

	virtual Vec * GetVec() {return this;};
	virtual String * GetString();
	virtual void MakeEqual(Var * other);
	virtual void Display(Str * str);
	virtual void MarkUsed();
	virtual bool IsConst();
	virtual void Remove(Var * var);
	virtual void Clear() {Values.DelAll();};

	virtual Var * operator [] (int i);
	virtual void Join(Var * var); //adds to listtor, if it's a listtor, adds individual members
	virtual void Add(Var * var) {(*Values.AddMember()) = var;};
	virtual void AddBegining(Var * var) {(*Values.AddBottom()) = var;};
	virtual int GetSize() {return Values.GetLength();};
	virtual void Replace(Var * from, Var * to);
	virtual void TypeName(Str * str) {*str = "vec";};
	virtual int Compare(Var * other);
	virtual bool IsExactForm(Form * form);
	virtual void CallRecFuncOnSubs(RecFunc rf, uint flags);

	Vec() {TypeID=Type_Vec;};
};

class Exp : public Type
{
public:
	//any number of these CAN be null
	Var * Arg;
	Func * TheFunc;

	virtual Type * GetType();
	virtual Exp * GetExp() {return this;};
	virtual String * GetString();
	virtual Real * GetReal()		{return GetType()->GetReal();};
	virtual List * GetList()		{return GetType()->GetList();};
	virtual Vec * GetVec()			{return GetType()->GetVec();};
	virtual void MakeEqual(Var * other);
	virtual void Display(Str * str);
	virtual void MarkUsed();
	virtual bool IsConst() {if (!Arg) return 1; return Arg->IsConst();};
	virtual void Replace(Var * from, Var * to) {if (Arg==from) Arg=to;};
	virtual int Compare(Var * var) {return GetType()->Compare(var);};
	virtual void TypeName(Str * str) {*str = "exp";};
	virtual bool IsExactForm(Form * form);
	virtual void CallRecFuncOnSubs(RecFunc rf, uint flags);

	Exp() {TypeID=Type_Exp; Arg=0; TheFunc=0;};
};


//Global functions and registers

BArray<Var> GVars;
BArray<Func*> AutoExecFuncs;
int GNumHiddenVars=0;
int GNumCollected=0;
BArray<Func> GFuncs;
Script GScript;
Func * FuncComma; //must be set
Func * FuncEval; //must be set
Func * FuncAdd;
Func * FuncMinus;
Func * FuncMultiply;
Func * FuncDivide;
BArray<Str> GErrors;
Var * GAns;

//Global values and constants
#define ConstPi 	3.1415926535897932384626433832795
#define ConstE		2.718281828459045
double GScanQuality=100;
double GScanDepth=2;
double GDx = 0.00000001; //to be considered a very small distance

//General functions and utilities

double * GetGVar(char * name)
{
	if (IsEqual("scanquality",name))
		return &GScanQuality;
	if (IsEqual("scandepth",name))
		return &GScanDepth;
	if (IsEqual("dx",name))
		return &GDx;
	return 0;
}

double * SetMode(char * name)
{
	if (IsEqual(name,"degrees"))
	{
		AngleRatio = ConstPi/180.0;
		return 0;
	}
	if (IsEqual(name,"radians"))
	{
		AngleRatio = 1;
		return 0;
	}
	return GetGVar(name);
}

Var * GetVar(char * name)
{
	BAMem<Var>*work=GVars.Base;
	while (work)
	{
		if (work->Val.Name == name)
			return &(work->Val);
		if (work->Val.OtherName == name)
			return &(work->Val);
		work=work->Next;
	}
	return 0;
}

Func * AddFunc(char * name, RealFunc funcp, int importance, int flags)
{
	Func * func = GFuncs.AddMember();
	func->Flags = flags;
	func->FuncP = funcp;
	func->Importance = importance;
	func->Name = name;
	GScript.AddFunc(name,importance,flags);
	return func;
}

Func * GetFunc(RealFunc func)
{
	BAMem<Func>*work=GFuncs.Base;
	while (work)
	{
		if (work->Val.FuncP == func)
			return (&work->Val);
		work=work->Next;
	}
	return 0;
}

Func * GetFunc(char * name)
{
	BAMem<Func>*work=GFuncs.Base;
	while (work)
	{
		if (work->Val.Name == name)
			return (&work->Val);
		work=work->Next;
	}
	return 0;
}

Var * NewKeeper(char * name)
{
	Var * var = GVars.AddMember();
	var->Name = name;
	var->Flags = VF_Keep;
	var->Init(Type_Real);
	return var;
}

Var * NewHidden()
{
	Var * var = GVars.AddMember();
	var->Flags = VF_Temp;
	var->Name = "__H";
	GNumHiddenVars++;
	Str num;
	num=GNumHiddenVars;
	var->Name += num.word;
	//test:
	var->Init(Type_Real);
	var->Val->GetReal()->Value = 0;
	return var;
}

Real * NewReal()
{
	Var * var = NewHidden();
	var->Init(Type_Real);
	var->Val->GetReal()->Value = 0;
	return (Real*)var->Val;
}

String * NewString()
{
	Var * var = NewHidden();
	var->Init(Type_String);
	return (String*)var->Val;
}

List * NewList()
{
	Var * var = NewHidden();
	var->Init(Type_List);
	return (List*)var->Val;
}

Vec * NewVec()
{
	Var * var = NewHidden();
	var->Init(Type_Vec);
	return (Vec*)var->Val;
}

Exp * NewExp()
{
	Var * var = NewHidden();
	var->Init(Type_Exp);
	return (Exp*)var->Val;
}

List * StdList(Var * one)
{
	//returns either the actual listtor, or a new listtor containing that Var
	if (one->Val->TypeID == Type_List)
		return one->Val->GetList();
	List * list = NewList();
	list->Add(one);
	return list;
}

void Switch(Var * one, Var * two)
{
	Type * type = two->Val;
	two->Val = one->Val;
	one->Val = type;
}

void ReplaceVar(Var * from, Var * to)
{
	BAMem<Var>*work=GVars.Base;
	while (work)
	{
		work->Val.Val->Replace(from,to);
		work=work->Next;
	}
}

bool IsAutoExecFunc(Func * func)
{
	BAMem<Func*>*work=AutoExecFuncs.Base;
	while (work)
	{
		if (work->Val == func)
			return 1;
		work=work->Next;
	}
	return 0;
}

void AddAutoExecFunc(Func * func)
{
	(*AutoExecFuncs.AddMember()) = func;
}

void RecursionCorrection()
{
	//corrects for a few functions which use anti-infinite-recursion tactics

	//convert DER to der
	Func * der = GetFunc("der");
	Func * DER = GetFunc("DER");
	BAMem<Var> * work = GVars.Base;
	while (work)
	{
		if (work->Val.Val->TypeID == Type_Exp)
		{
			if (work->Val.Val->GetExp()->TheFunc == DER)
				work->Val.Val->GetExp()->TheFunc = der;
		}
		work = work->Next;
	}
}

void GarbageCollection()
{
	//go through all vars
	//for all temp variables, set IsUsed to null
	BAMem<Var>*work=GVars.Base;
	while (work)
	{
		FlagOff(work->Val.Flags,VF_IsUsed);
		work=work->Next;
	}
	//then go through all non-temp vars and set IsUsed on all temp variables they use
	work = GVars.Base;
	while (work)
	{
		if (IsFlag(work->Val.Flags,VF_Keep))
		{

			if (!IsFlag(work->Val.Flags,VF_IsUsed))
			{
			//	work->Val.CallRecFunc(GarbageMarkUsed, RFF_Default);
				FlagOn(work->Val.Flags,VF_IsUsed);
				work->Val.Val->MarkUsed();
			}
		}
		work=work->Next;
	} 
	//then delete all temp vars which aren't being used
	work = GVars.Base;
	BAMem<Var>*other;
	while (work)
	{
		other = work->Next;
		if (!IsFlag(work->Val.Flags,VF_IsUsed))
		{
			GNumCollected++;
			GVars.DelCell(work);
		}
		work=other;
	}
}

//Var, Type, and Type-derivative member functions

void Exp::CallRecFuncOnSubs(RecFunc rf, uint flags)
{
	Arg = Arg->CallRecFunc(rf,flags);
}

void List::CallRecFuncOnSubs(RecFunc rf, uint flags)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		work->Val = work->Val->CallRecFunc(rf,flags);
		work = work->Next;
	}
}

void Vec::CallRecFuncOnSubs(RecFunc rf, uint flags)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		work->Val = work->Val->CallRecFunc(rf,flags);
		work = work->Next;
	}
}

Var * Var::CallRecFunc(RecFunc rf, uint flags)
{
	Var * cur = this;
	if (IsFlag(flags,RFF_NotKeepers))
	{
		if (IsFlag(cur->Flags,VF_Keep))
			return cur;
	}
	if (!IsFlag(flags,RFF_SubFirst))
	{
		cur = (*rf)(cur,flags);
	}
	if (IsFlag(flags,RFF_NotKeepers))
	{
		if (IsFlag(cur->Flags,VF_Keep))
			return cur;
	}

	cur->Val->CallRecFuncOnSubs(rf,flags);

	if (IsFlag(flags,RFF_SubFirst))
	{
		cur = (*rf)(cur,flags);
	}
	return cur;
}

bool Exp::IsExactForm(Form * form)
{
	//can assume: form->Comparison == Form_ExactSame and form->Arg->Val->TypeID == Type_List
	Exp * exp = form->Arg->Val->GetExp();
	if (TheFunc != exp->TheFunc)
	{
		form->Equiv = 0;
		return 0;
	}
	if (form->Extra.GetLength() != 1)
	{
		form->Equiv = 0;
		return 0;
	}
	if ( ! Arg->IsOfForm(form->Extra.Axs(0)) )
	{
		form->Equiv = 0;
		return 0;
	}
	form->Equiv = Owner;
	return 1;
}

bool Vec::IsExactForm(Form * form)
{
	//can assume: form->Comparison == Form_ExactSame and form->Arg->Val->TypeID == Type_Vec
	int fsize = form->Extra.GetLength();
	int size = GetSize();
	if (fsize != size)
	{
		form->Equiv = 0;
		return 0;
	}
	for (int i=0; i!=size; i++)
	{
		if ( ((*this)[i]->IsOfForm(form->Extra.Axs(i))) == 0)
		{
			form->Equiv = 0;
			return 0;
		}
	}
	form->Equiv = Owner;
	return 1;
}

bool List::IsExactForm(Form * form)
{
	//can assume: form->Comparison == Form_ExactSame and form->Arg->Val->TypeID == Type_List
	int fsize = form->Extra.GetLength();
	int size = GetSize();
	if (fsize != size)
	{
		form->Equiv = 0;
		return 0;
	}
	for (int i=0; i!=size; i++)
	{
		if ( ((*this)[i]->IsOfForm(form->Extra.Axs(i))) == 0)
		{
			form->Equiv = 0;
			return 0;
		}
	}
	form->Equiv = Owner;
	return 1;
}

bool Real::IsExactForm(Form * form)
{
	//can assume: form->Comparison == Form_ExactSame and form->Arg->Val->TypeID == Type_Real
	if (Value != form->Arg->Val->GetReal()->Value)
	{
		form->Equiv = 0;
		return 0;
	}
	form->Equiv = Owner;
	return 1;
}

bool String::IsExactForm(Form * form)
{
	//can assume: form->Comparison == Form_ExactSame and form->Arg->Val->TypeID == Type_String
	if (Value != form->Arg->Val->GetString()->Value)
	{
		form->Equiv = 0;
		return 0;
	}
	form->Equiv = Owner;
	return 1;
}

bool Var::IsOfForm(Form * form)
{
	if (form->Comparison == Form_Any)
	{
		form->Equiv = this;
		return 1;
	}
	if (IsFlag(Flags, VF_Keep))
	{
		form->Equiv = 0;
		return 0;
	}
	if (form->Comparison == Form_AbstractExp)
	{
		//only valid for Expression (currently)
		if (Val->TypeID != form->Arg->Val->TypeID)
		{
			form->Equiv = 0;
			return 0;
		}
		if (Val->TypeID != Type_Exp)
			throw Error(Error_Text,"Abstract Type only valid for Exps",Val);
		Exp * exp = Val->GetExp();
		return exp->Arg->IsOfForm(form->Extra.Axs(0));
	}
	if (form->Comparison == Form_SameType)
	{
		if (Val->TypeID != form->Arg->Val->TypeID)
		{
			form->Equiv = 0;
			return 0;
		}
		form->Equiv = this;
		return 1;
	}
	if (form->Comparison != Form_ExactSame) //if unknown Comparison, return 0
	{
		form->Equiv = 0;
		return 0;
	}

	//Comparison must be Form_ExactSame

	if (Val->TypeID != form->Arg->Val->TypeID)
	{
		form->Equiv = 0;
		return 0;
	}

	return Val->IsExactForm(form);
}

void Vec::Remove(Var * var)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (work->Val == var)
		{
			Values.DelCell(work);
			return;
		}
		work=work->Next;
	}
}

void Vec::Replace(Var * from, Var * to)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (work->Val == from)
			work->Val = to;
		work=work->Next;
	}
}

void List::Remove(Var * var)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (work->Val == var)
		{
			Values.DelCell(work);
			return;
		}
		work=work->Next;
	}
}

void List::Replace(Var * from, Var * to)
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (work->Val == from)
			work->Val = to;
		work=work->Next;
	}
}

bool Var::IsConst()
{
	if (IsFlag(Flags,VF_Keep))
		return 0;
	return Val->IsConst();
}

bool Vec::IsConst()
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (!work->Val->IsConst())
			return 0;
		work=work->Next;
	}
	return 1;
}

Var * Vec::operator [] (int i)
{
	int size=GetSize();
	if ((i < 0) || (i >= size))
		throw Error(Error_Text,"Out of bounds",this);
	return (*Values.Axs(i));
}

void Vec::MarkUsed()
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (!IsFlag(work->Val->Flags,VF_IsUsed))
		{
			FlagOn(work->Val->Flags,VF_IsUsed);
			work->Val->Val->MarkUsed();
		}
		work=work->Next;
	}
}

bool List::IsConst()
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (!work->Val->IsConst())
			return 0;
		work=work->Next;
	}
	return 1;
}

Var * List::operator [] (int i)
{
	int size=GetSize();
	if ((i < 0) || (i >= size))
		throw Error(Error_Text,"Out of bounds",this);
	return (*Values.Axs(i));
}

void List::MarkUsed()
{
	BAMem<Var*>*work=Values.Base;
	while (work)
	{
		if (!IsFlag(work->Val->Flags,VF_IsUsed))
		{
			FlagOn(work->Val->Flags,VF_IsUsed);
			work->Val->Val->MarkUsed();
		}
		work=work->Next;
	}
}

void Exp::MarkUsed()
{
	if (!Arg)
		return;
	if (!IsFlag(Arg->Flags,VF_IsUsed))
	{
		FlagOn(Arg->Flags,VF_IsUsed);
		Arg->Val->MarkUsed();
	}
}

void Real::MakeEqual(Var * other)
{
	other->Init(Type_Real);
	other->Val->GetReal()->Value = Value;
}

void String::MakeEqual(Var * other)
{
	other->Init(Type_String);
	other->Val->GetString()->Value = Value.word;
}

void Vec::MakeEqual(Var * other)
{
	other->Init(Type_Vec);
	BAMem<Var*>*work=Values.Base;
	Var * var;
	Vec * olist = other->Val->GetVec();
	while (work)
	{
		if (IsFlag(work->Val->Flags,VF_Keep))
		{
			(*olist->Values.AddMember()) = work->Val;
		}
		else
		{
			var = NewHidden();
			work->Val->Val->MakeEqual(var);
			(*olist->Values.AddMember()) = var;
		}
		work=work->Next;
	}
}

void List::MakeEqual(Var * other)
{
	other->Init(Type_List);
	BAMem<Var*>*work=Values.Base;
	Var * var;
	List * olist = other->Val->GetList();
	while (work)
	{
		if (IsFlag(work->Val->Flags,VF_Keep))
		{
			(*olist->Values.AddMember()) = work->Val;
		}
		else
		{
			var = NewHidden();
			(*olist->Values.AddMember()) = var;
			work->Val->Val->MakeEqual(var);
		}
		work=work->Next;
	}
}

int Vec::Compare(Var * var)
{
	Vec * vec = var->Val->GetVec();
	int curi = 0;
	int mysize = GetSize();
	int othersize = vec->GetSize();
	int res;

	while ((curi < mysize) && (curi < othersize))
	{
		res = (*this)[curi]->Val->Compare((*vec)[curi]);
		if (res != EQUAL)
			return res;
		curi++;
	}

	if (mysize == othersize)
		return EQUAL;

	if (mysize < othersize)
		return LESS;

	return MORE;
}

int List::Compare(Var * var)
{
	List * list = var->Val->GetList();
	int curi = 0;
	int mysize = GetSize();
	int othersize = list->GetSize();
	int res;

	while ((curi < mysize) && (curi < othersize))
	{
		res = (*this)[curi]->Val->Compare((*list)[curi]);
		if (res != EQUAL)
			return res;
		curi++;
	}

	if (mysize == othersize)
		return EQUAL;

	if (mysize < othersize)
		return LESS;

	return MORE;
}

int String::Compare(Var * var)
{
	return -(Value.Compare(var->Val->GetString()->Value.word));
}

int Real::Compare(Var * var)
{
	Real * real=var->Val->GetReal(); 
	if (Value == real->Value) 
		return EQUAL; 
	if (Value < real->Value) 
		return LESS; 
	return MORE;
}

void Exp::MakeEqual(Var * other)
{
/*	if (TheFunc == FuncEval)
	{
		Type * type = GetType();
		type->MakeEqual(other);
		return;
	} */

	Exp * exp;

	if (Arg)
	{
		if (IsFlag(Arg->Flags,VF_Keep))
		{
			other->Init(Type_Exp);
			exp = other->Val->GetExp();
			exp->TheFunc = 0;
			exp->Arg = Arg;
		}
		else
		{
			if (TheFunc)
			{
				other->Init(Type_Exp);
				exp = other->Val->GetExp();
				exp->TheFunc = TheFunc;
				exp->Arg = NewHidden();
				Arg->Val->MakeEqual(exp->Arg);
			}
			else
			{
				Arg->Val->MakeEqual(other);
			}
		}
	}
	else
	{
		other->Init(Type_Exp);
		exp = other->Val->GetExp();
		exp->TheFunc = TheFunc;
		exp->Arg = 0;
	}
}

Type * Exp::GetType()
{
	if (!TheFunc)
	{
		if (!Arg)
			throw Error(Error_Text,"Expression is not possible",this);
		return Arg->Val->GetType();
	}
	Var * var = (*TheFunc->FuncP)(Arg);
	return var->Val;
}

String * Exp::GetString()
{
	Type * type = GetType();
	if (type->TypeID == Type_String)
		return type->GetString();
	String * str = NewString();
	Display(&str->Value);
	return str;
}

void Exp::Display(Str * str)
{
	if (!TheFunc)
	{
		if (!Arg)
		{
			*str = "No Function";
			return;
		}
		Arg->Val->Display(str);
		return;
	}

	Str ostr;
	*str = "";

	if (Arg)
	{
		List * list;
		if (Arg->Val->TypeID == Type_List)
		{
			list = Arg->Val->GetList();
			if ((IsFlag(TheFunc->Flags,FuncFlag_ShowBefore)) || (list->GetSize()!=2))
			{
				*str = TheFunc->Name.word;
				*str += " ";
				if (IsFlag(Arg->Flags,VF_Keep))
					*str += Arg->Name.word;
				else
				{
					Arg->Val->Display(&ostr);
					*str += ostr.word;
				}
			}
			else
			{
				Var * aone, * atwo;
				bool mark;
				aone = (*list)[0];
				atwo = (*list)[1];

				mark = ((aone->Val->TypeID==Type_Exp) && (aone->Val->GetExp()->TheFunc->Importance < TheFunc->Importance));

				if (mark)
					*str += "( ";
				if (IsFlag(aone->Flags,VF_Keep))
					*str += aone->Name.word;
				else
				{
					aone->Val->Display(&ostr);
					*str += ostr.word;
				}
				if (mark)
					*str += " )";

				*str += " ";
				*str += TheFunc->Name.word;
				*str += " ";

				mark = ((atwo->Val->TypeID==Type_Exp) && (atwo->Val->GetExp()->TheFunc->Importance < TheFunc->Importance));

				if (mark)
					*str += "( ";
				if (IsFlag(atwo->Flags,VF_Keep))
					*str += atwo->Name.word;
				else
				{
					atwo->Val->Display(&ostr);
					*str += ostr.word;
				}
				if (mark)
					*str += " )";
			}
		}
		else
		{
			*str = TheFunc->Name.word;
			*str += " ( ";
			if (IsFlag(Arg->Flags,VF_Keep))
				*str += Arg->Name.word;
			else
			{
				Arg->Val->Display(&ostr);
				*str += ostr.word;
			}
			*str += " )";
		}
	}
	else
	{
		*str = TheFunc->Name.word;
		*str += "()";
	}
	ostr = "";
}

Exp * Type::GetExp()
{
	Var * var = NewHidden();
	var->Init(Type_Exp);
	Exp * exp = (Exp*)var->Val;
	
	exp->TheFunc = 0;
	exp->Arg = Owner;

	return exp;
}

void Vec::Join(Var * var)
{
	if (var->Val->TypeID != Type_Vec)
	{
		(*Values.AddMember()) = var;
		return;
	}
	BAMem<Var*>*work = var->Val->GetVec()->Values.Base;
	while (work)
	{
		(*Values.AddMember()) = work->Val;
		work=work->Next;
	}
}

void List::Join(Var * var)
{
	if (var->Val->TypeID != Type_List)
	{
		(*Values.AddMember()) = var;
		return;
	}
	BAMem<Var*>*work = var->Val->GetList()->Values.Base;
	while (work)
	{
		(*Values.AddMember()) = work->Val;
		work=work->Next;
	}
}

List * String::GetList()
{
	return GetExp()->GetType()->GetList();
}

String * Vec::GetString()
{
	if (GetSize()==1)
		return Values.Base->Val->Val->GetString();
	
	Var * ans = NewHidden();
	ans->Init(Type_String);
	String * vstr = ans->Val->GetString();
	Str * str = &vstr->Value;

	String * ostr;
	*str = "( ";

	BAMem<Var*>*work=Values.Base;

	while (work)
	{
		ostr = work->Val->Val->GetString();
		*str += ostr->Value.word;

		if (work->Next)
			*str += ", ";
		work = work->Next;
	}

	*str += " )";

	return vstr;
}

void Vec::Display(Str * str)
{
	Str ostr;
	*str = "( ";

	BAMem<Var*>*work=Values.Base;

	while (work)
	{
		if (IsFlag(work->Val->Flags,VF_Keep))
		{
			*str += work->Val->Name.word;
		}
		else
		{
			work->Val->Val->Display(&ostr);
			*str += ostr.word;
		}
		if (work->Next)
			*str += ", ";
		work = work->Next;
	}

	*str += " )";
}

String * List::GetString()
{
	if (GetSize()==1)
		return Values.Base->Val->Val->GetString();
	
	Var * ans = NewHidden();
	ans->Init(Type_String);
	String * vstr = ans->Val->GetString();
	Str * str = &vstr->Value;

	String * ostr;
	*str = "( ";

	BAMem<Var*>*work=Values.Base;

	while (work)
	{
		ostr = work->Val->Val->GetString();
		*str += ostr->Value.word;

		if (work->Next)
			*str += ", ";
		work = work->Next;
	}

	*str += " )";

	return vstr;
}

void List::Display(Str * str)
{
	Str ostr;
	*str = "( ";

	BAMem<Var*>*work=Values.Base;

	while (work)
	{
		if (IsFlag(work->Val->Flags,VF_Keep))
		{
			*str += work->Val->Name.word;
		}
		else
		{
			work->Val->Val->Display(&ostr);
			*str += ostr.word;
		}
		if (work->Next)
			*str += ", ";
		work = work->Next;
	}

	*str += " )";
}

Type * String::GetType()
{
	return GetExp()->GetType();
}

Real * String::GetReal()
{
	if (!Value.IsFloat())
		return GetExp()->GetType()->GetReal();
	Var * var=NewHidden();
	var->Init(Type_Real);
	Real * real=(Real*)var->Val;
	real->Value = ToNumber_Float(Value.word);
	return real;
}

Real * List::GetReal()
{
	if (GetSize()!=1)
		throw Error(Error_NotANumber,this);
	return (*Values.Axs(0))->Val->GetReal();
}

Vec * List::GetVec()
{
	Vec * vec = NewVec();
	int size=GetSize();
	for (int i=0; i!=size; i++)
	{
		vec->Add( (*this)[i] );
	}
	return vec;
}

void Real::Display(Str * str)
{
/*	double v = (Value / ConstPi);
	int i=v;
	double other=i;
	if ((v == other) && (v != 0))
	{
		*str = v;
		*str += "*ConstPi";
		return;
	} */
	*str = Value;
}

String * Real::GetString()
{
	Var * var = NewHidden();
	var->Init(Type_String);
	Display(&var->Val->GetString()->Value);
	return var->Val->GetString();
}

Vec * Type::GetVec()
{
	Vec * vec = NewVec();
	vec->Add(Owner);
	return vec;
}

List * Type::GetList()
{
	List * list = NewList();
	list->Add(Owner);
	return list;
}

Type * Var::Init(int type)
{
	if (Val)
		delete Val;
	switch (type)
	{
	case Type_Real:
		Val = new Real;
		break;
	case Type_String:
		Val = new String;
		break;
	case Type_List:
		Val = new List;
		break;
	case Type_Exp:
		Val = new Exp;
		break;
	case Type_Vec:
		Val = new Vec;
		break;
	}
	Val->Owner = this;
	return Val;
}

//THE COMPILER!

Exp * String::GetExp()
{
	//THIS IS THE COMPILER!

	/********** Do pre-compilation check  **********/
	
	/*
	Values from SimpleScript.cpp:
		NonmatchingParentheses 1
		EmptyParentheses 2
		NonmatchingBrackets 3
		NonmatchingQuotes 4
		EmptyQuotes 5
		InputTextErrors 5  (the number of possible error return values)
	*/
	
	Str inputTxtErrs[InputTextErrors] = { 
		"Non-matching Parentheses",   // 1
		"Empty Parentheses ()",       // 2
		"Non-matching Brackets",	  // 3
		"Non-matching Quotes",		  // 4
		"Empty Quotes \"\"" 		  // 5
	};

	int txterr = CheckText( Value.word );
	// CheckText is found in SimpleScript.cpp
	// it returns a value if there is a problem in the input string
	// which will prevent successful compilation

	if (txterr > 0)   // non-zero value means an error was found
	{
		if (txterr <= InputTextErrors )   // make sure CheckText hasn't returned an unknown value
			throw Error( Error_Text, inputTxtErrs[txterr-1] , this);
		else
			throw Error( Error_Text, "Unknown Error in Input Text" , this );
	}
	/********** END of pre-compilation check  **********/

	//compile into ASM
	GScript.FromText(Value.word);

	//create constants
	DAMem<Op>*work=GScript.Ops.Base;
	Var * var;
	while (work)
	{
		if (work->Val.Arg1!="")
		{
			if (work->Val.Arg1.IsFloat())
			{
				var = NewHidden();
				var->Init(Type_Real);
				((Real*)var->Val)->Value = work->Val.Arg1.ToFloat();
				work->Val.Arg1 = var->Name.word;
			}
			if (work->Val.Arg1.word[0]=='"')
			{
				var = NewHidden();
				var->Init(Type_String);
				var->Val->GetString()->Value = work->Val.Arg1.word;
				var->Val->GetString()->Value.RemoveQuotes();
				work->Val.Arg1 = var->Name.word;
			}
		}
		if (work->Val.Arg2!="")
		{
			if (work->Val.Arg2.IsFloat())
			{
				var = NewHidden();
				var->Init(Type_Real);
				((Real*)var->Val)->Value = work->Val.Arg2.ToFloat();
				work->Val.Arg2 = var->Name.word;
			}
			if (work->Val.Arg2.word[0]=='"')
			{
				var = NewHidden();
				var->Init(Type_String);
				var->Val->GetString()->Value = work->Val.Arg2.word;
				var->Val->GetString()->Value.RemoveQuotes();
				work->Val.Arg2 = var->Name.word;
			}
		}
	/*	if (work->Val.Fnc==MakeIntoVec)
		{
			work->Val.Fnc = "MAKEINTOVEC";
		} */
		work=work->Next;
	}

	//make unknown values into registered Reals
	work = GScript.Ops.Base;
	while (work)
	{
		if ((work->Val.Arg1 != "") && (!PartEquals(work->Val.Arg1.word,"__")))
		{
			var = GetVar(work->Val.Arg1.word);
			if (!var)
			{
				var = NewKeeper(work->Val.Arg1.word);
				var->Init(Type_Real);
			}
		}
		if ((work->Val.Arg2 != "") && (!PartEquals(work->Val.Arg2.word,"__")))
		{
			var = GetVar(work->Val.Arg2.word);
			if (!var)
			{
				var = NewKeeper(work->Val.Arg2.word);
				var->Init(Type_Real);
			}
		}
		work=work->Next;
	}

	//make ASM function calls into Exps
	BArray<Exp*> evals;
	work = GScript.Ops.Base;
	Func * func;
	Exp * answer=0;
	Exp * exp;
	List * list;
	while (work)
	{
		if (work->Val.Fnc == "")
		{
			answer = NewExp();
			answer->TheFunc = 0;
			answer->Arg = GetVar(work->Val.Arg1.word);
		}
		else
		{
			exp = NewExp();
			exp->Owner->OtherName = work->Val.Ans.word;
			exp->TheFunc = GetFunc(work->Val.Fnc.word);
		//	if (exp->TheFunc == FuncEval)
			if (IsAutoExecFunc(exp->TheFunc))
				(*evals.AddMember()) = exp;

			if (work->Val.Arg1=="")
			{
				exp->Arg = 0;
			}
			if ((work->Val.Arg1!="") && (work->Val.Arg2==""))
			{
				exp->Arg = GetVar(work->Val.Arg1.word);
			}
			if ((work->Val.Arg1!="") && (work->Val.Arg2!=""))
			{
				list = NewList();
				(*list->Values.AddMember()) = GetVar(work->Val.Arg1.word);
				(*list->Values.AddMember()) = GetVar(work->Val.Arg2.word);
				exp->Arg = list->Owner;
			}
		}
		
		work = work->Next;
	}

	//combine commas into listtors
	BAMem<Var> * vwork = GVars.Base;
	Var * aone, * atwo, * owner;
	while (vwork)
	{
		if (vwork->Val.Val->TypeID == Type_Exp) //if is Exp
		{
			exp = vwork->Val.Val->GetExp(); //safe to assume
			if (exp->TheFunc == FuncComma)
			{
				list = exp->Arg->Val->GetList(); //safe to assume

				aone = list->Values.Base->Val;
				atwo = list->Values.Base->Next->Val;
				owner = &vwork->Val;

				owner->Init(Type_List);
				list = owner->Val->GetList();
				list->Join(aone);
				list->Join(atwo);
			}
		}
		vwork=vwork->Next;
	}

	//remove OtherName s
	vwork = GVars.Base;
	while (vwork)
	{
		if (vwork->Val.OtherName != "")
		{
			vwork->Val.OtherName = "";
		}
		vwork = vwork->Next;
	}

	//evaluate things:
	BAMem<Exp*>*ework = evals.Base;
	Type * type;
	while (ework)
	{
		exp = ework->Val;
		type = exp->GetType();
		type->MakeEqual(exp->Owner);
		ework = ework->Next;
	}

	return answer;
}

void SystemRecover()
{
	//possibly add more later, call this after an error has been thrown
	
	BAMem<Var>*work=GVars.Base;
	while (work)
	{
		//check to make sure all variables have types
		if (!work->Val.Val)
		{
			work->Val.Init(Type_Real);
			work->Val.Val->GetReal()->Value=0;
		}
		//make sure they have no "OtherNames"
		if (work->Val.OtherName!="")
			work->Val.OtherName="";
		work=work->Next;
	}
}

void ErrorHandler(Error error)
{
	SystemRecover();
	Str str, ostr;
	Func * func;
	switch (error.ID)
	{
	case Error_WrongType:
		str = "Incorrect type: ";
		break;
	case Error_NotANumber:
		str = "Not a number: ";
		break;
	case Error_Text:
		str = error.Text.word;
		str += ": ";
		break;
	case Error_WrongArgs:
		str += "Incorrect arguments: ";
		break;
	case Error_FuncError:
		str = "Function error: ";
		break;
	case Error_DivZero:
		str = "Divided by zero: ";
		break;
	case Error_VecSize:
		str = "Vector is not correct size: ";
		break;
	default:
		str = "Unknown error: ";
		break;
	}
	if (error.CurFunc)
	{
		str += "Func:";
		func = GetFunc(error.CurFunc);
		str += func->Name.word;
		str += " ";
	}
	if (error.Target)
	{
		str += "Var:";
		str += error.Target->Owner->Name.word;
		error.Target->TypeName(&ostr);
		str += " <";
		str += ostr.word;
		str += ">";
	}
	(*GErrors.AddMember()) = str.word;
	GarbageCollection();
	RecursionCorrection();
}

List * SafeGetFuncList(Var * arg, int size)
{
	if (!arg)
		return 0;
	if (arg->Val->TypeID != Type_List)
		return 0;
	List * list = arg->Val->GetList();
	if (list->GetSize() != size)
		return 0;
	return list;
}

List * GetFuncList(RealFunc func, Var * arg, int size)
{
	if (!arg)
		throw Error(Error_WrongArgs, func, 0);
	if (arg->Val->TypeID != Type_List)
		throw Error(Error_WrongArgs, func, arg->Val);
	List * list = arg->Val->GetList();
	if (list->GetSize() != size)
		throw Error(Error_WrongArgs, func, list);
	return list;
}


double GetRatio(char * text)
{
	//base unit / GetRatio(type) == in that type

	//distance (base unit is meters)
	if (IsEqual("mm",text))
		return (1.0/1000.0);
	if (IsEqual("cm",text))
		return (1.0/100.0);
	if (IsEqual("km",text))
		return 1000;
	if (IsEqual("inch",text))
		return (0.3048 / 12);
	if (IsEqual("inches",text))
		return (0.3048 / 12);
	if (IsEqual("feet",text))
		return 0.3048;
	if (IsEqual("foot",text))
		return 0.3048;
	if (IsEqual("ft",text))
		return 0.3048;
	if (IsEqual("m",text))
		return 1;
	if (IsEqual("meter",text))
		return 1;
	if (IsEqual("meters",text))
		return 1;
	if (IsEqual("yard",text))
		return 0.9144;
	if (IsEqual("yards",text))
		return 0.9144;

	//time (base unit is second)
	if (IsEqual("second",text))
		return 1;
	if (IsEqual("seconds",text))
		return 1;
	if (IsEqual("minute",text))
		return 60.0;
	if (IsEqual("minutes",text))
		return 60.0;
	if (IsEqual("hour",text))
		return (60.0 * 60.0);
	if (IsEqual("hours",text))
		return (60.0 * 60.0);
	if (IsEqual("day",text))
		return (60.0 * 60.0 * 24.0);
	if (IsEqual("days",text))
		return (60.0 * 60.0 * 24.0);
	if (IsEqual("week",text))
		return (60.0 * 60.0 * 24.0 * 7.0);
	if (IsEqual("weeks",text))
		return (60.0 * 60.0 * 24.0 * 7.0);
	if (IsEqual("year",text))
		return (60*60*24*356.242198781);
	if (IsEqual("years",text))
		return (60*60*24*356.242198781);

	//computer units:
	if (IsEqual("byte",text))
		return 1;
	if (IsEqual("kilobyte",text))
		return 1024;
	if (IsEqual("kb",text))
		return 1024;
	if (IsEqual("mb",text))
		return 1024*1024;
	if (IsEqual("megabyte",text))
		return 1024*1024;
	if (IsEqual("gb",text))
		return 1024*1024*1024;
	if (IsEqual("gigabyte",text))
		return 1024*1024*1024;

	Str str = "Unknown unit: ";
	str += text;
	throw Error(Error_Text,str.word);
}

#include "CrystalMath05_Ops.h"
#include "CrystalMath05_Rules.h"

void InitGScript()
{
	//load variables and constants
	GAns = NewKeeper("ans");
	GAns->Init(Type_Real);
	NewKeeper("pi")->Init(Type_Real)->GetReal()->Value = ConstPi;
	NewKeeper("E")->Init(Type_Real)->GetReal()->Value = ConstE;

	//load all functions into GScript
	LoadStdOps();			//standard functions
	InitSymbolicOps();		//more symbolic functions
}
