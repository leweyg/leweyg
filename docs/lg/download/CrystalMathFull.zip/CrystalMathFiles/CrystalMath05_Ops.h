
// *****************************Crystal Math 0.5 - Primary Functions******************************

//These are the functions which Crystal Math uses, they should all registered with the system
//	by calling LoadStdOps()

Var * opToBase(Var * arg)
{
	List * list = GetFuncList(opToBase,arg,2);
	int base = (*list)[0]->Val->GetReal()->Value;
	int value = (*list)[1]->Val->GetReal()->Value;
	String * string = NewString();
	string->Value = "";

	if (value==0)
	{
		string->Value = "0";
		return string->Owner;
	}
	if (value < 0)
	{
		string->Value = "-";
		value *= -1;
	}

	int cur;
	char let;
	while (value != 0)
	{
		cur = (value % base);
		let = 0;
		if (cur < 10)
			let = (cur + '0');
		else
		{
			if (cur < 16)
				let = (cur - 10 + 'A');
			else
				let = 0;
		}
		if (let != 0)
			string->Value.AddThisBefore(let);

		value -= cur;
		value /= base;
	}

	return string->Owner;
}

Var * opFromBase(Var * arg)
{
	List * list = GetFuncList(opFromBase,arg,2);
	int base = (*list)[0]->Val->GetReal()->Value;
	String * string = (*list)[1]->Val->GetString();

	int curans=0;
	int i=0;
	char let;
	while (string->Value.word[i] != 0)
	{
		let = string->Value.word[i];
		curans *= base;
		if ((let >= '0') && (let <= '9'))
			curans += (let - '0');
		if ((let >= 'a') && (let <= 'z'))
			curans += (let - 'a' + 10);
		if ((let >= 'Z') && (let <= 'Z'))
			curans += (let - 'a' + 10);
		i++;
	}

	Real * ans = NewReal();
	ans->Value = curans;
	return ans->Owner;
}

Var * opDotProduct(Var * arg)
{
	List * list = GetFuncList(opDotProduct,arg,2);

	Vec * one = (*list)[0]->Val->GetVec();
	Vec * two = (*list)[1]->Val->GetVec();

	Real * ans = NewReal();
	ans->Value = 0;
	int size = one->GetSize();
	if (size != two->GetSize())
		throw Error(Error_VecSize,list);

	for (int i=0; i!=size; i++)
	{
		ans->Value += ( (*one)[i]->Val->GetReal()->Value * (*two)[i]->Val->GetReal()->Value );
	}

	return ans->Owner;
}

Var * opSet(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opSet, 0);
	List * list = arg->Val->GetList();

	Real * real;
	int i;
	if (list->GetSize()==3)
	{
		if ((*list)[0]->Val->TypeID == Type_Vec)
		{
			Vec * vec = (*list)[0]->Val->GetVec();
			i = (int)((*list)[1]->Val->GetReal()->Value);
			if (vec->GetSize() == i)
				vec->Add((*list)[2]);
			if (vec->GetSize() <= i)
				throw Error(Error_Text,"Out of bounds",vec);
			(*vec->Values.Axs(i)) = (*list)[2];
			return (*list)[2];
		}
		if ((*list)[0]->Val->TypeID == Type_List)
		{
			List * alist = (*list)[0]->Val->GetList();
			i = (int)((*list)[1]->Val->GetReal()->Value);
			if (alist->GetSize()==i)
				alist->Add((*list)[2]);
			if (alist->GetSize() <= i)
				throw Error(Error_Text,"Out of bounds",alist);
			(*alist->Values.Axs(i)) = (*list)[2];
			return (*list)[2];
		}
	}

	throw Error(Error_Text, "Wrong ars for 'set'",list);
}

Var * opPeriod(Var * arg)
{
	List * list = GetFuncList(opPeriod,arg,2);

	Real * real = (*list)[1]->Val->GetReal();
	if ((*list)[0]->Val->TypeID == Type_Vec)
	{
		Vec * vec = (*list)[0]->Val->GetVec();
		return (*vec)[(int)real->Value];
	}
	else
	{
		List * alist = (*list)[0]->Val->GetList();
		return (*alist)[(int)real->Value];
	}

	return 0;
}

Var * opLog(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	real->Value  = log((*list)[1]->Val->GetReal()->Value);
	real->Value /= log((*list)[0]->Val->GetReal()->Value);

	return real->Owner;
}

Var * opIsEqualOrMore(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) != LESS)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opIsEqualOrLess(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) != MORE)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opIsMore(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) == MORE)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opIsLess(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) == LESS)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opIsNotEqual(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) != EQUAL)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opIsEqual(Var * arg)
{
	List * list = GetFuncList(opLog,arg,2);

	Real * real = NewReal();
	if ((*list)[0]->Val->Compare((*list)[1]) == EQUAL)
		real->Value = 1;
	else
		real->Value = 0;

	return real->Owner;
}

Var * opNExtrema(Var * arg)
{
	List * list = GetFuncList(opNExtrema,arg,4);

	Var * f = (*list)[0];
	Var * x = (*list)[1];
	Var * from = (*list)[2];
	Var * to = (*list)[3];

	Vec * ans = NewVec();
	Real * anans;

	double basex = from->Val->GetReal()->Value;
	double baseend = to->Val->GetReal()->Value;
	double basedx = ((baseend-basex)/GScanQuality);
	double direction;
	if (basedx > 0)
		direction = 1;
	else
		direction = -1;
	double basey[3];

	int cursub;
	double subx, subend, subdx;
	double suby[3];
	bool subtest;

	x->Init(Type_Real);
	x->Val->GetReal()->Value = basex;
	basey[0] = f->Val->GetReal()->Value;

	basex += basedx;
	x->Val->GetReal()->Value = basex;
	basey[1] = f->Val->GetReal()->Value;

	while ((basedx > 0) && (basex + (direction * basedx) < baseend))
	{
		basex += basedx;
		x->Val->GetReal()->Value = basex;
		basey[2] = f->Val->GetReal()->Value;

		if ((basey[0] < basey[1]) != (basey[1] < basey[2]))
		{
			subx = basex - (2 * basedx);
			subend = basex;
			subdx = ((subend - subx)/GScanQuality);
			for (cursub=0; cursub!=GScanDepth; cursub++)
			{
				x->Val->GetReal()->Value = subx;
				suby[0] = f->Val->GetReal()->Value;

				subx += subdx;
				x->Val->GetReal()->Value = subx;
				suby[1] = f->Val->GetReal()->Value;

				subtest=1;
				while ((subtest) && ((subdx > 0) && (subx + (direction*subdx) < subend)))
				{
					subx += subdx;
					x->Val->GetReal()->Value = subx;
					suby[2] = f->Val->GetReal()->Value;

					if ((suby[0] < suby[1]) != (suby[1] < suby[2]))
						subtest=0;

					suby[0] = suby[1];
					suby[1] = suby[2];
				}
				subend = subx;
				subx -= (2 * subdx);
				subdx = ((subend - subx)/GScanQuality);

			}
			anans = NewReal();
			anans->Value = subx-subdx;
			ans->Add(anans->Owner);
		}

		basey[0] = basey[1];
		basey[1] = basey[2];
	}

	return ans->Owner;
}

Var * opNIntersects(Var * arg)
{
	List * list = GetFuncList(opNIntersects,arg,5);

	Var * f = (*list)[0];
	Var * f2 = (*list)[1];
	Var * x = (*list)[2];
	Var * from = (*list)[3];
	Var * to = (*list)[4];

	Vec * ans = NewVec();
	Real * anans;

	double basex = from->Val->GetReal()->Value;
	double baseend = to->Val->GetReal()->Value;
	double basedx = ((baseend-basex)/GScanQuality);
	double direction;
	if (basedx > 0)
		direction = 1;
	else
		direction = -1;
	bool lasty, cury;
	x->Init(Type_Real);
	x->Val->GetReal()->Value = basex;
	lasty = (f->Val->GetReal()->Value > f2->Val->GetReal()->Value);

	int subdepth=0;
	double subx, subend, subdx;
	bool lastsuby, cursuby;

	while ((basedx > 0) && (basex + (direction * basedx) < baseend))
	{
		basex += basedx;
		x->Val->GetReal()->Value = basex;
		cury = (f->Val->GetReal()->Value > f2->Val->GetReal()->Value);

		if (cury != lasty)
		{
			subx = basex-basedx;
			subend = basex;
			subdx = ((subend-subx)/GScanQuality);
			subdepth=0;
			lastsuby = lasty;
			while (subdepth < GScanDepth)
			{
				subdepth++;
				cursuby = lastsuby;
				while ((lastsuby == cursuby) && ((subdx > 0) && (subx + (direction * subdx) < subend)))
				{
					subx += subdx;
					x->Val->GetReal()->Value = subx;
					cursuby = (f->Val->GetReal()->Value > f2->Val->GetReal()->Value);
				}
				subend = subx;
				subx -= subdx;
				subdx = ((subend-subx)/GScanQuality);
			}

			anans = NewReal();
			ans->Add(anans->Owner);
			anans->GetReal()->Value = subx;
		}

		lasty = cury;
	}

	return ans->Owner;
}

Var * opNRoots(Var * arg)
{
	List * list = GetFuncList(opNRoots,arg,4);

	Var * f = (*list)[0];
	Var * x = (*list)[1];
	Var * from = (*list)[2];
	Var * to = (*list)[3];

	Vec * ans = NewVec();
	Real * anans;

	double basex = from->Val->GetReal()->Value;
	double baseend = to->Val->GetReal()->Value;
	double basedx = ((baseend-basex)/GScanQuality);
	double direction;
	if (basedx > 0)
		direction = 1;
	else
		direction = -1;
	bool lasty, cury;
	x->Init(Type_Real);
	x->Val->GetReal()->Value = basex;
	lasty = (f->Val->GetReal()->Value > 0);

	int subdepth=0;
	double subx, subend, subdx;
	bool lastsuby, cursuby;

	while ((basedx > 0) && (basex + (direction * basedx) < baseend))
	{
		basex += basedx;
		x->Val->GetReal()->Value = basex;
		cury = (f->Val->GetReal()->Value > 0);

		if (cury != lasty)
		{
			subx = basex-basedx;
			subend = basex;
			subdx = ((subend-subx)/GScanQuality);
			subdepth=0;
			lastsuby = lasty;
			while (subdepth < GScanDepth)
			{
				subdepth++;
				cursuby = lastsuby;
				while ((lastsuby == cursuby) && ((subdx > 0) && (subx + (direction * subdx) < subend)))
				{
					subx += subdx;
					x->Val->GetReal()->Value = subx;
					cursuby = (f->Val->GetReal()->Value > 0);
				}
				subend = subx;
				subx -= subdx;
				subdx = ((subend-subx)/GScanQuality);
			}

			anans = NewReal();
			ans->Add(anans->Owner);
			anans->GetReal()->Value = subx;
		}

		lasty = cury;
	}

	return ans->Owner;
}

Var * opToVec(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opToVec, 0);
	return arg->Val->GetVec()->Owner;
}

Var * opToExp(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opToExp, 0);
	return arg->Val->GetExp()->Owner;
}

Var * opToList(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opToList, 0);
	return arg->Val->GetList()->Owner;
}

Var * opToString(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opToString, 0);
	return arg->Val->GetString()->Owner;
}

Var * opToReal(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opToReal, 0);
	return arg->Val->GetReal()->Owner;
}

Var * opConvert(Var * arg)
{
	List * list = GetFuncList(opConvert,arg,3);

	Real * ans = NewReal();
	ans->Value = (*list)[0]->Val->GetReal()->Value;
	ans->Value *= GetRatio((*list)[1]->Name.word);
	ans->Value /= GetRatio((*list)[2]->Name.word);

	return ans->Owner;
}

Var * opSetMode(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs, opSetMode, 0);
	List * list = arg->Val->GetList();
	int size=list->GetSize(), i;
	double * gvar;
	Real * ans=NewReal();
	ans->Value = 1;
	for (i=0; i!=size; i++)
	{
		gvar = SetMode((*list)[i]->Name.word);
		if (gvar)
		{
			i++;
			ans->Value = *gvar;
			*gvar = (*list)[i]->Val->GetReal()->Value;
		}
	/*	if ((*list)[i]->Name == "degrees")
			AngleRatio = Pi/180.0;
		if ((*list)[i]->Name == "radians")
			AngleRatio = 1;
		gvar = GetGVar((*list)[i]->Name.word);
		if (gvar)
		{
			i++;
			ans->Value = *gvar;
			*gvar = (*list)[i]->Val->GetReal()->Value;
		} */
	}
	return ans->Owner;
}

Var * opRand(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opRand,0);

	Real * real = arg->Val->GetReal();
	Real * ans = NewReal();
	ans->Value = (Rand() * real->Value);

	return ans->Owner;
}

Var * opFrac(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opFrac,0);
	Real * real = arg->Val->GetReal();
	double f = real->Value;
	double n, d;
	int i;
	bool test=1;
	d=0;

	if (f==0)
		return real->Owner;

	while ((test) && (d < 1000))
	{
		d++;
		n = (d * f);
		i = n;
		if ((n - ((double)i)) == 0)
			test=0;
	}
	if (test)
		return real->Owner;

	Exp * exp = NewExp();
	List * list = NewList();
	exp->Arg = list->Owner;
	exp->TheFunc = GetFunc("/");

	real = NewReal();
	real->Value = n;
	list->Add(real->Owner);

	real = NewReal();
	real->Value = d;
	list->Add(real->Owner);

	return exp->Owner;
}

Var * opNInt(Var * arg)
{
	List * list = GetFuncList(opNInt,arg,4);

	Var * f		= (*list)[0];
	Var * x		= (*list)[1];
	Var * from	= (*list)[2];
	Var * to	= (*list)[3];

	double end = to->Val->GetReal()->Value;
	double curx = from->Val->GetReal()->Value;
	double dx = ((end-curx)/GScanQuality);
	double cury, lasty;
	double sum=0;
	double direction;
	if (dx > 0)
		direction=1;
	else
		direction=-1;

	x->Init(Type_Real);
	x->Val->GetReal()->Value = curx;
	lasty = f->Val->GetReal()->Value;

	while ((dx > 0) == (curx+(direction*GDx) <= end))
	{
		curx += dx;
		x->Val->GetReal()->Value = curx;
		cury = f->Val->GetReal()->Value;

		sum += (lasty * dx);
		sum += (((cury-lasty) * dx) * 0.5);
		lasty = cury;
	}

	Real * real = NewReal();
	real->Value = sum;
	return real->Owner;
}

Var * opNDer(Var * arg)
{
	List * list = GetFuncList(opNDer,arg,3);

	Var * f = (*list)[0];
	Var * x = (*list)[1];
	Var * a = (*list)[2];

	double dx = GDx;
	double a1 = a->Val->GetReal()->Value;
	double f1, f2, f3;
	double ans1, ans2;
	x->Init(Type_Real);

	x->Val->GetReal()->Value = a1;
	f1 = f->Val->GetReal()->Value;

	x->Val->GetReal()->Value = a1+dx;
	f2 = f->Val->GetReal()->Value;

	x->Val->GetReal()->Value = a1+(10*dx);
	f3 = f->Val->GetReal()->Value;

	ans1 = ((f2-f1)/dx);
	ans2 = ((f3-f1)/(10*dx));

	ans1 -= ((ans2 - ans1)/9.0);

	Real * ans = NewReal();
	ans->Value = ans1;
	return ans->Owner;
}

Var * opTestDer(Var * marg)
{
	List * list = GetFuncList(opTestDer,marg,5);

	Var * f = (*list)[0];
	Var * df = (*list)[1];
	Var * x = (*list)[2];
	Var * from = (*list)[3];
	Var * to = (*list)[4];
	Var * anans;

	x->Init(Type_Real);
	Real * ans = NewReal();
	ans->Value = 0;

	//test at a series of points:
	List * ndarg = NewList();
	Real * curreal = NewReal();
	ndarg->Add(f);
	ndarg->Add(x);
	ndarg->Add(curreal->Owner);

	double curnder, curder, curdiff;
	double curx = from->Val->GetReal()->Value;
	double endx = to->Val->GetReal()->Value;
	double dx = ((endx - curx) / GScanQuality);
	double mydiv=0;

	while ((dx > 0) == (curx <= endx))
	{
		mydiv++;
		curreal->Value = curx;
		curnder = opNDer(ndarg->Owner)->Val->GetReal()->Value;
		x->Val->GetReal()->Value = curx;
		curder = df->Val->GetReal()->Value;

		curdiff = Abs(curnder - curder);
		if (curdiff > 0.0001)
		{
			if (curnder > curder)
				ans->Value += Abs((curder - curnder)/curnder);
			else
				ans->Value += Abs((curnder - curder)/curder);
		}

		curx += dx;
	}
	ans->Value /= mydiv;

	return ans->Owner; 
}

Var * opLn(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opLn,0);

	Real * ans = NewReal();
	ans->Value = log(arg->Val->GetReal()->Value);

	return ans->Owner;
}

Var * opSqrt(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opSqrt,0);

	Real * ans = NewReal();
	Real * real = arg->Val->GetReal();
	if (real->Value < 0)
		throw Error(Error_Text,"No imaginary numbers (yet)",real);
	ans->Value = sqrt(real->Value);

	return ans->Owner;
}

Var * opEval(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opEval,0);

	Type * type;
	Var * var;
	int size, i;
	if (IsFlag(arg->Flags, VF_Keep))
	{
		var = NewHidden();
		arg->Val->MakeEqual(var);
		return var;
	}
	else
	{
		if (arg->Val->TypeID == Type_List)
		{
			List * list = arg->Val->GetList();
			size = list->GetSize();
			i=1;
			while (i < size)
			{
				(*list)[i]->Val->GetType();
				i++;
			}
			type = (*list)[0]->Val->GetType();
		}
		else
		{
			type = arg->Val->GetType();
		}
	}
	var = NewHidden();
	type->MakeEqual(var);
	return var;
}

Var * opFromTo(Var * arg)
{
	List * list = GetFuncList(opFromTo, arg, 2);
	opEval((*list)[0])->Val->MakeEqual((*list)[1]);
	return (*list)[1];
}

Var * opToFrom(Var * arg)
{
	List * list = GetFuncList(opToFrom, arg, 2);
	opEval((*list)[1])->Val->MakeEqual((*list)[0]);
	return (*list)[0];
}

Var * opEquals(Var * arg)
{
	List * list = GetFuncList(opEquals, arg, 2);

	(*list)[1]->Val->MakeEqual((*list)[0]);

	return (*list)[0];
}

Var * opAbs(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opAbs,0);

	Real * ans = NewReal();
	ans->Value = arg->Val->GetReal()->Value;
	if (ans->Value < 0)
		ans->Value *= -1;

	return ans->Owner;
}

Var * opATan(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opATan,0);

	Real * ans = NewReal();
	ans->Value = atan(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opACos(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opACos,0);

	Real * ans = NewReal();
	ans->Value = acos(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opASin(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opASin,0);

	Real * ans = NewReal();
	ans->Value = asin(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opTan(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opTan,0);

	Real * ans = NewReal();
	ans->Value = tan(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opCos(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opCos,0);

	Real * ans = NewReal();
	ans->Value = cos(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opSin(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opSin,0);

	Real * ans = NewReal();
	ans->Value = sin(arg->Val->GetReal()->Value * AngleRatio);

	return ans->Owner;
}

Var * opCsc(Var * arg)
{
	Real * ans = opSin(arg)->Val->GetReal();
	ans->Value = (1 / ans->Value);
	return ans->Owner;
}

Var * opSec(Var * arg)
{
	Real * ans = opCos(arg)->Val->GetReal();
	ans->Value = (1 / ans->Value);
	return ans->Owner;
}

Var * opCot(Var * arg)
{
	Real * ans = opTan(arg)->Val->GetReal();
	ans->Value = (1 / ans->Value);
	return ans->Owner;
}

Var * opASec(Var * arg)
{
	Real * ans = NewReal();
	ans->Value = acos(1/(arg->Val->GetReal()->Value));
	return ans->Owner;
}

Var * opACsc(Var * arg)
{
	Real * ans = NewReal();
	ans->Value = asin(1/(arg->Val->GetReal()->Value));
	return ans->Owner;
}

Var * opACot(Var * arg)
{
	Real * ans = NewReal();
	ans->Value = arg->Val->GetReal()->Value;
	ans->Value = asin(1/(sqrt( (ans->Value*ans->Value) +1) ));
	return ans->Owner;
}

Var * opExp(Var * arg)
{
	Real * ans = NewReal();
	ans->Value = exp( arg->Val->GetReal()->Value );
	return ans->Owner;
}

Var * opPower(Var * arg)
{
	List * list = GetFuncList(opPower, arg, 2);

	Real * ans = NewReal();
	ans->Value = pow(((*list)[0]->Val->GetReal()->Value)  ,  ((*list)[1]->Val->GetReal()->Value));

	return ans->Owner; 
}

Var * opDivide(Var * arg)
{
	List * list = GetFuncList(opDivide, arg, 2);

	Real * div = (*list)[1]->Val->GetReal();
	if (div->Value == 0)
		throw Error(Error_DivZero,div);

	Real * ans = NewReal();
	ans->Value = (((*list)[0]->Val->GetReal()->Value)  /  (div->Value));

	return ans->Owner; 
}

Var * opMinus(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opMinus,0);

	Real * ans;
	if (arg->Val->TypeID == Type_List) //minus one value from the other
	{
		List * list = GetFuncList(opMinus, arg, 2);
		ans = NewReal();
		ans->Value = (((*list)[0]->Val->GetReal()->Value)  -  ((*list)[1]->Val->GetReal()->Value));
		return ans->Owner;
	}

	ans = NewReal();	//make a value negative
	ans->Value = -(arg->Val->GetReal()->Value);
	return ans->Owner;
}

Var * opAdd(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opAdd,0);
	if (arg->Val->TypeID != Type_List)
		return arg;
	List * list = arg->Val->GetList();

	Real * rsum = 0;
	Vec * vsum = 0;
	Vec * vec;
	Type * type, * ltype;
	int j;
	for (int i=0; i!=list->GetSize(); i++)
	{
		type = (*list)[i]->Val;
		while ((type->TypeID != Type_Real) && (type->TypeID != Type_Vec))
		{
			ltype = type->GetType();
			if (ltype != type)
				type = ltype;
			else
				throw Error(Error_Text,"Can't be added",type);
		}
		switch (type->TypeID)
		{
		case Type_Real:
			if (vsum)
				throw Error(Error_Text,"Can't add reals and vectors",list);
			if (!rsum)
			{
				rsum = NewReal();
				rsum->Value = 0;
			}
			rsum->Value += type->GetReal()->Value;
			break;
		case Type_Vec:
			if (rsum)
				throw Error(Error_Text,"Can't add reals and vectors",list);
			vec = type->GetVec();
			if (!vsum)
			{
				vsum = NewVec();
				for (j=0; j!=vec->GetSize(); j++)
				{
					vsum->Add(NewReal()->Owner);
				}
			}
			if (vec->GetSize() != vsum->GetSize())
				throw Error(Error_VecSize,vec);
			for (j=0; j!=vec->GetSize(); j++)
			{
				(*vsum)[j]->Val->GetReal()->Value += (*vec)[j]->Val->GetReal()->Value;
			}
			break;
		}
	}

	if (rsum)
		return rsum->Owner;
	if (vsum)
		return vsum->Owner;

	return NewReal()->Owner;

/*	Real * sum = NewReal();
	sum->Value = 0;
	List * list = arg->Val->GetList();
	int size=list->GetSize();
	for (int i=0; i!=size; i++)
	{
		sum->Value += (*list)[i]->Val->GetReal()->Value;
	} 
	return sum->Owner;*/

/*	List * list = GetFuncList(opAdd, arg, 2);

	Real * ans = NewReal();
	ans->Value = (((*list)[0]->Val->GetReal()->Value)  +  ((*list)[1]->Val->GetReal()->Value));

	return ans->Owner;  */
}
Var * opMultiply(Var * arg)
{
	if (!arg)
		throw Error(Error_WrongArgs,opMultiply,0);
	if (arg->Val->TypeID != Type_List)
		return arg;
	List * list = arg->Val->GetList();

	Real * rsum = 0;
	Vec * vsum = 0;
	Vec * vec;
	Real * real;
	List * alist;
	Type * type, * ltype;
	int j;
	for (int i=0; i!=list->GetSize(); i++)
	{
		type = (*list)[i]->Val;
		while ((type->TypeID != Type_Real) && (type->TypeID != Type_Vec))
		{
			ltype = type->GetType();
			if (ltype != type)
				type = ltype;
			else
				throw Error(Error_Text,"Can't be added",type);
		}
		switch (type->TypeID)
		{
		case Type_Real:
			if (vsum)
			{
				real = type->GetReal();
				for (j=0; j!=vsum->GetSize(); j++)
				{
					(*vsum)[j]->Val->GetReal()->Value *= real->Value;
				}
			}
			else
			{
				if (!rsum)
				{
					rsum = NewReal();
					rsum->Value = 1;
				}
				rsum->Value *= type->GetReal()->Value;
			}
			break;
		case Type_Vec:
			vec = type->GetVec();
			if (rsum)
			{
				vsum = NewVec();
				for (j=0; j!=vec->GetSize(); j++)
				{
					vsum->Add(NewReal()->Owner);
					(*vsum)[j]->Val->GetReal()->Value = (rsum->Value * (*vec)[j]->Val->GetReal()->Value);
				}
				rsum = 0;
			}
			else
			{
				if (vsum)
				{
					alist = NewList();
					alist->Add(vsum->Owner);
					alist->Add(vec->Owner);
					rsum = opDotProduct(alist->Owner)->Val->GetReal();
					vsum = 0;
				}
				else
				{
					vsum = NewVec();
					for (j=0; j!=vec->GetSize(); j++)
					{
						real = NewReal();
						vsum->Add(real->Owner);
						real->Value = (*vec)[j]->Val->GetReal()->Value;
					}
				}
			}
			break;
		}
	}

	if (rsum)
		return rsum->Owner;
	if (vsum)
		return vsum->Owner;

	return NewReal()->Owner;

/*	Real * sum = NewReal();
	sum->Value = 1;
	int size=list->GetSize();
	for (int i=0; i!=size; i++)
	{
		sum->Value *= (*list)[i]->Val->GetReal()->Value;
	}

	return sum->Owner; */
}

//the following are far more developer functions:

Var * opIsConst(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->IsConst()))
		real->Value = 1;
	else
		real->Value = 0;
	return real->Owner;
}

Var * opIsSameVar(Var * arg)
{
	List * list = GetFuncList(opDivide, arg, 2);
	Real * real = NewReal();
	if ((*list)[0] == (*list)[1])
		real->Value = 1;
	else
		real->Value = 0;
	return real->Owner;
}

Var * opIsExp(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->Val->TypeID != Type_Exp))
		real->Value = 0;
	else
		real->Value = 1;
	return real->Owner;
}

Var * opIsList(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->Val->TypeID != Type_List))
		real->Value = 0;
	else
		real->Value = 1;
	return real->Owner;
}

Var * opIsReal(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->Val->TypeID != Type_Real))
		real->Value = 0;
	else
		real->Value = 1;
	return real->Owner;
}

Var * opIsString(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->Val->TypeID != Type_String))
		real->Value = 0;
	else
		real->Value = 1;
	return real->Owner;
}

Var * opIsVec(Var * arg)
{
	Real * real = NewReal();
	if ((!arg) || (arg->Val->TypeID != Type_Vec))
		real->Value = 0;
	else
		real->Value = 1;
	return real->Owner;
}

Var * opDebug(Var * arg)
{
	return arg;
}

void LoadStdOps()
{
	Func * func;

	FuncComma = AddFunc(",",0,1,FuncFlag_2ArgsAndReturn);
	AddFunc("==",opIsEqual,1,FuncFlag_2ArgsAndReturn);
	AddFunc("!=",opIsNotEqual,1,FuncFlag_2ArgsAndReturn);
	AddFunc("<",opIsLess,1,FuncFlag_2ArgsAndReturn);
	AddFunc(">",opIsMore,1,FuncFlag_2ArgsAndReturn);
	AddFunc("<=",opIsEqualOrLess,1,FuncFlag_2ArgsAndReturn);
	AddFunc(">=",opIsEqualOrMore,1,FuncFlag_2ArgsAndReturn);
	AddFunc("=",opEquals,2,FuncFlag_2ArgsAndReturn);
	AddFunc("<<",opToFrom,2,FuncFlag_2ArgsAndReturn);
	AddFunc(">>",opFromTo,2,FuncFlag_2ArgsAndReturn);
	AddFunc(".",opPeriod,30,FuncFlag_2ArgsAndReturn);
	FuncAdd = AddFunc("+",opAdd,15,FuncFlag_2ArgsAndReturn);
	FuncMinus = AddFunc("-",opMinus,15,FuncFlag_2ArgsAndReturn);
	FuncMultiply = AddFunc("*",opMultiply,20,FuncFlag_2ArgsAndReturn);
	FuncDivide = AddFunc("/",opDivide,20,FuncFlag_2ArgsAndReturn);
	AddFunc("^",opPower,25,FuncFlag_2ArgsAndReturn);
	AddFunc("ln",opLn,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("log",opLog,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("rand",opRand,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("sqrt",opSqrt,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("sin",opSin,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("cos",opCos,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("tan",opTan,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("csc",opCsc,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("sec",opSec,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("cot",opCot,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("asin",opASin,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("acos",opACos,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("atan",opATan,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("acsc",opACsc,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("asec",opASec,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("acot",opACot,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("exp",opExp,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("dot",opDotProduct,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("abs",opAbs,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("set",opSet,26,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("setmode",opSetMode,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	FuncEval = AddFunc("eval",opEval,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
		AddAutoExecFunc(FuncEval);
	AddFunc("nder",opNDer,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("nint",opNInt,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("nroots",opNRoots,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("nintersects",opNIntersects,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("nextrema",opNExtrema,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("frac",opFrac,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("convert",opConvert,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("frombase",opFromBase,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("tobase",opToBase,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("toexp",opToExp,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("toreal",opToReal,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("tostring",opToString,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("tolist",opToList,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("tovec",opToVec,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	func=AddFunc(MakeIntoVec,opToVec,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
		AddAutoExecFunc(func);
	AddFunc("testder",opTestDer,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);

	AddFunc("isconst",opIsConst,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("issamevar",opIsSameVar,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("isexp",opIsExp,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("isreal",opIsReal,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("isstring",opIsString,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("islist",opIsList,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("isvec",opIsVec,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);

	AddFunc("debug",opDebug,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
}
