
// *****************************Crystal Math 0.5 - Rule Sub System******************************

//This file contains the Rule Sub System for Crystal Math 0.5
//	It also includes some functions which use the Rule subsystem, and initializes and registers
//	these with LoadSymbolicOps()


class RVar;
class Rule;
class RuleSet;
class Cond;

typedef Var* (*RuleFunc)(Rule * rule, Var * arg);
typedef bool (*CondFunc)(Rule * rule, Var * arg);

class RVar	//variable used in the Rule
{
public:
	Str Name;
	Form * Equiv;

	RVar() {Equiv=0;};
};

class Cond
{
public:
	CondFunc TheFunc;
	Str CondScript;

	bool MeetsCond(Rule * rule, Var * arg);

	Cond() {TheFunc=0;};
};

class Rule
{
public:
	Form TheForm;
	DArray<RVar> RVars;
	BArray<Cond> Conds;
	void * RuleData;
	Str RuleText; //Just as reference, not used

	RVar * GetRVar(char * name);
	RVar * SetVar(char * name, Var * equiv);
		//use only for compiling variables, DON'T mix with normal Rule usage
	bool DoesApply(Var * arg);
	Cond * AddCond(char * script) {Cond * c=Conds.AddMember(); c->CondScript=script; return c;};
	Cond * AddCond(CondFunc func) {Conds.AddMember()->TheFunc = func;};

	RVar * AddRVar(char * name, Form * form);
	Rule() {RuleData=0;};
};

class RuleSet
{
public:
	BArray<Rule> Rules;
	void (*DelRuleData)(void * data);

	Rule * AddRule(char * ruletext, void * ruledata);
	Rule * FindRule(Var * var);

	RuleSet() {DelRuleData=0;};
	~RuleSet();
};

RuleSet::~RuleSet()
{
	if (!DelRuleData)
		return;
	BAMem<Rule>*work=Rules.Base;
	while (work)
	{
		(*DelRuleData)(work->Val.RuleData);
		work=work->Next;
	}
}

RVar * Rule::GetRVar(char * name)
{
	DAMem<RVar>*work=RVars.Base;
	while (work)
	{
		if (work->Val.Name == name)
			return &(work->Val);
		work=work->Next;
	}
	return 0;
}

RVar * Rule::SetVar(char * name, Var * equiv)
{
	RVar * var = RVars.AddMember();
	var->Name = name;
	Form * form = TheForm.Extra.AddMember();
	form->Equiv = equiv;
	var->Equiv = form;
	return var;
}

RVar * Rule::AddRVar(char * name, Form * form)
{
	DAMem<RVar>*work=RVars.Base;
	while (work)
	{
		if (work->Val.Name == name)
		{
			work->Val.Equiv = form;
			return &(work->Val);
		}
		work=work->Next;
	}
	RVar * var = RVars.AddMember();
	var->Name = name;
	var->Equiv = form;
	return var;
}

Var * SubCompileVar(Rule * rule, DAMem<Str> * work, DAMem<Str> ** next)
{
	//'next' will contain the next cell ('next' MAY NOT BE NULL)
	//'rule' can be null
	if (!work)
	{
		*next = 0;
		return 0;
	}

	Func * func;
	List * list;
	Vec * vec;
	Exp * exp;
	Real * real;
	String * string;
	RVar * rvar;
	DAMem<Str> * other;
	int i;

	func = GetFunc(work->Val.word);
	if (func)
	{
		exp = NewExp();
		exp->TheFunc = func;
		exp->Arg = SubCompileVar(rule, work->Next, next);
		return exp->Owner;
	}
	if (work->Val == "(" )
	{
		list = NewList();
		*next = work->Next;
		while ( (*next) && ( (*next)->Val != ")" ))
		{
			list->Add( SubCompileVar(rule,*next,&other) );
			*next = other;
			if ((*next)->Val == ",")
				*next = (*next)->Next;
		}
		if (*next)
			*next = (*next)->Next;
		return list->Owner;
	}
	if (work->Val == "[" )
	{
		vec = NewVec();
		*next = work->Next;
		while ( (*next) && ( (*next)->Val != "]" ))
		{
			vec->Add( SubCompileVar(rule,*next,&other) );
			*next = other;
			if ((*next)->Val == ",")
				*next = (*next)->Next;
		}
		if (*next)
			*next = (*next)->Next;
		return vec->Owner;
	}
	if (work->Val.IsFloat())
	{
		real = NewReal();
		real->Value = work->Val.ToFloat();
		*next = work->Next;
		return real->Owner;
	}
	if (work->Val.word[0]=='"')
	{
		string = NewString();
		string->Value = work->Val.word;
		string->Value.RemoveQuotes();
		*next = work->Next;
		return string->Owner;
	}
	if (rule)
	{
		rvar = rule->GetRVar(work->Val.word);
		if (rvar)
		{
			*next = work->Next;
			return rvar->Equiv->Equiv;
		}
	}
	Var * var = GetVar(work->Val.word);
	if (var)
	{
		return var;
	}
	return 0;
}

Var * CompileVar(Rule * rule, char * text)
{
	//you can set 'rule' to null and use this to compile a variable
	DArray<Str> list;
	ParseString(text, &list); //NOTE: doesn't affect script class at all
	DAMem<Str>*next;	//used for book keeping
	return SubCompileVar(rule, list.Base, &next);
}

DAMem<Str> * SubCompileForm(Rule * rule, Form * form, DAMem<Str> * cwork)
{
	//returns the next text cell
	if (!cwork)
		return 0;
	Func * func;
	List * list;
	Vec * vec;
	int i;
	DAMem<Str>*other;

	func = GetFunc(cwork->Val.word);
	if (func) //if Exp
	{
		form->Comparison = Form_ExactSame;

		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Exp);

		form->Arg->Val->GetExp()->TheFunc = func;
		form->Arg->Val->GetExp()->Arg = 0;
		return SubCompileForm(rule, form->Extra.AddMember(), cwork->Next);
	}
	if (cwork->Val == "(")	//if List
	{
		form->Comparison = Form_ExactSame;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_List);

		other = cwork->Next;
		while ((other) && (other->Val != ")"))
		{
			other = SubCompileForm(rule, form->Extra.AddMember(), other);
			if (other->Val == ",")
				other=other->Next;
		}
		if (other)
			other=other->Next;
		return other;
	}
	if (cwork->Val == "[")	//if Vec
	{
		form->Comparison = Form_ExactSame;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Vec);

		other = cwork->Next;
		while ((other) && (other->Val != "]"))
		{
			other = SubCompileForm(rule, form->Extra.AddMember(), other);
			if (other->Val == ",")
				other=other->Next;
		}
		if (other)
			other=other->Next;
		return other;
	}
	if (cwork->Val.IsFloat()) //if Real
	{
		form->Comparison = Form_ExactSame;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Real);

		form->Arg->Val->GetReal()->Value = cwork->Val.ToFloat();
		return cwork->Next;
	}
	if (cwork->Val.word[0] == '"') // if String
	{
		form->Comparison = Form_ExactSame;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_String);

		form->Arg->Val->GetString()->Value = cwork->Val.word;
		form->Arg->Val->GetString()->Value.RemoveQuotes();
		return cwork->Next;
	}

	//if is a type (NOTE: types in the Rule compiler start with capitols)
	if (cwork->Val == "Real")
	{
		form->Comparison = Form_SameType;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Real);

		rule->AddRVar(cwork->Next->Val.word,form);
		return cwork->Next->Next;
	}
	if (cwork->Val == "String")
	{
		form->Comparison = Form_SameType;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_String);

		rule->AddRVar(cwork->Next->Val.word,form);
		return cwork->Next->Next;
	}
	if (cwork->Val == "AbsExp")		//abstract expression, like a normal exp, but also has arguments
	{
		form->Comparison = Form_AbstractExp;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Exp);
		rule->AddRVar(cwork->Next->Val.word,form);

		form->Arg->Val->GetExp()->TheFunc = func;
		form->Arg->Val->GetExp()->Arg = 0;
		return SubCompileForm(rule, form->Extra.AddMember(), cwork->Next->Next);
	}
	if (cwork->Val == "Exp")
	{
		form->Comparison = Form_SameType;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Exp);

		rule->AddRVar(cwork->Next->Val.word,form);
		return cwork->Next->Next;
	}
	if (cwork->Val == "List")
	{
		form->Comparison = Form_SameType;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_List);

		rule->AddRVar(cwork->Next->Val.word,form);
		return cwork->Next->Next;
	}
	if (cwork->Val == "Vec")
	{
		form->Comparison = Form_SameType;
		form->Arg = NewKeeper("__RULE");
		form->Arg->Init(Type_Vec);

		rule->AddRVar(cwork->Next->Val.word,form);
		return cwork->Next->Next;
	}

	//cwork must be a variable:
	form->Comparison = Form_Any;
	form->Arg = NewKeeper("__RULE");
	form->Arg->Init(Type_Real);

	rule->AddRVar(cwork->Val.word,form);
	return cwork->Next;
}

void CompileRule(Rule * rule, char * text)
{
	//NOTE: there are very strict rules about writing Rules (the users can't, just programmers)

	DArray<Str> list;
	ParseString(text, &list); //NOTE: doesn't affect script class at all

	SubCompileForm(rule,&rule->TheForm,list.Base);
}

bool Cond::MeetsCond(Rule * rule, Var * arg)
{
	if (TheFunc)
		return (*TheFunc)(rule, arg);
	Var * var = CompileVar(rule, CondScript.word);
	var = var->Val->GetType()->Owner;
	if (var->Val->TypeID != Type_Real)
		return 0;
	Real * real = var->Val->GetReal();
	if (real->Value == 0)
		return 0;
	return 1;
}

bool Rule::DoesApply(Var * var)
{
	if (!var->IsOfForm(&TheForm))
		return 0;
	BAMem<Cond>*work = Conds.Base;
	while (work)
	{
		if (!work->Val.MeetsCond(this, var))
			return 0;
		work = work->Next;
	}
	return 1;
}

Rule * RuleSet::AddRule(char * ruletext, void * ruledata)
{
	Rule * rule = Rules.AddMember();
	rule->RuleData = ruledata;
	rule->RuleText = ruletext;
	CompileRule(rule, ruletext);
	return rule;
}

Rule * RuleSet::FindRule(Var * var)
{
	BAMem<Rule>*work=Rules.Base;
	while (work)
	{
	//	if (var->IsOfForm(&work->Val.TheForm))
		if (work->Val.DoesApply(var))
		{
			return &(work->Val);
		}
		work=work->Next;
	}
	return 0;
}

//		Rule set utilities

class TextRule	//the TextRule class can be used as the RuleData for easy text based rules
				//	or can actual (RealFunc) rules
{
public:
	Str RecompileText;
	RuleFunc NonTextFunc;

	TextRule() {NonTextFunc=0;};
};

void DelRuleData_TextRule(void * data)
{
	delete ((TextRule*)data);
}


//Actual symbolic operations

// **********************************Group**********************************

//Group groups similar functions: for example "+(a,+(b,c))" becomes "+(a,b,c)"
//	it also translates negatives into pluses, for example "-(a,b)" becomes "+(a,-b)"
//	this helps with grouping
//	Also groups things like -[a,b] into [-a,-b]

Var * GroupAddNegative(Var * arg)
{
	Exp * exp;
	List * list;
	Vec * vec;
	BAMem<Var*>*work;
	if ((!IsFlag(arg->Flags,VF_Keep)) && (arg->Val->TypeID == Type_Exp))
	{
		exp = arg->Val->GetExp();
		if (exp->TheFunc == FuncMinus)
		{
			if ((!IsFlag(exp->Arg->Flags,VF_Keep)) && ((exp->Arg->Val->TypeID == Type_List) || (exp->Arg->Val->TypeID == Type_Vec)))
			{
				return exp->Arg;
			}
			if (exp->Arg->Val->TypeID == Type_Vec)
			{
				vec = exp->Arg->Val->GetVec();
				work = vec->Values.Base;
				if (work)
				{
					work->Val = GroupAddNegative(work->Val);
					work=work->Next;
				}
				return exp->Arg;
			}
			if (exp->Arg->Val->TypeID == Type_List)
			{
				list = exp->Arg->Val->GetList();
				work = list->Values.Base;
				if (work)
				{
					work->Val = GroupAddNegative(work->Val);
					work=work->Next;
				}
				exp->TheFunc = FuncAdd;
			}
			return arg;
		}
		if (exp->TheFunc == FuncAdd)
		{
			list = exp->Arg->Val->GetList();
			work=list->Values.Base;
			while (work)
			{
				work->Val = GroupAddNegative(work->Val);
				work=work->Next;
			}
			return arg;
		}
	}
	exp = NewExp();
	exp->Arg = arg;
	exp->TheFunc = FuncMinus;
	return exp->Owner;
}

void GroupReplaceListArg(List * list, Var * replaceme, List * with)
{
	int i, size=with->GetSize();
	for (i=0; i!=size; i++)
	{
		list->Add((*with)[i]);
	}
	list->Remove(replaceme);
}

List * GroupGetArgList(Func * samefunc, Var * arg)
{
	if (IsFlag(arg->Flags, VF_Keep))
		return 0;
	if (arg->Val->TypeID != Type_Exp)
		return 0;
	Exp * exp = arg->Val->GetExp();
	if (exp->TheFunc != samefunc)
		return 0;
	if (exp->Arg->Val->TypeID != Type_List)
		return 0;
	return exp->Arg->Val->GetList();
}

void GroupSingle(Var * arg)
{
	if (IsFlag(arg->Flags, VF_Keep))
		return;
	if (arg->Val->TypeID != Type_Exp)
		return;
	Exp * exp = arg->Val->GetExp();
	bool found=0;
	List * rlist;
	if ((exp->TheFunc == FuncAdd) || (exp->TheFunc == FuncMultiply))
		found=1;
	if (!found)
		return;
	if (exp->Arg->Val->TypeID != Type_List)
		return;
	List * list = exp->Arg->Val->GetList();
	int i=0;
	while (i < list->GetSize())
	{
		rlist = GroupGetArgList(exp->TheFunc, (*list)[i]);
		if (rlist)
		{
			GroupReplaceListArg(list,(*list)[i],rlist);
			i--;
		}
		i++;
	}
}

Var * GroupRecReplaceNeg(Var * arg, uint flags)
{
	if (arg->Val->TypeID != Type_Exp)
		return arg;
	Exp * exp = arg->Val->GetExp();
	if (exp->TheFunc != FuncMinus)
		return arg;
	List * list;
	if ((IsFlag(exp->Arg->Flags,VF_Keep)) || (exp->Arg->Val->TypeID != Type_List))
	{
		list = NewList();
		list->Add(GroupAddNegative(exp->Arg));
		exp->TheFunc = FuncAdd;
		exp->Arg = list->Owner;
		return arg;
	}
	list = exp->Arg->Val->GetList();
	BAMem<Var*>*work=list->Values.Base;
	if (work)
		work=work->Next;
	while (work)
	{
		work->Val = GroupAddNegative(work->Val);
		work=work->Next;
	}
	exp->TheFunc = FuncAdd;
	return arg;
}

Var * GroupRecFunc(Var * arg, uint flags)
{
	GroupSingle(arg);
	return arg;
}


Var * opGroup(Var * arg)
{
	arg->CallRecFunc(GroupRecReplaceNeg, RFF_SubFirst | RFF_NotKeepers);
	return arg->CallRecFunc(GroupRecFunc, RFF_SubFirst | RFF_NotKeepers);
}

void InitRSGroup()
{
	AddFunc("group",opGroup,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
}

// **********************************opSimplify**********************************

RuleSet RSSimp;	//simplify rule set

void AddSimpRule(char * from, RuleFunc func)
{
	TextRule * tr = new TextRule;
	tr->NonTextFunc = func;
	RSSimp.AddRule(from,tr);
}

void AddSimpRule(char * from, char * to)
{
	TextRule * tr = new TextRule;
	tr->RecompileText = to;
	RSSimp.AddRule(from,tr);
}

Var * DoSimp(Var * arg)	//seperated from rest for use in rest of code
{
	if (IsFlag(arg->Flags, VF_Keep))
		return arg;
	if ((arg->Val->TypeID == Type_Exp) && (arg->Val->GetExp()->TheFunc == 0))
		return arg->Val->GetExp()->Arg;
	Rule * rule = RSSimp.FindRule(arg);
	if (!rule)
		return arg;//couldn't find a rule
	TextRule * tr = (TextRule*)rule->RuleData;
	if (tr->NonTextFunc)
		return (*tr->NonTextFunc)(rule, arg);
	return CompileVar(rule, tr->RecompileText.word);
}

Var * SimpMultiply(Rule * rule, Var * arg)
{
	List * list = arg->Val->GetExp()->Arg->Val->GetList();
	if (list->GetSize()==1)
		return ((*list)[0]);
	Real * real;
	Var * var;
	Real * sum = NewReal();
	sum->Value = 1;
	if (list->GetSize()==0)
	{
		sum->Value=0;
		return sum->Owner;
	}
	int numreal=0;
	int i=0;
	while (i < list->GetSize())
	{
		var = (*list)[i];
		if ((!IsFlag(var->Flags,VF_Keep)) && (var->Val->TypeID == Type_Real))
		{
			real = var->Val->GetReal();
			if (real->Value == 0)
				return real->Owner;
			sum->Value *= real->Value;
			numreal++;
			list->Remove(var);
			i--;
		}
		i++;
	}
	if (numreal > 0)
	{
		if (sum->Value != 1)
			list->AddBegining(sum->Owner);
		if (list->GetSize()==0)
		{
			real = NewReal();
			real->Value = 0;
			return real->Owner;
		}
		if (list->GetSize()==1)
			return (*list)[0];
		if (numreal > 1)
		{
			Exp * exp = NewExp();
			exp->TheFunc = FuncMultiply;
			exp->Arg = list->Owner;
			return exp->Owner;
		}
	}
	if (list->GetSize()==1)
		return (*list)[0];
	return arg;
}

Var * SimpAdd(Rule * rule, Var * arg)
{
	List * list = arg->Val->GetExp()->Arg->Val->GetList();
	if (list->GetSize()==1)
		return ((*list)[0]);
	Real * real;
	Var * var;
	Real * sum = NewReal();
	sum->Value = 0;
	if (list->GetSize()==0)
		return sum->Owner;
	int numreal=0;
	int i=0;
	while (i < list->GetSize())
	{
		var = (*list)[i];
		if ((!IsFlag(var->Flags,VF_Keep)) && (var->Val->TypeID == Type_Real))
		{
			real = var->Val->GetReal();
			sum->Value += real->Value;
			numreal++;
			list->Remove(var);
			i--;
		}
		i++;
	}
	if (numreal > 0)
	{
		if (sum->Value != 0)
			list->AddBegining(sum->Owner);
		if (list->GetSize()==0)
		{
			real = NewReal();
			real->Value = 0;
			return real->Owner;
		}
		if (list->GetSize()==1)
			return (*list)[0];
		if (numreal > 1)
		{
			Exp * exp = NewExp();
			exp->TheFunc = FuncAdd;
			exp->Arg = list->Owner;
			return exp->Owner;
		}
	}
	if (list->GetSize()==1)
		return (*list)[0];
	return arg;

}

Var * SimpCalc(Rule * rule, Var * arg)
{
	return arg->Val->GetType()->Owner;
}

/*Var * SimpRecFunc(Var * arg, uint flags)
{
	if (IsFlag(arg->Flags,VF_Keep))
		return arg;
	return DoSimp(arg);
}

Var * opSimplify(Var * arg)
{
	arg = opGroup(arg);
	return arg->CallRecFunc(SimpRecFunc, RFF_SubFirst | RFF_NotKeepers);
} */
	
Var * SimpRefFunc(Var * arg, uint flags)
{
	GroupSingle(arg);
	arg = DoSimp(arg);
	return arg;
}

Var * opSimplify(Var * arg)
{
	arg = opGroup(arg);
	return arg->CallRecFunc(SimpRefFunc, RFF_SubFirst | RFF_NotKeepers);
} 
	
void InitRSSimp()
{
	AddFunc("simp",opSimplify,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);

	AddSimpRule("+ List V",SimpAdd);
	AddSimpRule("* List V",SimpMultiply);
	AddSimpRule("/(U,1)","U");
	AddSimpRule("/(0,U)","0");
	AddSimpRule("^(U,1)","U");
	AddSimpRule("^(U,0)","1");
	AddSimpRule("- - U", "U");

	AddSimpRule("AbsExp E(Real U, Real V)",SimpCalc);
	AddSimpRule("AbsExp E Real U", SimpCalc);
	AddSimpRule("AbsExp E (Real U)", SimpCalc);
}

// **********************************opDer**********************************

RuleSet RSDer; //Der's RuleSet
Func * FuncDer;
Var * opDer(Var * arg);		//forward declaration

Rule * AddDerRule(char * from, RuleFunc func)
{
	TextRule * tr = new TextRule;
	tr->NonTextFunc = func;
	return RSDer.AddRule(from,tr);
}

Rule * AddDerRule(char * from, char * to)	//only for text functions
{
	TextRule * tr = new TextRule;
	tr->RecompileText = to;
	return RSDer.AddRule(from,tr);
}

Var * MakeDER(Var * arg, Var * x)
{
	List * list = NewList();
	list->Add(arg);
	list->Add(x);
	Exp * exp = NewExp();
	exp->TheFunc = GetFunc("DER");
	exp->Arg = list->Owner;
	return exp->Owner;
}

Var * MakeDer(Var * arg, Var * x)
{
	List * list = NewList();
	list->Add(arg);
	list->Add(x);
	Exp * exp = NewExp();
	exp->TheFunc = GetFunc("der");
	exp->Arg = list->Owner;
	return exp->Owner;
}

Var * DoDer(Var * arg)
{
	List * list = GetFuncList(opDer, arg, 2);
	if ((*list)[0] == (*list)[1])
	{
		Real * real = NewReal();
		real->Value = 1;
		return real->Owner;
	}
	if (IsFlag((*list)[0]->Flags,VF_Keep))
		return MakeDER((*list)[0],(*list)[1]);
	Rule * rule = RSDer.FindRule(arg);
	if (!rule)
		return MakeDer((*list)[0],(*list)[1]);//couldn't find a rule
	TextRule * tr = (TextRule*)rule->RuleData;
	if (tr->NonTextFunc)
		return (*tr->NonTextFunc)(rule,arg);
	return CompileVar(rule, tr->RecompileText.word);
}

Var * DerRecFunc(Var * arg, uint flags)
{
	if (IsFlag(arg->Flags,VF_Keep))
		return arg;
	if (arg->Val->TypeID != Type_Exp)
		return arg;
	Exp * exp = arg->Val->GetExp();
	if (exp->TheFunc != FuncDer)
		return arg;
	return DoDer(exp->Arg);
}

Var * opDer(Var * arg)
{
	Var * ans = DoDer(arg);
	ans = ans->CallRecFunc(DerRecFunc, RFF_NotKeepers);
	return opSimplify(ans);
}

Var * opDER(Var * arg)
{
	return NewReal()->Owner;
}

Var * DerVec(Rule * rule, Var * arg)
{
	Vec * vec = rule->GetRVar("V")->Equiv->Equiv->Val->GetVec();
	Var *  x  = rule->GetRVar("X")->Equiv->Equiv;
	Vec * ans = NewVec();
	for (int i=0; i!=vec->GetSize(); i++)
	{
		ans->Add(MakeDer((*vec)[i],x));
	}
	return ans->Owner;
}

Var * DerAdd(Rule * rule, Var * arg)
{
	List * list = rule->GetRVar("L")->Equiv->Equiv->Val->GetList();
	Var * x = rule->GetRVar("X")->Equiv->Equiv;

	Exp * exp = NewExp();
	exp->TheFunc = FuncAdd;
	List * args = NewList();
	exp->Arg = args->Owner;

	int i, size=list->GetSize();
	for (i=0; i!=size; i++)
	{
		args->Add( MakeDer( (*list)[i] , x));
	}

	return exp->Owner;
}

Var * DerMultiply(Rule * rule, Var * arg)
{
	List * list = rule->GetRVar("L")->Equiv->Equiv->Val->GetList();
	Var * x = rule->GetRVar("X")->Equiv->Equiv;

	Exp * mainexp = NewExp();
	mainexp->TheFunc = FuncAdd;
	List * mainlist = NewList();
	mainexp->Arg = mainlist->Owner;

	Exp * curexp;
	List * curlist;

	int i, j, size=list->GetSize();
	for (i=0; i!=size; i++)
	{
		curexp = NewExp();
		curexp->TheFunc = FuncMultiply;
		mainlist->Add(curexp->Owner);
		curlist = NewList();
		curexp->Arg = curlist->Owner;
		for (j=0; j!=size; j++)
		{
			if (i==j)
				curlist->Add(MakeDer((*list)[j],x));
			else
				curlist->Add((*list)[j]);
		}
	}

	return mainexp->Owner;
}

void InitRSDer()
{
	FuncDer = AddFunc("der",opDer,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	AddFunc("DER",opDER,8,FuncFlag_SingleArg|FuncFlag_ShowBefore);
	RSDer.DelRuleData = DelRuleData_TextRule;
	Rule * rule;

	AddDerRule("(+ List L, X)" , DerAdd );
		//D(U+V) == D(U)+D(V)		//special function because can have N arguments
	AddDerRule("(* List L, X)" , DerMultiply );
		//D(U*V) == U*D(V) + D(U)*V	//special function because can have N arguments
	AddDerRule("(Vec V, X)" , DerVec );
		//D( [a,b, ...] ) == [ D(a), D(b), ... ]//special function because can have N arguments
//	AddDerRule("/(1,U)", "/(- der(U,X), ^(U,2))" );
	AddDerRule("(/(U,V),X)" , "/(-(*(der(U,X),V),*(U,der(V,X))),^(V,2))" );
		//D(U/V) == U*D(V) + D(U)*V
	AddDerRule("(-U,X)" , "- der (U,X)");
		//D(-U) == -D(U)
	AddDerRule("(sin U,X)" , "*(der(U,X),cos U)" );
		//D(sin U) == D(U)*cos(U)
	AddDerRule("(cos U,X)" , "*( - der(U,X), sin U)" );
		//D(cos U) == -D(U)*sin(U)
	AddDerRule("(tan U,X)", "*(der(U,X),^(sec U,2))");
		//D(tan U) == D(U)*(sec(U)^2)
	AddDerRule("(csc U,X)", "*(- der(U,X), csc U, cot U)" );
		//D(csc U) == -D(U) * csc U * cot U
	AddDerRule("(sec U,X)", "*(der(U,X), sec U, tan U)" );
		//D(sec U) == D(U) * sec U * tan U
	AddDerRule("(cot U,X)" , "*(- der(U,X), ^(csc U,2))" );
		//D(cot U) == -D(U) * (csc U)^2
	AddDerRule("(Real U,X)","0");
		//D(c) == 0
//	rule = AddDerRule( "(^(V,U), X)" , "*(^(V,U),der(U,X))" );
//		rule->AddCond( "==(V,E)" );
		//D(E^U) == E^U*D(U)
	AddDerRule( "(^(U,E),X)" , "*(E,^(U,-(E,1)),der(U,X))" );
		//D(U^E) == E*U^(E-1)*D(U)
	AddDerRule( "(abs U,X)" , "*(/(U,abs U),der(U,X))" );
		//D(abs U) == (U/(abs U))*D(U)
	AddDerRule( "(ln U,X)", "/(der(U,X),U)");
		//D(ln U) == D(U)/U
	AddDerRule( "(log(B,U),X)" , "/(der(U,X),*(ln B,U))" );
		//D(log(B,U)) == D(U)/(U * ln B)
	AddDerRule( "(asin U,X)" , "*(/(1,sqrt -(1,^(U,2))),der(U,X))");
	AddDerRule( "(acos U,X)" , "*(/(- 1,sqrt -(1,^(U,2))),der(U,X))");
	AddDerRule( "(atan U,X)" , "*(/(1,+(1,^(U,2))),der(U,X))" );
	AddDerRule( "(acot U,X)" , "*(/(-1,+(1,^(U,2))),der(U,X))" );
	AddDerRule( "(asec U,X)" , "*(/(1,*(abs U,sqrt -(1,^(U,2)))),der(U,X))");
	AddDerRule( "(acsc U,X)" , "*(/(-1,*(abs U,sqrt -(1,^(U,2)))),der(U,X))");
}

//This function initializes all the functions which use the Rule system

void InitSymbolicOps()
{
	InitRSGroup();
	InitRSSimp();
	InitRSDer();
}
