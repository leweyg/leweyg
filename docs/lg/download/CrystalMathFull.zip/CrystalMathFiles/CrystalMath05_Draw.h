
// Equation Visualizer for Crystal Math 0.5

//This system displays equations in a format similar to what is looks like when you actually write it
//	(i.e. divide is two things above each other with a line in between).
//PROBLEM: this system takes advantage of certain characters that only display correctly in
//	Windows console programs.

//BE SURE TO CALL THIS AT THE BEGINING OF YOUR PROGRAM: InitDrawFuncs()

#ifndef HasCrystalMath05_Draw
#define HasCrystalMath05_Draw

#include "../Scr.cpp"

//To ignore operator precidence and just always put brackets, set the blow to 1
bool ForceBrackets = 0;

void AddType(Scr * scr, Var * var)
{
	int owidth = scr->Width;
	int oheight = scr->Height;
	Str name;
	var->Val->TypeName(&name);
	name += "]";
	name.AddThisBefore("  [");
	int nsize = GetSize(name.word);
	scr->Resize(scr->Width + nsize,scr->Height);
	scr->Text(owidth,Center(0,oheight,1),name.word);
}

void AddBrackets(Scr * scr)
{
	Scr to;
	to.Init(scr->Width + 4, scr->Height);

	to.Paste(2,0,scr);
	int width = to.Width;
	int height = to.Height;

	if (to.Height == 1)
	{
		to.Set(0,0,'[');
		to.Set(width-1, 0, ']' );
	}
	else
	{
		to.Line(0,0,0,1,height);
		to.Line(width-1,0,0,1,height);
		to.Set(0,0,GetSymbol(0,1,1,0));
		to.Set(0,height-1,GetSymbol(1,0,1,0));
		to.Set(width-1,0,GetSymbol(0,1,0,1));
		to.Set(width-1,height-1,GetSymbol(1,0,0,1));
	}

	to.Swap(scr);
}

typedef void (*DrawOp)(Exp * exp, Scr * to);

class DrawFunc
{
public:
	DrawOp TheFunc;
	BArray<Str> Funcs;
};

DrawFunc DefDrawFunc;
BArray<DrawFunc> DrawFuncs;

DrawFunc * GetDrawFunc(char * funcname)
{
	BAMem<DrawFunc>*fwork=DrawFuncs.Base;
	BAMem<Str>*swork;
	while (fwork)
	{
		swork = fwork->Val.Funcs.Base;
		while (swork)
		{
			if (swork->Val == funcname)
				return (&fwork->Val);
			swork=swork->Next;
		}
		fwork=fwork->Next;
	}
	return &DefDrawFunc;
}

void AddDrawFunc(DrawOp func, char * funcname)
{
	BAMem<DrawFunc>*work=DrawFuncs.Base;
	while (work)
	{
		if (work->Val.TheFunc == func)
		{
			(*work->Val.Funcs.AddMember()) = funcname;
			return;
		}
		work=work->Next;
	}
	work = DrawFuncs.AddCellTop();
	work->Val.TheFunc = func;
	(*work->Val.Funcs.AddMember()) = funcname;
}

void DrawAbout(Scr * to)
{
	to->Resize(31,5);
	to->Text(0,0,"Crystal Math 0.5.7");
	to->Text(0,1,"Developed by Ogre Industrial");
	to->Text(5,2,"http://plaza.ufl.edu/lewey");
	to->Text(0,3,"Created by Lewey Geselowitz");
	to->Text(5,4,"lewey@ufl.edu");
}

void Draw(Var * var, Scr * to, bool forcenokeep)
{
	if (var->Name == "about")
	{
		DrawAbout(to);
		return;
	}

	if ((IsFlag(var->Flags,VF_Keep)) && (!forcenokeep))
	{
		to->JustText(var->Name.word);
		return;
	}

	if (var->Val->TypeID == Type_String)
	{
		to->JustText(var->Val->GetString()->Value.word);
		return;
	}

	Str str;
	if (var->Val->TypeID == Type_Real)
	{
		to->JustText(var->Val->GetString()->Value.word);
		return;
	}

	BArray<Scr> els;
	List * list=0;
	Vec * vec=0;
	Scr * scr;
	int width=0, height=1, size;
	int i, curx;
	if ((var->Val->TypeID == Type_List) || (var->Val->TypeID == Type_Vec))
	{
		if (var->Val->TypeID == Type_List)
		{
			list = var->Val->GetList();
			size = list->GetSize();
		}
		else
		{
			vec = var->Val->GetVec();
			size = vec->GetSize();
		}
		for (int i=0; i!=size; i++)
		{
			scr = els.AddMember();
			if (list)
				Draw((*list)[i], scr, 0);
			else
				Draw((*vec)[i], scr, 0);
			
			width += (2 + scr->Width);
			if (height < scr->Height)
				height = scr->Height;
		}
		if (width != 0)
			width-=2;

		to->Init(width,height);

		curx=0;
		for (i=0; i!=els.GetLength(); i++)
		{
			scr = els.Axs(i);
			to->Paste(curx,Center(0,height,scr->Height),scr);
			curx+=scr->Width;
			if (i+1 != els.GetLength())
			{
				to->Set(curx,Center(0,height,1),',');
				curx+=2;
			}
		}
		AddBrackets(to);

		return;
	}

	if (var->Val->TypeID != Type_Exp)
	{
		to->JustText("?");
		return;
	}

	//must be exp:
	Exp * exp = var->Val->GetExp();
	if (!exp->TheFunc)
	{
		Draw(exp->Arg, to, 0);
		return;
	}

	DrawFunc * df = GetDrawFunc(exp->TheFunc->Name.word);
	(*df->TheFunc)(exp,to);

	return;
}

bool IsPutBrackets(Exp * exp, Var * anarg)
{
	if (anarg->Val->TypeID != Type_Exp)
		return 0;
	if (ForceBrackets)
		return 1;
	Exp * axp = anarg->Val->GetExp();
	if (!axp->TheFunc)
		return IsPutBrackets(exp,axp->Arg);
	if (exp->TheFunc->Importance > axp->TheFunc->Importance)
		return 1;
	return 0;
}

//Draw funcs:

void dfDefault(Exp * exp, Scr * to)
{
	int nsize = GetSize(exp->TheFunc->Name.word);

	Scr one;
	Draw(exp->Arg, &one, 0);
	if ((exp->Arg->Val->TypeID != Type_List) && (exp->Arg->Val->TypeID != Type_Vec))
	{
//		if (IsPutBrackets(exp,exp->Arg))
			AddBrackets(&one);
	}

	to->Init(nsize + one.Width, one.Height);
	to->Paste(nsize,0,&one);
	to->Text(0,Center(0,one.Height,1),exp->TheFunc->Name.word);
}

void dfMiddleOp(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr one, two;
	Draw((*list)[0], &one, 0);
	if (IsPutBrackets(exp,(*list)[0]))
		AddBrackets(&one);
	Draw((*list)[1], &two, 0);
	if (IsPutBrackets(exp,(*list)[1]))
		AddBrackets(&two);

	int nsize = GetSize(exp->TheFunc->Name.word);

	int width = nsize + one.Width + two.Width + 1;
	int height = one.Height;
	if (height < two.Height)
		height = two.Height;

	to->Init(width, height);
	to->Paste(0,Center(0,height,one.Height),&one);
	to->Text(one.Width+1,Center(0,height,1),exp->TheFunc->Name.word);
	to->Paste(one.Width+1+nsize,Center(0,height,two.Height),&two);
}

void dfTightMiddleOp(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr one, two;
	Draw((*list)[0], &one, 0);
	if (IsPutBrackets(exp,(*list)[0]))
		AddBrackets(&one);
	Draw((*list)[1], &two, 0);
	if (IsPutBrackets(exp,(*list)[1]))
		AddBrackets(&two);

	int nsize = GetSize(exp->TheFunc->Name.word)-1;

	int width = nsize + one.Width + two.Width;
	int height = one.Height;
	if (height < two.Height)
		height = two.Height;

	to->Init(width, height);
	to->Paste(0,Center(0,height,one.Height),&one);
	to->Text(one.Width,Center(0,height,1),exp->TheFunc->Name.word);
	to->Paste(one.Width+nsize,Center(0,height,two.Height),&two);
}

void dfPower(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr one, two;
	Draw((*list)[0], &one, 0);
	if (IsPutBrackets(exp,(*list)[0]))
		AddBrackets(&one);
	Draw((*list)[1], &two, 0);

	int width = one.Width + two.Width;
	int height = one.Height + two.Height;

	to->Init(width, height);
	to->Paste(0,two.Height,&one);
	to->Paste(one.Width,0,&two);
}

void dfDivide(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr one, two;
	Draw((*list)[0], &one, 0);
	Draw((*list)[1], &two, 0);

	int width = one.Width;
	if (width < two.Width)
		width = two.Width;
	int height = one.Height + two.Height + 1;

	to->Init(width, height);
	to->Paste(Center(0,width,one.Width),0,&one);
	to->Paste(Center(0,width,two.Width),one.Height+1,&two);
	to->Line(0,one.Height,1,0,width);
}

void dfSqrt(Exp * exp, Scr * to)
{
	Scr one;
	Draw(exp->Arg, &one, 0);

	int width = one.Width+1;
	int height = one.Height+1;

	to->Init(width, height);
	to->Paste(1,1,&one);
	to->Line(0,0,1,0,width);
	to->Line(0,0,0,1,height);
	to->Set(0,0,GetSymbol(0,1,1,0));
	to->Set(0,height-1,GetSymbol(1,1,0,1));
}

void dfMinus(Exp * exp, Scr * to)
{
	if (exp->Arg->Val->TypeID == Type_List)
		dfMiddleOp(exp,to);
	else
		dfDefault(exp,to);
}

void dfAbs(Exp * exp, Scr * to)
{
	Scr one;
	Draw(exp->Arg, &one, 0);
	to->Init(one.Width+2,one.Height);
	to->Paste(1,0,&one);
	to->Line(0,0,0,1,one.Height);
	to->Line(one.Width+1,0,0,1,one.Height);
}

void dfLog(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr one, two;
	Draw((*list)[0], &one, 0);
	Draw((*list)[1], &two, 0);
	if (IsPutBrackets(exp,(*list)[1]))
		AddBrackets(&two);

	int width = 3 + one.Width + 1 + two.Width;
	int height = one.Height + two.Height;

	to->Init(width,height);

	to->Text(0,two.Height-1,"log");
	to->Paste(3,two.Height,&one);
	to->Paste(4+one.Width, 0, &two);
}

void dfDer(Exp * exp, Scr * to)
{
	List * list = GetFuncList(0,exp->Arg,2);

	Scr f, ox;
	Draw((*list)[0],&f,0);
	if (IsPutBrackets(exp,(*list)[0]))
		AddBrackets(&f);
	else
	{
		if (f.Width > 3)
			AddBrackets(&f);
	}
	Draw((*list)[1],&ox,0);
	
	Scr x;
	x.Init(ox.Width+1,ox.Height+2);
	x.Text(Center(0,x.Width,1),0,"d");
	x.Text(0,2,"d");
	x.Line(0,1,1,0,x.Width);
	x.Paste(1,2,&ox);

	to->Init(x.Width + 1 + f.Width, Greater(x.Height,f.Height));
	to->Paste(0,Center(0,to->Height,x.Height),&x);
	to->Paste(x.Width+1,Center(0,to->Height,f.Height),&f);
}

void dfMiddleMulti(Exp * exp, Scr * to)
{
	if (exp->Arg->Val->TypeID != Type_List)
	{
		dfDefault(exp,to);
		return;
	}
	List * list = exp->Arg->Val->GetList();
	if (list->GetSize()==1)
	{
		Draw(exp->Arg, to, 0);
		return;
	}
	BArray<Scr> els;
	Scr * scr;
	int width=0;
	int height = 0;
	int curx=0;
	int i;
	for (i=0; i!=list->GetSize(); i++)
	{
		scr = els.AddMember();
		Draw((*list)[i], scr, 0);
		if (IsPutBrackets(exp,(*list)[i]))
			AddBrackets(scr);
		
		width += (3 + scr->Width);
		if (height < scr->Height)
			height = scr->Height;
	}
	if (width != 0)
		width-=3;

	to->Init(width,height);

	curx=0;
	for (i=0; i!=els.GetLength(); i++)
	{
		scr = els.Axs(i);
		to->Paste(curx,Center(0,height,scr->Height),scr);
		curx+=scr->Width;
		if (i+1 != els.GetLength())
		{
			to->Text(curx+1,Center(0,height,1),exp->TheFunc->Name.word);
		}
		curx+=3;
	}
}

void InitDrawFuncs()
{
	//Add functions neccasary for Draw() to work correctly

	AddDrawFunc(dfMiddleMulti, "+");
	AddDrawFunc(dfMiddleMulti, "*");
	AddDrawFunc(dfMiddleOp, "=");
	AddDrawFunc(dfTightMiddleOp, ".");
	AddDrawFunc(dfMiddleOp, "==");
	AddDrawFunc(dfMiddleOp, "!=");
	AddDrawFunc(dfMiddleOp, "<");
	AddDrawFunc(dfMiddleOp, ">");
	AddDrawFunc(dfMiddleOp, ">=");
	AddDrawFunc(dfMiddleOp, "<=");
	AddDrawFunc(dfMiddleOp, "<<");
	AddDrawFunc(dfMiddleOp, ">>");

	AddDrawFunc(dfDivide, "/");
	AddDrawFunc(dfPower, "^");
	AddDrawFunc(dfSqrt, "sqrt");
	AddDrawFunc(dfMinus, "-");
	AddDrawFunc(dfAbs, "abs");
	AddDrawFunc(dfLog, "log");
	AddDrawFunc(dfDer,"der");
	AddDrawFunc(dfDer,"DER");

	DefDrawFunc.TheFunc = dfDefault;
}

#endif
