#include <iostream.h>
#include "CrystalMath05_Core.h"
#include "CrystalMath05_Draw.h"

//  NOTE: To disable the equation visualizer, set UseEquationVisualizer to 0 below

//If you are using the equation visualizer, and compiling for the Windows console mode,
//		then set IsWindowsMode to 1, in Scr.cpp (this makes the equations look much better)

//***********************Console GUI for Crystal Math 0.5.7*****************************

bool UseEquationVisualizer = 1;
int MaxCharactersOnScreen = 73;

void ShowScr(Scr * scr, int offset)
{
	int x;
	for (int y=0; y!=scr->Height; y++)
	{
		for (x=0; x!=offset; x++)
			cout << ' ';
		for (x=0; (x!=scr->Width)&&(x < MaxCharactersOnScreen); x++)
		{
			cout << scr->Pixels[x+(y * scr->Width)];
		}
		if (x >= MaxCharactersOnScreen)
			cout << "...";
		cout << endl;
	}
}

void ShowVar(Var * var)
{
	if (UseEquationVisualizer)
	{
		//for equation visualizer
		Scr scr;
		Draw(var, &scr, 1);
		AddType(&scr, var);
		ShowScr(&scr, 3);
		cout << endl;
	}
	else
	{
		//no equation visualizer
		Str disp;
		var->Val->Display(&disp);
		Str type;
		var->Val->TypeName(&type);
		cout << "   " << disp.word << "  [" << type.word << "]" << endl;
	}
}

void Execute(char * text)
{
	String * string;
	Exp * exp;
	Type * type, * otype;
	Var * var;
	BAMem<Str>*ework;
	Str disp;
	bool donedisp=0;

	try
	{
		string = NewString();
		string->Value = text;
		exp = string->GetExp(); //compile

		ShowVar(exp->Owner);

		type = exp->GetType(); //execute;

		ShowVar(type->Owner);

	/*	type->MakeEqual(GAns);

		donedisp=1;

		if (type->TypeID == Type_Exp) //if an expression, display result
		{
			otype = type->GetType();
			ShowVar(otype->Owner);
		} */

		GarbageCollection();
		RecursionCorrection();
	}
	catch (Error er)
	{
		ErrorHandler(er);
		if (donedisp)
			return;
		ework = GErrors.Base;
		cout << "Errors:" << endl;
		while (ework)
		{
			cout << "  " << ework->Val.word << endl;
			ework = ework->Next;
		}
		return;
	};
}

int main()
{
	cout << endl;
	cout << "  Crystal Math - Version 0.5.7" << endl;;
	cout << "     Console Edition" << endl;
	cout << "     Developed by Ogre Industrial" << endl;
	cout << "     Created by Lewey Geselowitz" << endl;
	cout << endl;
	char text[300];
	MaxTextDigits = 6;
	InitGScript();	//initialize functions
	text[0]=0;
	SetMode("radians");
	InitDrawFuncs();	//initialize functions for Draw

	while (1)
	{
		cout << "\n>";
		cin.getline(text,300);		//get input
		if (PartEquals(text,"exit"))
		{
			cout << "\nExecution Info:" << endl;
			cout << "Number of Hiddens  : " << GNumHiddenVars << endl;
			cout << "Number of Vars     : " << GVars.GetLength() << endl;
			cout << "Number of Collected: " << GNumCollected << endl;
			cout << endl;
			return 0;
		}
		if (PartEquals(text,"help"))
		{
			cout << "Either enter in an equation to evaluate, or type 'exit' to quit" << endl;
			cout << endl;
		}
		else
			Execute(text);				//execute
	}
}

int scriptmain()
{
	cout << "go" << endl;

	char buff[300];
	cout << "Enter code:";
	cin.getline(buff,300);

	Script scr;
	scr.AddFunc("=",4, FuncFlag_2ArgsAndReturn);
	scr.AddFunc("+",10,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("-",10,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("*",20,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("/",20,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("^",20,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("if",3,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("else",2,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("sin",20,FuncFlag_SingleArg);
	scr.AddFunc("nder",20,FuncFlag_SingleArg);
	scr.AddFunc("add",20,FuncFlag_SingleArg);
	scr.AddFunc(",",2,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("char",5,FuncFlag_SingleArg);
	scr.AddFunc(".",30,FuncFlag_2ArgsAndReturn);
	scr.AddFunc("about",30,FuncFlag_NoArgs);
	scr.FromText(buff);

	DAMem<Op>*work=scr.Ops.Base;
	while (work)
	{
		cout << work->Val.Arg1.word << " " << work->Val.Fnc.word << " ";
		cout << work->Val.Arg2.word << " -> " << work->Val.Ans.word << endl;
		work=work->Next;
	}
	return 1;
}
