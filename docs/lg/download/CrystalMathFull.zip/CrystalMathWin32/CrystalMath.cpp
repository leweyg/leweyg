// CrystalMath.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"
#include <math.h>
#include <shellapi.h>

//NOTE: to compile, change the following to where ever CrystalMath05_Core.h is
#include "C:/CStuff/CppForRef/CrystalMathfiles/CrystalMath05_Core.h"
#include "C:/CStuff/CppForRef/CrystalMathfiles/CrystalMath05_Draw.h"

char GTextBuff[300];
HWND MainWnd;
HINSTANCE hInst;

void SaveToClipBoard(char * from, HWND hDlg)
{
	if (!from) return;
	char * text;
	HANDLE hdl;
	if (OpenClipboard(hDlg))
	{
		EmptyClipboard();
		hdl = GlobalAlloc(GMEM_DDESHARE,GetSize(from));
		text=(char*)GlobalLock(hdl);
		int i=0;
		while (from[i])
		{
			text[i]=from[i];
			i++;
		}
		text[i]=0;
		GlobalUnlock(hdl);
		SetClipboardData(CF_TEXT,hdl);
		CloseClipboard();
	}
}

void SetHexTextValue(char * text, long int num, long int base)
{
	if (num==0)
	{
		text[0]='0';
		if (base==26)
			text[0]='A';
		text[1]=0;
		return;
	}
	long int pos=0;
	long int curi;
	while (num)
	{
		curi=(num%base);
		if (base==26)
			text[pos]=('A'+curi);
		else
		{
			if (curi < 10)
				text[pos]=('0'+curi);
			else
				text[pos]=('A'+curi-10);
		}
		pos++;
		num-=curi;
		num/=base;
	}
	FlipBytes(text,pos);
	text[pos]=0;
}

long int GetHexValue(char * text, long int base)
{
	long int ans=0;
	long int pos=0;
	long int cur;
	char let;
	while (text[pos])
	{
		let=text[pos];
		if (base==26)
		{
			if ((let >= 'a') && (let <= 'z'))
				cur=(let-'a');
			else
				cur=(let-'A');
		}
		else
		{
			if (IsLetter(let))
			{
				if ((let >= 'a') && (let <= 'z'))
					cur=(10+let-'a');
				else
					cur=(10+let-'A');
			}
			else
				cur=(let-'0');
		}
		ans*=base;
		ans+=cur;
		pos++;
	}
	return ans;
}

void SetHexerValues(long int val, HWND hDlg)
{
	SetHexTextValue(GTextBuff,val,16);
	SetDlgItemText(hDlg,IDC_Hex_Hex,GTextBuff);
	SetHexTextValue(GTextBuff,val,10);
	SetDlgItemText(hDlg,IDC_Hex_Dec,GTextBuff);
	SetHexTextValue(GTextBuff,val,2);
	SetDlgItemText(hDlg,IDC_Hex_Bin,GTextBuff);
	SetHexTextValue(GTextBuff,val,26);
	SetDlgItemText(hDlg,IDC_Hex_Let,GTextBuff);
}

LRESULT CALLBACK HexProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hDlg,IDC_Hex_Hex,"0");
			SetDlgItemText(hDlg,IDC_Hex_Dec,"0");
			SetDlgItemText(hDlg,IDC_Hex_Bin,"0");
			SetDlgItemText(hDlg,IDC_Hex_Let,"A");
				return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
			case IDCANCEL:
				EndDialog(hDlg,LOWORD(wParam));
				break;
			case IDC_Hex_FromHex:
				GetDlgItemText(hDlg,IDC_Hex_Hex,GTextBuff,300);
				SetHexerValues(GetHexValue(GTextBuff,16),hDlg);
				break;
			case IDC_Hex_FromDec:
				GetDlgItemText(hDlg,IDC_Hex_Dec,GTextBuff,300);
				SetHexerValues(GetHexValue(GTextBuff,10),hDlg);
				break;
			case IDC_Hex_FromLet:
				GetDlgItemText(hDlg,IDC_Hex_Let,GTextBuff,300);
				SetHexerValues(GetHexValue(GTextBuff,26),hDlg);
				break;
			case IDC_Hex_FromBin:
				GetDlgItemText(hDlg,IDC_Hex_Bin,GTextBuff,300);
				SetHexerValues(GetHexValue(GTextBuff,2),hDlg);
				break;
			}
			break;
	}
    return FALSE;
}

LRESULT CALLBACK AboutProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	DAMem<Str>*work;
	switch (message)
	{
		case WM_INITDIALOG:
				return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDCANCEL:
			case IDOK:
				EndDialog(hDlg,LOWORD(wParam));
				break;
			}
			break;
	}
    return FALSE;
}

void Disp(char * text)
{
	SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_ADDSTRING,0,(LPARAM)text);
	int i=SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_GETCOUNT,0,0);
	SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_SETCURSEL,i-1,i-1);
}


HWND CHWnd;
char LastConsoleCommand[300];
bool Console_ExitNow=0;
bool UseVisualizer = 1;

void COut(char * text)
{
	SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_ADDSTRING, 0, (LPARAM)text);
	int i = SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_GETCOUNT, 0, 0);
	SendDlgItemMessage(CHWnd,IDC_Console_Text,LB_SETCURSEL,i-1,i-1);
}

void ConsoleShowScr(Scr * scr, int offset)
{
	int y, x;
	Str off;
	off="";
	for (y=0; y!=offset; y++)
		off += " ";
	Str disp;
	for (y=0; y!=scr->Height; y++)
	{
		disp.GetFrag(scr->Pixels, y*scr->Width, scr->Width);
		disp.AddThisBefore(off.word);
		COut(disp.word);
	}
}

void ConsoleShowVar(Var * var)
{
	if (UseVisualizer)
	{
		//using visualizer
		Scr scr;
		Draw(var, &scr, 1);
		AddType(&scr, var);
		ConsoleShowScr(&scr, 3);
		COut("");
	}
	else
	{
		//no equation visualizer
		Str disp;
		var->Val->Display(&disp);
		Str type;
		var->Val->TypeName(&type);
		Str out;
		out="";
		out << "   " << disp.word << "  [" << type.word << "]";
		COut(out.word);
	}
}

bool ConsoleEnter()
{
	GetDlgItemText(CHWnd,IDC_Console_Input,GTextBuff,300);
	if (GTextBuff[0]==0)
		JustCopy(LastConsoleCommand,GTextBuff);
	if (IsEqual(GTextBuff,"exit"))
	{
		Console_ExitNow=1;
		return 0;
	}
	COut("");
	JustCopy(GTextBuff,LastConsoleCommand);

	String * string;
	Exp * exp;
	Type * type, * otype;
	Var * var;
	BAMem<Str>*ework;
	Str disp;
	Str out;
	bool donedisp=0;

	try
	{
		string = NewString();
		string->Value = GTextBuff;
		COut(GTextBuff);
		exp = string->GetExp(); //compile

	/*	exp->Display(&disp);
		out="";
		out << "   " << disp.word << " [Exp]";
		COut(out.word);  */
		ConsoleShowVar(exp->Owner);

		type = exp->GetType(); //execute;

		donedisp=1;
	/*	type->Display(&disp);
		out="";
		out << "   " << disp.word;
		type->TypeName(&disp);
		out << " [" << disp.word << "]";
		COut(out.word); */
		ConsoleShowVar(type->Owner);

		if (type->TypeID == Type_Exp) //if an expression, display result
		{
			otype = type->GetType();
		/*	otype->Display(&disp);
			out="";
			out << "   = " << disp.word;
			otype->TypeName(&disp);
			out << " [" << disp.word << "]";
			COut(out.word); */
			ConsoleShowVar(otype->Owner);
		}
		type->MakeEqual(GAns);
		GarbageCollection();
		RecursionCorrection();
	}
	catch (Error er)
	{
		ErrorHandler(er);
		ework = GErrors.Base;
		COut("Errors:");
		if (donedisp)
		{
			COut("  NOTE: these error(s) occured AFTER normal execution");
		}
		while (ework)
		{
			out="";
			out << "  " << ework->Val.word;
			COut(out.word);
			ework = ework->Next;
		}
		return 1;
	};

	SetDlgItemText(CHWnd,IDC_Console_Input,"");

	return 1;
}

void ConsoleCopy()
{
	int i = SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_GETCURSEL, 0, 0);
	if (i==-1)
		return;
	SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_GETTEXT, i, (LPARAM)GTextBuff);
	i=0;
	while ((GTextBuff[i]) && (GTextBuff[i]==' '))
		i++;
	int end = GetSize(GTextBuff)-1;
	while ((end > 0) && (GTextBuff[end]!='['))
		end--;
	if (GTextBuff[end]=='[')
		end-=2;
	Str ans;
	if (end != 0)
		ans.GetFrag(GTextBuff,i,(end-i)+1);
	else
		ans.GetFrag(GTextBuff,i,(GetSize(GTextBuff)-i));

	SaveToClipBoard(ans.word,CHWnd);
}

void ConsoleDblClick()
{
	int i = SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_GETCURSEL, 0, 0);
	if (i==-1)
		return;
	SendDlgItemMessage(CHWnd, IDC_Console_Text, LB_GETTEXT, i, (LPARAM)GTextBuff);
	i=0;
	while ((GTextBuff[i]) && (GTextBuff[i]==' '))
		i++;
	int end = GetSize(GTextBuff)-1;
	while ((end > 0) && (GTextBuff[end]!='['))
		end--;
	if (GTextBuff[end]=='[')
		end-=2;
	Str ans;
	if (end != 0)
		ans.GetFrag(GTextBuff,i,(end-i)+1);
	else
		ans.GetFrag(GTextBuff,i,(GetSize(GTextBuff)-i));

	GetDlgItemText(CHWnd, IDC_Console_Input,GTextBuff,300);
	ans.AddThisBefore(GTextBuff);
	SetDlgItemText(CHWnd, IDC_Console_Input,ans.word);
}

LRESULT CALLBACK ConsoleProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
		case WM_INITDIALOG:
			CHWnd = hDlg;
			COut("");
			COut("  Crystal Math - Version 0.5.7");
			COut("     Developed by Ogre Industrial");
			COut("     Written by Lewey Geselowitz");
			COut("");
			SendDlgItemMessage(CHWnd,IDC_Console_Text,LB_SETCURSEL,-1,-1);
			if (AngleRatio != 1)
				SendDlgItemMessage(hDlg,IDC_Console_Degrees,BM_CLICK,0,0);
			LastConsoleCommand[0]=0;
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDC_Console_Clear:
				SendDlgItemMessage(hDlg,IDC_Console_Text,LB_RESETCONTENT,0,0);
				break;
			case IDC_Console_Copy:
				ConsoleCopy();
				break;
			case IDC_Console_Degrees:
				if (SendDlgItemMessage(hDlg,IDC_Console_Degrees,BM_GETCHECK,0,0))
					SetMode("degrees");
				else
					SetMode("radians");
				break;
			case IDOK:
				if (!ConsoleEnter())
					EndDialog(hDlg,IDCANCEL);
				break;
			case IDCANCEL:
				EndDialog(hDlg,LOWORD(wParam));
				break;
			case IDC_Console_Text:
				if (HIWORD(wParam)==LBN_DBLCLK)
					ConsoleDblClick();
				break;
			}
			break;
	}
    return FALSE;
}

LRESULT CALLBACK ErrorsProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	DAMem<Str>*work;
	BAMem<Str>*ework;
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hDlg,IDC_ListBanner,GTextBuff);
			if (IsEqual(GTextBuff,"Errors:"))
			{
				ework=GErrors.Base;
				while (ework)
				{
					SendDlgItemMessage(hDlg,IDC_Errors_List,LB_ADDSTRING,0,(LPARAM)ework->Val.word);
					ework=ework->Next;
				}
			}
			return TRUE;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDCANCEL:
			case IDOK:
				EndDialog(hDlg,LOWORD(wParam));
				break;
			}
			break;
	}
    return FALSE;
}

void RunEquals()
{
	bool test;
	Str str, ostr;
	int i;
	DAMem<Str>*work;
	GetDlgItemText(MainWnd,IDC_Calc_Func,GTextBuff,300);
	if (GTextBuff[0]==0)
	{
		i=SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_GETCOUNT,0,0);
		if (i!=0)
			SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_GETTEXT,i-2,(LPARAM)GTextBuff);
		else
			return;
	}
	if (IsEqual(GTextBuff,"exit"))
	{
		EndDialog(MainWnd,IDOK);
		return;
	}

	String * string;
	Exp * exp;
	Type * type;
	Str disp, other;
	try
	{
		string = NewString();
		string->Value = GTextBuff;
		exp = string->GetExp();		//compile
		type = exp->GetType();		//execute

		type->Display(&disp);
		Disp(GTextBuff);
		SetDlgItemText(MainWnd,IDC_Calc_Func,"");
		SetDlgItemText(MainWnd,IDC_Calc_Answer,disp.word);
		other = "  =";
		other += disp.word;
		Disp(other.word);

		type->MakeEqual(GAns);
		GarbageCollection();
		RecursionCorrection();
	}
	catch (Error er)
	{
		ErrorHandler(er);
		JustCopy("Errors:",GTextBuff);
		DialogBox(hInst, (LPCTSTR)IDD_Errors, MainWnd, (DLGPROC)ErrorsProc);
		return;
	};
}

void AddText(int id)
{
	GetDlgItemText(MainWnd,id,GTextBuff,300);
	Str one=GTextBuff;
	GetDlgItemText(MainWnd,IDC_Calc_Func,GTextBuff,300);
	Str two=GTextBuff;
	two+=one.word;
	SetDlgItemText(MainWnd,IDC_Calc_Func,two.word);
}

char STextBuff[300];

void ChangedText()
{
	GetDlgItemText(MainWnd,IDC_Calc_Func,STextBuff,300);
	bool test=0;
	test|=(IsEqual(STextBuff,"+"));
	test|=(IsEqual(STextBuff,"-"));
	test|=(IsEqual(STextBuff,"*"));
	test|=(IsEqual(STextBuff,"/"));
	test|=(IsEqual(STextBuff,"^"));
	if (test)
	{
		Str str="ans";
		str+=STextBuff;
		SetDlgItemText(MainWnd,IDC_Calc_Func,str.word);
		SendDlgItemMessage(MainWnd,IDC_Calc_Func,EM_SETSEL,4,4);
	}
}

void SelectHistory()
{
	int i=SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_GETCURSEL,0,0);
	SendDlgItemMessage(MainWnd,IDC_Calc_History,LB_GETTEXT,i,(LPARAM)GTextBuff);
	Str str;
	str=GTextBuff;
	if ((i%2)==1)
		str-="  =";
	GetDlgItemText(MainWnd,IDC_Calc_Func,GTextBuff,300);
	Str ostr;
	ostr=GTextBuff;
	ostr+=str.word;
	SetDlgItemText(MainWnd,IDC_Calc_Func,ostr.word);
}

bool OneChan=0;

LRESULT CALLBACK MainProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	bool test;
	switch (message)
	{
		case WM_INITDIALOG:
			SetDlgItemText(hDlg,IDC_Calc_Answer,"0");
			MainWnd=hDlg;
			OneChan=1;
			if (AngleRatio != 1)
				SendDlgItemMessage(hDlg,IDC_Calc_Degrees,BM_CLICK,0,0);
			return TRUE;
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDC_Calc_Help:
			case IDM_Calc_Help:
				if ((int)ShellExecute(hDlg,"open","CrystalGuide.html",0,0,SW_SHOWNORMAL)==ERROR_FILE_NOT_FOUND)
				{
					MessageBox(hDlg,"Make sure that CrystalGuide.html is\nin the same folder as Crystal Math.","Crystal Math Error",MB_OK|MB_ICONEXCLAMATION);
					MessageBox(hDlg,"CrystalGuide.html can be downloaded from plaza.ufl.edu\\lewey","Crystal Math",MB_OK);
				}
				break;
			case IDM_CallHexer:
				DialogBox(hInst,(LPCSTR)IDD_Hexer,hDlg,(DLGPROC)HexProc);
				break;
			case IDM_CallConsole:
				DialogBox(hInst,(LPCSTR)IDD_Console,hDlg,(DLGPROC)ConsoleProc);
				if (Console_ExitNow)
					EndDialog(hDlg,IDCANCEL);
				break;
			case IDC_Calc_Func:
				if ((OneChan) && (HIWORD(wParam)==EN_CHANGE))
				{
					ChangedText();
					OneChan=0;
				}
				break;
			case IDC_Calc_Degrees:
			case IDM_ToggleDegrees:
				if (SendDlgItemMessage(hDlg,IDC_Calc_Degrees,BM_GETCHECK,0,0))
					SetMode("degrees");
				else
					SetMode("radians");
				break;
			case IDM_CallAbout:
				DialogBox(hInst,(LPCSTR)IDD_About,hDlg,(DLGPROC)AboutProc);
				break;
			case IDCANCEL:
			case IDC_Calc_Done:
			case IDM_Exit:
				EndDialog(hDlg,LOWORD(wParam));
				break;
			case IDC_Calc_ClearHistory:
				SendDlgItemMessage(hDlg,IDC_Calc_History,LB_RESETCONTENT,0,0);
				break;
			case IDC_Calc_Copy:
				GetDlgItemText(hDlg,IDC_Calc_Answer,GTextBuff,300);
				SaveToClipBoard(GTextBuff,hDlg);
				break;
			case IDC_Calc_Clear:
				SetDlgItemText(hDlg,IDC_Calc_Func,"");
				OneChan=1;
				break;
			case IDC_Calc_sin:
			case IDC_Calc_cos:
			case IDC_Calc_tan:
			case IDC_Calc_ln:
			case IDC_Calc_zero:
			case IDC_Calc_one:
			case IDC_Calc_two:
			case IDC_Calc_three:
			case IDC_Calc_four:
			case IDC_Calc_five:
			case IDC_Calc_six:
			case IDC_Calc_seven:
			case IDC_Calc_eight:
			case IDC_Calc_nine:
			case IDC_Calc_open:
			case IDC_Calc_close:
			case IDC_Calc_plus:
			case IDC_Calc_minus:
			case IDC_Calc_times:
			case IDC_Calc_divide:
			case IDC_Calc_ans:
			case IDC_Calc_e:
			case IDC_Calc_pi:
			case IDC_Calc_sqrt:
			case IDC_Calc_period:
			case IDC_Calc_power:
			case IDC_Calc_equals:
			case IDC_Calc_comma:
				AddText(LOWORD(wParam));
				break;
			case IDC_Calc_go:
			case IDOK:
				RunEquals();
				OneChan=1;
				break;
			case IDC_Calc_History:
				if (HIWORD(wParam)==LBN_DBLCLK)
					SelectHistory();
				break;
			}
			break;
	}
    return FALSE;
}

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	GTextBuff[0]=0;
	MaxTextDigits=6;
	InitGScript();
	SetMode("degrees");
	IsWindowsMode = 0;//Set the equation rendering mode to non-Windows-console specific
	InitDrawFuncs();

	bool loadconsole=0;
	loadconsole |= IsEqual(lpCmdLine,"console");
	loadconsole |= IsEqual(lpCmdLine,"\"console\"");
	loadconsole |= IsEqual(lpCmdLine,"CONSOLE");
	loadconsole |= IsEqual(lpCmdLine,"\"CONSOLE\"");

	if (loadconsole)
		DialogBox(hInstance, (LPCTSTR)IDD_Console, 0, (DLGPROC)ConsoleProc);
	else
		DialogBox(hInstance, (LPCTSTR)IDD_MainDlg, 0, (DLGPROC)MainProc);

	return 0;
}


