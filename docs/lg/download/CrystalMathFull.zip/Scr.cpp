
//Scr class, creates a window for use in text based displays

#ifndef HasStr2

int GetSize(char * other)
{
	int num=0;
	while (*other != 0)
	{
		num++;
		other++;
	}
	return num+1;
}

#endif

#include "Console.cpp"

//set to 1 if compiling for the Windows console (not just any Windows), other wise set to 0
bool IsWindowsMode = 1;

unsigned char GetSymbol(bool n, bool s, bool e, bool w)
{
	//Limited character set
	if (IsWindowsMode)
	{
		if ((n && s && w) && (!e))
			return Sl_nsw;
		if (s && e)
			return Sl_se;
		if (n && e)
			return Sl_ne;
		if (s && w)
			return Sl_sw;
		if (n && w)
			return Sl_nw;
	}
	else
	{
		if ((n && s && w) && (!e))
			return '/';
		if (s && e)
			return '/';
		if (n && e)
			return '\\';
		if (s && w)
			return '\\';
		if (n && w)
			return '/';
	}
	return '?';
}

int Center(int from, int to, int len)
{
	return from+((to-from-len)/2);
}

int Greater(int one, int two)
{
	if (one > two)
		return one;
	return two;
}

class Scr
{
public:
	char * Pixels;
	int Width, Height;

	void Swap(Scr * other);
	void Paste(int x, int y, Scr * other);
	void Resize(int width, int height);
	void Text(int x, int y, char * text);
	void JustText(char * text);
	void Line(int ix, int iy, int dx, int dy, int len);
	void Fill(char let);

	bool IsValid(int x, int y) {return (((x>=0) && (x<Width)) && ((y>=0) && (y<Height)));};
	char & Axs(int x, int y) {return Pixels[x+(Width*y)];};
	char Get(int x, int y) {if (!IsValid(x,y)) return 0; return Pixels[x+(Width*y)];};
	void Set(int x, int y, char let) {if (IsValid(x,y)) {Pixels[x+(Width*y)]=let;}};

	void Clear();
	void UnInit();
	void Init(int width, int height);

	Scr() {Pixels=0; Width=0; Height=0;};
	~Scr() {UnInit();};
};

void Scr::UnInit()
{
	if (!Pixels)
		return;
	delete [] Pixels;
	Width=0;
	Height=0;
}

void Scr::Init(int width, int height)
{
	UnInit();
	Width = width;
	Height = height;
	Pixels = new char [width * height];
	Clear();
}

void Scr::Clear()
{
	for (int i=0; i!=(Width*Height); i++)
		Pixels[i]=' ';
}

void Scr::Fill(char let)
{
	for (int i=0; i!=(Width*Height); i++)
		Pixels[i]=let;
}

void Scr::Text(int x, int y, char * text)
{
	if ((y < 0) || (y >= Height))
		return;
	int i=0;
	while (x < 0)
	{
		if (text[i]==0)
			return;
		i++;
		x++;
	}
	while ((text[i]) && (x <= Width))
	{
		Set(x,y,text[i]);
		x++;
		i++;
	}
}

void Scr::Line(int ix, int iy, int dx, int dy, int len)
{
	unsigned char let;
	if (IsWindowsMode)
		let = WinDirectionalLine(dx, dy);
	else
		let = DirectionalLine(dx,dy);

	while (len > 0)
	{
		Set(ix,iy,let);
		ix += dx;
		iy += dy;
		len--;
	}
}

void Scr::Resize(int width, int height)
{
	char * ans = new char [width * height];

	int x, y;
	for (y=0; y!=height; y++)
	{
		for (x=0; x!=width; x++)
		{
			if (IsValid(x,y))
				ans[x+(width*y)] = Pixels[x+(Width*y)];
			else
				ans[x+(width*y)] = ' ';
		}
	}

	delete [] Pixels;
	Pixels =  ans;
	Width  =  width;
	Height =  height;
}

void Scr::JustText(char * text)
{
	int size = GetSize(text);
	Init(size-1,1);
	int i=0;
	while (text[i])
	{
		Pixels[i]=text[i];
		i++;
	}
}

void Scr::Paste(int ix, int iy, Scr * other)
{
	int x, y;
	for (y=0; y!=other->Height; y++)
	{
		for (x=0; x!=other->Width; x++)
		{
			Set(x+ix,y+iy,other->Get(x,y));
		}
	}
}

void Scr::Swap(Scr * other)
{
	int width = Width;
	int height = Height;
	char * pixels = Pixels;

	Width = other->Width;
	Height = other->Height;
	Pixels = other->Pixels;

	other->Width = width;
	other->Height = height;
	other->Pixels = pixels;
}

/*void Display(Scr * scr)
{
	int x;
	for (int y=0; y!=scr->Height; y++)
	{
		for (x=0; x!=scr->Width; x++)
		{
			cout << scr->Pixels[x+(y * scr->Width)];
		}
		cout << endl;
	}
} */

