using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace BScript
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Button button1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public static Form1 MainWnd = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			MainWnd = this;

			int dh = this.textBox1.Height / 2;
			this.textBox1.Height -= dh;
			Point at = this.textBox2.Location;
			at.Y -= dh;
			this.textBox2.Location = at;
			this.textBox2.Height /= 4;

			at.Y += this.textBox2.Height+10;

			Viewer = new CompTreeViewer();
			Viewer.Location = at;
			Viewer.Size = new Size(textBox2.Width, Height-at.Y-40 );
			Viewer.Anchor = this.textBox2.Anchor;
			Viewer.Parent = this;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox1
			// 
			this.textBox1.AcceptsReturn = true;
			this.textBox1.AcceptsTab = true;
			this.textBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox1.Location = new System.Drawing.Point(8, 8);
			this.textBox1.Multiline = true;
			this.textBox1.Name = "textBox1";
			this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox1.Size = new System.Drawing.Size(224, 136);
			this.textBox1.TabIndex = 0;
			this.textBox1.Text = "var sum=0; for(var i=0; i!=10; i++) {sum+=i;} print(sum);";
			// 
			// textBox2
			// 
			this.textBox2.AcceptsReturn = true;
			this.textBox2.AcceptsTab = true;
			this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.textBox2.Location = new System.Drawing.Point(8, 152);
			this.textBox2.Multiline = true;
			this.textBox2.Name = "textBox2";
			this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox2.Size = new System.Drawing.Size(272, 160);
			this.textBox2.TabIndex = 1;
			this.textBox2.Text = "textBox2";
			// 
			// button1
			// 
			this.button1.Anchor = (System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right);
			this.button1.Location = new System.Drawing.Point(240, 8);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(48, 48);
			this.button1.TabIndex = 2;
			this.button1.Text = "Go";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(7, 11);
			this.ClientSize = new System.Drawing.Size(296, 318);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button1,
																		  this.textBox2,
																		  this.textBox1});
			this.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Name = "Form1";
			this.Text = "BScript Interpreter";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form3());
		}

		public CompTreeViewer Viewer;

		public void Print(string val)
		{
			this.textBox2.Text += val;
		}

		public void PrintLn(string val)
		{
			Print( val + "\r\n");
		}

		public double MyValue
		{
			get { return 666; }
			set
			{
				PrintLn( "was set to = " + value );
			}
		}
		public double FValue = 67;
		private bool doneonce = false;
		private void button1_Click(object sender, System.EventArgs e)
		{	
			if (doneonce)
			{
				BScript.Global.GGlobal.Reset();
				this.Viewer.Tree.Reset();
			}
			doneonce = true;

			Global.TypeNamespaces.Add( "BScript" );
			Global.GNamespace.AddVar("comptree", this.Viewer.Tree);

			BScript.Global.AddCode( this.textBox1.Text );

			if (true)
			{
				System.Timers.Timer timer = new System.Timers.Timer( 1000.0/15.0 );
				timer.Elapsed += new System.Timers.ElapsedEventHandler( OnTick );
				timer.Enabled = true;
			}

			/*
			if (!doneonce)
			{
				CB cb = BScriptCore.Compile( this.textBox1.Text );

				this.textBox2.Text = "";
				string code = cb.ToString();
				PrintLn( code );
				//return;
				PrintLn("");
				PrintLn("Output:");

				Global.GNamespace.AddVar("this", this);
				Global.GNamespace.AddVar("global", Global.GGlobal );
				Global.GNamespace.AddVar("comptree", this.Viewer.Tree);
				Global.GGlobal.AddBranch(cb, Global.GNamespace, null);

				Global.GGlobal.RunFrame();
				doneonce = true;
				this.Viewer.Invalidate();

				if (true)
				{
					System.Timers.Timer timer = new System.Timers.Timer( 1000.0/15.0 );
					timer.Elapsed += new System.Timers.ElapsedEventHandler( OnTick );
					timer.Enabled = true;
				}
			}
			else
			{
				Global.GGlobal.RunFrame();
				this.Viewer.Invalidate();
			}
			*/
		}

		public void OnTick(object sender, System.Timers.ElapsedEventArgs ea)
		{
			BScript.Global.RunFrame();
			this.Viewer.Invalidate();
		}
	}
}
