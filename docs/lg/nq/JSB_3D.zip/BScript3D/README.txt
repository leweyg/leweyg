
/*
	Simply drag and drop any of these .bs.txt files over
BScriptInterp.exe to execute them. You can also write your own and
launch them in the same way. The source code is in the src folder so you can check that out if you wish. Also please note that the 3D code is based on the "Drunken Hyena" tutorials (which are very good), which you can find on their website: http://www.drunkenhyena.com/

	I hope you enjoy these little demos, and possibly try writing a few on your own. You can find out more about bscript at:

http://www.leweyg.com/nq/branching

	All my best,
		-Lewey G. (lewey@leweyg.com)

P.S. Requirements: you will need the following to be able to run these demos:
	The .Net Framework
	Managed DirectX
*/