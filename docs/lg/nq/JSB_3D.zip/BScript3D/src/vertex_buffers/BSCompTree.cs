using System;
using System.Collections;
using System.Drawing; //for Color'
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;

namespace vertex_buffers
{
	public abstract class Transform
	{
		protected CompNode target;

		public CompNode Target
		{
			get { return target; }
			set
			{
				if (target!=null)
					target.Transforms.Remove( this );
				target = value;
				if (target!=null)
					target.Transforms.Add( this );
			}
		}
		public abstract void GetMatrix(ref Matrix ans);
	}

	public class ScaleTransform : Transform
	{
		public double x, y, z;

		public double All
		{
			get { return (x+y+z)/3; }
			set
			{
				x = value;
				y = value;
				z = value;
			}
		}

		public override void GetMatrix(ref Matrix ans)
		{
			//ans.RotateAxis( Axis, -((float)Environment.TickCount) / 450.0f );
			ans.Scale((float)x, (float)y, (float)z);
		}

		public ScaleTransform()
		{

		}

		public ScaleTransform(double ax, double ay, double az)
		{
			x = ax; y = ay; z = az;
		}
	}

	public class RotateTransform : Transform
	{
		public fpnt Axis;
		public float Angle;

		public double Rot
		{
			get { return Angle; }
			set { Angle = (float)value; }
		}
		public override void GetMatrix(ref Matrix ans)
		{
			ans.RotateAxis( Axis.AsVector, Angle );
		}

		public RotateTransform()
		{
			Axis = new fpnt(0, 0, 1);
			Angle = 0;
		}

		public RotateTransform(fpnt axis, float angle)
		{
			Axis = axis;
			Angle = angle;
		}
	}

	public class CompEnum
	{
		public delegate bool VisitHandler(CompEnum en, CompNode at);

		public VisitHandler Func;
		public Matrix WorldView;
		public Vector3 WorldOffset;
		public object Extra, Extra2, Extra3, Extra4, Result;
		public bool Done;

		public CompEnum(VisitHandler visitor)
		{
			Func = visitor;
			WorldView = Matrix.Identity;
			WorldOffset = new Vector3(0, 0, 0);
			Done = false;
		}
	}

	public class CompNode : IEnumerable
	{
		private CompNode parent;
		private ArrayList children;

		public fpnt Pos;
		public ArrayList Transforms;
		public Material Material;
		public fcolor Color;
		public object HitToken;

		public CompNode this [int i]
		{
			get
			{
				return (CompNode)children[i];
			}
			set
			{
				children[i] = value;
			}
		}

		public CompNode Parent
		{
			get { return parent; }
			set
			{
				if (parent!=null)
					parent.children.Remove( this );
				parent = value;
				if (parent!=null)
					parent.children.Insert(0, this );
			}
		}

		public void ClearChildren()
		{
			children.Clear();
		}

		public CompNode()
		{
			Pos = new fpnt(0, 0, 0);
			children = new ArrayList();
			Transforms = new ArrayList();
			Color = new fcolor();

			Material.Ambient = System.Drawing.Color.White;
			Material.Diffuse = System.Drawing.Color.White;
			Material.Specular = System.Drawing.Color.White;
			Material.SpecularSharpness = 10;
		}

		public virtual bool HitTest(Vector3 pos, Vector3 dir, out float dist) {dist=0; return false;}
		public virtual void SelfRender(Device dev) {}

		public void Render(Device dev, CompEnum ce)
		{
			Matrix orig;
			if (ce==null)
				orig = dev.Transform.World;
			else
				orig = ce.WorldView;

			if (this.Transforms.Count!=0)
			{
				Matrix work2 = Matrix.Identity;
				Matrix work1 = Matrix.Translation( Pos.AsVector );
				work1.Multiply( orig );
				bool use1 = true;

				for(int i=0; i<Transforms.Count; i++)
				{
					Transform t = (Transform)Transforms[i];
					if (use1)
					{
						t.GetMatrix( ref work2 );
						work2.Multiply( work1 );
					}
					else
					{
						t.GetMatrix( ref work1 );
						work1.Multiply( work2 );
					}
					use1 = !use1;
				}
				if (ce==null)
				{
					if (use1)
						dev.Transform.World = work1;
					else
						dev.Transform.World = work2;
				}
				else
				{
					if (use1)
						ce.WorldView = work1;
					else
						ce.WorldView = work2;
				}
			}
			else
			{
				Matrix work1 = Matrix.Translation( Pos.AsVector );
				work1.Multiply( orig );
				if (ce==null)
					dev.Transform.World = work1;
				else
					ce.WorldView = work1;
			}

			//if (ce!=null)
			//	ce.WorldOffset += this.Pos.AsVector;

			Material.AmbientColor = ColorValue.FromArgb( Color.AsInt );
			dev.Material = this.Material;

			if (ce==null)
				SelfRender(dev);
			else
				ce.Done = !ce.Func(ce, this);

			foreach(object ob in children)
			{
				if ((ce==null) || (!ce.Done))
					((CompNode)ob).Render( dev, ce );
			}

			//if (ce!=null)
			//	ce.WorldOffset -= this.Pos.AsVector;

			if (ce==null)
				dev.Transform.World = orig;
			else
				ce.WorldView = orig;
		}

		public IEnumerator GetEnumerator()
		{
			return children.GetEnumerator();
		}
	};

	public class Disk : CompMesh
	{
		private float radius;

		public double Radius
		{
			get { return radius; }
			set
			{
				radius = (float)value;
				mesh = Mesh.Cylinder(CompTree.Current.Device, radius, radius, 0.5f, 9, 1);
			}
		}

		public Disk()
		{
			Radius = 5;
		}
	}

	public class TextView : CompMesh
	{
		private string text;

		public string Text
		{
			get { return text; }
			set
			{
				text = value;
				TextMesh(text, 0.1f, 0.2f);
			}
		}

		public TextView()
		{
			text = "";
		}
	}

	public class Box : CompMesh
	{
		private float width, depth, height;

		public double Width
		{
			get { return width; }
			set { width = (float)value; Recalc(); }
		}
		public double Depth
		{
			get { return depth; }
			set { depth = (float)value; Recalc(); }
		}
		public double Height
		{
			get { return height; }
			set { height = (float)value; Recalc(); }
		}

		public double All
		{
			get { return width; }
			set
			{
				width=(float)value; depth=(float)value; height=(float)value;
				Recalc();
			}
		}

		private void Recalc()
		{
			mesh = Mesh.Box(CompTree.Current.Device, width, height, depth);
		}

		public Box(double w, double d, double h)
		{
			width = (float)w; depth = (float)d; height = (float)h;
			Recalc();
		}
		public Box()
		{
			All = 5;
		}
	}

	public class Block : CompMesh
	{
		private float sidelength;

		public double SideLength
		{
			get { return sidelength; }
			set
			{
				sidelength = (float)value;
				mesh = Mesh.Box(CompTree.Current.Device, sidelength, sidelength, sidelength);
			}
		}

		public double Width
		{
			get { return SideLength; }
			set { SideLength = value; }
		}
		public double Height
		{
			get { return SideLength; }
			set { SideLength = value; }
		}

		public Block()
		{
			SideLength = 10;
		}
	}

	/*
	public class Block : CompMesh
	{
		private float left, right, top, bottom, front, back;

		private void Reform()
		{
			mesh = Mesh.Box(CompTree.Current.Device, right-left, bottom-top, front-back);
		}

		public double Left {get{return left;}set{left=(float)value; Reform();}}
		public double Right{get{return right;}set{right=(float)value; Reform();}}

		public fpnt Center
		{
			get
			{
				return new fpnt( (left+right)/2,
					(top+bottom)/2,
					(front+back)/2 );
			}
		}

		public double SideLength
		{
			get 
			{
				return (right-left);
			}
			set
			{
				float hv = (float)value/2;
				left = -hv; right = hv;
				bottom = hv; top = -hv;
				back = -hv; front = hv;
				Reform();
			}
		}

		public Block()
		{
			SideLength = 2;
		}
	}
	*/

	public class CompLine : CompNode
	{
		public fpnt End1, End2;

		public override void SelfRender(Device dev)
		{
			Microsoft.DirectX.Vector3[] verts = new Vector3[2];
			verts[0] = End1.AsVector;
			verts[1] = End2.AsVector;
			dev.RenderState.Lighting = false;
			dev.DrawUserPrimitives( PrimitiveType.LineList, 2, verts);
			dev.RenderState.Lighting = true;
		}


		public override bool HitTest(Vector3 pos, Vector3 dir, out float dist)
		{
			dist = 0;
			return false;
		}

		public CompLine()
		{
			End1 = new fpnt(0, 0, 0);
			End2 = new fpnt(0, 0, 0);
		}
	}

	public class CompMesh : CompNode
	{
		protected Mesh mesh;

		public override void SelfRender(Device dev)
		{
			mesh.DrawSubset(0);
		}
		public override bool HitTest(Vector3 pos, Vector3 dir, out float dist)
		{
			IntersectInformation ii;
			dist = 0;
			bool didhit = mesh.Intersect(pos, dir, out ii);
			if (didhit)
				dist = ii.Dist;
			return didhit;
		}


		public void Cylinder(float r, float h)
		{
			mesh = Mesh.Cylinder( CompTree.Current.Device, r, r, h, 9, 1);
			mesh.ComputeNormals();
		}

		public void Sphere(float r)
		{
			mesh = Mesh.Sphere(CompTree.Current.Device, r, 9, 7);
			Color = new fcolor(  System.Drawing.Color.YellowGreen );
			mesh.ComputeNormals();
		}

		public void TextMesh(string str, float fs, float h)
		{
			System.Drawing.Font font = new System.Drawing.Font("Ariel", fs);
			mesh = Mesh.TextFromFont(CompTree.Current.Device, font, str, 0, h);
			mesh.ComputeNormals();
		}

		public void Tile(float r, float h)
		{
			r *= 2; h *= 2;
			mesh = Mesh.Box(CompTree.Current.Device, r, r, h);
			Color = new fcolor( System.Drawing.Color.CornflowerBlue );
			mesh.ComputeNormals();
		}

		public void Cube(float r)
		{
			r *= 2;
			mesh = Mesh.Box(CompTree.Current.Device, r, r, r);
			Color = new fcolor( System.Drawing.Color.CornflowerBlue );
			mesh.ComputeNormals();
		}
	}

	public struct fpnt
	{
		public float x, y, z;

		public fpnt Lerp(fpnt b, float t)
		{
			float ot = 1-t;
			fpnt ans;
			ans.x = x*t + b.x*ot;
			ans.y = y*t + b.y*ot;
			ans.z = z*t + b.z*ot;
			return ans;
		}

		public Vector3 AsVector
		{
			get
			{
				return new Vector3(x,y,z);
			}
		}

		public fpnt(double ax, double ay)
		{
			x = (float)ax; y = (float)ay; z = 0;
		}

		public fpnt(double ax, double ay, double az)
		{
			x = (float)ax; y = (float)ay; z = (float)az;
		}
	}

	public struct fcolor
	{
		public float red, green, blue;

		public int AsInt
		{
			get
			{
				int ans=0;
				ans |= ((int)(blue*255));
				ans |= ((int)(green*255)) << 8;
				ans |= ((int)(red*255)) << 16;
				return ans;
			}
		}

		public fcolor Lerp(fcolor b, float t)
		{
			fcolor ans;
			float ot = 1-t;
			ans.red = red*t + b.red*ot;
			ans.blue = blue*t + b.blue*ot;
			ans.green = green*t + b.green*ot;
			return ans;
		}

		public void ScaleBy(float f)
		{
			red *= f; green *= f; blue *= f;
		}

		public static fcolor FromColor(System.Drawing.Color col)
		{
			int rgb = col.ToArgb();
			fcolor ans;
			ans.blue = ((float)(rgb & 0xff)) / 255.0f; rgb>>=8;
			ans.green = ((float)(rgb & 0xff)) / 255.0f; rgb>>=8;
			ans.red = ((float)(rgb & 0xff)) / 255.0f; rgb>>=8;
			return ans;
		}

		public fcolor(System.Drawing.Color col)
		{
			this = FromColor(col);
		}

		public fcolor(string name)
		{
			this = FromColor( System.Drawing.Color.FromName(name) );
		}

		public fcolor(double r, double g, double b)
		{
			red = (float)r; green = (float)g; blue = (float)b;
		}
	}

	public class CompTree
	{
		public CompNode Root;
		public fpnt CameraPos, CameraLookAt, CameraUp;
		public bool IsWireFrame;
		public fcolor ClearColor;
		private Device device;

		public BScript.BSEvent OnHitNode;

		private static CompTree _curtree = null;
		public static CompTree Current
		{
			get { return _curtree; }
		}

		public void OnMouseUp(MouseEventArgs e)
		{
			Matrix proj = Device.Transform.Projection;
			Matrix view = Device.Transform.View;
			Matrix world = Device.Transform.World;

			Vector3 p1 = CameraPos.AsVector;

			Vector3 p2 = Vector3.Unproject( new Vector3(e.X, e.Y, 0.7f),
				Device.Viewport,
				proj,
				view,
				world );

			Vector3 dir = p2-p1;
			CompNode node = HitTest( p1, dir );

			if (false)
			{
				string mess;
				if (node==null)
					mess = "didn't hit";
				else if (node.HitToken==null)
					mess = "null token";
				else
					mess = "token=" + node.HitToken.ToString();
				mess += "  (" + dir.X + ", " + dir.Y + ", " + dir.Z + ")";
				MessageBox.Show(mess, "Here you go");
			}
			else
			{
				if (node==null)
					return;
				if (OnHitNode!=null)
					OnHitNode.Fire( node );
			}
		}

		public static Vector3 FromR4(Vector4 v)
		{
			return new Vector3(v.X/v.W, v.Y/v.W, v.Z/v.W);
		}

		private bool _helper_MeshIntersect(CompEnum ce, CompNode node, out float dist)
		{
			Vector3 from = (Vector3)ce.Extra;
			Vector3 dir = (Vector3)ce.Extra2;

			//Vector3 nf = from - ce.WorldOffset;
			Matrix m = ce.WorldView;
			m.Invert();

			Vector3 nd = FromR4( Vector3.Transform( from+dir, m ) );
			Vector3 nf = FromR4( Vector3.Transform( from, m ) );
			nd -= from;

			return node.HitTest(nf, dir, out dist);
		}

		private bool _func_BestHit(CompEnum ce, CompNode node)
		{
			float dist;
			bool didhit = _helper_MeshIntersect(ce, node, out dist);
			if (!didhit)
				return true;

			if ((ce.Extra3==null) || ( ((float)ce.Extra3) > dist ))
			{
				ce.Extra3 = dist;
				ce.Result = node;
			}
			return true;
		}

		private bool _func_SingleHit(CompEnum ce, CompNode node)
		{
			float dist;
			bool didhit = _helper_MeshIntersect(ce, node, out dist);
			if (didhit)
			{
				if ((ce.Result==null) || (node.HitToken!=null))
					ce.Result = node;
				if (node.HitToken!=null)
					return false;
			}
			return true;
		}

		public CompNode HitTest(Vector3 from, Vector3 dir)
		{
			CompEnum ce = new CompEnum(new CompEnum.VisitHandler(_func_SingleHit));//_func_BestHit));
			ce.Extra = from;
			ce.Extra2 = dir;

			Root.Render( Device, ce );

			return (CompNode)ce.Result;
		}

		public Device Device
		{
			get
			{
				return device;
			}
			set
			{
				device = value;
			}
		}

		public void Render(Device dev, float screenratio)
		{
			_curtree = this;
			device = dev;

			//Clear the render target
			dev.Clear( ClearFlags.Target | ClearFlags.ZBuffer, ClearColor.AsInt, 1.0f, 0);

			//Signal the device that we're beginning a new scene
			dev.BeginScene();

			//Set render states
			dev.RenderState.CullMode = Cull.None;
			dev.RenderState.ZBufferEnable = true;
			dev.RenderState.NormalizeNormals = true;
			dev.VertexFormat = VertexFormats.PositionNormal;



			Light l = dev.Lights[0];
			l.Type = LightType.Directional;
			l.Ambient = Color.White;
			l.AmbientColor = ColorValue.FromArgb( 0xcccccc );
			l.DiffuseColor = ColorValue.FromArgb( 0x333333 );
			l.SpecularColor = ColorValue.FromArgb( 0x222222 );
			float ang = ((float)Environment.TickCount) / 600.0f;
			l.Direction = new Vector3((float)Math.Sin(ang), 0.1f, (float)Math.Cos(ang));
			l.Enabled = true;

			dev.RenderState.Lighting = true;
			dev.RenderState.SpecularEnable = true;
			dev.RenderState.ShadeMode = ShadeMode.Phong;


			if (IsWireFrame)
				dev.RenderState.FillMode=FillMode.WireFrame;
			else
				dev.RenderState.FillMode=FillMode.Solid;

			//Setup the cameras:
			//dev.Transform.World = Matrix.RotationZ(
			//	Environment.TickCount / 450.0f );
			dev.Transform.World = Matrix.Identity;

			dev.Transform.View = Matrix.LookAtLH( 
				CameraPos.AsVector,
				CameraLookAt.AsVector,
				CameraUp.AsVector );

			dev.Transform.Projection = Matrix.PerspectiveFovLH( 
				(float)Math.PI / 4, screenratio, 0.1f, 100.0f );

			//Actually draw the tree
			Root.Render(dev, null);

			//Signal the device that we're done with our scene
			dev.EndScene();
		}

		public void Reset()
		{
			Root = new CompNode();

			CameraPos = new fpnt(0, 0, 15);
			CameraLookAt = new fpnt(0, 0, 0);
			CameraUp = new fpnt(0, 1, 0);
			ClearColor = new fcolor( 0.8f, 0.9f, 0.8f );

			IsWireFrame = false;
		}

		public CompTree()
		{
			_curtree = this;
			Reset();
		}
	}
}
