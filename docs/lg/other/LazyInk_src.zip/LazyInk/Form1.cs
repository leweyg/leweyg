using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using Microsoft.Ink;

namespace LazyInk
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.Button button3;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			//create a new "LazyArea" and put it in place of the
			//picture box (which was just there so i could design it)
			la = new LazyArea();
			la.Location = this.pictureBox1.Location;
			la.Size = this.pictureBox1.Size;
			la.Anchor = this.pictureBox1.Anchor;
			this.pictureBox1.Parent = null;
			la.Parent = this.groupBox1;
		}
		private LazyArea la;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.button3 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.pictureBox1});
			this.groupBox1.Location = new System.Drawing.Point(8, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(412, 228);
			this.groupBox1.TabIndex = 0;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Draw Here, then hit \'Start\'";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Anchor = (((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right);
			this.pictureBox1.Location = new System.Drawing.Point(8, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(396, 204);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// button1
			// 
			this.button1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button1.Location = new System.Drawing.Point(284, 240);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(88, 32);
			this.button1.TabIndex = 1;
			this.button1.Text = "Clear";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.button2.Location = new System.Drawing.Point(204, 240);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(72, 32);
			this.button2.TabIndex = 2;
			this.button2.Text = "Start";
			this.button2.Click += new System.EventHandler(this.button2_Click_1);
			// 
			// checkBox1
			// 
			this.checkBox1.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
			this.checkBox1.Location = new System.Drawing.Point(124, 244);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(74, 24);
			this.checkBox1.TabIndex = 3;
			this.checkBox1.Text = "Auto Fall";
			this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
			// 
			// button3
			// 
			this.button3.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left);
			this.button3.Location = new System.Drawing.Point(8, 240);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(56, 32);
			this.button3.TabIndex = 4;
			this.button3.Text = "Info";
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 278);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.button3,
																		  this.checkBox1,
																		  this.button2,
																		  this.button1,
																		  this.groupBox1});
			this.Name = "Form1";
			this.Text = "Lazy Ink";
			this.groupBox1.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.la.ClearInk();
			this.Refresh();
		}

		private void button2_Click(object sender, System.EventArgs e)
		{
			this.Refresh();
		}

		private void checkBox1_CheckedChanged(object sender, System.EventArgs e)
		{
			la.AutoFall = checkBox1.Checked;
		}

		private void button2_Click_1(object sender, System.EventArgs e)
		{
			la.FallAll();
		}

		private void button3_Click(object sender, System.EventArgs e)
		{
			string mess = "Lazy Ink\n\nWritten by Lewey Geselowitz";
			mess += "\n\nMore info, the source code, and actual apps at:\nhttp://plaza.ufl.edu/lewey";
			MessageBox.Show(this, mess);
		}
	}

	public class StrokePhysObject
	{
		private Stroke mStroke;

		/// <summary>
		/// angle the stroke started at
		/// </summary>
		private double mBaseAngle;

		/// <summary>
		/// The current angle you want the ink to hang at
		/// </summary>
		private double mCurAngle;

		/// <summary>
		/// the previous angle the ink was at
		/// must keep track of this because transformations
		/// and additive and I can't figure out how to clear
		/// the transformation.
		/// </summary>
		private double mLastAngle;

		private double mAniState;
		private System.DateTime mStartTime;

		public bool Done
		{
			get 
			{
				return (mAniState >= 1.0);
			}
		}

		public static Point CenterOfMass(Stroke s)
		{
			//sort of cheap, using average points location
			//as the center of mass. You should really take
			//into consideration the length of the line to
			//propertly calculate the center. On the other
			//hand "ink" doesn't really have a center of mass
			//so it's all just to look good anyway.

			Point[] pts = s.GetPoints();
			Point ans = new Point(0, 0);
			for (int i=0; i<pts.Length; i++)
			{
				ans.X += pts[i].X;
				ans.Y += pts[i].Y;
			}
			ans.X /= pts.Length;
			ans.Y /= pts.Length;
			return ans;
		}

		public StrokePhysObject(Stroke s)
		{
			mStroke = s;

			int ilast = mStroke.PacketCount-1;
			Point last = mStroke.GetPoint(ilast);
			Point center = CenterOfMass(mStroke);
			double dx = (last.X - center.X);
			double dy = (last.Y - center.Y);
			mBaseAngle = ((180.0 / Math.PI) * Math.Atan2(dx, dy));
			if (mBaseAngle < 0)
				mBaseAngle += 360.0;
			mCurAngle = mBaseAngle;
			mLastAngle = mBaseAngle;

			mAniState = 0.0;
			mStartTime = System.DateTime.Now;
			SetTransform();
		}

		public static long Duration
		{
			get { return (6 * 10000000); }
		}

		public void UpdateTime(DateTime now)
		{
			long lasted = (now.Ticks - mStartTime.Ticks);
			if (lasted >= Duration)
				mAniState = 1.0;
			else
				mAniState = ((double)lasted) / ((double)Duration);

			double x = Math.Cos( mAniState * 8.5 * Math.PI );
			x *= ((1.0 - mAniState) * (1.0 - mAniState));

			mCurAngle = 180 + (x * (mBaseAngle - 180));
		}

		public void SetTransform()
		{
			Matrix mat = new Matrix();

			double delta = -(mCurAngle - mLastAngle);
			if (delta == 0.0)
				return;
			mLastAngle = mCurAngle;

			int last = mStroke.PacketCount-1;
			Point p = mStroke.GetPoint(last);
			mat.Translate( -p.X, -p.Y, MatrixOrder.Append );
			mat.Rotate( (float)delta, MatrixOrder.Append );
			mat.Translate( p.X, p.Y, MatrixOrder.Append );

			mStroke.Transform( mat );
		}
	};

	/// <summary>
	/// This is an Ink Control that actually does the Lazy ink stuff
	/// </summary>
	public class LazyArea : System.Windows.Forms.Control
	{
		private InkCollector ic;
		private System.Collections.ArrayList transforms;
		private bool autofall = false;

		public bool AutoFall
		{
			get { return autofall; }
			set { autofall = value; }
		}

		public LazyArea()
		{
			this.SetStyle( System.Windows.Forms.ControlStyles.UserPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.AllPaintingInWmPaint, true);
			this.SetStyle( System.Windows.Forms.ControlStyles.DoubleBuffer, true );

			ic = new InkCollector(this.Handle);

			ic.DefaultDrawingAttributes.AntiAliased = true;
			ic.DefaultDrawingAttributes.IgnorePressure = false;
			ic.DefaultDrawingAttributes.FitToCurve = true;
			ic.Enabled = true;

			this.Paint += new System.Windows.Forms.PaintEventHandler(this.onPaint);
			ic.Stroke += new InkCollectorStrokeEventHandler(onStroke);


			transforms = new ArrayList();

			System.Timers.Timer aTimer = new System.Timers.Timer();
			aTimer.Elapsed+=new System.Timers.ElapsedEventHandler(onTimedEvent);
			aTimer.Interval=30;
			aTimer.Enabled=true;
		}

		protected override void OnResize(EventArgs ea)
		{
			this.Refresh();
		}

		public void FallAll()
		{
			transforms.Clear();
			foreach(Stroke s in ic.Ink.Strokes)
			{
				transforms.Add( new StrokePhysObject(s) );
			}
		}

		public void ClearInk()
		{
			ic.Ink.DeleteStrokes();
			transforms.Clear();
			this.Refresh();
		}

		private void onPaint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
			e.Graphics.FillRectangle( System.Drawing.Brushes.White, e.ClipRectangle );
			Rectangle rect = System.Drawing.Rectangle.FromLTRB(0, 0, Size.Width-1, Size.Height-1);
			e.Graphics.DrawRectangle( System.Drawing.Pens.Black, rect );
			Renderer rend = new Renderer();
			foreach(Stroke s in ic.Ink.Strokes)
			{
				rend.Draw(e.Graphics, s);
			}
		}

		protected void onStroke(object ob, InkCollectorStrokeEventArgs ica)
		{
			if (autofall)
			{
				StrokePhysObject sa = new StrokePhysObject(ica.Stroke);
				sa.SetTransform();
				transforms.Add(sa);
				this.Refresh();
			}
		}

		protected void onTimedEvent(object nada, System.Timers.ElapsedEventArgs eea)
		{
			if (transforms.Count == 0)
				return;

			DateTime dt = System.DateTime.Now;
			foreach(object ob in transforms)
			{
				StrokePhysObject sa = (StrokePhysObject)ob;
				sa.UpdateTime(dt);
				sa.SetTransform();
				if (sa.Done)
				{
					transforms.Remove(sa);
				}
			}
			this.Refresh();
		}
	};
}
