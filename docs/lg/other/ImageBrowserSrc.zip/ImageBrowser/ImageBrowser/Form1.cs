using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace ImageBrowser
{
    public partial class Form1 : Form
    {
        public ImageHandle MainImage = null;
        public ImageHandle SecondaryImage = null;
        public List<string> History = new List<string>();
        public int HistoryIndex = 0;
        public bool Inited = false;
        public bool IsEditMode = false;

        // Editor Mode Stuff:
        public FlowPair CurrentPair = null;
        public float2 DebugPoint = float2.Zero;
        public bool IsEditDrawGuide = true;
        public mcDrag CurrentDrag = null;

        public class mcDrag
        {
            public FlowPair Pair;
            public FlowLine Line;
        }

        private bool mShowMainUI = false;
        public bool ShowMainUI
        {
            get { return mShowMainUI; }
            set 
            {
                bool old = mShowMainUI;
                mShowMainUI = value;
                if (old != value)
                {
                    this.groupBox1.Visible = value;
                    this.groupBox3.Visible = value;
                    if (mShowMainUI)
                        ShowNavUI = true;
                    this.Invalidate();
                }
            }
        }

        private bool mShowNavUI = true;
        public bool ShowNavUI
        {
            get { return mShowNavUI; }
            set
            {
                bool old = mShowNavUI;
                mShowNavUI = value;
                if (old != value)
                {
                    this.groupBox2.Visible = value;
                    this.Invalidate();
                }
            }
        }

        public static Form1 TheOnly = null;
        public Form1()
        {
            TheOnly = this;
            InitializeComponent();
            string s = "http://www.leweyg.com/lc/screens/Shuzzle_7.jpeg";
            string[] args = Environment.GetCommandLineArgs();
            if ( args.Length > 1 )
                s = args[1];
            MainText = s;

            this.textBox1.TextChanged += new EventHandler(textBox1_TextChanged);
            this.DragDrop += new DragEventHandler(Form1_DragDrop);
            this.DragEnter += new DragEventHandler(Form1_DragEnter);
            this.AllowDrop = true;

            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
        }

        void Form1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        void Form1_DragDrop(object sender, DragEventArgs e)
        {
            string[] formats = e.Data.GetFormats();
            if (e.Data.GetDataPresent("FileName"))
            {
                string[] strs = (string[])e.Data.GetData("FileName");
                MainText = strs[0];
                DoGo();
            }
            else if (e.Data.GetDataPresent("Text"))
            {
                string s = e.Data.GetData("Text").ToString();
                MainText = s;
                DoGo();
            }
            else
            {
                MessageBox.Show("Unknown drag type");
            }
        }

        void textBox1_TextChanged(object sender, EventArgs e)
        {
            MainText = this.textBox1.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Focus();

            //this.KeyDown += new KeyEventHandler(Form1_KeyDown);
            //DoGo();
            foreach (Button b in AllButtons())
            {
                string s = b.AccessibleDescription;
                if ((s != null) && (s != ""))
                {
                    this.toolTip1.SetToolTip(b, s);
                }
            }

            if (IsEscherMode)
            {
                ShowNavUI = false;
            }
        }

        void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            DoKey(e.KeyCode);
        }

        public List<StringPart> Parts = new List<StringPart>();
        public StringPart SelectedPart = null;
        public string MainText
        {
            get { return this.textBox1.Text; }
            set 
            {
                if (this.textBox1.Text == value)
                    return;
                this.textBox1.Text = value;

                SelectedPart = null;
                Parts.Clear();
                StringPart cur = new StringPart( value, -1, -1 );

                for (int i = 0; i < value.Length; i++)
                {
                    char let = value[i];
                    if ((let >= '0') && (let <= '9'))
                    {
                        if (cur.Start < 0)
                            cur.Start = i;
                    }
                    else
                    {
                        if (cur.Start >= 0)
                        {
                            cur.Length = i - cur.Start;
                            cur.Owner = value;

                            Parts.Add(cur);
                            SelectedPart = cur;

                            cur = new StringPart(value, -1, -1);
                        }
                    }
                }
                RedoParts();
                Status = UIStatus.Loading;

                if (HistoryIndex == History.Count)
                {
                    History.Add(value);
                    HistoryIndex++;
                }
                else if (History[HistoryIndex] == value)
                {
                    //already there, don't worry about it
                }
                else
                {
                    History[HistoryIndex++] = value;
                    while (History.Count > HistoryIndex)
                        History.RemoveAt(History.Count - 1);
                }
            }
        }

        public void RedoParts()
        {
            string s = "";
            foreach (StringPart sp in Parts)
            {
                if (sp == SelectedPart)
                {
                    s += ">>> ";
                }
                s += sp.ToString();
                if (sp == SelectedPart)
                {
                    s += " <<<";
                }
                s += "   ";
            }
            this.label1.Text = s;
        }

        void DoGo()
        {
            SecondaryImage = MainImage;
            MainImage = FileStore.DownloadImage(MainText, FilePri.Fastest);
            if (!MainImage.IsReady)
            {
                MainImage.OnReadyChanged += new CHandle.HandleChangeEvent(MainImage_OnReadyChanged);
                MainImage.OnFailedChanged += new CHandle.HandleChangeEvent(MainImage_OnFailedChanged);
            }
            else
            {
                mcReset();
                Status = UIStatus.Showing;
            }
            this.Focus();
            this.Invalidate();
        }

        void MainImage_OnFailedChanged(IHandle handle)
        {
            MainImage = SecondaryImage;
            SecondaryImage = null;
            Status = UIStatus.Failed;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DoGo();
        }

        void MainImage_OnReadyChanged(IHandle handle)
        {
            if (handle.IsReady)
            {
                Status = UIStatus.Showing;
                mcReset();
                this.Invalidate();
            }
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            this.Invalidate();
        }

        public enum UIStatus
        {
            Showing,
            Loading,
            Failed,
            Initializing,
        }

        private UIStatus mStatus = UIStatus.Initializing;
        public UIStatus Status
        {
            get { return mStatus; }
            set 
            { 
                mStatus = value;
            }
        }

        IEnumerable<Button> AllButtons()
        {
            yield return this.button1;
            yield return this.button2;
            yield return this.button3;
            yield return this.button4;
            yield return this.button5;
            yield return this.button6;
            yield return this.button7;
            yield return this.button8;
            yield return this.button9;
            yield return this.button10;
        }

        protected Brush BackBrush = null;
        protected Color LastColor = Color.DodgerBlue;
        public Color MyBackgroundColor = Color.Maroon;
        protected override void OnPaintBackground(PaintEventArgs e)
        {
            MyBackgroundColor = Color.Maroon;
            ImageHandle handle = VisibleImage;
            if ((handle != null)&&(handle.IsReady))
                MyBackgroundColor = handle.BackgroundColor;

            if ((BackBrush == null) || (LastColor != MyBackgroundColor))
            {
                BackBrush = new SolidBrush(MyBackgroundColor);
                LastColor = MyBackgroundColor;
            }
            e.Graphics.FillRectangle(BackBrush, 0, 0, Width - 1, Height - 1);
        }

        public float2 MouseStart = float2.Zero;
        public bool IsRightDown = false;
        public mcSpace StartNextSpace;
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            if (IsEscherMode)
            {
                if (e.Button == MouseButtons.Left)
                {
                    MouseStart = new float2(e.Location);
                    Matrix m = ScreenSpace.IntoMatrix();

                    CurrentDrag = null;
                    foreach (FlowPair p in MainImage.Diagram.Lines)
                    {
                        FlowPair q = p.Transform(m);
                        if (q.Contains(MouseStart))
                        {
                            CurrentDrag = new mcDrag();
                            CurrentDrag.Pair = p;
                        }
                    }
                }
                if (e.Button == MouseButtons.Right)
                {
                    StartNextSpace = NextScreenSpace;

                    MouseStart = new float2(e.Location);
                    IsRightDown = true;
                    float2 loc = new float2(e.Location);
                    IsShowNextSpace = true;
                    float2 top = float2.One.OnlyY * -50.0f + loc;
                    NextScreenSpace.TopLeft = top;
                    NextScreenSpace.Down = loc - top;
                    NextScreenSpace.Right = NextScreenSpace.Down.Cross;
                    this.Invalidate();
                }
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                    ShowNavUI = true;
            }
        }

        ToolStripMenuItem GenMenuItem(StringPart sp)
        {
            ToolStripMenuItem mi = new ToolStripMenuItem(sp.JustPart);
            mi.Tag = sp;
            mi.Click += new EventHandler(mi_Click);
            if (sp == SelectedPart)
                mi.Checked = true;

            if (!sp.HasReplacement)
            {
                int num;
                if (int.TryParse(sp.JustPart, out num))
                {
                    StringPart cp;
                    string rep;
                    
                    for (int di = 3; di >= 1; di--)
                    {
                        if (TryApplyDelta(sp.JustPart, di, out rep))
                        {
                            cp = new StringPart(sp);
                            cp.Replacement = rep;
                            mi.DropDownItems.Add(GenMenuItem(cp));
                        }
                    }

                    ToolStripMenuItem mid = new ToolStripMenuItem("Arrow Keys");
                    mid.Tag = sp;
                    mid.Click += new EventHandler(mi_Click);
                    mi.DropDownItems.Add(mid);

                    for (int di = -1; di >= -3; di--)
                    {
                        if (TryApplyDelta(sp.JustPart, di, out rep))
                        {
                            cp = new StringPart(sp);
                            cp.Replacement = rep;
                            mi.DropDownItems.Add(GenMenuItem(cp));

                            if (rep.StartsWith("0") && !sp.JustPart.StartsWith("0")
                                && (rep.Length > 1))
                            {
                                cp = new StringPart(sp);
                                cp.Replacement = rep.Substring(1);
                                mi.DropDownItems.Add(GenMenuItem(cp));
                            }
                        }
                    }
                }
            }

            return mi;
        }

        public void BringUpMenu(Point pnt)
        {
            this.placeHolderItemToolStripMenuItem.Text = MainText;
            ToolStrip ts = this.tHEURLToolStripMenuItem.Owner;
            for (int i = 0; i < ts.Items.Count; )
            {
                if (ts.Items[i] != this.tHEURLToolStripMenuItem)
                    ts.Items.RemoveAt(i);
                else
                    i++;
            }

            foreach (StringPart sp in Parts)
            {
                ToolStripMenuItem mi = GenMenuItem(sp);
                ts.Items.Add(mi);
            }

            this.contextMenuStrip1.Show(this, pnt);
        }

        int mcCurrentIndex = 0;
        public bool IsRotateMode = false;
        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            IsRotateMode = false;
            if (IsEscherMode)
            {
                IsRotateMode = false;
                if (e.Button == MouseButtons.Left && IsRightDown)
                {
                    IsRotateMode = true;
                    IsShowNextSpace = false;
                    CurrentDrag = null;
                }
                else if (e.Button == MouseButtons.Right)
                {
                    IsRightDown = false;

                    float2 loc = new float2(e.Location);
                    IsShowNextSpace = false;
                    if ((loc - MouseStart).Length < 5.0f)
                    {
                        BringUpMenu(e.Location);
                    }
                    else if (IsEditMode)
                    {
                        float2 ia = NextScreenSpace.TopLeft;
                        float2 ib = NextScreenSpace.TopLeft + NextScreenSpace.Down;
                        PointF[] eyes = { ia.AsPointF, ib.AsPointF };
                        ScreenSpace.OutOfMatrix().TransformPoints(eyes);
                        float2 a = new float2(eyes[0]);
                        float2 b = new float2(eyes[1]);

                        if (CurrentPair == null)
                            CurrentPair = new FlowPair(a, b, a, b);
                        else
                        {
                            CurrentPair.Bottom = new FlowLine(a, b);
                            //CurrentPair.Sort();
                            MainImage.Diagram.Lines.Add(CurrentPair);
                            CurrentPair = null;
                        }
                        NextScreenSpace = StartNextSpace;
                    }
                    this.Invalidate();
                }
            }
            else
            {
                if (e.Button == MouseButtons.Right)
                {
                    BringUpMenu(e.Location);
                }
            }
        }

        void mi_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem mi = (ToolStripMenuItem)sender;
            StringPart sp = ((StringPart)mi.Tag);
            if (sp.HasReplacement)
            {
                string s = sp.ReplacedWith(sp.Replacement);
                MainText = s;
                DoGo();
            }
            else
            {
                SelectedPart = sp;
                RedoParts();
            }
        }

        void DoKey(Keys k)
        {
            if (k == Keys.Space)
            {
                ShowNavUI = false;
                ShowMainUI = false;
            }
            switch (k)
            {
                case Keys.Up:
                    DoNextNumberSet(-1);
                    break;
                case Keys.Down:
                    DoNextNumberSet(1);
                    break;
                case Keys.Enter:
                    if (ShowMainUI || ShowNavUI)
                    {
                        ShowMainUI = false;
                        ShowNavUI = false;
                    }
                    else
                    {
                        ApplyDelta(1);
                    }
                    break;
                case Keys.M:
                case Keys.MediaNextTrack:
                case Keys.MediaPreviousTrack:
                case Keys.Next:
                    BringUpMenu(this.groupBox2.Location);
                    break;
                case Keys.N:
                    ShowNavUI = true;
                    break;
                case Keys.Right:
                case Keys.Space:
                    ApplyDelta(1);
                    break;
                case Keys.Left:
                    ApplyDelta(-1);
                    break;
            }
        }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
            DoKey(e.KeyCode);
        }

        protected Point LastMouse = new Point(0, 0);
        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);

            if (!Inited)
            {
                Inited = true;
                DoGo();
            }

            if (IsEscherMode)
            {
                if (e.Button == MouseButtons.Left)
                {
                    if (CurrentDrag!=null)
                    {
                        PointF[] eyes = { (new float2(e.Location)).AsPointF, (new float2(LastMouse)).AsPointF };
                        ScreenSpace.OutOfMatrix().TransformPoints(eyes);
                        float2 a = new float2(eyes[0]);
                        float2 b = new float2(eyes[1]);

                        FlowLine fa = CurrentDrag.Pair.LineThrough(a);
                        FlowLine fb = CurrentDrag.Pair.LineThrough(b);

                        mcSpace sa = new mcSpace();
                        sa.TopLeft = fa.A;
                        sa.Down = (fa.B - fa.A);
                        sa.Right = sa.Down.Perpendicular;

                        mcSpace sb = new mcSpace();
                        sb.TopLeft = fb.A;
                        sb.Down = (fb.B - fb.A);
                        sb.Right = sb.Down.Perpendicular;

                        Matrix toscreen = ScreenSpace.IntoMatrix();

                        mcFullStep( sb.TransformBy(toscreen), sa.TransformBy(toscreen));
                        DebugPoint = a;
                    }
                    else
                    {
                        float2 diff = (new float2(LastMouse) - new float2(e.Location));
                        this.ScreenSpace.TopLeft += diff * -1.0f;
                        this.NextScreenSpace.TopLeft += diff * -1.0f;
                        mcStep(new float2(e.Location), diff.Length/((float)Width));

                        DebugPoint = float2.Zero;
                    }


                    this.Invalidate();
                }
                if (e.Button == MouseButtons.Right)
                {
                    //IsShowNextSpace = false;
                    float2 loc = new float2(e.Location);

                    mcSpace oldspace = NextScreenSpace;
                    float2 bottom = NextScreenSpace.Down + NextScreenSpace.TopLeft;
                    NextScreenSpace.TopLeft = loc;
                    NextScreenSpace.Down = bottom - loc;
                    NextScreenSpace.Right = NextScreenSpace.Down.Cross;

                    if (IsRotateMode)
                    {
                        mcFullStep(oldspace, NextScreenSpace );
                    }

                    /*
                    if (NextScreenSpace.Down.Length > 10.0f)
                    {
                        float2 diff = (new float2(LastMouse) - new float2(e.Location));
                        mcStep(new float2(e.Location), 10.0f * diff.Length / ((float)Width));
                    }
                    */
                    this.Invalidate();

                }
            }
            else
            {
                if (e.Button == MouseButtons.Left)
                {
                    float2 diff = (new float2(LastMouse) - new float2(e.Location));
                    ViewOffset -= diff;
                    this.Invalidate();
                }
            }

            LastMouse = e.Location;
        }

        ImageHandle VisibleImage
        {
            get
            {
                ImageHandle handle = null;
                if ((MainImage != null) && (MainImage.IsFailed) )
                {
                    MainImage = SecondaryImage;
                    SecondaryImage = null;
                }

                if (MainImage != null)
                {
                    if (MainImage.IsReady)
                    {
                        handle = MainImage;
                    }
                    else if ((SecondaryImage != null) && (SecondaryImage.IsReady))
                    {
                        handle = SecondaryImage;
                    }
                }
                return handle;
            }
        }




        //Escher Mode:
        public bool IsEscherMode = true;
        public mcSpace TextureSpace = new mcSpace();
        public mcSpace ScreenSpace = new mcSpace();
        public mcSpace NextScreenSpace = new mcSpace();
        public Matrix TextureToScreen = new Matrix();
        public bool IsShowNextSpace = false;

        void mcReset()
        {
            int maxw = Math.Max(this.MainImage.Image.Width, this.MainImage.Image.Height);
            TextureSpace.TopLeft = float2.Zero;
            TextureSpace.Right = new float2(maxw, 0);
            TextureSpace.Down = new float2(0,maxw);
            TextureSpace.TopLeft = new float2((MainImage.Image.Width - maxw) / 2, (MainImage.Image.Height - maxw) / 2);

            float r = ((float)MainImage.Image.Width) / ((float)MainImage.Image.Height);
            float myr = ((float)Width) / ((float)Height);

            ScreenSpace.TopLeft = float2.Zero;
            if (myr > 1)
            {
                float2 center = (new float2(Width, Height)) * 0.5f;
                ScreenSpace.TopLeft = new float2(center.X - myr, 0);
                ScreenSpace.Right = new float2(1, 0);
                ScreenSpace.Down = new float2(0, -1);

                /*
                float f = ((float)MainImage.Image.Width) / ((float)MainImage.Image.Height);
                ScreenSpace.Right = new float2(f, 0);
                ScreenSpace.Down = new float2(0, f);
                float w = (float)Width;
                ScreenSpace.TopLeft = new float2(w*f / 2, 0);
                */
            }
            else
            {
                float f = ((float)MainImage.Image.Width) / ((float)MainImage.Image.Height);
                ScreenSpace.Right = new float2(f, 0);
                ScreenSpace.Down = new float2(0, f);
            }

            NextScreenSpace = ScreenSpace;
        }

        void mcFullStep(mcSpace from, mcSpace to)
        {
            Matrix m = new Matrix();

            Matrix mfrom = from.IntoMatrix();
            Matrix mto = to.IntoMatrix();
            // mfrom * m == mto
            // m = mto * inv( mfrom )
            mfrom.Invert();
            mto.Multiply(mfrom);
            m = mto;
            
            //NextScreenSpace = NextScreenSpace.TransformBy(m);
            ScreenSpace = ScreenSpace.TransformBy(m);
            //TextureSpace = TextureSpace.TransformBy(m);
        }

        void mcFullStepOutOf(mcSpace from, mcSpace to)
        {
            Matrix m = new Matrix();

            Matrix mfrom = from.OutOfMatrix();
            Matrix mto = to.OutOfMatrix();
            mfrom.Invert();
            mto.Multiply(mfrom);
            m = mto;

            ScreenSpace = ScreenSpace.TransformBy(m);
        }

        void mcStep(float2 at, float delta)
        {
            Matrix m = new Matrix();
            float mult = NextScreenSpace.Down.Normalized.X;
            float ny = NextScreenSpace.Down.Normalized.Y;
            if (ny < 0)
                mult += 1.0f * ((mult > 0)? 1 : -1.0f);
            m.RotateAt(delta * mult * 200.5f, at.AsPointF);

            NextScreenSpace = NextScreenSpace.TransformBy(m);
            ScreenSpace = ScreenSpace.TransformBy(m);
        }

        public float2 TexToScreen(float2 t)
        {
            return ScreenSpace.OutOf(TextureSpace.OutOf(t));
        }

        void mcDrawFlow(Graphics g, Pen p, FlowLine line)
        {
            g.DrawLine(p, line.A.AsPoint, line.B.AsPoint);
        }

        void mcDrawFlow(Graphics g, Pen p, FlowPair pair)
        {
            mcDrawFlow(g, p, pair.Across(0));
            mcDrawFlow(g, p, pair.Across(1));
            mcDrawFlow(g, p, pair.Along(0));
            mcDrawFlow(g, p, pair.Along(1));
            mcDrawFlow(g, p, pair.Across(0.5f));
            mcDrawFlow(g, p, pair.Along(0.5f));

            if (DebugPoint != float2.Zero)
            {
                mcDrawFlow(g, p, pair.LineThrough(DebugPoint));
                mcDrawFlow(g, p, pair.Alternate.LineThrough(DebugPoint));
            }
        }

        private static bool mcIsSetup = false;
        void mcDraw(Graphics g)
        {
            if (!mcIsSetup)
            {
                mcIsSetup = true;
                mcReset();
            }

            Matrix keep = g.Transform;
            Matrix m = ScreenSpace.IntoMatrix();
            //m.Multiply(TextureSpace.IntoMatrix());
            g.Transform = m;
            g.DrawImage(MainImage.Image, new Point(0,0));
            Pen pen = Pens.CornflowerBlue;
            if (IsEditMode && IsEditDrawGuide)
            {
                if (CurrentPair != null)
                {
                    float2 a = CurrentPair.Top.A;
                    float2 b = CurrentPair.Top.B;
                    g.DrawLine(pen, a.AsPoint, b.AsPoint);
                }
                foreach (FlowPair p in MainImage.Diagram.Lines)
                {
                    mcDrawFlow(g, pen, p);
                }
            }
            g.Transform = keep;
            pen = Pens.White;

            if (IsShowNextSpace)
            {
                float2 bottom = NextScreenSpace.Into(float2.Zero);
                float2 top = NextScreenSpace.Into(new float2(0, 1));
                float2 left = NextScreenSpace.Into(new float2(0.1f, 0.1f));
                float2 rght = NextScreenSpace.Into(new float2(-0.1f, 0.1f));
                g.DrawLine(pen, bottom.AsPoint, top.AsPoint);
                g.DrawLine(pen, bottom.AsPoint, left.AsPoint);
                g.DrawLine(pen, left.AsPoint, rght.AsPoint);
                g.DrawLine(pen, rght.AsPoint, bottom.AsPoint);
            }
        }

        public struct mcSpace
        {
            public float2 TopLeft, Right, Down;

            public float2 OutOf(float2 f)
            {
                float2 d = (f - TopLeft);
                float x = Right.Normalized.Dot(d);
                float y = Down.Normalized.Dot(d);
                return new float2(x, y);
            }

            public float DownAngle
            {
                get
                {
                    return (float)Math.Atan2(Down.Y, Down.X);
                }
            }

            public float2 Into(float2 f)
            {
                return TopLeft + Right.Normalized * f.X + Down.Normalized * f.Y;
            }

            public Matrix IntoMatrix()
            {
                Matrix m = new Matrix(Right.X, Right.Y, Down.X, Down.Y, TopLeft.X, TopLeft.Y);
                return m;
            }

            public Matrix OutOfMatrix()
            {
                Matrix m = IntoMatrix();
                m.Invert();
                return m;
            }

            public mcSpace TransformBy(Matrix m)
            {
                PointF[] pnts = new PointF[3];
                pnts[0] = TopLeft.AsPointF;
                pnts[1] = (Down + TopLeft).AsPointF;
                pnts[2] = (Right + TopLeft).AsPointF;
                m.TransformPoints(pnts);
                mcSpace ans = new mcSpace();
                ans.TopLeft = new float2(pnts[0]);
                ans.Down = new float2(pnts[1]) - ans.TopLeft;
                ans.Right = new float2(pnts[2]) - ans.TopLeft;
                return ans;
            }
        }

        ImageHandle mLastShown = null;
        float2 ViewOffset = float2.Zero;
        float2 LastSize = float2.One;
        float2 LastCenter = float2.One;
        float ViewScale = 1.0f;

        protected override void OnPaint(PaintEventArgs e)
        {
            ImageHandle handle = VisibleImage;

            if (mLastShown != handle)
            {
                ViewOffset = float2.Zero;
                ViewScale = 1.0f;
            }
            mLastShown = handle;

            Color c = (Status == UIStatus.Loading) ? Color.Orange : Color.CornflowerBlue;
            if (Status == UIStatus.Failed) c = Color.Red;
            foreach (Button b in AllButtons())
            {
                if ( b != null )
                    b.BackColor = c;
            }
            string small_id = ((SelectedPart != null) ? (Parts.IndexOf(SelectedPart)+1).ToString() + " : " + SelectedPart.JustPart : "Go");
            this.Text = Status.ToString() + " - " + small_id + " - Image Browser";
            if (IsEditMode)
                this.Text = "Design Mode - Image Browser";

            this.groupBox1.Visible = ShowMainUI;
            this.groupBox3.Visible = ShowMainUI;
            this.groupBox2.Visible = ((Status == UIStatus.Loading) || (ShowNavUI));
            this.groupBox2.Text = small_id;

            base.OnPaint(e);

            if ((handle != null) && (handle.IsReady) && !IsEscherMode)
            {
                //MyBackgroundColor = handle.BackgroundColor;
                Control bounds = this.button4;
                Image img = handle.Image;
                Pen pen = Pens.White;

                float2 space_top = new float2(bounds.Location);
                float2 space_size = new float2(bounds.Size.Width, bounds.Size.Height);

                if (!ShowMainUI)
                {
                    space_top = float2.Zero;
                    space_size = new float2(Width, Height);
                }

                float space_r = space_size.X / space_size.Y;

                float2 img_size = new float2(img.Width, img.Height);
                float img_r = (((float)img.Width) / ((float)img.Height));

                float2 dest_top = space_top;
                float2 dest_size = space_size;

                if (img_r < space_r)
                {
                    dest_size.X = (space_size.Y / img_size.Y) * img_size.X;
                    dest_top.X += (space_size.X - dest_size.X) * 0.5f;
                }
                else
                {
                    dest_size.Y = (space_size.X / img_size.X) * img_size.Y;
                    dest_top.Y += (space_size.Y - dest_size.Y) * 0.5f;
                }

                float2 zoom_size = dest_size * ViewScale - dest_size;
                dest_top -= zoom_size * 0.5f;
                dest_size += zoom_size;
                dest_top += ViewOffset;
                LastSize = dest_size;
                LastCenter = dest_top;// +(dest_size * 0.5f);

                e.Graphics.DrawImage(img, dest_top.ToRect(dest_top + dest_size), 0, 0, img.Width, img.Height, GraphicsUnit.Pixel);
            }

            if (IsEscherMode && MainImage!=null && MainImage.IsReady)
            {
                mcDraw(e.Graphics);
            }
        }

        protected override void OnMouseWheel(MouseEventArgs e)
        {
            base.OnMouseWheel(e);

            if (IsEscherMode)
            {
                float mult = 1.0f;
                if (e.Delta > 0)
                    mult = 1.1f;
                else
                    mult = 0.9f;
                //ScreenSpace.Right *= mult;
                //ScreenSpace.Down *= mult;
                Matrix m = new Matrix();
                m.Translate(e.Location.X, e.Location.Y);
                m.Scale(mult, mult);
                m.Translate(-e.Location.X, -e.Location.Y);
                ScreenSpace = ScreenSpace.TransformBy(m);

                float2 diff = (new float2(LastMouse) - new float2(e.Location));
                this.ScreenSpace.TopLeft += diff * -1.0f;
                this.NextScreenSpace.TopLeft += diff * -1.0f;
                mcStep(new float2(e.Location), 0.05f);
            }
            else
            {
                float diff = (((float)e.Delta) / 120.0f) * 0.2f;
                //diff = Math.Max(diff, 0.2f);

                float2 mouseLoc = new float2(e.Location);
                ViewScale += diff;
                ViewScale = Math.Max(ViewScale, 0.2f);
                //ViewOffset += (mouseThen - mouseNow) * 0.2f;
            }

            this.Invalidate();
        }

        public void DoNextNumberSet(int delta)
        {
            if (!ShowMainUI)
            {
                ShowMainUI = true;
                return;
            }

            if (delta < 0)
                delta = Parts.Count - 1;

            int i = Parts.IndexOf(SelectedPart);
            if (i >= 0)
            {
                SelectedPart = Parts[(i + delta) % Parts.Count];
                RedoParts();
            }
            ShowMainUI = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DoNextNumberSet(-1);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DoNextNumberSet(1);
        }

        bool TryApplyDelta(string s, int di, out string changed)
        {
            int number;
            if (int.TryParse(s, out number))
            {
                string rep = (number + di).ToString();
                while (rep.Length < s.Length)
                {
                    rep = "0" + rep;
                }
                changed = rep;
                return true;
            }
            else
            {
                changed = "";
                return false;
            }
        }

        void ApplyDelta(int di)
        {
            if (MainImage.FileHandle.IsLocalFile)
            {
                string s = MainImage.FileHandle.GetLocalNext(di);
                if (s == null)
                    return;
                MainText = s;
                DoGo();
                this.Invalidate();
                this.Focus();
                return;
            }
            if (SelectedPart == null)
                return;
            string text = SelectedPart.JustPart;
            string rep;
            if (TryApplyDelta( text, di, out rep ) )
            {
                int keepIndex = Parts.IndexOf(SelectedPart);
                MainText = SelectedPart.ReplacedWith(rep);
                SelectedPart = Parts[keepIndex];
                RedoParts();
                DoGo();
                this.Focus();
                this.Invalidate();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ApplyDelta(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ApplyDelta(-1);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ShowMainUI = !ShowMainUI;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ShowNavUI = !ShowNavUI;
        }

        public void DoPaste()
        {
            if (System.Windows.Forms.Clipboard.ContainsText())
            {
                string s = System.Windows.Forms.Clipboard.GetText();

                if (Uri.IsWellFormedUriString(s, UriKind.Absolute))
                {
                    MainText = s;
                    DoGo();
                }
                else
                {
                    MessageBox.Show(this, s + "\n\nIs not a valid URI", "Bad URI", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            DoPaste();
        }

        void DoBack()
        {
            HistoryIndex--;
            if (HistoryIndex < 0)
                HistoryIndex = 0;
            if ((HistoryIndex != 0) && (MainText == History[HistoryIndex]))
                HistoryIndex--;
            MainText = History[HistoryIndex];
            DoGo();

        }

        private void button10_Click(object sender, EventArgs e)
        {
            DoBack();
        }

        private void nextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ApplyDelta(1);
        }

        private void beforeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ApplyDelta(-1);
        }

        private void hideControlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ShowMainUI = false;
            ShowNavUI = !ShowNavUI;
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DoPaste();
        }

        private void backToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            DoBack();
        }

        private void controlsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string s = "Mouse Controls:\n";
            s += "\nUse the left mouse button to drag the image around.\n";
            s += "\nUse the mouse scroll wheel to zoom in/out.\n";
            s += "\nTap the right mouse button for a context menu.\n";
            s += "\nHold down and drag the right mouse button to define\n";
            s += "   a new up direction. The next time you drag the image or\n";
            s += "   zoom, the image will rotate to match the new direction.\n";
            s += "\nWhile holding down the right mouse button, tap the left\n";
            s += "   mouse button to go into manual control mode.\n";
            MessageBox.Show(this, s, "Controls", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void flowModeToggleToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void onToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IsEditMode = !IsEditMode;
            this.Invalidate();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MainImage.Diagram.SaveToFile(this.MainImage.HandleName + ".flow");
        }

        private void loadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IsEditMode = true;
            MainImage.Diagram = FlowDiagram.LoadFromFile(this.MainImage.HandleName + ".flow");
            this.Invalidate();
        }

        private void toggleGuideToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.IsEditDrawGuide = !this.IsEditDrawGuide;
            this.Invalidate();
        }

        private void debugMenuItemToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mcReset();
            this.Invalidate();
        }

    }
}