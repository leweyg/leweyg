using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Windows.Forms;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Xml;
using System.IO;

namespace ImageBrowser
{
    public class StringPart
    {
        public string Owner;
        public int Start, Length;
        public string Replacement = "";

        public StringPart(string s, int start, int len)
        {
            Owner = s;
            Start = start;
            Length = len;
        }

        public StringPart(StringPart other)
            : this(other.Owner, other.Start, other.Length)
        {
        }

        public bool HasReplacement
        {
            get { return (Replacement != ""); }
        }

        public string JustPart
        {
            get
            {
                if (HasReplacement)
                    return Replacement;
                return Owner.Substring(Start, Length);
            }
        }

        public string ReplacedWith(string s)
        {
            string before = Owner.Substring(0, Start);
            string after = Owner.Substring(Start + Length);
            return before + s + after;
        }

        public override string ToString()
        {
            return JustPart;
        }
    }

    public enum FilePri
    {
        Fastest,
        Background,
    }

    class FileStore
    {
        public static List<IHandle> Handles = new List<IHandle>();

        public static IHandle Find(string name)
        {
            name = Path.GetFullPath(name).ToLower();
            foreach (IHandle fh in Handles)
            {
                string fname = Path.GetFullPath(fh.HandleName).ToLower();
                if (fname == name)
                {
                    return fh;
                }
            }
            return null;
        }

        public static int UsageId = 0;
        public static ImageHandle DownloadImage(string name, FilePri pri)
        {
            UsageId++;
            IHandle handle = Find(name);
            if (handle != null)
            {
                handle.UsageHash = UsageId;
                return ((ImageHandle)handle);
            }
            ImageHandle ih = new ImageHandle(name, pri);
            ih.UsageHash = UsageId;
            GarbageCollect();
            return ih;
        }

        public static int CompareHandles(IHandle a, IHandle b)
        {
            return -a.UsageHash.CompareTo(b.UsageHash);
        }

        public static void GarbageCollect()
        {
            int max = 30;
            if (Handles.Count > max)
            {
                Handles.Sort( CompareHandles );

                while (Handles.Count > max)
                {
                    IHandle handle = Handles[Handles.Count - 1];
                    Handles.RemoveAt(Handles.Count - 1);
                    handle.Close();
                }
            }
        }

        public static void Register(IHandle handle)
        {
            Handles.Add(handle);
        }
    }

    public interface IHandle
    {
        bool IsReady { get; }
        bool IsLoaded { get; }
        bool IsFailed { get; }
        string HandleName { get; }
        int UsageHash { get; set; }
        void Close();
    }

    public class CHandle : IHandle
    {
        private string mHandleName;
        public string HandleName
        {
            get { return mHandleName; }
            set { mHandleName = value; }
        }

        private int mUsageHash;
        public int UsageHash
        {
            get { return mUsageHash; }
            set { mUsageHash = value; }
        }

        private bool mIsReady = false;
        public bool IsReady
        {
            get { return mIsReady; }
            set 
            {
                bool old = mIsReady;
                mIsReady = value;
                if ((old != value)&&(OnReadyChanged!=null))
                {
                    OnReadyChanged(this);
                }
            }
        }

        private bool mIsLoaded = false;
        public bool IsLoaded
        {
            get { return mIsLoaded; }
            set 
            {
                bool old = mIsLoaded;
                mIsLoaded = value;
                if ((old != value) && (OnLoadedChanged != null))
                {
                    OnLoadedChanged(this);
                }
            }
        }

        private bool mIsFailed;
        public bool IsFailed
        {
            get { return mIsFailed; }
            set 
            {
                bool old = mIsFailed;
                mIsFailed = value;
                if ((old != value) && (OnFailedChanged != null))
                {
                    OnFailedChanged(this);
                }
            }
        }

        public virtual void Close()
        {
        }

        public delegate void HandleChangeEvent(IHandle handle);
        public event HandleChangeEvent OnReadyChanged;
        public event HandleChangeEvent OnLoadedChanged;
        public event HandleChangeEvent OnFailedChanged;
    }

    public class ColorInfo
    {
        public int R = 0, G = 0, B = 0;
        public int Count = 0;
        public List<Color> All = new List<Color>();

        public void AddColor(Color c)
        {
            Count++;
            R += c.R;
            G += c.G;
            B += c.B;
            All.Add(c);
        }

        public static int Clamp(int c)
        {
            if ((c >= 0) && (c <= 255))
                return c;
            if (c < 0)
                return 0;
            else
                return 255;
        }

        struct FColor
        {
            float R, G, B;
            float Bright;
            float Range;

            public FColor(Color c)
            {
                R = ((float)c.R) / 255.0f;
                G = ((float)c.G) / 255.0f;
                B = ((float)c.B) / 255.0f;
                Bright = 1.0f;
                Range = 1.0f;
            }

            void Normalize()
            {
                float low = Math.Min(R, Math.Min(G, B));
                float high = Math.Max(R, Math.Max(G, B));
                float span = (high - low);
                if (span == 0) span = 1.0f;

                Bright = (R + G + B) / 3.0f;
                Range = span;
                R = ((R - low) / span);
                G = ((G - low) / span);
                B = ((B - low) / span);
            }

            public static float Square(float a)
            {
                return a * a;
            }

            public float Distance(FColor other)
            {
                float br = Square(this.Bright - other.Bright);
                float cl = Square(this.R - other.R) + Square(this.G - other.G) + Square(this.B - other.B);
                return (float)Math.Sqrt(br + (Range * cl));
            }
        }

        public static int Distance(Color a, Color b)
        {
            int r = ((int)a.R) - ((int)b.R);
            int g = ((int)a.G) - ((int)b.G);
            int p = ((int)a.B) - ((int)b.B);
            return (int)Math.Sqrt(r * r + g * g + p * p);
        }

        public Color AsColor
        {
            get
            {
                int r = Clamp(R / Count);
                int g = Clamp(G / Count);
                int b = Clamp(B / Count);
                Color avg = Color.FromArgb(255, r, g, b);

                Color bestcolor = All[0];
                float bestcount = 0;
                for (int i = 0; i < All.Count; i++)
                {
                    float mindist = 1000000.0f;
                    float maxdist = 0.0f;

                    FColor curcolor = new FColor(All[i]);
                    for (int j = 0; j < All.Count; j++)
                    {
                        FColor jc = new FColor(All[j]);
                        float dist = curcolor.Distance(jc);
                        if (dist < mindist)
                            mindist = dist;
                        if (dist > maxdist)
                            maxdist = dist;
                    }

                    int distsofar = 0;
                    maxdist = ((maxdist - mindist) / 8.0f) + mindist;

                    for (int j = 0; j < All.Count; j++)
                    {
                        FColor jc = new FColor(All[j]);
                        float dist = curcolor.Distance(jc);
                        if ((dist >= mindist) && (dist <= maxdist))
                            distsofar++;
                    }

                    if (distsofar > bestcount)
                    {
                        bestcolor = All[i];
                        bestcount = distsofar;
                    }
                }
                return bestcolor;
            }
        }
    }

    public class FlowLine
    {
        public float2 A, B;

        public FlowLine(float2 a, float2 b)
        {
            A = a;
            B = b;
        }

        public float Length
        {
            get
            {
                return (A - B).Length;
            }
        }

        public float Dot(float2 p)
        {
            return (A-B).Cross.Dot(p-B);
        }

        public float2 Direction
        {
            get
            {
                return (B - A).Normalized;
            }
        }

        public bool IsBelow(float2 p)
        {
            return (Dot(p) > 0);
        }

        public float2 Encode(float2 p)
        {
            float2 d = (p - A);
            float2 dir = (B - A);
            float x = dir.Normalized.Dot(d);
            float y = dir.Perpendicular.Normalized.Dot(d);
            x /= dir.Length;
            return new float2(x, y);
        }

        public float2 Decode(float along, float outwards)
        {
            return Decode(new float2(along, outwards));
        }

        public float2 Decode(float2 p)
        {
            float2 dir = (B - A);
            return B + dir * p.X + dir.Perpendicular.Normalized * p.Y;
        }
    }

    public class FlowPair
    {
        public FlowLine Top, Bottom;

        public bool Contains(float2 p)
        {
            for (int i = 0; i < 4; i++)
            {
                float2 a = this[i];
                float2 b = this[(i + 1) % 4];
                if ((b - a).Perpendicular.Dot(p - a) > 0)
                {
                    return false;
                }
            }
            return true;
        }

        public FlowPair Transform(System.Drawing.Drawing2D.Matrix m)
        {
            FlowPair fp = new FlowPair(Top.A.TransformBy(m), Top.B.TransformBy(m),
                Bottom.A.TransformBy(m), Bottom.B.TransformBy(m));
            return fp;
        }

        public float2 this[int i]
        {
            get
            {
                switch (i)
                {
                    case 0:
                        return Top.A;
                    case 1:
                        return Top.B;
                    case 2:
                        return Bottom.B;
                    case 3:
                        return Bottom.A;
                    default:
                        Code.BadPlace();
                        return float2.Zero;
                }
            }
            set
            {
                switch (i)
                {
                    case 0:
                        Top.A = value;
                        break;
                    case 1:
                        Top.B = value;
                        break;
                    case 2:
                        Bottom.B = value;
                        break;
                    case 3:
                        Bottom.A = value;
                        break;
                    default:
                        Code.BadPlace();
                        break;
                }
            }
        }

        public IEnumerable<float2> AllPoints()
        {
            yield return this[0];
            yield return this[1];
            yield return this[2];
            yield return this[3];
        }

        public FlowLine Across(float t)
        {
            float2 a = float2.Interp(t, Top.A, Bottom.A);
            float2 b = float2.Interp(t, Top.B, Bottom.B);
            return new FlowLine(a, b);
        }

        public FlowLine Along(float t)
        {
            float2 tp = float2.Interp(t, Top.A, Top.B);
            float2 btm = float2.Interp(t, Bottom.A, Bottom.B);
            return new FlowLine(tp, btm);
        }

        public FlowLine LineThrough(float2 p)
        {
            float2 topEnc = Top.Encode(p);
            float2 btmEnc = Bottom.Encode(p);

            float mid = float2.Avg(topEnc, btmEnc).X;
            float top = topEnc.X - 1;
            float bottom = btmEnc.X - 1;

            float topf = Math.Abs(topEnc.Y);
            float btmf = Math.Abs(btmEnc.Y);
            float sumf = topf + btmf;
            topf = ((topf / sumf));// *Math.Sign(topEnc.Y);
            btmf = ((btmf / sumf));// *Math.Sign(btmEnc.Y);

            mid = top * topf + bottom * btmf;
            //mid -= (float)Math.Sqrt(2);
            /*
            */

            FlowLine fl = new FlowLine(Top.Decode(mid,0), Bottom.Decode(mid,0));
            return fl;
        }

        public FlowPair(float2 a1, float2 b1, float2 a2, float2 b2)
        {
            Top = new FlowLine(a1, b1);
            Bottom = new FlowLine(a2, b2);  
        }

        public FlowPair Alternate
        {
            get
            {
                return new FlowPair(Top.A, Bottom.A, Top.B, Bottom.B);
            }
        }

        public FlowLine DiagonalTop
        {
            get
            {
                return new FlowLine(Top.A, Bottom.B);
            }
        }

        public FlowLine DiagonalBottom
        {
            get
            {
                return new FlowLine(Bottom.A, Top.B);
            }
        }

        public FlowPair Twisted()
        {
            return new FlowPair(Top.A, Top.B, Bottom.B, Bottom.A);
        }

        public void Sort()
        {
            FlowPair tw = this.Twisted();
            if (tw.Top.Length < this.Top.Length)
            {
                this.Top = tw.Top;
                this.Bottom = tw.Bottom;
            }
        }
    }

    public class FlowDiagram
    {
        public List<FlowPair> Lines = new List<FlowPair>();

        public static FlowDiagram LoadFromFile(string filename)
        {
            FlowDiagram fd = new FlowDiagram();
            XmlTextReader xtr = new XmlTextReader(filename);
            FlowPair pair = null;
            int curindex = 0;
            while (xtr.Read())
            {
                switch (xtr.NodeType)
                {
                    case XmlNodeType.Element:
                        {
                            switch (xtr.Name)
                            {
                                case "Pair":
                                    {
                                        pair = new FlowPair(float2.Zero, float2.Zero, float2.Zero, float2.Zero);
                                        fd.Lines.Add(pair);
                                        curindex = 0;
                                    }
                                    break;
                                case "float2":
                                    {
                                        float x = float.Parse(xtr["x"]);
                                        float y = float.Parse(xtr["y"]);
                                        pair[curindex++] = new float2(x, y);
                                    }
                                    break;
                            }
                        }
                        break;
                }
            }
            xtr.Close();
            return fd;
        }

        public void SaveToFile(string filename)
        {
            XmlTextWriter xtw = new XmlTextWriter(filename, Encoding.ASCII);
            xtw.Formatting = Formatting.Indented;
            xtw.WriteStartDocument(true);
            xtw.WriteStartElement("Lines");
            foreach (FlowPair pair in Lines)
            {
                xtw.WriteStartElement("Pair");
                foreach (float2 pnt in pair.AllPoints())
                {
                    xtw.WriteStartElement("float2");
                    xtw.WriteAttributeString("x", pnt.X.ToString());
                    xtw.WriteAttributeString("y", pnt.Y.ToString());
                    xtw.WriteEndElement();
                }
                xtw.WriteEndElement();
            }
            xtw.WriteEndElement();
            xtw.WriteEndDocument();
            xtw.Close();
        }
    }

    public class ImageHandle : CHandle
    {
        public Color BackgroundColor = Color.Black;
        public FlowDiagram Diagram = new FlowDiagram();

        public ImageHandle(string name, FilePri pri)
        {
            HandleName = name;
            FileHandle = new FileHandle(name, pri);
            FileStore.Register(this);
            if (!FileHandle.IsReady)
            {
                FileHandle.OnReadyChanged += new HandleChangeEvent(FileHandle_OnReadyChanged);
                FileHandle.OnFailedChanged += new HandleChangeEvent(FileHandle_OnFailedChanged);
            }
            else
            {
                FileHandle_OnReadyChanged(FileHandle);
            }
        }

        public override void Close()
        {
            IsReady = false;
            IsLoaded = false;
            mImage = null;
            FileHandle.Close();
            FileHandle = null;
        }

        void FileHandle_OnFailedChanged(IHandle handle)
        {
            IsFailed = true;
        }

        void FileHandle_OnReadyChanged(IHandle handle)
        {
            if (handle.IsReady)
            {
                IsLoaded = true;
                mImage = Image.FromStream(FileHandle.Stream);
                IsReady = true;

                if (mImage is Bitmap)
                {
                    Bitmap bmp = (Bitmap)mImage;

                    ColorInfo ci = new ColorInfo();

                    int steps = 20;
                    for (int y = 1; y < steps; y++)
                    {
                        int iy = (y * bmp.Height) / steps;
                        iy = Math.Min(iy, bmp.Height - 1);
                        ci.AddColor(bmp.GetPixel(0, iy));
                        ci.AddColor(bmp.GetPixel(bmp.Width - 1, iy));
                    }
                    /*
                    ci.AddColor(bmp.GetPixel(0, 0));
                    ci.AddColor(bmp.GetPixel(bmp.Width/2, 0));
                    ci.AddColor(bmp.GetPixel(bmp.Width-1, 0));
                    ci.AddColor(bmp.GetPixel(0, bmp.Height/2));
                    ci.AddColor(bmp.GetPixel(bmp.Width - 1, bmp.Height / 2));
                    ci.AddColor(bmp.GetPixel(0, bmp.Height-1));
                    ci.AddColor(bmp.GetPixel(bmp.Width / 2, bmp.Height - 1));
                    ci.AddColor(bmp.GetPixel(bmp.Width - 1, bmp.Height - 1));
                    */

                    BackgroundColor = ci.AsColor;
                }

                Form1.TheOnly.Invalidate();
            }
        }


        private Image mImage;
        public Image Image
        {
            get { return mImage; }
            set { mImage = value; }
        }


        private FileHandle mFileHandle;
        public FileHandle FileHandle
        {
            get { return mFileHandle; }
            set { mFileHandle = value; }
        }

    }

    // The RequestState class passes data across async calls.
    public class RequestState
    {
        const int BufferSize = 1024;
        public StringBuilder RequestData;
        public byte[] BufferRead;
        public WebRequest Request;
        public Stream ResponseStream;
        // Create Decoder for appropriate enconding type.
        public Decoder StreamDecode = Encoding.UTF8.GetDecoder();

        public RequestState()
        {
            BufferRead = new byte[BufferSize];
            RequestData = new StringBuilder(String.Empty);
            Request = null;
            ResponseStream = null;
        }
    }

    public class FileHandle : CHandle
    {
        protected IAsyncResult Result;
        protected WebRequest Request;
        public bool IsLocalFile = false;

        public FileHandle(string name, FilePri pri)
        {
            mFilename = name;
            HandleName = name;
            mPri = pri;

            string here = Environment.CurrentDirectory;
            if (!name.ToLower().Contains("http"))
            {
                if (File.Exists(name))
                {
                    Stream = new FileStream(name, FileMode.Open);
                    IsLocalFile = true;
                    IsLoaded = true;
                    IsReady = true;
                    return;
                }
                else
                {
                    IsFailed = true;
                    return;
                }
            }

            // for each URL in the collection...
            Request = HttpWebRequest.Create(name);
            Request.Method = "GET";
            Request.UseDefaultCredentials = true;
            Request.ImpersonationLevel = System.Security.Principal.TokenImpersonationLevel.Anonymous;

            // RequestState is a custom class to pass info
            RequestState state = new RequestState();
            state.Request = Request;


            Result = Request.BeginGetResponse(
              new AsyncCallback(OnDownloaded), state);

            // PLACEHOLDER: See below...
        }

        public string GetLocalNext(int delta)
        {
            string dir = Path.GetDirectoryName(Filename);
            string[] files = Directory.GetFiles(dir);
            if (files.Length == 0)
                return null;
            int i = 0;
            int at = -1;
            string myfile = Path.GetFileName( Filename ).ToLower();
            foreach (string s in files)
            {
                string sname = Path.GetFileName(s).ToLower();
                if (sname == myfile)
                {
                    at = i;
                }
                i++;
            }
            if (at < 0)
                at = 0;
            else
            {
                at = Code.Mod(at + delta, files.Length);
                bool isvalid = false;
                while (!isvalid)
                {
                    string ex = Path.GetExtension(files[at]).ToLower();
                    switch (ex)
                    {
                        case ".bmp":
                        case ".jpg":
                        case ".jpeg":
                        case ".gif":
                            isvalid = true;
                            break;
                        default:
                            at = Code.Mod(at + delta, files.Length);
                            break;
                    }
                }
            }
            return files[at];
        }

        protected void OnDownloaded(IAsyncResult result)
        {
            try
            {
                // grab the custom state object
                RequestState state = (RequestState)result.AsyncState;
                WebRequest request = (WebRequest)state.Request;

                // get the Response
                HttpWebResponse response =
                  (HttpWebResponse)request.EndGetResponse(result);

                // process the response...

                IsLoaded = true;
                Stream = response.GetResponseStream();
                IsReady = true;

            }
            catch (Exception e)
            {
                mFailMessage = e.ToString();
                IsFailed = true;
            }
        }

        private string mFailMessage = "None";
        public string FailureMessage
        {
            get { return mFailMessage; }
            set { mFailMessage = value; }
        }

        public override void Close()
        {
            base.Close();
            IsReady = false;
            IsLoaded = false;
            if (Stream != null)
            {
                Stream.Close();
                Stream = null;
            }
            if (Request != null)
            {
                Request.Abort();
                Request = null;
            }
        }

        private Stream mStream;
        public Stream Stream
        {
            get { return mStream; }
            set { mStream = value; }
        }

        private string mFilename;
        public string Filename
        {
            get { return mFilename; }
            set { mFilename = value; }
        }


        private FilePri mPri;
        public FilePri Priority
        {
            get { return mPri; }
            set { mPri = value; }
        }
    }
}
