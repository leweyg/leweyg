using System;

namespace ImageBrowser
{
	/// <summary>
	/// Summary description for float2.
	/// </summary>
	public struct float2
	{
		public float X, Y;

        public override string ToString()
        {
            return "" + X + ", " + Y;
        }

		public float2( float x, float y )
		{
			X = x;
			Y = y;
		}

        public float2(int x, int y)
        {
            X = (float)x;
            Y = (float)y;
        }

        public float2(System.Drawing.Point pnt)
            : this( (float)pnt.X, (float)pnt.Y )
        {
        }

        public float2(System.Drawing.PointF pnt)
            : this( pnt.X, pnt.Y )
        {
        }

        public float2 Cross
        {
            get
            {
                float x = -Y;
                float y = X;
                return new float2(x, y);
            }
        }

        public static float2 Avg(float2 a, float2 b)
        {
            return (a + b) * 0.5f;
        }

        public float2 TransformBy(System.Drawing.Drawing2D.Matrix m)
        {
            System.Drawing.PointF[] pnts = { this.AsPointF };
            m.TransformPoints(pnts);
            return new float2(pnts[0]);
        }

        public System.Drawing.Rectangle ToRect(float2 other)
        {
            int minx = (int)Math.Min(X, other.X);
            int miny = (int)Math.Min(Y, other.Y);
            int maxx = (int)Math.Max(X, other.X);
            int maxy = (int)Math.Max(Y, other.Y);
            return new System.Drawing.Rectangle(minx, miny, maxx - minx, maxy - miny);
        }

        public System.Drawing.Point AsPoint
        {
            get
            {
                return new System.Drawing.Point((int)X, (int)Y);
            }
        }

        public System.Drawing.PointF AsPointF
        {
            get
            {
                return new System.Drawing.PointF(X, Y);
            }
        }

		public float Length
		{
			get
			{
				return (float)Math.Sqrt( X*X + Y*Y );
			}
		}

		public float2 Perpendicular
		{
			get
			{
				return new float2( -Y, X );
			}
		}

        public float2 OnlyX
        {
            get
            {
                return new float2(X, 0);
            }
        }

        public float2 OnlyY
        {
            get
            {
                return new float2(0, Y);
            }
        }

		public float Dot(float2 other)
		{
			return X*other.X + Y*other.Y;
		}

		public float SelfDot
		{
			get { return X*X + Y*Y; }
		}

		public float2 Normalized
		{
			get
			{
				return this / this.Length;
			}
		}

		public float Direction
		{
			get
			{
				return (float)Math.Atan2( Y, X );
			}
		}

        public float2 Mult(float mx, float my)
        {
            return new float2(X * mx, Y * my);
        }

		public static float2 FromDirection(float dir)
		{
			return new float2( (float)Math.Cos(dir), (float)Math.Sin(dir) );
		}

        public static float2 MaxOf(float2 a, float2 b)
        {
            return new float2(Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
        }

        public static float2 MinOf(float2 a, float2 b)
        {
            return new float2(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y));
        }

        public float2 Rotate(float r)
		{
			float sin = (float)Math.Sin( (double)r );
			float cos = (float)Math.Cos( (double)r );
			float x = Y*cos - X*sin;
			float y = Y*sin + X*cos;
			return new float2( x, y );
		}

        public static float DecimalPart(float t)
        {
            return t - ((float)Math.Floor(t));
        }

        public static float2 Interp(float t, float2 a, float2 b)
        {
            float ot = 1.0f - t;
            float x = a.X * ot + b.X * t;
            float y = a.Y * ot + b.Y * t;
            return new float2(x, y);
        }

        public static float2 Interp(float t, float2 a, float2 m, float2 b)
        {
            float2 am = Interp(t, a, m);
            float2 mb = Interp(t, m, b);
            return Interp(t, am, mb);
        }

		public static float2 operator * (float2 a, float b)
		{
			return new float2( a.X * b, a.Y * b );
		}

		public static float2 operator + (float2 a, float b)
		{
			return new float2( a.X + b, a.Y + b );
		}

		public static float2 operator - (float2 a, float b)
		{
			return new float2( a.X - b, a.Y - b );
		}

		public static float2 operator / (float2 a, float b)
		{
			return new float2( a.X / b, a.Y / b );
		}

		public static float2 operator + (float2 a, float2 b)
		{
			return new float2( a.X + b.X, a.Y + b.Y );
		}

		public static float2 operator * (float2 a, float2 b)
		{
			return new float2( a.X * b.X, a.Y * b.Y );
		}

		public static float2 operator - (float2 a, float2 b)
		{
			return new float2( a.X - b.X, a.Y - b.Y );
		}

		public static float2 operator / (float2 a, float2 b)
		{
			return new float2( a.X / b.X, a.Y / b.Y );
		}

		public static bool operator == (float2 a, float2 b)
		{
			return ( ( a.X == b.X ) && ( a.Y == b.Y) );
		}

		public static bool operator != (float2 a, float2 b)
		{
			return ( ( a.X != b.X ) || ( a.Y != b.Y) );
		}

		public float2 SwapXY
		{
			get { return new float2( Y, X ); }
		}

		public float2 Negative
		{
			get { return new float2( -X, -Y ); }
		}

		public override bool Equals(object obj)
		{
			return ( this == ((float2)obj) );
		}

		public override int GetHashCode()
		{
			return ( X.GetHashCode() ^ Y.GetHashCode() );
		}


		public static Random RandSource = new Random();

		public static float2 Rand()
		{
			return new float2( (float)RandSource.NextDouble(),
				(float)RandSource.NextDouble() );
		}

		public static float2 RandCircle()
		{
			double r = RandSource.NextDouble() * Math.PI * 2;
			double x = Math.Cos( r );
			double y = Math.Sin( r );
			return new float2( (float)x, (float)y );
		}

		public static float2 Zero
		{
			get
			{
				return new float2( 0, 0 );
			}
		}

		public static float2 One
		{
			get { return new float2( 1, 1 ); }
		}

		public static float2 XAxis
		{
			get { return new float2( 1, 0 ); }
		}

		public static float2 YAxis
		{
			get { return new float2( 0, 1 ); }
		}
    }
}
