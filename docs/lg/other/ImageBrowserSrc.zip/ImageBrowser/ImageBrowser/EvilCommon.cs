using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Xml;

namespace ImageBrowser
{
	public interface ISaveable
	{
	}

	public abstract class Code
	{
		public const string Version = "0.1";

        public delegate int MyCompare<T>(T a, T b);
        public void MySort<T>(T[] ar, MyCompare<T> f)
        {

        }

		public static int Mod(int i, int m)
		{
			if ( i >= 0 )
				return i % m;
			while ( i < 0 )
				i += m;
			return i;
		}

		public static string Status
		{
			set
			{
				long t = System.DateTime.Now.Ticks;

				//Game._theGamePointer.TheApp.Text = value + " ("+t+")";
                Code.TODO();
			}
		}

		public static bool Is(int flag, int mask)
		{
			return ( ( flag & mask ) == mask );
		}

		public static string FormatFloat(float f)
		{
			int secs = (int)f;
			float ls = f - ((float)secs);
			string s = ls.ToString();
			if ( s.Length > 5 )
				s = s.Substring( 0, 5 );
			return secs.ToString() + s.Substring(1);
		}

		public static void SaveToFile(object ob, string filename)
		{
			System.IO.StreamWriter sw = new System.IO.StreamWriter( filename );
			System.Xml.Serialization.XmlSerializer xs = new System.Xml.Serialization.XmlSerializer( ob.GetType() );
			xs.Serialize( sw, ob );
			sw.Close();
		}

		public static object LoadFromFile(Type t, string filename)
		{
			System.IO.TextReader sr;
			try
			{
				sr = new System.IO.StreamReader( filename );
			}
			catch
			{
				return null;
			}
			System.Xml.Serialization.XmlSerializer xs = new System.Xml.Serialization.XmlSerializer( t );
			object ans = xs.Deserialize( sr );
			sr.Close();
			return ans;
		}

		public static void ShellExecute(string txt)
		{
			System.Diagnostics.Process link = new System.Diagnostics.Process();
			link.StartInfo.FileName = txt;
			link.Start();
		}

		public static bool IsValidArray(FieldInfo fi)
		{
			return ( fi.FieldType.IsSubclassOf( typeof( Array ) ) );
		}

		public static void ReadSingleArray(XmlTextReader xr, FieldInfo fi, object ob)
		{
			Code.Assert( IsValidArray( fi ) );

			string slen = xr.GetAttribute( "length" );
			int len = int.Parse( slen );
			object[] conargs = { len };
			Array ar = (Array)System.Activator.CreateInstance( fi.FieldType, conargs );
			Type itemtype = fi.FieldType.GetElementType();

			for (int i=0; i<len; i++)
			{
				xr.Read();
				object item = System.Activator.CreateInstance( itemtype );
				ReadFields( xr, item );
				ReadArrays( xr, item );
				ar.SetValue( item, i );
			}

			if ( len != 0 )
				xr.Read();

			fi.SetValue( ob, ar );

		}

		public static void ReadArrays(XmlTextReader xr, object ob)
		{
			FieldInfo[] fields = ob.GetType().GetFields();
			foreach ( FieldInfo fi in fields )
			{
				if ( IsValidArray( fi ) )
				{
					xr.Read();
					ReadSingleArray( xr, fi, ob );
				}
			}
		}

		public static void WriteArrays(XmlTextWriter xw, object ob)
		{
			FieldInfo[] fields = ob.GetType().GetFields();
			foreach ( FieldInfo fi in fields )
			{
				if ( IsValidArray( fi ) )
				{
					Array ar = (Array)fi.GetValue( ob );
					xw.WriteStartElement( fi.Name );
					xw.WriteAttributeString( "length", ar.Length.ToString() );
					if ( ar.Length != 0 )
						xw.WriteAttributeString( "type", ar.GetValue(0).GetType().FullName );
					foreach ( object item in ar )
					{
						xw.WriteStartElement( item.GetType().Name );
						WriteFields( xw, item );
						WriteArrays( xw, item );
						xw.WriteEndElement();
					}
					xw.WriteEndElement();
				}
			}
		}

		public static bool IsValidField(FieldInfo fi)
		{
			return ( fi.FieldType.IsValueType
					|| fi.FieldType == typeof(string) );
		}

		public static void WriteFields(XmlTextWriter tw, object ob)
		{
			FieldInfo[] fields = ob.GetType().GetFields();
			foreach ( FieldInfo fi in fields )
			{
				if ( IsValidField( fi ) )
				{
					string s = fi.GetValue(ob).ToString();
					if ( fi.FieldType.IsEnum )
						s = ((int)(fi.GetValue(ob))).ToString();
					tw.WriteAttributeString( fi.Name, s );
				}
			}
		}

		public static void ReadSingleField(XmlTextReader tr, object ob, FieldInfo fi)
		{
			if ( IsValidField( fi ) )
			{
				string str = tr.GetAttribute( fi.Name );
				if ( str != null )
				{
					object val;

					if ( !fi.FieldType.IsEnum )
						val = System.Convert.ChangeType( str, fi.FieldType );
					else
					{
						val = null;
						Code.TODO();
					}
					fi.SetValue( ob, val );
				}
			}
		}

		public static void ReadFields(XmlTextReader tr, object ob)
		{
			FieldInfo[] fields = ob.GetType().GetFields();
			foreach ( FieldInfo fi in fields )
			{
				ReadSingleField( tr, ob, fi );
			}
		}

		public static string SecondsToString(int seconds)
		{
			int mins = seconds / 60;
			int secs = seconds % 60;
			string s = ""+secs;
			if ( s.Length == 1 )
				s = "0" + s;
			return ""+mins+":"+s;
		}

		public static void LaxTODO()
		{
			System.Windows.Forms.MessageBox.Show( "TODO" );
		}

		public static void TODO()
		{
			throw new NotImplementedException( "TODO" );
		}

        public static void TODO(string msg)
        {
            throw new NotImplementedException(msg);
        }

		public static void BadPlace()
		{
			throw new NotSupportedException( "Shouldn't be here" );
		}

		public static void Assert(bool stmt)
		{
			if ( !stmt )
				throw new ArgumentException( "Assert Failed" );
			stmt = false;
		}

		public static void AssertOnNull(object arg)
		{
			if ( arg == null )
				throw new ArgumentException( "Assert on Null Raised" );
		}

		public static Array ArrayRemove(Array ar, object ob)
		{
			object[] args = { ar.Length-1 };
			Array ans = (Array)System.Activator.CreateInstance( ar.GetType(), args );
			int to = 0;
			for (int i=0; i<ar.Length; i++)
			{
				if ( ar.GetValue(i) != ob )
					ans.SetValue( ar.GetValue(i), to++ );
			}
			Code.Assert( to+1 == ar.Length );
			return ans;
		}

		public static Array ArrayAppend(Array ar, object ob)
		{
			object[] args = { ar.Length+1 };
			Array ans = (Array)System.Activator.CreateInstance( ar.GetType(), args );
			for (int i=0; i<ar.Length; i++)
				ans.SetValue( ar.GetValue(i), i );
			ans.SetValue( ob, ar.Length );
			return ans;
		}

		public static System.Random Random = new Random();
	}
}
