
#include "stdafx.h"
#include "MIKE.h"

void _CalledAssert(const char* text, int line, const char* file)
{
	printf( "Assert Failed: '%s' on %d of %s\n", text, line, file );
	int* ptr = NULL;
	*ptr = 5;
}

void Keyframe::Add(MikDelta* delta)
{
	//remove any deltas in this set which this delta replaces
	size_t count = Delta.Deltas.size();
	for (size_t i=0; i<count; i++)
	{
		MikDelta* od = Delta.Deltas[i];
		if ( delta->Replaces( od ) )
		{
			od->IsKeyframed = false;
			Manager()->ChangeList( this, &(Delta.Deltas), 
				od, (int)i, false );
			break;
		}
	}

	//add it to the list
	Manager()->ChangeList( this, &(Delta.Deltas), delta, -1, true );
}

void DeltaSet::Add(MikDelta* md)
{
	Deltas.push_back( md );
}

void MikManager::InternalSetTime(float newtime)
{
	float oldtime = GetTime();
	CurrentKeyframe = NULL;
	if ( newtime > oldtime )
	{
		//going forward in time
		for (size_t i=0; i<Timeline.size(); i++)
		{
			Keyframe* kf = Timeline[i];
			if ( kf->TimeFrom <= newtime )
			{
				if ( kf->TimeFrom > oldtime )
					kf->Apply();
				if ( kf->TimeFrom == newtime )
				{
					Assert( CurrentKeyframe == NULL );
					CurrentKeyframe = kf;
				}
			}
		}
	}
	else
	{
		//going backwards in time
		for (int i=( ((int)Timeline.size()) - 1 ); i >= 0; i-- )
		{
			Keyframe* kf = Timeline[i];
			if ( kf->TimeFrom > newtime )
			{
				if ( kf->TimeFrom <= oldtime )
					kf->UnApply();
			}
			if ( kf->TimeFrom == newtime )
			{
				Assert( CurrentKeyframe == NULL );
				CurrentKeyframe = kf;
			}
		}
	}
	CurrentTime = newtime;
}

void MikManager::SetTime(float newtime)
{
	Assert( IsMetaDelta == false );
	IsMetaDelta = true;
	timeCache = CurrentTime;
	ChangeValue( this, &timeCache, newtime );
	IsMetaDelta = false;
}

void MikManager::OnPropertyChanged(void* prop)
{
	if ( prop == &timeCache )
		InternalSetTime( timeCache );
}

void MikManager::RegisterDelta(MikDelta* delta)
{
	Assert( delta != NULL );
	CurrentSet->Add( delta );
	DeleteVectorEntries( &RedoStack );

	if ( IsMetaDelta )
		return;

	IsMetaDelta = true;

	if ( IsRecording )
	{
		delta->IsKeyframed = true;
		Keyframe* ds = ForceGetKeyframe();
		ds->Add( delta );
	}

	IsMetaDelta = false;
}

Keyframe* MikManager::ForceGetKeyframe()
{
	Assert( IsMetaDelta );

	if ( CurrentKeyframe != NULL )
		return CurrentKeyframe;

	Keyframe* tds = new Keyframe();
	tds->TimeFrom = GetTime();

	//find place to insert into the timeline:
	int index = 0;
	while ( ( index < (int)Timeline.size() ) && 
		( Timeline[index]->TimeFrom < tds->TimeFrom ) )
		index++;

	if ( index < (int)Timeline.size() )
		Assert( Timeline[index]->TimeFrom != tds->TimeFrom );

	//Add the item to the Timeline, but do this using a Delta so that
	//	an Undo will remove the change
	ChangeList( this, &(this->Timeline), tds, index, true );

	CurrentKeyframe = tds;
	return tds;
}

void MikManager::GetKeyframeTimes(vector<float>* ar)
{
	for (size_t i=0; i<Timeline.size(); i++)
		ar->push_back( Timeline[i]->TimeFrom );
}

void MikManager::GroupDeltas()
{
	if ( CurrentSet->Count() == 0 )
		return;
	UndoStack.push_back( CurrentSet );
	CurrentSet = new DeltaSet();
}

void MikManager::Undo()
{
	GroupDeltas(); //just to be safe

	if ( UndoStack.size() == 0 )
		return;

	DeltaSet* set = UndoStack.back();
	UndoStack.pop_back();
	RedoStack.push_back( set );

	set->UnApply();
}

void MikManager::Redo()
{
	if ( RedoStack.size() == 0 )
		return;

	DeltaSet* set = RedoStack.back();
	RedoStack.pop_back();
	UndoStack.push_back( set );

	set->Apply();
}

MikManager::MikManager()
{
	CurrentSet = new DeltaSet();
	CurrentKeyframe = NULL;
	CurrentTime = 0.0f;
	IsMetaDelta = false;
	IsRecording = false;
}

MikManager::~MikManager()
{
	delete CurrentSet;
	DeleteVectorEntries( &UndoStack );
	DeleteVectorEntries( &RedoStack );
	DeleteVectorEntries( &Timeline );
}

DeltaSet::~DeltaSet()
{
	for (size_t i=0; i<Deltas.size(); i++)
	{
		MikDelta* md = Deltas[i];
		if ( !md->IsKeyframed )
			delete md;
	}
	Deltas.clear();
}

MikManager* _manager = NULL;
MikManager* Manager()
{
	if ( _manager != NULL )
		return _manager;
	_manager = new MikManager();
	return _manager;
}

void FreeManager()
{
	if ( _manager == NULL )
		return;

	delete _manager;
	_manager = NULL;
}
