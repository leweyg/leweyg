
#pragma once

#include "common.h"

#define MIKE_MAX_OBJECT_SIZE	100
#define MIKE_ISSAMETYPE(a,b) ( *((void**)a) == *((void**)b) )

template <typename T> void DeleteVectorEntries(vector<T>* ar)
{
	if ( ar->size() == 0 )
		return;

	for (size_t i=0; i<ar->size(); i++)
		delete ( (*ar)[i] );

	ar->clear();
}

class MikObject
{
public:
	virtual void OnPropertyChanged(void* prop) {};
};



class MikDelta
{
public:
	MikObject* Target;
	int PropId;
	bool IsKeyframed;

	virtual void Apply() {TODO();};
	virtual void UnApply() {TODO();};
	virtual bool Replaces(MikDelta* other) {return false;}

protected:
	MikDelta()
	{
		IsKeyframed = false;
	};

	void OnChanged()
	{
		Target->OnPropertyChanged( PropPtr() );
	};

	void Init(MikObject* target, void* prop)
	{
		Assert( target != NULL && prop != NULL );
		Target = target;
		PropId = (int)( ((byte*)prop) - ((byte*)target) );
		Assert( ( PropId >= 0 ) && ( PropId < MIKE_MAX_OBJECT_SIZE ) );
	}

	bool SameTypeAndTarget(MikDelta* other)
	{
		if ( other->Target!=Target || other->PropId!=PropId )
			return false;
		if ( !MIKE_ISSAMETYPE( this, other ) )
			return false;
		return true;
	}

	void* PropPtr()
	{
		return ( ((byte*)Target) + PropId );
	};
};

template <typename T> class VectorDelta : public MikDelta
{
public:
	T Item;
	int Index;
	bool IsInsert; //false=Remove

	void DoListOp(bool forward)
	{
		vector<T>* list = (vector<T>*)PropPtr();
		if ( forward == IsInsert )
		{
			if ( Index == list->size() )
				list->push_back( Item );
			else
				list->insert( list->begin() + Index, Item );
		}
		else
		{
			list->erase( list->begin() + Index );
		}
		OnChanged();
	};

	virtual void Apply()
	{
		DoListOp( true );
	};

	virtual void UnApply()
	{
		DoListOp( false );
	};

	VectorDelta(MikObject* target, vector<T>* prop, T item,
		int index, bool isinsert )
	{
		Init( target, prop );
		Item = item;
		Index = index;
		if ( Index < 0 )
			Index = (int)prop->size();
		Assert( Index <= (int)prop->size() );
		IsInsert = isinsert;
		if ( !IsInsert )
			Assert( (*prop)[Index] == item );
	};
};

template <typename T> class StdDelta : public MikDelta
{
public:
	T OldVal, NewVal;

	virtual void Apply() 
	{ 
		*((T*)PropPtr()) = NewVal; 
		OnChanged();
	};

	virtual void UnApply() 
	{ 
		*((T*)PropPtr()) = OldVal; 
		OnChanged();
	};

	virtual bool Replaces(MikDelta* other)
	{
		return SameTypeAndTarget( other );
	};

	StdDelta(MikObject* target, T* prop, T nv)
	{
		Init( target, prop );
		OldVal = *prop;
		NewVal = nv;
	};
};

class DeltaSet
{
public:
	vector<MikDelta*> Deltas;

	void UnApply()
	{
		int end = ((int)Deltas.size()) - 1;
		for (int i = end; i>=0; i--)
			Deltas[i]->UnApply();
		end = 0;
	}

	void Apply()
	{
		for (size_t i=0; i<Deltas.size(); i++)
			Deltas[i]->Apply();
	}

	void Add(MikDelta* md);

	int Count()
	{
		return (int)Deltas.size();
	};

	~DeltaSet();
};

class Keyframe : public MikObject
{
public:
	float TimeFrom;
	DeltaSet Delta;

	void Apply() { Delta.Apply(); };
	void UnApply() { Delta.UnApply(); }
	void Add(MikDelta* delta);

	Keyframe()
	{
		TimeFrom = 0.0f;
	};

	~Keyframe()
	{
		DeleteVectorEntries( &(Delta.Deltas) );
	};
};

class MikManager : public MikObject
{
private:
	DeltaSet* CurrentSet;
	Keyframe* CurrentKeyframe;
	vector<DeltaSet*> UndoStack;
	vector<DeltaSet*> RedoStack;
	float CurrentTime;
	vector<Keyframe*> Timeline;
	bool IsMetaDelta;
	bool IsRecording;
	float timeCache;

	Keyframe* ForceGetKeyframe();
	void InternalSetTime(float time);

public:

	//Use this to add a custom Delta (doesn't automatically Apply it)
	void RegisterDelta(MikDelta* delta);

	//These are interfaces to calling RegisterDelta
	template <typename T> void ChangeValue(MikObject* obj, T* prop, T nv)
	{
		MikDelta* delta = new StdDelta<T>( obj, prop, nv );
		RegisterDelta( delta );
		delta->Apply();
	};
	template <typename T> void ChangeList(MikObject* obj,
		vector<T>* prop, T item, int index, bool isinsert)
	{
		VectorDelta<T>* vd = new VectorDelta<T>( obj, prop,
			item, index, isinsert );
		RegisterDelta( vd );
		vd->Apply();
	};

	//Call this once per frame to break up Delta sets
	void GroupDeltas();

	//These are obvious:
	void Undo();
	void Redo();

	//Animation stuff:
	float GetTime() { return CurrentTime; };
	void SetTime(float t);
	void SetIsRecording(bool isrec) { IsRecording = isrec; };
	bool GetIsRecording() { return IsRecording; };
	void GetKeyframeTimes(vector<float>* ar);

	//Internal:
	virtual void OnPropertyChanged(void* prop);

	MikManager();
	~MikManager();
};

MikManager* Manager();
void FreeManager();

