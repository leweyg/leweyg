
#pragma once

#include "../stdafx.h"
#include <vector>

#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>



void _CalledAssert(const char* text, int line, const char* file);
typedef char byte;
#define ForceAssert(stmt,text)	{if(!(stmt)){_CalledAssert(text,__LINE__,__FILE__);}}
#define Assert(stmt)			ForceAssert(stmt,#stmt)
#define AssertInvalid()			ForceAssert(false,"Invalid operation");
#define TODO()					ForceAssert(false,"TODO" );

using namespace std;
