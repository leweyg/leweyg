// MIKE_Test.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "MIKE_Test.h"

#include "MIKE/MIKE.h"

#define MAX_LOADSTRING 100

// Global Variables:
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name

const int NumKnownColors = 8;
COLORREF KnownColors[NumKnownColors] = {
	0x00FF0000,
	0x00FF00FF,
	0x00FFff00,
	0x00FFffFF,
	0x00000000,
	0x000000FF,
	0x0000ff00,
	0x0000ffFF,
};

const char* KeyMessage = "Keys:\n"
	"U - Undo\n"
	"R - Redo\n"
	"C - change Color\n"
	"B - change Border color\n"
	"SPACE - toggle Recording\n";
;

COLORREF NextColor(COLORREF c)
{
	for (int i=0; i<NumKnownColors; i++)
	{
		if ( KnownColors[i] == c )
			return KnownColors[ (i+1)%NumKnownColors ];
	}
	return KnownColors[0];
}

//Lewey: App stuff

class Box : MikObject
{
public:
	int Width, Height;
	int Top, Left;
	COLORREF Color, BgColor;
	bool Dragging;
	POINT LastPoint;
	POINT Offset;

	Box()
	{
		Color = KnownColors[1];
		BgColor = KnownColors[5];
		Width = 90;
		Height = 40;
		Top = 5;
		Left = 10;
		Offset.x = 0;
		Offset.y = 0;
		Dragging = false;
	};

	virtual void KeyMsg(UINT msg, WPARAM vkey)
	{
		if ( msg == WM_KEYUP )
		{
			switch ( vkey )
			{
			case 'C':
				{
					Manager()->ChangeValue( this, &Color, 
						NextColor( Color ) );
				}
				break;
			case 'B':
				{
					Manager()->ChangeValue( this, &BgColor, 
						NextColor( BgColor ) );
				}
				break;
			};
		}
	};

	virtual void MouseMsg(UINT msg, POINT p)
	{
		switch ( msg )
		{
		case WM_MOUSEMOVE:
			if ( Dragging )
			{
				Offset.x += ( p.x - LastPoint.x );
				Offset.y += ( p.y - LastPoint.y );
			}
			break;
		case WM_LBUTTONDOWN:
			Dragging = true;
			break;
		case WM_LBUTTONUP:
			Dragging = false;

			Manager()->ChangeValue( this, &Left, (int)( Left + Offset.x ) );
			Manager()->ChangeValue( this, &Top, (int)( Top + Offset.y ) );
			Offset.x = 0;
			Offset.y = 0;
			break;
		};
		LastPoint = p;
	};

	bool Contains(POINT p)
	{
		RECT r = GetRect();
		if ( ( p.x < r.left ) || ( p.x > r.right ) )
			return false;
		if ( ( p.y < r.top ) || ( p.y > r.bottom ) )
			return false;
		return true;
	};

	RECT GetRect()
	{
		RECT r;
		r.top = Offset.y + Top;
		r.left = Offset.x + Left;
		r.bottom = Offset.y + Top + Height;
		r.right = Offset.x + Left + Width;
		return r;
	};

	virtual void Draw(HDC hdc)
	{
		HBRUSH brush = CreateSolidBrush( BgColor );
		RECT rect = GetRect();
		rect.right += 5;
		rect.bottom += 5;
		FillRect( hdc, &rect, brush );
		DeleteObject( brush );

		brush = CreateSolidBrush( Color );
		rect.right -= 5;
		rect.bottom -= 5;
		FillRect( hdc, &rect, brush );
		DeleteObject( brush );
	};
};

class Timebar : public Box
{
public: 
	float MinTime, MaxTime;
	float StartTime;

	float CurrentTime()
	{
		return Manager()->GetTime();
	};

	Timebar()
	{
		MinTime = 0.0f;
		MaxTime = 10.0f;
		Color = 0x00ffFFff;

		Width = 300;
		Top = 300;
	};

	void DraggedTo(POINT p)
	{
		float f = (float)( p.x - Left );
		f /= (float)Width;
		float ct = MinTime + f*( MaxTime - MinTime );

		Manager()->SetTime( ct );
	};

	virtual void MouseMsg(UINT msg, POINT p)
	{
		switch ( msg )
		{
		case WM_MOUSEMOVE:
			if ( Dragging )
			{
				Manager()->Undo();
				Assert( Manager()->GetTime() == StartTime );
				DraggedTo( p );
			}
			break;
		case WM_LBUTTONDOWN:
			Dragging = true;
			StartTime = Manager()->GetTime();
			DraggedTo( p );
			break;
		case WM_LBUTTONUP:
			Dragging = false;
			break;
		};
		LastPoint = p;
	};

	int TimeToX(float t)
	{
		float fx = ( ( t - MinTime ) / ( MaxTime - MinTime ) );
		return (int)( Left + ( Width * fx ) );
	};

	virtual void Draw(HDC hdc)
	{
		Box::Draw( hdc );
		int ix = TimeToX( CurrentTime() );
		MoveToEx( hdc, ix, Top, NULL );
		LineTo( hdc, ix, Top+Height );

		vector<float> keys;
		Manager()->GetKeyframeTimes( &keys );
		for (size_t i=0; i<keys.size(); i++)
		{
			ix = TimeToX( keys[i] );
			MoveToEx( hdc, ix, Top+Height/2, NULL );
			LineTo( hdc, ix, Top+Height );
		}
	};
};

class World : MikObject
{
public:
	vector<Box*> Boxes;
	Box* SelectedBox;

	~World()
	{
		DeleteVectorEntries( &Boxes );
	};

	void KeyMsg(UINT msg, WPARAM vkey)
	{
		if ( msg == WM_KEYUP )
		{
			bool found = true;
			switch ( vkey )
			{
			case 'U':
				Manager()->Undo();
				break;
			case 'R':
				Manager()->Redo();
				break;
			case ' ':
				Manager()->SetIsRecording( !Manager()->GetIsRecording() );
				break;
			default:
				found = false;
				break;
			}
			if ( found )
				return;
		}

		if ( SelectedBox != NULL )
			SelectedBox->KeyMsg( msg, vkey );
	}

	void MouseMsg(UINT msg, POINT p)
	{
		for (size_t i=0; i<Boxes.size(); i++)
		{
			Box* box = Boxes[i];
			if ( box->Contains( p ) )
			{
				box->MouseMsg( msg, p );
				SelectedBox = box;
				return;
			}
		}
	};

	void Draw(HDC hdc, RECT client)
	{
		HBRUSH brush;
		if ( Manager()->GetIsRecording() )
			brush = CreateSolidBrush( 0x00AAaaFF );
		else
			brush = CreateSolidBrush( 0x00aaAAaa );
		FillRect( hdc, &client, brush );
		DeleteObject( brush );

		for ( size_t i=0; i<Boxes.size(); i++ )
			Boxes[i]->Draw(hdc);

		Manager()->GroupDeltas();
	};

	World()
	{
		SelectedBox = new Box();
		Boxes.push_back( SelectedBox );
		Boxes.push_back( new Timebar() );
	};
};

World* GWorld;














// Forward declarations of functions included in this code module:
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

int APIENTRY _tWinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPTSTR    lpCmdLine,
                     int       nCmdShow)
{
 	// TODO: Place code here.
	MSG msg;
	HACCEL hAccelTable;

	char text[200];
	sprintf( text, "sizeof(StdDelta<int>)=%d\n", sizeof( StdDelta<int> ) );
	OutputDebugString( text );

	GWorld = new World();

	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Initialize global strings
	LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, IDC_MIKE_TEST, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// Perform application initialization:
	if (!InitInstance (hInstance, nCmdShow)) 
	{
		return FALSE;
	}

	hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_MIKE_TEST);

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
	}

	FreeManager();
	delete GWorld;

	return (int) msg.wParam;
}



//
//  FUNCTION: MyRegisterClass()
//
//  PURPOSE: Registers the window class.
//
//  COMMENTS:
//
//    This function and its usage are only necessary if you want this code
//    to be compatible with Win32 systems prior to the 'RegisterClassEx'
//    function that was added to Windows 95. It is important to call this function
//    so that the application will get 'well formed' small icons associated
//    with it.
//
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX); 

	wcex.style			= CS_HREDRAW | CS_VREDRAW;
	wcex.lpfnWndProc	= (WNDPROC)WndProc;
	wcex.cbClsExtra		= 0;
	wcex.cbWndExtra		= 0;
	wcex.hInstance		= hInstance;
	wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_MIKE_TEST);
	wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground	= (HBRUSH)(COLOR_WINDOW+1);
	wcex.lpszMenuName	= (LPCTSTR)IDC_MIKE_TEST;
	wcex.lpszClassName	= szWindowClass;
	wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

	return RegisterClassEx(&wcex);
}

//
//   FUNCTION: InitInstance(HANDLE, int)
//
//   PURPOSE: Saves instance handle and creates main window
//
//   COMMENTS:
//
//        In this function, we save the instance handle in a global variable and
//        create and display the main program window.
//
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   HWND hWnd;

   hInst = hInstance; // Store instance handle in our global variable

   hWnd = CreateWindow(szWindowClass, "MIKE Test Application", WS_OVERLAPPEDWINDOW,
      150, 150, 400, 400, NULL, NULL, hInstance, NULL);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   return TRUE;
}

//
//  FUNCTION: WndProc(HWND, unsigned, WORD, LONG)
//
//  PURPOSE:  Processes messages for the main window.
//
//  WM_COMMAND	- process the application menu
//  WM_PAINT	- Paint the main window
//  WM_DESTROY	- post a quit message and return
//
//
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	PAINTSTRUCT ps;
	HDC hdc;

	switch (message) 
	{
	case WM_COMMAND:
		wmId    = LOWORD(wParam); 
		wmEvent = HIWORD(wParam); 
		// Parse the menu selections:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
			break;
		case ID_FILE_KEYS:
			MessageBox( hWnd, KeyMessage, "Keys", MB_OK );
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	case WM_KEYDOWN:
	case WM_KEYUP:
		{
			GWorld->KeyMsg( message, wParam );
			InvalidateRect( hWnd, NULL, FALSE );
		}
		break;
	case WM_MOUSEMOVE:
	case WM_LBUTTONUP:
	case WM_LBUTTONDOWN:
		{
			POINT p;
			p.x = LOWORD( lParam );
			p.y = HIWORD( lParam );
			GWorld->MouseMsg( message, p );
			InvalidateRect( hWnd, NULL, FALSE );
		}
		break;
	case WM_PAINT:
		{
			hdc = BeginPaint(hWnd, &ps);
			// TODO: Add any drawing code here...
			RECT client;
			GetClientRect( hWnd, &client );
			GWorld->Draw( hdc, client );
			EndPaint(hWnd, &ps);
		}
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

// Message handler for about box.
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		return TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		{
			EndDialog(hDlg, LOWORD(wParam));
			return TRUE;
		}
		break;
	}
	return FALSE;
}
