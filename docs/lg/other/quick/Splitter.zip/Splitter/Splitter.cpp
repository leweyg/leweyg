// Splitter.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

int _tmain(int argc, _TCHAR* argv[])
{
	if ( argc < 2 )
	{
		printf( "No argument given\n" );
		return 0;
	}

	const char* filename = argv[1];

	FILE* infile = fopen( filename, "r" );

	const int bsize = 50000;
	char buffer[ bsize ];

	bool again = true;
	int count = 0;
	while ( again )
	{
		int red = (int)fread( buffer, 1, bsize, infile );
		if ( red != bsize )
			again = false;
		if ( red != 0 )
		{
			char out_filename[200];
			sprintf( out_filename, "part%d.txt", count++ );
			FILE* ofile = fopen( out_filename, "w" );
			fwrite( buffer, 1, red, ofile );
			fclose( ofile );
		}
	}

	fclose( infile );

	return 0;
}

