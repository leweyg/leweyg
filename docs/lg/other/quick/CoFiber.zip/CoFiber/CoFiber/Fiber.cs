using System;
using System.Collections.Generic;
using System.Text;

namespace CoFiber
{
    public enum Yield
    {
        /// <summary>
        /// Sleep until the next frame
        /// </summary>
        SleepFrame,

        /// <summary>
        /// End execution of this Fiber
        /// </summary>
        Exit,
    }

    public class Fiber
    {
        private IEnumerator<Yield> Enum;
        public bool IsAlive = true;
        public Fiber Parent;
        public IsReadyMethod IsReady = null;

        public delegate bool IsReadyMethod();

        public Fiber(IEnumerator<Yield> e)
        {
            Enum = e;
        }

        public Yield INTERNAL_Tick()
        {
            IsAlive = Enum.MoveNext();
            if (IsAlive)
            {
                Yield y = Enum.Current;
                if (y == Yield.Exit)
                    IsAlive = false;
                return y;
            }
            else
                return Yield.Exit;
        }
    }

    public interface ITimeProvider
    {
        float Now { get; }
        float Delta { get; }
    }

    public class FiberSet
    {
        private List<Fiber> Fibers = new List<Fiber>();
        private Fiber CurrentFiber;
        public ITimeProvider Time;
        public int FrameHash = 0;

        public delegate IEnumerator<Yield> StartMethod(FiberSet fs);
        public delegate void UseFloatMethod(float f);

        public class FrameTimer : ITimeProvider
        {
            public FiberSet Fibers;

            public FrameTimer(FiberSet fs)
            {
                Fibers = fs;
            }

            public float Now
            {
                get 
                { 
                    float t = (float)Fibers.FrameHash; 
                    return t * Delta; 
                }
            }

            public float Delta
            {
                get { return 0.25f; }
            }
        }

        public Fiber Current
        {
            get { return CurrentFiber; }
        }

        public Fiber Add(StartMethod sm)
        {
            IEnumerator<Yield> ie = sm(this);
            return Add(ie);
        }

        public Fiber Add(IEnumerator<Yield> ie)
        {
            Fiber f = new Fiber(ie);
            f.Parent = CurrentFiber;
            Fibers.Add(f);

            Fiber prev = CurrentFiber;
            LowTick(f);
            CurrentFiber = prev;

            return f;
        }

        /// <summary>
        /// Blocks the current Fiber until the given method is complete
        /// </summary>
        /// <param name="func">New Fiber to create</param>
        /// <returns></returns>
        public Yield Call(IEnumerator<Yield> func)
        {
            Fiber f = Add(func);
            Code.Assert( CurrentFiber.IsReady == null );
            CurrentFiber.IsReady = delegate()
            {
                return !f.IsAlive;
            };
            return Yield.SleepFrame;
        }

        public Yield SleepFrame()
        {
            return Yield.SleepFrame;
        }

        public Yield WaitUntil(Fiber.IsReadyMethod test)
        {
            Code.Assert(CurrentFiber.IsReady == null);
            CurrentFiber.IsReady = test;
            return Yield.SleepFrame;
        }

        public Yield SleepFor(float seconds)
        {
            float end = Time.Now + seconds;
            Code.Assert(CurrentFiber.IsReady == null);
            CurrentFiber.IsReady = delegate()
            {
                return (Time.Now >= end);
            };
            return Yield.SleepFrame;
        }

        public Yield SmoothInto(float from, float to, float dur, UseFloatMethod meth)
        {
            float start = Time.Now;
            float end = Time.Now + dur;
            Code.Assert(CurrentFiber.IsReady == null);
            meth(from);
            CurrentFiber.IsReady = delegate()
            {
                if (Time.Now >= end)
                {
                    meth(to);
                    return true;
                }
                float t = (Time.Now - start) / (end - start);
                t = (to * t) + (from * (1.0f - t));
                meth(t);
                return false;
            };
            return Yield.SleepFrame;
        }

        public IEnumerable<float> Smooth(float from, float to, float duration)
        {
            if (duration < 0)
            {
                yield return to;
                yield break;
            }

            int frame = FrameHash;
            float start = Time.Now;
            float end = Time.Now + duration;

            yield return from;

            while (Time.Now < end)
            {
                float t = ((Time.Now - start) / (end - start));
                t = (to * t) + (from * (1.0f - t));
                yield return t;

                if (frame == FrameHash)
                {
                    throw new InvalidOperationException("Smooth must be yielded between frames");
                }
                frame = FrameHash;
            }

            yield return to;
        }

        private void LowTick(Fiber f)
        {
            CurrentFiber = f;
            if (f.IsReady != null)
            {
                if (!f.IsReady())
                    return;
                f.IsReady = null;
            }
            f.INTERNAL_Tick();
        }

        public bool Tick()
        {
            Code.Echo("Ticking[" + Fibers.Count + "@"+FrameHash+"]...");
            FrameHash = ((FrameHash + 1) % 10000);
            bool anydead = false;
            for (int fi=0; fi<Fibers.Count; fi++)
            {
                Fiber f = Fibers[fi];
                LowTick(f);
                anydead = (anydead || !f.IsAlive);
            }
            CurrentFiber = null;
            if (!anydead)
                return (Fibers.Count!=0);
            for (int i = 0; i < Fibers.Count;)
            {
                if (Fibers[i].IsAlive)
                    i++;
                else
                    Fibers.RemoveAt(i);
            }
            return Fibers.Count != 0;
        }
    }
}
