using System;
using System.Collections.Generic;
using System.Text;

namespace CoFiber
{
    public abstract class Code
    {
        public static void Assert(bool test)
        {
            if (test)
                return;
            throw new ArgumentException("Assert Failed");
        }

        public static void TODO()
        {
            throw new NotImplementedException("TODO");
        }

        public static void Echo(object first, params object[] args)
        {
            string s = first.ToString();
            foreach (object ob in args)
            {
                s += " '" + ob.ToString() + "'";
            }
            System.Console.WriteLine(s);
        }
    }

    class Program
    {
        public IEnumerable<string> Names()
        {
            yield return "One";
            yield return "Two";
            yield return "Three";
        }

        public IEnumerator<Yield> SlowExec(FiberSet fs, int times)
        {
            //Step by step:
            for (int i = 0; i < times; i++)
            {
                Code.Echo("Woot=" + i);
                yield return fs.SleepFrame();
            }

            //Smooth a value between 0.5f and 1.0f over 2.0f seconds
            foreach (float s in fs.Smooth(0.5f, 1.0f, 2.0f))
            {
                Code.Echo("s = " + s);
                yield return fs.SleepFrame();
            }

            //Same as the above but only 1 1/2 lines:
            yield return fs.SmoothInto(0.5f, 1.0f, 2.0f, delegate(float t) { 
                Code.Echo("t=" + t); });

            //Done
            Code.Echo("Woot=Done");
        }

        static void Main(string[] args)
        {
            Code.Echo("Hello World");
            Program p = new Program();
            FiberSet fs = new FiberSet();
            fs.Time = new FiberSet.FrameTimer(fs);
            fs.Add(p.SlowExec(fs, 3));
            while (fs.Tick()) { }
            Code.Echo("Done");
        }
    }
}
